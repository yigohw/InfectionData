from bayesian.factor_graph import *
from bayesian.bbn import *

dictionary_person_0_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_0_7_0(person_0_7_0):
    return dictionary_person_0_7_0[person_0_7_0]

dictionary_person_1_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_1_7_0(person_1_7_0):
    return dictionary_person_1_7_0[person_1_7_0]

dictionary_person_2_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_2_7_0(person_2_7_0):
    return dictionary_person_2_7_0[person_2_7_0]

dictionary_person_3_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_3_7_0(person_3_7_0):
    return dictionary_person_3_7_0[person_3_7_0]

dictionary_person_4_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_4_7_0(person_4_7_0):
    return dictionary_person_4_7_0[person_4_7_0]

dictionary_person_5_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_5_7_0(person_5_7_0):
    return dictionary_person_5_7_0[person_5_7_0]

dictionary_person_6_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_6_7_0(person_6_7_0):
    return dictionary_person_6_7_0[person_6_7_0]

dictionary_person_7_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_7_7_0(person_7_7_0):
    return dictionary_person_7_7_0[person_7_7_0]

dictionary_person_8_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_8_7_0(person_8_7_0):
    return dictionary_person_8_7_0[person_8_7_0]

dictionary_person_9_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_9_7_0(person_9_7_0):
    return dictionary_person_9_7_0[person_9_7_0]

dictionary_person_10_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_10_7_0(person_10_7_0):
    return dictionary_person_10_7_0[person_10_7_0]

dictionary_person_11_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_11_7_0(person_11_7_0):
    return dictionary_person_11_7_0[person_11_7_0]

dictionary_person_12_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_12_7_0(person_12_7_0):
    return dictionary_person_12_7_0[person_12_7_0]

dictionary_person_13_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_13_7_0(person_13_7_0):
    return dictionary_person_13_7_0[person_13_7_0]

dictionary_person_14_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_14_7_0(person_14_7_0):
    return dictionary_person_14_7_0[person_14_7_0]

dictionary_person_15_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_15_7_0(person_15_7_0):
    return dictionary_person_15_7_0[person_15_7_0]

dictionary_person_16_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_16_7_0(person_16_7_0):
    return dictionary_person_16_7_0[person_16_7_0]

dictionary_person_17_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_17_7_0(person_17_7_0):
    return dictionary_person_17_7_0[person_17_7_0]

dictionary_person_18_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_18_7_0(person_18_7_0):
    return dictionary_person_18_7_0[person_18_7_0]

dictionary_person_19_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_19_7_0(person_19_7_0):
    return dictionary_person_19_7_0[person_19_7_0]

dictionary_person_20_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_20_7_0(person_20_7_0):
    return dictionary_person_20_7_0[person_20_7_0]

dictionary_person_21_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_21_7_0(person_21_7_0):
    return dictionary_person_21_7_0[person_21_7_0]

dictionary_person_22_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_22_7_0(person_22_7_0):
    return dictionary_person_22_7_0[person_22_7_0]

dictionary_person_23_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_23_7_0(person_23_7_0):
    return dictionary_person_23_7_0[person_23_7_0]

dictionary_person_24_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_24_7_0(person_24_7_0):
    return dictionary_person_24_7_0[person_24_7_0]

dictionary_person_25_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_25_7_0(person_25_7_0):
    return dictionary_person_25_7_0[person_25_7_0]

dictionary_person_26_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_26_7_0(person_26_7_0):
    return dictionary_person_26_7_0[person_26_7_0]

dictionary_person_27_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_27_7_0(person_27_7_0):
    return dictionary_person_27_7_0[person_27_7_0]

dictionary_person_28_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_28_7_0(person_28_7_0):
    return dictionary_person_28_7_0[person_28_7_0]

dictionary_person_29_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_29_7_0(person_29_7_0):
    return dictionary_person_29_7_0[person_29_7_0]

dictionary_person_30_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_30_7_0(person_30_7_0):
    return dictionary_person_30_7_0[person_30_7_0]

dictionary_person_31_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_31_7_0(person_31_7_0):
    return dictionary_person_31_7_0[person_31_7_0]

dictionary_person_32_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_32_7_0(person_32_7_0):
    return dictionary_person_32_7_0[person_32_7_0]

dictionary_person_33_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_33_7_0(person_33_7_0):
    return dictionary_person_33_7_0[person_33_7_0]

dictionary_person_34_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_34_7_0(person_34_7_0):
    return dictionary_person_34_7_0[person_34_7_0]

dictionary_person_35_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_35_7_0(person_35_7_0):
    return dictionary_person_35_7_0[person_35_7_0]

dictionary_risk_0_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_8_0(risk_0_8_0):
    return dictionary_risk_0_8_0[risk_0_8_0]

dictionary_risk_1_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_8_0(risk_1_8_0):
    return dictionary_risk_1_8_0[risk_1_8_0]

dictionary_risk_2_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_8_0(risk_2_8_0):
    return dictionary_risk_2_8_0[risk_2_8_0]

dictionary_risk_3_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_8_0(risk_3_8_0):
    return dictionary_risk_3_8_0[risk_3_8_0]

dictionary_risk_4_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_8_0(risk_4_8_0):
    return dictionary_risk_4_8_0[risk_4_8_0]

dictionary_risk_5_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_8_0(risk_5_8_0):
    return dictionary_risk_5_8_0[risk_5_8_0]

dictionary_risk_6_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_8_0(risk_6_8_0):
    return dictionary_risk_6_8_0[risk_6_8_0]

dictionary_risk_7_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_8_0(risk_7_8_0):
    return dictionary_risk_7_8_0[risk_7_8_0]

dictionary_risk_8_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_8_0(risk_8_8_0):
    return dictionary_risk_8_8_0[risk_8_8_0]

dictionary_risk_9_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_8_0(risk_9_8_0):
    return dictionary_risk_9_8_0[risk_9_8_0]

dictionary_risk_10_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_8_0(risk_10_8_0):
    return dictionary_risk_10_8_0[risk_10_8_0]

dictionary_risk_11_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_8_0(risk_11_8_0):
    return dictionary_risk_11_8_0[risk_11_8_0]

dictionary_risk_12_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_8_0(risk_12_8_0):
    return dictionary_risk_12_8_0[risk_12_8_0]

dictionary_risk_13_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_8_0(risk_13_8_0):
    return dictionary_risk_13_8_0[risk_13_8_0]

dictionary_risk_14_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_8_0(risk_14_8_0):
    return dictionary_risk_14_8_0[risk_14_8_0]

dictionary_risk_15_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_8_0(risk_15_8_0):
    return dictionary_risk_15_8_0[risk_15_8_0]

dictionary_risk_16_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_8_0(risk_16_8_0):
    return dictionary_risk_16_8_0[risk_16_8_0]

dictionary_risk_17_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_8_0(risk_17_8_0):
    return dictionary_risk_17_8_0[risk_17_8_0]

dictionary_risk_18_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_8_0(risk_18_8_0):
    return dictionary_risk_18_8_0[risk_18_8_0]

dictionary_risk_19_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_8_0(risk_19_8_0):
    return dictionary_risk_19_8_0[risk_19_8_0]

dictionary_risk_20_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_8_0(risk_20_8_0):
    return dictionary_risk_20_8_0[risk_20_8_0]

dictionary_risk_20_8_1 = {'true': 1.0, 'false': 0.0}

def f_risk_20_8_1(risk_20_8_1):
    return dictionary_risk_20_8_1[risk_20_8_1]

dictionary_risk_21_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_8_0(risk_21_8_0):
    return dictionary_risk_21_8_0[risk_21_8_0]

dictionary_risk_22_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_8_0(risk_22_8_0):
    return dictionary_risk_22_8_0[risk_22_8_0]

dictionary_risk_23_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_8_0(risk_23_8_0):
    return dictionary_risk_23_8_0[risk_23_8_0]

dictionary_risk_24_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_8_0(risk_24_8_0):
    return dictionary_risk_24_8_0[risk_24_8_0]

dictionary_risk_25_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_8_0(risk_25_8_0):
    return dictionary_risk_25_8_0[risk_25_8_0]

dictionary_risk_26_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_8_0(risk_26_8_0):
    return dictionary_risk_26_8_0[risk_26_8_0]

dictionary_risk_27_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_8_0(risk_27_8_0):
    return dictionary_risk_27_8_0[risk_27_8_0]

dictionary_risk_28_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_8_0(risk_28_8_0):
    return dictionary_risk_28_8_0[risk_28_8_0]

dictionary_risk_29_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_8_0(risk_29_8_0):
    return dictionary_risk_29_8_0[risk_29_8_0]

dictionary_risk_30_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_8_0(risk_30_8_0):
    return dictionary_risk_30_8_0[risk_30_8_0]

dictionary_risk_31_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_8_0(risk_31_8_0):
    return dictionary_risk_31_8_0[risk_31_8_0]

dictionary_risk_32_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_8_0(risk_32_8_0):
    return dictionary_risk_32_8_0[risk_32_8_0]

dictionary_risk_33_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_8_0(risk_33_8_0):
    return dictionary_risk_33_8_0[risk_33_8_0]

dictionary_risk_34_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_8_0(risk_34_8_0):
    return dictionary_risk_34_8_0[risk_34_8_0]

dictionary_risk_35_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_8_0(risk_35_8_0):
    return dictionary_risk_35_8_0[risk_35_8_0]

dictionary_risk_0_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_9_0(risk_0_9_0):
    return dictionary_risk_0_9_0[risk_0_9_0]

dictionary_risk_1_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_9_0(risk_1_9_0):
    return dictionary_risk_1_9_0[risk_1_9_0]

dictionary_risk_2_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_9_0(risk_2_9_0):
    return dictionary_risk_2_9_0[risk_2_9_0]

dictionary_risk_3_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_9_0(risk_3_9_0):
    return dictionary_risk_3_9_0[risk_3_9_0]

dictionary_risk_4_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_9_0(risk_4_9_0):
    return dictionary_risk_4_9_0[risk_4_9_0]

dictionary_risk_5_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_9_0(risk_5_9_0):
    return dictionary_risk_5_9_0[risk_5_9_0]

dictionary_risk_6_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_9_0(risk_6_9_0):
    return dictionary_risk_6_9_0[risk_6_9_0]

dictionary_risk_7_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_9_0(risk_7_9_0):
    return dictionary_risk_7_9_0[risk_7_9_0]

dictionary_risk_8_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_9_0(risk_8_9_0):
    return dictionary_risk_8_9_0[risk_8_9_0]

dictionary_risk_9_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_9_0(risk_9_9_0):
    return dictionary_risk_9_9_0[risk_9_9_0]

dictionary_risk_10_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_9_0(risk_10_9_0):
    return dictionary_risk_10_9_0[risk_10_9_0]

dictionary_risk_11_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_9_0(risk_11_9_0):
    return dictionary_risk_11_9_0[risk_11_9_0]

dictionary_risk_12_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_9_0(risk_12_9_0):
    return dictionary_risk_12_9_0[risk_12_9_0]

dictionary_risk_13_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_9_0(risk_13_9_0):
    return dictionary_risk_13_9_0[risk_13_9_0]

dictionary_risk_14_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_9_0(risk_14_9_0):
    return dictionary_risk_14_9_0[risk_14_9_0]

dictionary_risk_15_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_9_0(risk_15_9_0):
    return dictionary_risk_15_9_0[risk_15_9_0]

dictionary_risk_16_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_9_0(risk_16_9_0):
    return dictionary_risk_16_9_0[risk_16_9_0]

dictionary_risk_17_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_9_0(risk_17_9_0):
    return dictionary_risk_17_9_0[risk_17_9_0]

dictionary_risk_18_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_9_0(risk_18_9_0):
    return dictionary_risk_18_9_0[risk_18_9_0]

dictionary_risk_19_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_9_0(risk_19_9_0):
    return dictionary_risk_19_9_0[risk_19_9_0]

dictionary_risk_20_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_9_0(risk_20_9_0):
    return dictionary_risk_20_9_0[risk_20_9_0]

dictionary_risk_21_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_9_0(risk_21_9_0):
    return dictionary_risk_21_9_0[risk_21_9_0]

dictionary_risk_22_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_9_0(risk_22_9_0):
    return dictionary_risk_22_9_0[risk_22_9_0]

dictionary_risk_23_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_9_0(risk_23_9_0):
    return dictionary_risk_23_9_0[risk_23_9_0]

dictionary_risk_24_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_9_0(risk_24_9_0):
    return dictionary_risk_24_9_0[risk_24_9_0]

dictionary_risk_25_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_9_0(risk_25_9_0):
    return dictionary_risk_25_9_0[risk_25_9_0]

dictionary_risk_26_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_9_0(risk_26_9_0):
    return dictionary_risk_26_9_0[risk_26_9_0]

dictionary_risk_27_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_9_0(risk_27_9_0):
    return dictionary_risk_27_9_0[risk_27_9_0]

dictionary_risk_28_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_9_0(risk_28_9_0):
    return dictionary_risk_28_9_0[risk_28_9_0]

dictionary_risk_29_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_9_0(risk_29_9_0):
    return dictionary_risk_29_9_0[risk_29_9_0]

dictionary_risk_30_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_9_0(risk_30_9_0):
    return dictionary_risk_30_9_0[risk_30_9_0]

dictionary_risk_31_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_9_0(risk_31_9_0):
    return dictionary_risk_31_9_0[risk_31_9_0]

dictionary_risk_32_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_9_0(risk_32_9_0):
    return dictionary_risk_32_9_0[risk_32_9_0]

dictionary_risk_33_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_9_0(risk_33_9_0):
    return dictionary_risk_33_9_0[risk_33_9_0]

dictionary_risk_34_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_9_0(risk_34_9_0):
    return dictionary_risk_34_9_0[risk_34_9_0]

dictionary_risk_35_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_9_0(risk_35_9_0):
    return dictionary_risk_35_9_0[risk_35_9_0]

dictionary_risk_0_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_10_0(risk_0_10_0):
    return dictionary_risk_0_10_0[risk_0_10_0]

dictionary_risk_1_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_10_0(risk_1_10_0):
    return dictionary_risk_1_10_0[risk_1_10_0]

dictionary_risk_2_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_10_0(risk_2_10_0):
    return dictionary_risk_2_10_0[risk_2_10_0]

dictionary_risk_3_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_10_0(risk_3_10_0):
    return dictionary_risk_3_10_0[risk_3_10_0]

dictionary_risk_4_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_10_0(risk_4_10_0):
    return dictionary_risk_4_10_0[risk_4_10_0]

dictionary_risk_5_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_10_0(risk_5_10_0):
    return dictionary_risk_5_10_0[risk_5_10_0]

dictionary_risk_6_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_10_0(risk_6_10_0):
    return dictionary_risk_6_10_0[risk_6_10_0]

dictionary_risk_7_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_10_0(risk_7_10_0):
    return dictionary_risk_7_10_0[risk_7_10_0]

dictionary_risk_8_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_10_0(risk_8_10_0):
    return dictionary_risk_8_10_0[risk_8_10_0]

dictionary_risk_9_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_10_0(risk_9_10_0):
    return dictionary_risk_9_10_0[risk_9_10_0]

dictionary_risk_10_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_10_0(risk_10_10_0):
    return dictionary_risk_10_10_0[risk_10_10_0]

dictionary_risk_11_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_10_0(risk_11_10_0):
    return dictionary_risk_11_10_0[risk_11_10_0]

dictionary_risk_12_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_10_0(risk_12_10_0):
    return dictionary_risk_12_10_0[risk_12_10_0]

dictionary_risk_13_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_10_0(risk_13_10_0):
    return dictionary_risk_13_10_0[risk_13_10_0]

dictionary_risk_14_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_10_0(risk_14_10_0):
    return dictionary_risk_14_10_0[risk_14_10_0]

dictionary_risk_15_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_10_0(risk_15_10_0):
    return dictionary_risk_15_10_0[risk_15_10_0]

dictionary_risk_16_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_10_0(risk_16_10_0):
    return dictionary_risk_16_10_0[risk_16_10_0]

dictionary_risk_17_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_10_0(risk_17_10_0):
    return dictionary_risk_17_10_0[risk_17_10_0]

dictionary_risk_18_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_10_0(risk_18_10_0):
    return dictionary_risk_18_10_0[risk_18_10_0]

dictionary_risk_19_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_10_0(risk_19_10_0):
    return dictionary_risk_19_10_0[risk_19_10_0]

dictionary_risk_20_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_10_0(risk_20_10_0):
    return dictionary_risk_20_10_0[risk_20_10_0]

dictionary_risk_21_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_10_0(risk_21_10_0):
    return dictionary_risk_21_10_0[risk_21_10_0]

dictionary_risk_22_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_10_0(risk_22_10_0):
    return dictionary_risk_22_10_0[risk_22_10_0]

dictionary_risk_23_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_10_0(risk_23_10_0):
    return dictionary_risk_23_10_0[risk_23_10_0]

dictionary_risk_24_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_10_0(risk_24_10_0):
    return dictionary_risk_24_10_0[risk_24_10_0]

dictionary_risk_25_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_10_0(risk_25_10_0):
    return dictionary_risk_25_10_0[risk_25_10_0]

dictionary_risk_26_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_10_0(risk_26_10_0):
    return dictionary_risk_26_10_0[risk_26_10_0]

dictionary_risk_27_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_10_0(risk_27_10_0):
    return dictionary_risk_27_10_0[risk_27_10_0]

dictionary_risk_28_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_10_0(risk_28_10_0):
    return dictionary_risk_28_10_0[risk_28_10_0]

dictionary_risk_29_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_10_0(risk_29_10_0):
    return dictionary_risk_29_10_0[risk_29_10_0]

dictionary_risk_30_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_10_0(risk_30_10_0):
    return dictionary_risk_30_10_0[risk_30_10_0]

dictionary_risk_31_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_10_0(risk_31_10_0):
    return dictionary_risk_31_10_0[risk_31_10_0]

dictionary_risk_32_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_10_0(risk_32_10_0):
    return dictionary_risk_32_10_0[risk_32_10_0]

dictionary_risk_33_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_10_0(risk_33_10_0):
    return dictionary_risk_33_10_0[risk_33_10_0]

dictionary_risk_34_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_10_0(risk_34_10_0):
    return dictionary_risk_34_10_0[risk_34_10_0]

dictionary_risk_35_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_10_0(risk_35_10_0):
    return dictionary_risk_35_10_0[risk_35_10_0]

dictionary_observe_0_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6030115025419784, ('false', 'false'): 1.0, ('true', 'true'): 0.39698849745802156}
def f_observe_0_7_0(person_0_7_0, observe_0_7_0):
    return dictionary_observe_0_7_0[(person_0_7_0, observe_0_7_0)]

dictionary_observe_1_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.745586926987434, ('false', 'false'): 1.0, ('true', 'true'): 0.254413073012566}
def f_observe_1_7_0(person_1_7_0, observe_1_7_0):
    return dictionary_observe_1_7_0[(person_1_7_0, observe_1_7_0)]

dictionary_observe_2_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.759268013703126, ('false', 'false'): 1.0, ('true', 'true'): 0.24073198629687398}
def f_observe_2_7_0(person_2_7_0, observe_2_7_0):
    return dictionary_observe_2_7_0[(person_2_7_0, observe_2_7_0)]

dictionary_observe_3_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5542878056988532, ('false', 'false'): 1.0, ('true', 'true'): 0.44571219430114684}
def f_observe_3_7_0(person_3_7_0, observe_3_7_0):
    return dictionary_observe_3_7_0[(person_3_7_0, observe_3_7_0)]

dictionary_observe_4_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7108535358735568, ('false', 'false'): 1.0, ('true', 'true'): 0.2891464641264432}
def f_observe_4_7_0(person_4_7_0, observe_4_7_0):
    return dictionary_observe_4_7_0[(person_4_7_0, observe_4_7_0)]

dictionary_observe_5_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4882011375603327, ('false', 'false'): 1.0, ('true', 'true'): 0.5117988624396673}
def f_observe_5_7_0(person_5_7_0, observe_5_7_0):
    return dictionary_observe_5_7_0[(person_5_7_0, observe_5_7_0)]

dictionary_observe_6_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5893799522264676, ('false', 'false'): 1.0, ('true', 'true'): 0.41062004777353245}
def f_observe_6_7_0(person_6_7_0, observe_6_7_0):
    return dictionary_observe_6_7_0[(person_6_7_0, observe_6_7_0)]

dictionary_observe_7_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5966297991550333, ('false', 'false'): 1.0, ('true', 'true'): 0.40337020084496666}
def f_observe_7_7_0(person_7_7_0, observe_7_7_0):
    return dictionary_observe_7_7_0[(person_7_7_0, observe_7_7_0)]

dictionary_observe_8_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.41311079154875086, ('false', 'false'): 1.0, ('true', 'true'): 0.5868892084512491}
def f_observe_8_7_0(person_8_7_0, observe_8_7_0):
    return dictionary_observe_8_7_0[(person_8_7_0, observe_8_7_0)]

dictionary_observe_9_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5863949671890444, ('false', 'false'): 1.0, ('true', 'true'): 0.4136050328109556}
def f_observe_9_7_0(person_9_7_0, observe_9_7_0):
    return dictionary_observe_9_7_0[(person_9_7_0, observe_9_7_0)]

dictionary_observe_10_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8475269660768192, ('false', 'false'): 1.0, ('true', 'true'): 0.1524730339231808}
def f_observe_10_7_0(person_10_7_0, observe_10_7_0):
    return dictionary_observe_10_7_0[(person_10_7_0, observe_10_7_0)]

dictionary_observe_11_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9766096784380282, ('false', 'false'): 1.0, ('true', 'true'): 0.02339032156197185}
def f_observe_11_7_0(person_11_7_0, observe_11_7_0):
    return dictionary_observe_11_7_0[(person_11_7_0, observe_11_7_0)]

dictionary_observe_12_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6017690295605871, ('false', 'false'): 1.0, ('true', 'true'): 0.3982309704394129}
def f_observe_12_7_0(person_12_7_0, observe_12_7_0):
    return dictionary_observe_12_7_0[(person_12_7_0, observe_12_7_0)]

dictionary_observe_13_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5530006588616918, ('false', 'false'): 1.0, ('true', 'true'): 0.4469993411383082}
def f_observe_13_7_0(person_13_7_0, observe_13_7_0):
    return dictionary_observe_13_7_0[(person_13_7_0, observe_13_7_0)]

dictionary_observe_14_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9257995813986699, ('false', 'false'): 1.0, ('true', 'true'): 0.07420041860133009}
def f_observe_14_7_0(person_14_7_0, observe_14_7_0):
    return dictionary_observe_14_7_0[(person_14_7_0, observe_14_7_0)]

dictionary_observe_15_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6616223304786768, ('false', 'false'): 1.0, ('true', 'true'): 0.3383776695213232}
def f_observe_15_7_0(person_15_7_0, observe_15_7_0):
    return dictionary_observe_15_7_0[(person_15_7_0, observe_15_7_0)]

dictionary_observe_16_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8231297042032375, ('false', 'false'): 1.0, ('true', 'true'): 0.1768702957967625}
def f_observe_16_7_0(person_16_7_0, observe_16_7_0):
    return dictionary_observe_16_7_0[(person_16_7_0, observe_16_7_0)]

dictionary_observe_17_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6318065134389809, ('false', 'false'): 1.0, ('true', 'true'): 0.36819348656101913}
def f_observe_17_7_0(person_17_7_0, observe_17_7_0):
    return dictionary_observe_17_7_0[(person_17_7_0, observe_17_7_0)]

dictionary_observe_18_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9439530651079304, ('false', 'false'): 1.0, ('true', 'true'): 0.05604693489206958}
def f_observe_18_7_0(person_18_7_0, observe_18_7_0):
    return dictionary_observe_18_7_0[(person_18_7_0, observe_18_7_0)]

dictionary_observe_19_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5681918972893909, ('false', 'false'): 1.0, ('true', 'true'): 0.4318081027106091}
def f_observe_19_7_0(person_19_7_0, observe_19_7_0):
    return dictionary_observe_19_7_0[(person_19_7_0, observe_19_7_0)]

dictionary_observe_20_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6735314564185677, ('false', 'false'): 1.0, ('true', 'true'): 0.3264685435814323}
def f_observe_20_7_0(person_20_7_0, observe_20_7_0):
    return dictionary_observe_20_7_0[(person_20_7_0, observe_20_7_0)]

dictionary_observe_21_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9016767139324234, ('false', 'false'): 1.0, ('true', 'true'): 0.09832328606757657}
def f_observe_21_7_0(person_21_7_0, observe_21_7_0):
    return dictionary_observe_21_7_0[(person_21_7_0, observe_21_7_0)]

dictionary_observe_22_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6806756696706082, ('false', 'false'): 1.0, ('true', 'true'): 0.3193243303293918}
def f_observe_22_7_0(person_22_7_0, observe_22_7_0):
    return dictionary_observe_22_7_0[(person_22_7_0, observe_22_7_0)]

dictionary_observe_23_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8391385298120589, ('false', 'false'): 1.0, ('true', 'true'): 0.16086147018794106}
def f_observe_23_7_0(person_23_7_0, observe_23_7_0):
    return dictionary_observe_23_7_0[(person_23_7_0, observe_23_7_0)]

dictionary_observe_24_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5411651970611463, ('false', 'false'): 1.0, ('true', 'true'): 0.4588348029388537}
def f_observe_24_7_0(person_24_7_0, observe_24_7_0):
    return dictionary_observe_24_7_0[(person_24_7_0, observe_24_7_0)]

dictionary_observe_25_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4017649698063761, ('false', 'false'): 1.0, ('true', 'true'): 0.5982350301936239}
def f_observe_25_7_0(person_25_7_0, observe_25_7_0):
    return dictionary_observe_25_7_0[(person_25_7_0, observe_25_7_0)]

dictionary_observe_26_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4009507571374158, ('false', 'false'): 1.0, ('true', 'true'): 0.5990492428625842}
def f_observe_26_7_0(person_26_7_0, observe_26_7_0):
    return dictionary_observe_26_7_0[(person_26_7_0, observe_26_7_0)]

dictionary_observe_27_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6918388567365816, ('false', 'false'): 1.0, ('true', 'true'): 0.30816114326341837}
def f_observe_27_7_0(person_27_7_0, observe_27_7_0):
    return dictionary_observe_27_7_0[(person_27_7_0, observe_27_7_0)]

dictionary_observe_28_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7939831700020247, ('false', 'false'): 1.0, ('true', 'true'): 0.20601682999797533}
def f_observe_28_7_0(person_28_7_0, observe_28_7_0):
    return dictionary_observe_28_7_0[(person_28_7_0, observe_28_7_0)]

dictionary_observe_29_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7778218963672767, ('false', 'false'): 1.0, ('true', 'true'): 0.22217810363272328}
def f_observe_29_7_0(person_29_7_0, observe_29_7_0):
    return dictionary_observe_29_7_0[(person_29_7_0, observe_29_7_0)]

dictionary_observe_30_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8795125744465425, ('false', 'false'): 1.0, ('true', 'true'): 0.12048742555345748}
def f_observe_30_7_0(person_30_7_0, observe_30_7_0):
    return dictionary_observe_30_7_0[(person_30_7_0, observe_30_7_0)]

dictionary_observe_31_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5375802532266547, ('false', 'false'): 1.0, ('true', 'true'): 0.4624197467733453}
def f_observe_31_7_0(person_31_7_0, observe_31_7_0):
    return dictionary_observe_31_7_0[(person_31_7_0, observe_31_7_0)]

dictionary_observe_32_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9137015167440126, ('false', 'false'): 1.0, ('true', 'true'): 0.08629848325598743}
def f_observe_32_7_0(person_32_7_0, observe_32_7_0):
    return dictionary_observe_32_7_0[(person_32_7_0, observe_32_7_0)]

dictionary_observe_33_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9495961247697297, ('false', 'false'): 1.0, ('true', 'true'): 0.050403875230270345}
def f_observe_33_7_0(person_33_7_0, observe_33_7_0):
    return dictionary_observe_33_7_0[(person_33_7_0, observe_33_7_0)]

dictionary_observe_34_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5203958006939997, ('false', 'false'): 1.0, ('true', 'true'): 0.4796041993060003}
def f_observe_34_7_0(person_34_7_0, observe_34_7_0):
    return dictionary_observe_34_7_0[(person_34_7_0, observe_34_7_0)]

dictionary_observe_35_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6720088156754851, ('false', 'false'): 1.0, ('true', 'true'): 0.3279911843245149}
def f_observe_35_7_0(person_35_7_0, observe_35_7_0):
    return dictionary_observe_35_7_0[(person_35_7_0, observe_35_7_0)]

dictionary_person_0_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_0_8_0(person_0_7_0, risk_0_8_0, person_0_8_0):
    return dictionary_person_0_8_0[(person_0_7_0, risk_0_8_0, person_0_8_0)]

dictionary_observe_0_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9032359102883634, ('false', 'false'): 1.0, ('true', 'true'): 0.09676408971163664}
def f_observe_0_8_0(person_0_8_0, observe_0_8_0):
    return dictionary_observe_0_8_0[(person_0_8_0, observe_0_8_0)]

dictionary_person_1_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_1_8_0(person_1_7_0, risk_1_8_0, person_1_8_0):
    return dictionary_person_1_8_0[(person_1_7_0, risk_1_8_0, person_1_8_0)]

dictionary_observe_1_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6676453647246472, ('false', 'false'): 1.0, ('true', 'true'): 0.3323546352753528}
def f_observe_1_8_0(person_1_8_0, observe_1_8_0):
    return dictionary_observe_1_8_0[(person_1_8_0, observe_1_8_0)]

dictionary_person_2_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_2_8_0(person_2_7_0, risk_2_8_0, person_2_8_0):
    return dictionary_person_2_8_0[(person_2_7_0, risk_2_8_0, person_2_8_0)]

dictionary_observe_2_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5236643548961877, ('false', 'false'): 1.0, ('true', 'true'): 0.4763356451038123}
def f_observe_2_8_0(person_2_8_0, observe_2_8_0):
    return dictionary_observe_2_8_0[(person_2_8_0, observe_2_8_0)]

dictionary_person_3_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7670409061215834, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.23295909387841662, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7662738652154618, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2337261347845382, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_3_8_0(person_3_7_0, person_2_7_0, risk_3_8_0, person_3_8_0):
    return dictionary_person_3_8_0[(person_3_7_0, person_2_7_0, risk_3_8_0, person_3_8_0)]

dictionary_observe_3_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9396106975945892, ('false', 'false'): 1.0, ('true', 'true'): 0.06038930240541085}
def f_observe_3_8_0(person_3_8_0, observe_3_8_0):
    return dictionary_observe_3_8_0[(person_3_8_0, observe_3_8_0)]

dictionary_person_4_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_8_0(person_4_7_0, risk_4_8_0, person_4_8_0):
    return dictionary_person_4_8_0[(person_4_7_0, risk_4_8_0, person_4_8_0)]

dictionary_observe_4_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7626164946994978, ('false', 'false'): 1.0, ('true', 'true'): 0.23738350530050223}
def f_observe_4_8_0(person_4_8_0, observe_4_8_0):
    return dictionary_observe_4_8_0[(person_4_8_0, observe_4_8_0)]

dictionary_person_5_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.68473302362021, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.31526697637978995, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6840482905965898, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3159517094034102, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_5_8_0(person_5_7_0, person_35_7_0, risk_5_8_0, person_5_8_0):
    return dictionary_person_5_8_0[(person_5_7_0, person_35_7_0, risk_5_8_0, person_5_8_0)]

dictionary_observe_5_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6987495849464144, ('false', 'false'): 1.0, ('true', 'true'): 0.30125041505358563}
def f_observe_5_8_0(person_5_8_0, observe_5_8_0):
    return dictionary_observe_5_8_0[(person_5_8_0, observe_5_8_0)]

dictionary_person_6_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_6_8_0(person_6_7_0, risk_6_8_0, person_6_8_0):
    return dictionary_person_6_8_0[(person_6_7_0, risk_6_8_0, person_6_8_0)]

dictionary_observe_6_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.750961760507675, ('false', 'false'): 1.0, ('true', 'true'): 0.24903823949232495}
def f_observe_6_8_0(person_6_8_0, observe_6_8_0):
    return dictionary_observe_6_8_0[(person_6_8_0, observe_6_8_0)]

dictionary_person_7_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.37743272052853016, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.6225672794714698, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.3770552878080016, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.6229447121919984, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_7_8_0(person_7_7_0, person_0_7_0, risk_7_8_0, person_7_8_0):
    return dictionary_person_7_8_0[(person_7_7_0, person_0_7_0, risk_7_8_0, person_7_8_0)]

dictionary_observe_7_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9350969717285854, ('false', 'false'): 1.0, ('true', 'true'): 0.06490302827141459}
def f_observe_7_8_0(person_7_8_0, observe_7_8_0):
    return dictionary_observe_7_8_0[(person_7_8_0, observe_7_8_0)]

dictionary_person_8_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_8_8_0(person_8_7_0, risk_8_8_0, person_8_8_0):
    return dictionary_person_8_8_0[(person_8_7_0, risk_8_8_0, person_8_8_0)]

dictionary_observe_8_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6119661039305343, ('false', 'false'): 1.0, ('true', 'true'): 0.3880338960694657}
def f_observe_8_8_0(person_8_8_0, observe_8_8_0):
    return dictionary_observe_8_8_0[(person_8_8_0, observe_8_8_0)]

dictionary_person_9_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_9_8_0(person_9_7_0, risk_9_8_0, person_9_8_0):
    return dictionary_person_9_8_0[(person_9_7_0, risk_9_8_0, person_9_8_0)]

dictionary_observe_9_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6100182922763152, ('false', 'false'): 1.0, ('true', 'true'): 0.3899817077236848}
def f_observe_9_8_0(person_9_8_0, observe_9_8_0):
    return dictionary_observe_9_8_0[(person_9_8_0, observe_9_8_0)]

dictionary_person_10_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6156834573380829, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.38431654266191706, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6150677738807449, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.38493222611925515, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_10_8_0(person_10_7_0, person_16_7_0, risk_10_8_0, person_10_8_0):
    return dictionary_person_10_8_0[(person_10_7_0, person_16_7_0, risk_10_8_0, person_10_8_0)]

dictionary_observe_10_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7684123320444579, ('false', 'false'): 1.0, ('true', 'true'): 0.2315876679555421}
def f_observe_10_8_0(person_10_8_0, observe_10_8_0):
    return dictionary_observe_10_8_0[(person_10_8_0, observe_10_8_0)]

dictionary_person_11_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3364355557705676, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.47647495255217653, ('false', 'false', 'true', 'false', 'false'): 0.789748608596596, ('false', 'true', 'false', 'true', 'true'): 0.33709912021479704, ('false', 'false', 'true', 'false', 'true'): 0.210251391403404, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.662900879785203, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7889588599879994, ('false', 'true', 'true', 'false', 'true'): 0.4759509034556322, ('false', 'true', 'true', 'false', 'false'): 0.5240490965443678, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.21104114001200058, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6635644442294324, ('false', 'true', 'true', 'true', 'false'): 0.5235250474478235}
def f_person_11_8_0(person_11_7_0, person_12_7_0, person_10_7_0, risk_11_8_0, person_11_8_0):
    return dictionary_person_11_8_0[(person_11_7_0, person_12_7_0, person_10_7_0, risk_11_8_0, person_11_8_0)]

dictionary_observe_11_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4043149700745463, ('false', 'false'): 1.0, ('true', 'true'): 0.5956850299254537}
def f_observe_11_8_0(person_11_8_0, observe_11_8_0):
    return dictionary_observe_11_8_0[(person_11_8_0, observe_11_8_0)]

dictionary_person_12_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_12_8_0(person_12_7_0, risk_12_8_0, person_12_8_0):
    return dictionary_person_12_8_0[(person_12_7_0, risk_12_8_0, person_12_8_0)]

dictionary_observe_12_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7010265869311469, ('false', 'false'): 1.0, ('true', 'true'): 0.29897341306885306}
def f_observe_12_8_0(person_12_8_0, observe_12_8_0):
    return dictionary_observe_12_8_0[(person_12_8_0, observe_12_8_0)]

dictionary_person_13_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_13_8_0(person_13_7_0, risk_13_8_0, person_13_8_0):
    return dictionary_person_13_8_0[(person_13_7_0, risk_13_8_0, person_13_8_0)]

dictionary_observe_13_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7250578272588308, ('false', 'false'): 1.0, ('true', 'true'): 0.27494217274116917}
def f_observe_13_8_0(person_13_8_0, observe_13_8_0):
    return dictionary_observe_13_8_0[(person_13_8_0, observe_13_8_0)]

dictionary_person_14_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_14_8_0(person_14_7_0, risk_14_8_0, person_14_8_0):
    return dictionary_person_14_8_0[(person_14_7_0, risk_14_8_0, person_14_8_0)]

dictionary_observe_14_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9105546903681525, ('false', 'false'): 1.0, ('true', 'true'): 0.08944530963184749}
def f_observe_14_8_0(person_14_8_0, observe_14_8_0):
    return dictionary_observe_14_8_0[(person_14_8_0, observe_14_8_0)]

dictionary_person_15_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_15_8_0(person_15_7_0, risk_15_8_0, person_15_8_0):
    return dictionary_person_15_8_0[(person_15_7_0, risk_15_8_0, person_15_8_0)]

dictionary_observe_15_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7984923621793274, ('false', 'false'): 1.0, ('true', 'true'): 0.2015076378206726}
def f_observe_15_8_0(person_15_8_0, observe_15_8_0):
    return dictionary_observe_15_8_0[(person_15_8_0, observe_15_8_0)]

dictionary_person_16_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4560878903195774, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5439121096804226, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4556318024292578, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5443681975707422, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_16_8_0(person_16_7_0, person_10_7_0, risk_16_8_0, person_16_8_0):
    return dictionary_person_16_8_0[(person_16_7_0, person_10_7_0, risk_16_8_0, person_16_8_0)]

dictionary_observe_16_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5858322549994698, ('false', 'false'): 1.0, ('true', 'true'): 0.4141677450005302}
def f_observe_16_8_0(person_16_8_0, observe_16_8_0):
    return dictionary_observe_16_8_0[(person_16_8_0, observe_16_8_0)]

dictionary_person_17_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_17_8_0(person_17_7_0, risk_17_8_0, person_17_8_0):
    return dictionary_person_17_8_0[(person_17_7_0, risk_17_8_0, person_17_8_0)]

dictionary_observe_17_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.42635948007904734, ('false', 'false'): 1.0, ('true', 'true'): 0.5736405199209527}
def f_observe_17_8_0(person_17_8_0, observe_17_8_0):
    return dictionary_observe_17_8_0[(person_17_8_0, observe_17_8_0)]

dictionary_person_18_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.4587769157120898, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7768733429490777, ('false', 'false', 'true', 'false', 'false'): 0.41267642408830896, ('false', 'true', 'false', 'true', 'true'): 0.45931813879637773, ('false', 'false', 'true', 'false', 'true'): 0.587323575911691, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5406818612036223, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.41226374766422064, ('false', 'true', 'true', 'false', 'true'): 0.7766499929420198, ('false', 'true', 'true', 'false', 'false'): 0.22335000705798022, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5877362523357794, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5412230842879102, ('false', 'true', 'true', 'true', 'false'): 0.22312665705092224}
def f_person_18_8_0(person_18_7_0, person_12_7_0, person_19_7_0, risk_18_8_0, person_18_8_0):
    return dictionary_person_18_8_0[(person_18_7_0, person_12_7_0, person_19_7_0, risk_18_8_0, person_18_8_0)]

dictionary_observe_18_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4301919916927154, ('false', 'false'): 1.0, ('true', 'true'): 0.5698080083072846}
def f_observe_18_8_0(person_18_8_0, observe_18_8_0):
    return dictionary_observe_18_8_0[(person_18_8_0, observe_18_8_0)]

dictionary_person_19_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_19_8_0(person_19_7_0, risk_19_8_0, person_19_8_0):
    return dictionary_person_19_8_0[(person_19_7_0, risk_19_8_0, person_19_8_0)]

dictionary_observe_19_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7329755502749487, ('false', 'false'): 1.0, ('true', 'true'): 0.26702444972505135}
def f_observe_19_8_0(person_19_8_0, observe_19_8_0):
    return dictionary_observe_19_8_0[(person_19_8_0, observe_19_8_0)]

dictionary_person_20_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.5639905348733193, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6079838899046013, ('false', 'false', 'true', 'false', 'false'): 0.999, ('false', 'true', 'false', 'true', 'true'): 0.6075914813859873, ('false', 'false', 'true', 'false', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.9, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.39240851861401266, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8991, ('false', 'true', 'true', 'false', 'true'): 0.564426544338446, ('false', 'true', 'true', 'false', 'false'): 0.43557345566155403, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.09999999999999998, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.4360094651266807, ('false', 'true', 'true', 'true', 'false'): 0.39201611009539866}
def f_person_20_8_0(person_20_7_0, person_21_7_0, risk_20_8_0, risk_20_8_1, person_20_8_0):
    return dictionary_person_20_8_0[(person_20_7_0, person_21_7_0, risk_20_8_0, risk_20_8_1, person_20_8_0)]

dictionary_observe_20_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.44855244968729446, ('false', 'false'): 1.0, ('true', 'true'): 0.5514475503127055}
def f_observe_20_8_0(person_20_8_0, observe_20_8_0):
    return dictionary_observe_20_8_0[(person_20_8_0, observe_20_8_0)]

dictionary_person_21_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7927804480932283, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.20721955190677166, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7919876676451351, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.20801233235486494, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_21_8_0(person_21_7_0, person_22_7_0, risk_21_8_0, person_21_8_0):
    return dictionary_person_21_8_0[(person_21_7_0, person_22_7_0, risk_21_8_0, person_21_8_0)]

dictionary_observe_21_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9804154598296273, ('false', 'false'): 1.0, ('true', 'true'): 0.0195845401703727}
def f_observe_21_8_0(person_21_8_0, observe_21_8_0):
    return dictionary_observe_21_8_0[(person_21_8_0, observe_21_8_0)]

dictionary_person_22_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.613682255366015, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.38631774463398505, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6130685731106489, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3869314268893511, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_22_8_0(person_22_7_0, person_34_7_0, risk_22_8_0, person_22_8_0):
    return dictionary_person_22_8_0[(person_22_7_0, person_34_7_0, risk_22_8_0, person_22_8_0)]

dictionary_observe_22_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.647531346548831, ('false', 'false'): 1.0, ('true', 'true'): 0.35246865345116896}
def f_observe_22_8_0(person_22_8_0, observe_22_8_0):
    return dictionary_observe_22_8_0[(person_22_8_0, observe_22_8_0)]

dictionary_person_23_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_23_8_0(person_23_7_0, risk_23_8_0, person_23_8_0):
    return dictionary_person_23_8_0[(person_23_7_0, risk_23_8_0, person_23_8_0)]

dictionary_observe_23_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6791424789876777, ('false', 'false'): 1.0, ('true', 'true'): 0.32085752101232234}
def f_observe_23_8_0(person_23_8_0, observe_23_8_0):
    return dictionary_observe_23_8_0[(person_23_8_0, observe_23_8_0)]

dictionary_person_24_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3869852839695278, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6299620295301485, ('false', 'false', 'true', 'false', 'false'): 0.6042405984105081, ('false', 'true', 'false', 'true', 'true'): 0.3875982986855583, ('false', 'false', 'true', 'false', 'true'): 0.39575940158949185, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6124017013144417, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6036363578120977, ('false', 'true', 'true', 'false', 'true'): 0.6295916211512997, ('false', 'true', 'true', 'false', 'false'): 0.37040837884870026, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3963636421879023, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6130147160304722, ('false', 'true', 'true', 'true', 'false'): 0.37003797046985154}
def f_person_24_8_0(person_24_7_0, person_18_7_0, person_23_7_0, risk_24_8_0, person_24_8_0):
    return dictionary_person_24_8_0[(person_24_7_0, person_18_7_0, person_23_7_0, risk_24_8_0, person_24_8_0)]

dictionary_observe_24_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7509278273522788, ('false', 'false'): 1.0, ('true', 'true'): 0.2490721726477212}
def f_observe_24_8_0(person_24_8_0, observe_24_8_0):
    return dictionary_observe_24_8_0[(person_24_8_0, observe_24_8_0)]

dictionary_person_25_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_25_8_0(person_25_7_0, risk_25_8_0, person_25_8_0):
    return dictionary_person_25_8_0[(person_25_7_0, risk_25_8_0, person_25_8_0)]

dictionary_observe_25_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7714286128348173, ('false', 'false'): 1.0, ('true', 'true'): 0.22857138716518266}
def f_observe_25_8_0(person_25_8_0, observe_25_8_0):
    return dictionary_observe_25_8_0[(person_25_8_0, observe_25_8_0)]

dictionary_person_26_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3245380075407489, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5490250608334984, ('false', 'false', 'true', 'false', 'false'): 0.6683223787151384, ('false', 'true', 'false', 'true', 'true'): 0.3252134695332082, ('false', 'false', 'true', 'false', 'true'): 0.33167762128486156, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6747865304667918, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6676540563364233, ('false', 'true', 'true', 'false', 'true'): 0.5485736344679664, ('false', 'true', 'true', 'false', 'false'): 0.4514263655320336, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3323459436635767, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6754619924592511, ('false', 'true', 'true', 'true', 'false'): 0.45097493916650155}
def f_person_26_8_0(person_26_7_0, person_27_7_0, person_25_7_0, risk_26_8_0, person_26_8_0):
    return dictionary_person_26_8_0[(person_26_7_0, person_27_7_0, person_25_7_0, risk_26_8_0, person_26_8_0)]

dictionary_observe_26_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5829169308083926, ('false', 'false'): 1.0, ('true', 'true'): 0.4170830691916074}
def f_observe_26_8_0(person_26_8_0, observe_26_8_0):
    return dictionary_observe_26_8_0[(person_26_8_0, observe_26_8_0)]

dictionary_person_27_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7045369611448642, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2954630388551358, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7038324241837193, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2961675758162807, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_27_8_0(person_27_7_0, person_33_7_0, risk_27_8_0, person_27_8_0):
    return dictionary_person_27_8_0[(person_27_7_0, person_33_7_0, risk_27_8_0, person_27_8_0)]

dictionary_observe_27_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8149092678648966, ('false', 'false'): 1.0, ('true', 'true'): 0.1850907321351034}
def f_observe_27_8_0(person_27_8_0, observe_27_8_0):
    return dictionary_observe_27_8_0[(person_27_8_0, observe_27_8_0)]

dictionary_person_28_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_28_8_0(person_28_7_0, risk_28_8_0, person_28_8_0):
    return dictionary_person_28_8_0[(person_28_7_0, risk_28_8_0, person_28_8_0)]

dictionary_observe_28_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5213003380054231, ('false', 'false'): 1.0, ('true', 'true'): 0.4786996619945769}
def f_observe_28_8_0(person_28_8_0, observe_28_8_0):
    return dictionary_observe_28_8_0[(person_28_8_0, observe_28_8_0)]

dictionary_person_29_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_29_8_0(person_29_7_0, risk_29_8_0, person_29_8_0):
    return dictionary_person_29_8_0[(person_29_7_0, risk_29_8_0, person_29_8_0)]

dictionary_observe_29_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6436159123832333, ('false', 'false'): 1.0, ('true', 'true'): 0.35638408761676665}
def f_observe_29_8_0(person_29_8_0, observe_29_8_0):
    return dictionary_observe_29_8_0[(person_29_8_0, observe_29_8_0)]

dictionary_person_30_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_30_8_0(person_30_7_0, risk_30_8_0, person_30_8_0):
    return dictionary_person_30_8_0[(person_30_7_0, risk_30_8_0, person_30_8_0)]

dictionary_observe_30_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9731569273498766, ('false', 'false'): 1.0, ('true', 'true'): 0.026843072650123423}
def f_observe_30_8_0(person_30_8_0, observe_30_8_0):
    return dictionary_observe_30_8_0[(person_30_8_0, observe_30_8_0)]

dictionary_person_31_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_31_8_0(person_31_7_0, risk_31_8_0, person_31_8_0):
    return dictionary_person_31_8_0[(person_31_7_0, risk_31_8_0, person_31_8_0)]

dictionary_observe_31_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7338305281389551, ('false', 'false'): 1.0, ('true', 'true'): 0.2661694718610449}
def f_observe_31_8_0(person_31_8_0, observe_31_8_0):
    return dictionary_observe_31_8_0[(person_31_8_0, observe_31_8_0)]

dictionary_person_32_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8656566268114212, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.1343433731885788, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8647909701846098, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.13520902981539018, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_32_8_0(person_32_7_0, person_2_7_0, risk_32_8_0, person_32_8_0):
    return dictionary_person_32_8_0[(person_32_7_0, person_2_7_0, risk_32_8_0, person_32_8_0)]

dictionary_observe_32_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5752370549160082, ('false', 'false'): 1.0, ('true', 'true'): 0.4247629450839918}
def f_observe_32_8_0(person_32_8_0, observe_32_8_0):
    return dictionary_observe_32_8_0[(person_32_8_0, observe_32_8_0)]

dictionary_person_33_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_33_8_0(person_33_7_0, risk_33_8_0, person_33_8_0):
    return dictionary_person_33_8_0[(person_33_7_0, risk_33_8_0, person_33_8_0)]

dictionary_observe_33_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4521056170514113, ('false', 'false'): 1.0, ('true', 'true'): 0.5478943829485887}
def f_observe_33_8_0(person_33_8_0, observe_33_8_0):
    return dictionary_observe_33_8_0[(person_33_8_0, observe_33_8_0)]

dictionary_person_34_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.6159259433524438, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7856288163236187, ('false', 'false', 'true', 'false', 'false'): 0.5587093575621037, ('false', 'true', 'false', 'true', 'true'): 0.6163100174090913, ('false', 'false', 'true', 'false', 'true'): 0.4412906424378963, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.3836899825909087, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5581506482045416, ('false', 'true', 'true', 'false', 'true'): 0.7854142305541728, ('false', 'true', 'true', 'false', 'false'): 0.21458576944582716, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.44184935179545837, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.38407405664755623, ('false', 'true', 'true', 'true', 'false'): 0.21437118367638133}
def f_person_34_8_0(person_34_7_0, person_28_7_0, person_5_7_0, risk_34_8_0, person_34_8_0):
    return dictionary_person_34_8_0[(person_34_7_0, person_28_7_0, person_5_7_0, risk_34_8_0, person_34_8_0)]

dictionary_observe_34_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7714441687245095, ('false', 'false'): 1.0, ('true', 'true'): 0.2285558312754905}
def f_observe_34_8_0(person_34_8_0, observe_34_8_0):
    return dictionary_observe_34_8_0[(person_34_8_0, observe_34_8_0)]

dictionary_person_35_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_35_8_0(person_35_7_0, risk_35_8_0, person_35_8_0):
    return dictionary_person_35_8_0[(person_35_7_0, risk_35_8_0, person_35_8_0)]

dictionary_observe_35_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7127934397239275, ('false', 'false'): 1.0, ('true', 'true'): 0.2872065602760725}
def f_observe_35_8_0(person_35_8_0, observe_35_8_0):
    return dictionary_observe_35_8_0[(person_35_8_0, observe_35_8_0)]

dictionary_person_0_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5561756124907875, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4438243875092125, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5556194368782967, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.44438056312170326, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_0_9_0(person_0_8_0, person_35_8_0, risk_0_9_0, person_0_9_0):
    return dictionary_person_0_9_0[(person_0_8_0, person_35_8_0, risk_0_9_0, person_0_9_0)]

dictionary_observe_0_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8339543441642345, ('false', 'false'): 1.0, ('true', 'true'): 0.16604565583576547}
def f_observe_0_9_0(person_0_9_0, observe_0_9_0):
    return dictionary_observe_0_9_0[(person_0_9_0, observe_0_9_0)]

dictionary_person_1_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5249870159993915, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.47501298400060854, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5244620289833921, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4755379710166079, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_1_9_0(person_1_8_0, person_7_8_0, risk_1_9_0, person_1_9_0):
    return dictionary_person_1_9_0[(person_1_8_0, person_7_8_0, risk_1_9_0, person_1_9_0)]

dictionary_observe_1_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5949570762396195, ('false', 'false'): 1.0, ('true', 'true'): 0.40504292376038054}
def f_observe_1_9_0(person_1_9_0, observe_1_9_0):
    return dictionary_observe_1_9_0[(person_1_9_0, observe_1_9_0)]

dictionary_person_2_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_2_9_0(person_2_8_0, risk_2_9_0, person_2_9_0):
    return dictionary_person_2_9_0[(person_2_8_0, risk_2_9_0, person_2_9_0)]

dictionary_observe_2_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6261773510804433, ('false', 'false'): 1.0, ('true', 'true'): 0.37382264891955674}
def f_observe_2_9_0(person_2_9_0, observe_2_9_0):
    return dictionary_observe_2_9_0[(person_2_9_0, observe_2_9_0)]

dictionary_person_3_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.630512932414822, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.369487067585178, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6298824194824072, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3701175805175928, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_3_9_0(person_3_8_0, person_2_8_0, risk_3_9_0, person_3_9_0):
    return dictionary_person_3_9_0[(person_3_8_0, person_2_8_0, risk_3_9_0, person_3_9_0)]

dictionary_observe_3_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.42837640637382735, ('false', 'false'): 1.0, ('true', 'true'): 0.5716235936261727}
def f_observe_3_9_0(person_3_9_0, observe_3_9_0):
    return dictionary_observe_3_9_0[(person_3_9_0, observe_3_9_0)]

dictionary_person_4_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_9_0(person_4_8_0, risk_4_9_0, person_4_9_0):
    return dictionary_person_4_9_0[(person_4_8_0, risk_4_9_0, person_4_9_0)]

dictionary_observe_4_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5526202973605029, ('false', 'false'): 1.0, ('true', 'true'): 0.4473797026394971}
def f_observe_4_9_0(person_4_9_0, observe_4_9_0):
    return dictionary_observe_4_9_0[(person_4_9_0, observe_4_9_0)]

dictionary_person_5_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_5_9_0(person_5_8_0, risk_5_9_0, person_5_9_0):
    return dictionary_person_5_9_0[(person_5_8_0, risk_5_9_0, person_5_9_0)]

dictionary_observe_5_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9009512054880162, ('false', 'false'): 1.0, ('true', 'true'): 0.09904879451198378}
def f_observe_5_9_0(person_5_9_0, observe_5_9_0):
    return dictionary_observe_5_9_0[(person_5_9_0, observe_5_9_0)]

dictionary_person_6_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_6_9_0(person_6_8_0, risk_6_9_0, person_6_9_0):
    return dictionary_person_6_9_0[(person_6_8_0, risk_6_9_0, person_6_9_0)]

dictionary_observe_6_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7680534984326355, ('false', 'false'): 1.0, ('true', 'true'): 0.23194650156736452}
def f_observe_6_9_0(person_6_9_0, observe_6_9_0):
    return dictionary_observe_6_9_0[(person_6_9_0, observe_6_9_0)]

dictionary_person_7_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_7_9_0(person_7_8_0, risk_7_9_0, person_7_9_0):
    return dictionary_person_7_9_0[(person_7_8_0, risk_7_9_0, person_7_9_0)]

dictionary_observe_7_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7770091444685366, ('false', 'false'): 1.0, ('true', 'true'): 0.22299085553146336}
def f_observe_7_9_0(person_7_9_0, observe_7_9_0):
    return dictionary_observe_7_9_0[(person_7_9_0, observe_7_9_0)]

dictionary_person_8_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_8_9_0(person_8_8_0, risk_8_9_0, person_8_9_0):
    return dictionary_person_8_9_0[(person_8_8_0, risk_8_9_0, person_8_9_0)]

dictionary_observe_8_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9190729217523141, ('false', 'false'): 1.0, ('true', 'true'): 0.08092707824768586}
def f_observe_8_9_0(person_8_9_0, observe_8_9_0):
    return dictionary_observe_8_9_0[(person_8_9_0, observe_8_9_0)]

dictionary_person_9_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7854736317962868, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.21452636820371318, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7846881581644906, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.21531184183550944, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_9_9_0(person_9_8_0, person_21_8_0, risk_9_9_0, person_9_9_0):
    return dictionary_person_9_9_0[(person_9_8_0, person_21_8_0, risk_9_9_0, person_9_9_0)]

dictionary_observe_9_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8329835679668466, ('false', 'false'): 1.0, ('true', 'true'): 0.16701643203315342}
def f_observe_9_9_0(person_9_9_0, observe_9_9_0):
    return dictionary_observe_9_9_0[(person_9_9_0, observe_9_9_0)]

dictionary_person_10_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5834686616219511, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4165313383780489, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5828851929603291, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.41711480703967085, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_10_9_0(person_10_8_0, person_4_8_0, risk_10_9_0, person_10_9_0):
    return dictionary_person_10_9_0[(person_10_8_0, person_4_8_0, risk_10_9_0, person_10_9_0)]

dictionary_observe_10_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4536635177635422, ('false', 'false'): 1.0, ('true', 'true'): 0.5463364822364578}
def f_observe_10_9_0(person_10_9_0, observe_10_9_0):
    return dictionary_observe_10_9_0[(person_10_9_0, observe_10_9_0)]

dictionary_person_11_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_11_9_0(person_11_8_0, risk_11_9_0, person_11_9_0):
    return dictionary_person_11_9_0[(person_11_8_0, risk_11_9_0, person_11_9_0)]

dictionary_observe_11_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6232450645515313, ('false', 'false'): 1.0, ('true', 'true'): 0.3767549354484687}
def f_observe_11_9_0(person_11_9_0, observe_11_9_0):
    return dictionary_observe_11_9_0[(person_11_9_0, observe_11_9_0)]

dictionary_person_12_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_12_9_0(person_12_8_0, risk_12_9_0, person_12_9_0):
    return dictionary_person_12_9_0[(person_12_8_0, risk_12_9_0, person_12_9_0)]

dictionary_observe_12_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9891974667852689, ('false', 'false'): 1.0, ('true', 'true'): 0.010802533214731125}
def f_observe_12_9_0(person_12_9_0, observe_12_9_0):
    return dictionary_observe_12_9_0[(person_12_9_0, observe_12_9_0)]

dictionary_person_13_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_13_9_0(person_13_8_0, risk_13_9_0, person_13_9_0):
    return dictionary_person_13_9_0[(person_13_8_0, risk_13_9_0, person_13_9_0)]

dictionary_observe_13_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9149149075008504, ('false', 'false'): 1.0, ('true', 'true'): 0.08508509249914964}
def f_observe_13_9_0(person_13_9_0, observe_13_9_0):
    return dictionary_observe_13_9_0[(person_13_9_0, observe_13_9_0)]

dictionary_person_14_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_14_9_0(person_14_8_0, risk_14_9_0, person_14_9_0):
    return dictionary_person_14_9_0[(person_14_8_0, risk_14_9_0, person_14_9_0)]

dictionary_observe_14_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.597461347925007, ('false', 'false'): 1.0, ('true', 'true'): 0.40253865207499295}
def f_observe_14_9_0(person_14_9_0, observe_14_9_0):
    return dictionary_observe_14_9_0[(person_14_9_0, observe_14_9_0)]

dictionary_person_15_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_15_9_0(person_15_8_0, risk_15_9_0, person_15_9_0):
    return dictionary_person_15_9_0[(person_15_8_0, risk_15_9_0, person_15_9_0)]

dictionary_observe_15_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5252543332223307, ('false', 'false'): 1.0, ('true', 'true'): 0.4747456667776693}
def f_observe_15_9_0(person_15_9_0, observe_15_9_0):
    return dictionary_observe_15_9_0[(person_15_9_0, observe_15_9_0)]

dictionary_person_16_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_16_9_0(person_16_8_0, risk_16_9_0, person_16_9_0):
    return dictionary_person_16_9_0[(person_16_8_0, risk_16_9_0, person_16_9_0)]

dictionary_observe_16_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6153057555592715, ('false', 'false'): 1.0, ('true', 'true'): 0.38469424444072853}
def f_observe_16_9_0(person_16_9_0, observe_16_9_0):
    return dictionary_observe_16_9_0[(person_16_9_0, observe_16_9_0)]

dictionary_person_17_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5861635465058883, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4138364534941117, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5855773829593824, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.41442261704061756, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_17_9_0(person_17_8_0, person_23_8_0, risk_17_9_0, person_17_9_0):
    return dictionary_person_17_9_0[(person_17_8_0, person_23_8_0, risk_17_9_0, person_17_9_0)]

dictionary_observe_17_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4452230900792953, ('false', 'false'): 1.0, ('true', 'true'): 0.5547769099207047}
def f_observe_17_9_0(person_17_9_0, observe_17_9_0):
    return dictionary_observe_17_9_0[(person_17_9_0, observe_17_9_0)]

dictionary_person_18_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_18_9_0(person_18_8_0, risk_18_9_0, person_18_9_0):
    return dictionary_person_18_9_0[(person_18_8_0, risk_18_9_0, person_18_9_0)]

dictionary_observe_18_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.739511382893949, ('false', 'false'): 1.0, ('true', 'true'): 0.260488617106051}
def f_observe_18_9_0(person_18_9_0, observe_18_9_0):
    return dictionary_observe_18_9_0[(person_18_9_0, observe_18_9_0)]

dictionary_person_19_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_19_9_0(person_19_8_0, risk_19_9_0, person_19_9_0):
    return dictionary_person_19_9_0[(person_19_8_0, risk_19_9_0, person_19_9_0)]

dictionary_observe_19_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6828012469625875, ('false', 'false'): 1.0, ('true', 'true'): 0.3171987530374125}
def f_observe_19_9_0(person_19_9_0, observe_19_9_0):
    return dictionary_observe_19_9_0[(person_19_9_0, observe_19_9_0)]

dictionary_person_20_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_20_9_0(person_20_8_0, risk_20_9_0, person_20_9_0):
    return dictionary_person_20_9_0[(person_20_8_0, risk_20_9_0, person_20_9_0)]

dictionary_observe_20_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9144649774448141, ('false', 'false'): 1.0, ('true', 'true'): 0.08553502255518586}
def f_observe_20_9_0(person_20_9_0, observe_20_9_0):
    return dictionary_observe_20_9_0[(person_20_9_0, observe_20_9_0)]

dictionary_person_21_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_21_9_0(person_21_8_0, risk_21_9_0, person_21_9_0):
    return dictionary_person_21_9_0[(person_21_8_0, risk_21_9_0, person_21_9_0)]

dictionary_observe_21_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6096679491972368, ('false', 'false'): 1.0, ('true', 'true'): 0.39033205080276323}
def f_observe_21_9_0(person_21_9_0, observe_21_9_0):
    return dictionary_observe_21_9_0[(person_21_9_0, observe_21_9_0)]

dictionary_person_22_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_22_9_0(person_22_8_0, risk_22_9_0, person_22_9_0):
    return dictionary_person_22_9_0[(person_22_8_0, risk_22_9_0, person_22_9_0)]

dictionary_observe_22_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4712392728879171, ('false', 'false'): 1.0, ('true', 'true'): 0.5287607271120829}
def f_observe_22_9_0(person_22_9_0, observe_22_9_0):
    return dictionary_observe_22_9_0[(person_22_9_0, observe_22_9_0)]

dictionary_person_23_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.5104382465639656, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.669658786531223, ('false', 'false', 'true', 'false', 'false'): 0.6754446870763084, ('false', 'true', 'false', 'true', 'true'): 0.5109278083174016, ('false', 'false', 'true', 'false', 'true'): 0.32455531292369155, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.48907219168259836, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6747692423892322, ('false', 'true', 'true', 'false', 'true'): 0.6693281146458689, ('false', 'true', 'true', 'false', 'false'): 0.3306718853541311, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3252307576107678, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.48956175343603436, ('false', 'true', 'true', 'true', 'false'): 0.330341213468777}
def f_person_23_9_0(person_23_8_0, person_29_8_0, person_24_8_0, risk_23_9_0, person_23_9_0):
    return dictionary_person_23_9_0[(person_23_8_0, person_29_8_0, person_24_8_0, risk_23_9_0, person_23_9_0)]

dictionary_observe_23_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5448308116089868, ('false', 'false'): 1.0, ('true', 'true'): 0.45516918839101317}
def f_observe_23_9_0(person_23_9_0, observe_23_9_0):
    return dictionary_observe_23_9_0[(person_23_9_0, observe_23_9_0)]

dictionary_person_24_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_24_9_0(person_24_8_0, risk_24_9_0, person_24_9_0):
    return dictionary_person_24_9_0[(person_24_8_0, risk_24_9_0, person_24_9_0)]

dictionary_observe_24_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7266703334125004, ('false', 'false'): 1.0, ('true', 'true'): 0.2733296665874996}
def f_observe_24_9_0(person_24_9_0, observe_24_9_0):
    return dictionary_observe_24_9_0[(person_24_9_0, observe_24_9_0)]

dictionary_person_25_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.4633718781559153, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7691743103099519, ('false', 'false', 'true', 'false', 'false'): 0.4305714460928256, ('false', 'true', 'false', 'true', 'true'): 0.46390850627775937, ('false', 'false', 'true', 'false', 'true'): 0.5694285539071744, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5360914937222406, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.4301408746467328, ('false', 'true', 'true', 'false', 'true'): 0.7689432535635154, ('false', 'true', 'true', 'false', 'false'): 0.23105674643648458, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5698591253532672, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5366281218440847, ('false', 'true', 'true', 'true', 'false'): 0.2308256896900481}
def f_person_25_9_0(person_25_8_0, person_30_8_0, person_19_8_0, risk_25_9_0, person_25_9_0):
    return dictionary_person_25_9_0[(person_25_8_0, person_30_8_0, person_19_8_0, risk_25_9_0, person_25_9_0)]

dictionary_observe_25_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6587998017433203, ('false', 'false'): 1.0, ('true', 'true'): 0.3412001982566797}
def f_observe_25_9_0(person_25_9_0, observe_25_9_0):
    return dictionary_observe_25_9_0[(person_25_9_0, observe_25_9_0)]

dictionary_person_26_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7128292334603555, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.28717076653964446, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7121164042268951, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.28788359577310485, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_26_9_0(person_26_8_0, person_27_8_0, risk_26_9_0, person_26_9_0):
    return dictionary_person_26_9_0[(person_26_8_0, person_27_8_0, risk_26_9_0, person_26_9_0)]

dictionary_observe_26_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6010263569116401, ('false', 'false'): 1.0, ('true', 'true'): 0.3989736430883599}
def f_observe_26_9_0(person_26_9_0, observe_26_9_0):
    return dictionary_observe_26_9_0[(person_26_9_0, observe_26_9_0)]

dictionary_person_27_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.786010444405292, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.213989555594708, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7852244339608867, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2147755660391133, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_27_9_0(person_27_8_0, person_26_8_0, risk_27_9_0, person_27_9_0):
    return dictionary_person_27_9_0[(person_27_8_0, person_26_8_0, risk_27_9_0, person_27_9_0)]

dictionary_observe_27_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.631899209184585, ('false', 'false'): 1.0, ('true', 'true'): 0.368100790815415}
def f_observe_27_9_0(person_27_9_0, observe_27_9_0):
    return dictionary_observe_27_9_0[(person_27_9_0, observe_27_9_0)]

dictionary_person_28_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_28_9_0(person_28_8_0, risk_28_9_0, person_28_9_0):
    return dictionary_person_28_9_0[(person_28_8_0, risk_28_9_0, person_28_9_0)]

dictionary_observe_28_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7628613776136148, ('false', 'false'): 1.0, ('true', 'true'): 0.23713862238638517}
def f_observe_28_9_0(person_28_9_0, observe_28_9_0):
    return dictionary_observe_28_9_0[(person_28_9_0, observe_28_9_0)]

dictionary_person_29_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_29_9_0(person_29_8_0, risk_29_9_0, person_29_9_0):
    return dictionary_person_29_9_0[(person_29_8_0, risk_29_9_0, person_29_9_0)]

dictionary_observe_29_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6503117193707466, ('false', 'false'): 1.0, ('true', 'true'): 0.3496882806292534}
def f_observe_29_9_0(person_29_9_0, observe_29_9_0):
    return dictionary_observe_29_9_0[(person_29_9_0, observe_29_9_0)]

dictionary_person_30_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7298378592951414, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.27016214070485856, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7291080214358463, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2708919785641537, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_30_9_0(person_30_8_0, person_0_8_0, risk_30_9_0, person_30_9_0):
    return dictionary_person_30_9_0[(person_30_8_0, person_0_8_0, risk_30_9_0, person_30_9_0)]

dictionary_observe_30_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7596479368409442, ('false', 'false'): 1.0, ('true', 'true'): 0.24035206315905577}
def f_observe_30_9_0(person_30_9_0, observe_30_9_0):
    return dictionary_observe_30_9_0[(person_30_9_0, observe_30_9_0)]

dictionary_person_31_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.5290713196812886, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.632133648473151, ('false', 'false', 'true', 'false', 'false'): 0.7819328095790451, ('false', 'true', 'false', 'true', 'true'): 0.5295422483616073, ('false', 'false', 'true', 'false', 'true'): 0.2180671904209549, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.47045775163839265, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.781150876769466, ('false', 'true', 'true', 'false', 'true'): 0.6317654138870381, ('false', 'true', 'true', 'false', 'false'): 0.36823458611296195, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.21884912323053396, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.4709286803187114, ('false', 'true', 'true', 'true', 'false'): 0.367866351526849}
def f_person_31_9_0(person_31_8_0, person_1_8_0, person_30_8_0, risk_31_9_0, person_31_9_0):
    return dictionary_person_31_9_0[(person_31_8_0, person_1_8_0, person_30_8_0, risk_31_9_0, person_31_9_0)]

dictionary_observe_31_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8734479509229089, ('false', 'false'): 1.0, ('true', 'true'): 0.12655204907709106}
def f_observe_31_9_0(person_31_9_0, observe_31_9_0):
    return dictionary_observe_31_9_0[(person_31_9_0, observe_31_9_0)]

dictionary_person_32_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_32_9_0(person_32_8_0, risk_32_9_0, person_32_9_0):
    return dictionary_person_32_9_0[(person_32_8_0, risk_32_9_0, person_32_9_0)]

dictionary_observe_32_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7427821401483554, ('false', 'false'): 1.0, ('true', 'true'): 0.2572178598516446}
def f_observe_32_9_0(person_32_9_0, observe_32_9_0):
    return dictionary_observe_32_9_0[(person_32_9_0, observe_32_9_0)]

dictionary_person_33_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_33_9_0(person_33_8_0, risk_33_9_0, person_33_9_0):
    return dictionary_person_33_9_0[(person_33_8_0, risk_33_9_0, person_33_9_0)]

dictionary_observe_33_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8562356224066223, ('false', 'false'): 1.0, ('true', 'true'): 0.14376437759337768}
def f_observe_33_9_0(person_33_9_0, observe_33_9_0):
    return dictionary_observe_33_9_0[(person_33_9_0, observe_33_9_0)]

dictionary_person_34_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_34_9_0(person_34_8_0, risk_34_9_0, person_34_9_0):
    return dictionary_person_34_9_0[(person_34_8_0, risk_34_9_0, person_34_9_0)]

dictionary_observe_34_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.945555209759755, ('false', 'false'): 1.0, ('true', 'true'): 0.054444790240244956}
def f_observe_34_9_0(person_34_9_0, observe_34_9_0):
    return dictionary_observe_34_9_0[(person_34_9_0, observe_34_9_0)]

dictionary_person_35_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6964565180400937, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3035434819599063, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6957600615220536, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3042399384779464, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_35_9_0(person_35_8_0, person_0_8_0, risk_35_9_0, person_35_9_0):
    return dictionary_person_35_9_0[(person_35_8_0, person_0_8_0, risk_35_9_0, person_35_9_0)]

dictionary_observe_35_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5599218014214373, ('false', 'false'): 1.0, ('true', 'true'): 0.4400781985785627}
def f_observe_35_9_0(person_35_9_0, observe_35_9_0):
    return dictionary_observe_35_9_0[(person_35_9_0, observe_35_9_0)]

dictionary_person_0_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_0_10_0(person_0_9_0, risk_0_10_0, person_0_10_0):
    return dictionary_person_0_10_0[(person_0_9_0, risk_0_10_0, person_0_10_0)]

dictionary_observe_0_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7751071769515222, ('false', 'false'): 1.0, ('true', 'true'): 0.2248928230484778}
def f_observe_0_10_0(person_0_10_0, observe_0_10_0):
    return dictionary_observe_0_10_0[(person_0_10_0, observe_0_10_0)]

dictionary_person_1_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5718230050828854, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4281769949171146, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5712511820778026, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.42874881792219743, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_1_10_0(person_1_9_0, person_0_9_0, risk_1_10_0, person_1_10_0):
    return dictionary_person_1_10_0[(person_1_9_0, person_0_9_0, risk_1_10_0, person_1_10_0)]

dictionary_observe_1_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.46415387991261214, ('false', 'false'): 1.0, ('true', 'true'): 0.5358461200873879}
def f_observe_1_10_0(person_1_10_0, observe_1_10_0):
    return dictionary_observe_1_10_0[(person_1_10_0, observe_1_10_0)]

dictionary_person_2_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5019070933340155, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4980929066659845, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5014051862406815, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.49859481375931847, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_2_10_0(person_2_9_0, person_1_9_0, risk_2_10_0, person_2_10_0):
    return dictionary_person_2_10_0[(person_2_9_0, person_1_9_0, risk_2_10_0, person_2_10_0)]

dictionary_observe_2_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8029140015114842, ('false', 'false'): 1.0, ('true', 'true'): 0.19708599848851582}
def f_observe_2_10_0(person_2_10_0, observe_2_10_0):
    return dictionary_observe_2_10_0[(person_2_10_0, observe_2_10_0)]

dictionary_person_3_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7175439413185327, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2824560586814673, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7168263973772142, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2831736026227858, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_3_10_0(person_3_9_0, person_1_9_0, risk_3_10_0, person_3_10_0):
    return dictionary_person_3_10_0[(person_3_9_0, person_1_9_0, risk_3_10_0, person_3_10_0)]

dictionary_observe_3_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9958800260024625, ('false', 'false'): 1.0, ('true', 'true'): 0.004119973997537496}
def f_observe_3_10_0(person_3_10_0, observe_3_10_0):
    return dictionary_observe_3_10_0[(person_3_10_0, observe_3_10_0)]

dictionary_person_4_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_10_0(person_4_9_0, risk_4_10_0, person_4_10_0):
    return dictionary_person_4_10_0[(person_4_9_0, risk_4_10_0, person_4_10_0)]

dictionary_observe_4_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9650948772034602, ('false', 'false'): 1.0, ('true', 'true'): 0.03490512279653979}
def f_observe_4_10_0(person_4_10_0, observe_4_10_0):
    return dictionary_observe_4_10_0[(person_4_10_0, observe_4_10_0)]

dictionary_person_5_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5780949700352536, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.42190502996474644, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5775168750652183, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4224831249347817, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_5_10_0(person_5_9_0, person_9_9_0, risk_5_10_0, person_5_10_0):
    return dictionary_person_5_10_0[(person_5_9_0, person_9_9_0, risk_5_10_0, person_5_10_0)]

dictionary_observe_5_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5420576023264656, ('false', 'false'): 1.0, ('true', 'true'): 0.4579423976735344}
def f_observe_5_10_0(person_5_10_0, observe_5_10_0):
    return dictionary_observe_5_10_0[(person_5_10_0, observe_5_10_0)]

dictionary_person_6_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.26439435035341463, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5368911593562766, ('false', 'false', 'true', 'false', 'false'): 0.6301914800131008, ('false', 'true', 'false', 'true', 'true'): 0.2651299560030612, ('false', 'false', 'true', 'false', 'true'): 0.36980851998689923, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7348700439969388, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6295612885330877, ('false', 'true', 'true', 'false', 'true'): 0.5364275869432199, ('false', 'true', 'true', 'false', 'false'): 0.4635724130567801, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3704387114669123, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7356056496465854, ('false', 'true', 'true', 'true', 'false'): 0.4631088406437233}
def f_person_6_10_0(person_6_9_0, person_5_9_0, person_7_9_0, risk_6_10_0, person_6_10_0):
    return dictionary_person_6_10_0[(person_6_9_0, person_5_9_0, person_7_9_0, risk_6_10_0, person_6_10_0)]

dictionary_observe_6_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8125561992785157, ('false', 'false'): 1.0, ('true', 'true'): 0.18744380072148425}
def f_observe_6_10_0(person_6_10_0, observe_6_10_0):
    return dictionary_observe_6_10_0[(person_6_10_0, observe_6_10_0)]

dictionary_person_7_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_7_10_0(person_7_9_0, risk_7_10_0, person_7_10_0):
    return dictionary_person_7_10_0[(person_7_9_0, risk_7_10_0, person_7_10_0)]

dictionary_observe_7_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8446706176177179, ('false', 'false'): 1.0, ('true', 'true'): 0.1553293823822821}
def f_observe_7_10_0(person_7_10_0, observe_7_10_0):
    return dictionary_observe_7_10_0[(person_7_10_0, observe_7_10_0)]

dictionary_person_8_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_8_10_0(person_8_9_0, risk_8_10_0, person_8_10_0):
    return dictionary_person_8_10_0[(person_8_9_0, risk_8_10_0, person_8_10_0)]

dictionary_observe_8_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.805774764337355, ('false', 'false'): 1.0, ('true', 'true'): 0.19422523566264505}
def f_observe_8_10_0(person_8_10_0, observe_8_10_0):
    return dictionary_observe_8_10_0[(person_8_10_0, observe_8_10_0)]

dictionary_person_9_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.31015811867793586, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5708093285974318, ('false', 'false', 'true', 'false', 'false'): 0.6227808188028627, ('false', 'true', 'false', 'true', 'true'): 0.3108479605592579, ('false', 'false', 'true', 'false', 'true'): 0.37721918119713727, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6891520394407421, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6221580379840599, ('false', 'true', 'true', 'false', 'true'): 0.5703797083057376, ('false', 'true', 'true', 'false', 'false'): 0.42962029169426236, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3778419620159401, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6898418813220641, ('false', 'true', 'true', 'true', 'false'): 0.4291906714025681}
def f_person_9_10_0(person_9_9_0, person_21_9_0, person_7_9_0, risk_9_10_0, person_9_10_0):
    return dictionary_person_9_10_0[(person_9_9_0, person_21_9_0, person_7_9_0, risk_9_10_0, person_9_10_0)]

dictionary_observe_9_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5187022553249433, ('false', 'false'): 1.0, ('true', 'true'): 0.4812977446750567}
def f_observe_9_10_0(person_9_10_0, observe_9_10_0):
    return dictionary_observe_9_10_0[(person_9_10_0, observe_9_10_0)]

dictionary_person_10_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4409798282023032, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5590201717976968, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4405388483741009, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5594611516258992, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_10_10_0(person_10_9_0, person_4_9_0, risk_10_10_0, person_10_10_0):
    return dictionary_person_10_10_0[(person_10_9_0, person_4_9_0, risk_10_10_0, person_10_10_0)]

dictionary_observe_10_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6203266448801916, ('false', 'false'): 1.0, ('true', 'true'): 0.3796733551198084}
def f_observe_10_10_0(person_10_10_0, observe_10_10_0):
    return dictionary_observe_10_10_0[(person_10_10_0, observe_10_10_0)]

dictionary_person_11_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5980004861021488, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.40199951389785116, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5974024856160467, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4025975143839533, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_11_10_0(person_11_9_0, person_10_9_0, risk_11_10_0, person_11_10_0):
    return dictionary_person_11_10_0[(person_11_9_0, person_10_9_0, risk_11_10_0, person_11_10_0)]

dictionary_observe_11_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8676429748389329, ('false', 'false'): 1.0, ('true', 'true'): 0.13235702516106707}
def f_observe_11_10_0(person_11_10_0, observe_11_10_0):
    return dictionary_observe_11_10_0[(person_11_10_0, observe_11_10_0)]

dictionary_person_12_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_12_10_0(person_12_9_0, risk_12_10_0, person_12_10_0):
    return dictionary_person_12_10_0[(person_12_9_0, risk_12_10_0, person_12_10_0)]

dictionary_observe_12_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7870229159172603, ('false', 'false'): 1.0, ('true', 'true'): 0.21297708408273974}
def f_observe_12_10_0(person_12_10_0, observe_12_10_0):
    return dictionary_observe_12_10_0[(person_12_10_0, observe_12_10_0)]

dictionary_person_13_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.30555368810445227, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5991006890527917, ('false', 'false', 'true', 'false', 'false'): 0.5778713266737416, ('false', 'true', 'false', 'true', 'true'): 0.3062481344163478, ('false', 'false', 'true', 'false', 'true'): 0.42212867332625836, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6937518655836522, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5772934553470679, ('false', 'true', 'true', 'false', 'true'): 0.5986993884412328, ('false', 'true', 'true', 'false', 'false'): 0.4013006115587671, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4227065446529321, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6944463118955477, ('false', 'true', 'true', 'true', 'false'): 0.4008993109472084}
def f_person_13_10_0(person_13_9_0, person_1_9_0, person_14_9_0, risk_13_10_0, person_13_10_0):
    return dictionary_person_13_10_0[(person_13_9_0, person_1_9_0, person_14_9_0, risk_13_10_0, person_13_10_0)]

dictionary_observe_13_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9816524222889853, ('false', 'false'): 1.0, ('true', 'true'): 0.018347577711014695}
def f_observe_13_10_0(person_13_10_0, observe_13_10_0):
    return dictionary_observe_13_10_0[(person_13_10_0, observe_13_10_0)]

dictionary_person_14_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.27419073374759184, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.592947003926383, ('false', 'false', 'true', 'false', 'false'): 0.5613877852979192, ('false', 'true', 'false', 'true', 'true'): 0.2749165430138443, ('false', 'false', 'true', 'false', 'true'): 0.4386122147020808, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7250834569861557, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5608263975126213, ('false', 'true', 'true', 'false', 'true'): 0.5925395434698528, ('false', 'true', 'true', 'false', 'false'): 0.4074604565301472, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4391736024873787, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7258092662524082, ('false', 'true', 'true', 'true', 'false'): 0.407052996073617}
def f_person_14_10_0(person_14_9_0, person_8_9_0, person_15_9_0, risk_14_10_0, person_14_10_0):
    return dictionary_person_14_10_0[(person_14_9_0, person_8_9_0, person_15_9_0, risk_14_10_0, person_14_10_0)]

dictionary_observe_14_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6002461022788265, ('false', 'false'): 1.0, ('true', 'true'): 0.39975389772117353}
def f_observe_14_10_0(person_14_10_0, observe_14_10_0):
    return dictionary_observe_14_10_0[(person_14_10_0, observe_14_10_0)]

dictionary_person_15_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.38625102031711345, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.6137489796828866, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.3858647692967963, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.6141352307032037, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_15_10_0(person_15_9_0, person_11_9_0, risk_15_10_0, person_15_10_0):
    return dictionary_person_15_10_0[(person_15_9_0, person_11_9_0, risk_15_10_0, person_15_10_0)]

dictionary_observe_15_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9269688552629007, ('false', 'false'): 1.0, ('true', 'true'): 0.07303114473709926}
def f_observe_15_10_0(person_15_10_0, observe_15_10_0):
    return dictionary_observe_15_10_0[(person_15_10_0, observe_15_10_0)]

dictionary_person_16_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6147835904437109, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3852164095562891, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6141688068532671, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.38583119314673286, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_16_10_0(person_16_9_0, person_22_9_0, risk_16_10_0, person_16_10_0):
    return dictionary_person_16_10_0[(person_16_9_0, person_22_9_0, risk_16_10_0, person_16_10_0)]

dictionary_observe_16_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9780810833882694, ('false', 'false'): 1.0, ('true', 'true'): 0.02191891661173062}
def f_observe_16_10_0(person_16_10_0, observe_16_10_0):
    return dictionary_observe_16_10_0[(person_16_10_0, observe_16_10_0)]

dictionary_person_17_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5599992295249845, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4400007704750155, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5594392302954595, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4405607697045405, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_17_10_0(person_17_9_0, person_12_9_0, risk_17_10_0, person_17_10_0):
    return dictionary_person_17_10_0[(person_17_9_0, person_12_9_0, risk_17_10_0, person_17_10_0)]

dictionary_observe_17_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7851598685055271, ('false', 'false'): 1.0, ('true', 'true'): 0.2148401314944729}
def f_observe_17_10_0(person_17_10_0, observe_17_10_0):
    return dictionary_observe_17_10_0[(person_17_10_0, observe_17_10_0)]

dictionary_person_18_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_18_10_0(person_18_9_0, risk_18_10_0, person_18_10_0):
    return dictionary_person_18_10_0[(person_18_9_0, risk_18_10_0, person_18_10_0)]

dictionary_observe_18_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7078341497935091, ('false', 'false'): 1.0, ('true', 'true'): 0.2921658502064909}
def f_observe_18_10_0(person_18_10_0, observe_18_10_0):
    return dictionary_observe_18_10_0[(person_18_10_0, observe_18_10_0)]

dictionary_person_19_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.42534302886932096, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.4671374970380635, ('false', 'false', 'true', 'false', 'false'): 0.9281987788494106, ('false', 'true', 'false', 'true', 'true'): 0.42591768584045164, ('false', 'false', 'true', 'false', 'true'): 0.0718012211505894, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5740823141595484, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.9272705800705612, ('false', 'true', 'true', 'false', 'true'): 0.4666041011392027, ('false', 'true', 'true', 'false', 'false'): 0.5333958988607973, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.07272941992943882, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.574656971130679, ('false', 'true', 'true', 'true', 'false'): 0.5328625029619365}
def f_person_19_10_0(person_19_9_0, person_25_9_0, person_13_9_0, risk_19_10_0, person_19_10_0):
    return dictionary_person_19_10_0[(person_19_9_0, person_25_9_0, person_13_9_0, risk_19_10_0, person_19_10_0)]

dictionary_observe_19_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8508082903522972, ('false', 'false'): 1.0, ('true', 'true'): 0.14919170964770279}
def f_observe_19_10_0(person_19_10_0, observe_19_10_0):
    return dictionary_observe_19_10_0[(person_19_10_0, observe_19_10_0)]

dictionary_person_20_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.4033288702291813, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7064829865557618, ('false', 'false', 'true', 'false', 'false'): 0.49241669256120946, ('false', 'true', 'false', 'true', 'true'): 0.4039255413589521, ('false', 'false', 'true', 'false', 'true'): 0.5075833074387905, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5960744586410479, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.49192427586864823, ('false', 'true', 'true', 'false', 'true'): 0.7061891757314933, ('false', 'true', 'true', 'false', 'false'): 0.29381082426850674, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5080757241313518, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5966711297708187, ('false', 'true', 'true', 'true', 'false'): 0.29351701344423825}
def f_person_20_10_0(person_20_9_0, person_14_9_0, person_19_9_0, risk_20_10_0, person_20_10_0):
    return dictionary_person_20_10_0[(person_20_9_0, person_14_9_0, person_19_9_0, risk_20_10_0, person_20_10_0)]

dictionary_observe_20_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.46053399739418666, ('false', 'false'): 1.0, ('true', 'true'): 0.5394660026058133}
def f_observe_20_10_0(person_20_10_0, observe_20_10_0):
    return dictionary_observe_20_10_0[(person_20_10_0, observe_20_10_0)]

dictionary_person_21_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.21349316891965775, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5199656188088614, ('false', 'false', 'true', 'false', 'false'): 0.6109481534028036, ('false', 'true', 'false', 'true', 'true'): 0.21427967575073814, ('false', 'false', 'true', 'false', 'true'): 0.3890518465971964, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7857203242492619, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6103372052494008, ('false', 'true', 'true', 'false', 'true'): 0.5194851039127741, ('false', 'true', 'true', 'false', 'false'): 0.48051489608722586, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3896627947505992, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7865068310803423, ('false', 'true', 'true', 'true', 'false'): 0.4800343811911386}
def f_person_21_10_0(person_21_9_0, person_20_9_0, person_22_9_0, risk_21_10_0, person_21_10_0):
    return dictionary_person_21_10_0[(person_21_9_0, person_20_9_0, person_22_9_0, risk_21_10_0, person_21_10_0)]

dictionary_observe_21_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6462267106173261, ('false', 'false'): 1.0, ('true', 'true'): 0.35377328938267394}
def f_observe_21_10_0(person_21_10_0, observe_21_10_0):
    return dictionary_observe_21_10_0[(person_21_10_0, observe_21_10_0)]

dictionary_person_22_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_22_10_0(person_22_9_0, risk_22_10_0, person_22_10_0):
    return dictionary_person_22_10_0[(person_22_9_0, risk_22_10_0, person_22_10_0)]

dictionary_observe_22_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9080084117743936, ('false', 'false'): 1.0, ('true', 'true'): 0.09199158822560638}
def f_observe_22_10_0(person_22_10_0, observe_22_10_0):
    return dictionary_observe_22_10_0[(person_22_10_0, observe_22_10_0)]

dictionary_person_23_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7793621121281932, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.22063788787180683, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.778582750016065, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.22141724998393497, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_23_10_0(person_23_9_0, person_22_9_0, risk_23_10_0, person_23_10_0):
    return dictionary_person_23_10_0[(person_23_9_0, person_22_9_0, risk_23_10_0, person_23_10_0)]

dictionary_observe_23_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5617947466209715, ('false', 'false'): 1.0, ('true', 'true'): 0.4382052533790285}
def f_observe_23_10_0(person_23_10_0, observe_23_10_0):
    return dictionary_observe_23_10_0[(person_23_10_0, observe_23_10_0)]

dictionary_person_24_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6006195360044204, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3993804639955796, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.600018916468416, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.399981083531584, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_24_10_0(person_24_9_0, person_18_9_0, risk_24_10_0, person_24_10_0):
    return dictionary_person_24_10_0[(person_24_9_0, person_18_9_0, risk_24_10_0, person_24_10_0)]

dictionary_observe_24_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6261304062266204, ('false', 'false'): 1.0, ('true', 'true'): 0.3738695937733796}
def f_observe_24_10_0(person_24_10_0, observe_24_10_0):
    return dictionary_observe_24_10_0[(person_24_10_0, observe_24_10_0)]

dictionary_person_25_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_25_10_0(person_25_9_0, risk_25_10_0, person_25_10_0):
    return dictionary_person_25_10_0[(person_25_9_0, risk_25_10_0, person_25_10_0)]

dictionary_observe_25_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.48051245890259353, ('false', 'false'): 1.0, ('true', 'true'): 0.5194875410974065}
def f_observe_25_10_0(person_25_10_0, observe_25_10_0):
    return dictionary_observe_25_10_0[(person_25_10_0, observe_25_10_0)]

dictionary_person_26_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3881740349531313, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6910323634570159, ('false', 'false', 'true', 'false', 'false'): 0.5054981826944014, ('false', 'true', 'false', 'true', 'true'): 0.3887858609181781, ('false', 'false', 'true', 'false', 'true'): 0.4945018173055986, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6112141390818219, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.504992684511707, ('false', 'true', 'true', 'false', 'true'): 0.6907230865435595, ('false', 'true', 'true', 'false', 'false'): 0.3092769134564405, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.495007315488293, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6118259650468687, ('false', 'true', 'true', 'true', 'false'): 0.30896763654298404}
def f_person_26_10_0(person_26_9_0, person_20_9_0, person_32_9_0, risk_26_10_0, person_26_10_0):
    return dictionary_person_26_10_0[(person_26_9_0, person_20_9_0, person_32_9_0, risk_26_10_0, person_26_10_0)]

dictionary_observe_26_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8178274809401013, ('false', 'false'): 1.0, ('true', 'true'): 0.18217251905989873}
def f_observe_26_10_0(person_26_10_0, observe_26_10_0):
    return dictionary_observe_26_10_0[(person_26_10_0, observe_26_10_0)]

dictionary_person_27_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_27_10_0(person_27_9_0, risk_27_10_0, person_27_10_0):
    return dictionary_person_27_10_0[(person_27_9_0, risk_27_10_0, person_27_10_0)]

dictionary_observe_27_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6953639651888881, ('false', 'false'): 1.0, ('true', 'true'): 0.3046360348111119}
def f_observe_27_10_0(person_27_10_0, observe_27_10_0):
    return dictionary_observe_27_10_0[(person_27_10_0, observe_27_10_0)]

dictionary_person_28_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_28_10_0(person_28_9_0, risk_28_10_0, person_28_10_0):
    return dictionary_person_28_10_0[(person_28_9_0, risk_28_10_0, person_28_10_0)]

dictionary_observe_28_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.639447896579326, ('false', 'false'): 1.0, ('true', 'true'): 0.360552103420674}
def f_observe_28_10_0(person_28_10_0, observe_28_10_0):
    return dictionary_observe_28_10_0[(person_28_10_0, observe_28_10_0)]

dictionary_person_29_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.37788964698108873, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5734811705277576, ('false', 'false', 'true', 'false', 'false'): 0.6862862403360634, ('false', 'true', 'false', 'true', 'true'): 0.3785117573341077, ('false', 'false', 'true', 'false', 'true'): 0.31371375966393655, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6214882426658923, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6855999540957274, ('false', 'true', 'true', 'false', 'true'): 0.5730542247525101, ('false', 'true', 'true', 'false', 'false'): 0.42694577524748983, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3144000459042726, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6221103530189113, ('false', 'true', 'true', 'true', 'false'): 0.42651882947224234}
def f_person_29_10_0(person_29_9_0, person_28_9_0, person_35_9_0, risk_29_10_0, person_29_10_0):
    return dictionary_person_29_10_0[(person_29_9_0, person_28_9_0, person_35_9_0, risk_29_10_0, person_29_10_0)]

dictionary_observe_29_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9780847312187564, ('false', 'false'): 1.0, ('true', 'true'): 0.021915268781243613}
def f_observe_29_10_0(person_29_10_0, observe_29_10_0):
    return dictionary_observe_29_10_0[(person_29_10_0, observe_29_10_0)]

dictionary_person_30_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5819331936566872, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.41806680634331284, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5813512604630304, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.41864873953696957, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_30_10_0(person_30_9_0, person_24_9_0, risk_30_10_0, person_30_10_0):
    return dictionary_person_30_10_0[(person_30_9_0, person_24_9_0, risk_30_10_0, person_30_10_0)]

dictionary_observe_30_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6640775447892784, ('false', 'false'): 1.0, ('true', 'true'): 0.3359224552107216}
def f_observe_30_10_0(person_30_10_0, observe_30_10_0):
    return dictionary_observe_30_10_0[(person_30_10_0, observe_30_10_0)]

dictionary_person_31_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3619057625991634, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5743817655085137, ('false', 'false', 'true', 'false', 'false'): 0.6676823794956558, ('false', 'true', 'false', 'true', 'true'): 0.3625438568365642, ('false', 'false', 'true', 'false', 'true'): 0.3323176205043442, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6374561431634358, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6670146971161601, ('false', 'true', 'true', 'false', 'true'): 0.5739557212297435, ('false', 'true', 'true', 'false', 'false'): 0.42604427877025647, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3329853028838399, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6380942374008366, ('false', 'true', 'true', 'true', 'false'): 0.4256182344914862}
def f_person_31_10_0(person_31_9_0, person_25_9_0, person_1_9_0, risk_31_10_0, person_31_10_0):
    return dictionary_person_31_10_0[(person_31_9_0, person_25_9_0, person_1_9_0, risk_31_10_0, person_31_10_0)]

dictionary_observe_31_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.407926537821251, ('false', 'false'): 1.0, ('true', 'true'): 0.592073462178749}
def f_observe_31_10_0(person_31_10_0, observe_31_10_0):
    return dictionary_observe_31_10_0[(person_31_10_0, observe_31_10_0)]

dictionary_person_32_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5919263840566449, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4080736159433551, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5913344576725882, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4086655423274118, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_32_10_0(person_32_9_0, person_33_9_0, risk_32_10_0, person_32_10_0):
    return dictionary_person_32_10_0[(person_32_9_0, person_33_9_0, risk_32_10_0, person_32_10_0)]

dictionary_observe_32_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9654013759083969, ('false', 'false'): 1.0, ('true', 'true'): 0.03459862409160308}
def f_observe_32_10_0(person_32_10_0, observe_32_10_0):
    return dictionary_observe_32_10_0[(person_32_10_0, observe_32_10_0)]

dictionary_person_33_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6084525714601108, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3915474285398892, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6078441188886506, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.39215588111134936, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_33_10_0(person_33_9_0, person_27_9_0, risk_33_10_0, person_33_10_0):
    return dictionary_person_33_10_0[(person_33_9_0, person_27_9_0, risk_33_10_0, person_33_10_0)]

dictionary_observe_33_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7190136967248786, ('false', 'false'): 1.0, ('true', 'true'): 0.2809863032751214}
def f_observe_33_10_0(person_33_10_0, observe_33_10_0):
    return dictionary_observe_33_10_0[(person_33_10_0, observe_33_10_0)]

dictionary_person_34_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.20291175255985394, ('false', 'true', 'false', 'false', 'false', 'true'): 0.38769333296498587, ('false', 'true', 'true', 'false', 'true', 'true'): 0.6177068018398486, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.38229319816015145, ('false', 'true', 'false', 'false', 'false', 'false'): 0.6123066670350141, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.6116943603679791, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.37502579240689093, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.7970882474401461, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.7968851325727188, ('false', 'false', 'true', 'false', 'false', 'false'): 0.6249742075931091, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.32499719981967584, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.3246722026198562, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.6750028001803241, ('false', 'false', 'false', 'true', 'false', 'true'): 0.46922478993505523, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.3883056396320209, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.20311486742728121, ('false', 'false', 'true', 'false', 'true', 'false'): 0.624349233385516, ('false', 'true', 'true', 'false', 'false', 'false'): 0.3826758740341856, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.6682791836795952, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.6753277973801438, ('false', 'false', 'false', 'true', 'true', 'false'): 0.5302444348548798, ('false', 'false', 'false', 'true', 'false', 'false'): 0.5307752100649448, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.33172081632040484, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.6686109044959155, ('false', 'false', 'true', 'false', 'true', 'true'): 0.37565076661448404, ('false', 'false', 'false', 'true', 'true', 'true'): 0.4697555651451202, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.6173241259658144, ('false', 'false', 'true', 'true', 'true', 'false'): 0.33138909550408446}
def f_person_34_10_0(person_34_9_0, person_35_9_0, person_4_9_0, person_10_9_0, risk_34_10_0, person_34_10_0):
    return dictionary_person_34_10_0[(person_34_9_0, person_35_9_0, person_4_9_0, person_10_9_0, risk_34_10_0, person_34_10_0)]

dictionary_observe_34_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8557028546671084, ('false', 'false'): 1.0, ('true', 'true'): 0.14429714533289162}
def f_observe_34_10_0(person_34_10_0, observe_34_10_0):
    return dictionary_observe_34_10_0[(person_34_10_0, observe_34_10_0)]

dictionary_person_35_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_35_10_0(person_35_9_0, risk_35_10_0, person_35_10_0):
    return dictionary_person_35_10_0[(person_35_9_0, risk_35_10_0, person_35_10_0)]

dictionary_observe_35_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.47488430438842677, ('false', 'false'): 1.0, ('true', 'true'): 0.5251156956115732}
def f_observe_35_10_0(person_35_10_0, observe_35_10_0):
    return dictionary_observe_35_10_0[(person_35_10_0, observe_35_10_0)]

functions = [f_person_0_7_0, f_person_1_7_0, f_person_2_7_0, f_person_3_7_0, f_person_4_7_0, f_person_5_7_0, f_person_6_7_0, f_person_7_7_0, f_person_8_7_0, f_person_9_7_0, f_person_10_7_0, f_person_11_7_0, f_person_12_7_0, f_person_13_7_0, f_person_14_7_0, f_person_15_7_0, f_person_16_7_0, f_person_17_7_0, f_person_18_7_0, f_person_19_7_0, f_person_20_7_0, f_person_21_7_0, f_person_22_7_0, f_person_23_7_0, f_person_24_7_0, f_person_25_7_0, f_person_26_7_0, f_person_27_7_0, f_person_28_7_0, f_person_29_7_0, f_person_30_7_0, f_person_31_7_0, f_person_32_7_0, f_person_33_7_0, f_person_34_7_0, f_person_35_7_0, f_risk_0_8_0, f_risk_1_8_0, f_risk_2_8_0, f_risk_3_8_0, f_risk_4_8_0, f_risk_5_8_0, f_risk_6_8_0, f_risk_7_8_0, f_risk_8_8_0, f_risk_9_8_0, f_risk_10_8_0, f_risk_11_8_0, f_risk_12_8_0, f_risk_13_8_0, f_risk_14_8_0, f_risk_15_8_0, f_risk_16_8_0, f_risk_17_8_0, f_risk_18_8_0, f_risk_19_8_0, f_risk_20_8_0, f_risk_20_8_1, f_risk_21_8_0, f_risk_22_8_0, f_risk_23_8_0, f_risk_24_8_0, f_risk_25_8_0, f_risk_26_8_0, f_risk_27_8_0, f_risk_28_8_0, f_risk_29_8_0, f_risk_30_8_0, f_risk_31_8_0, f_risk_32_8_0, f_risk_33_8_0, f_risk_34_8_0, f_risk_35_8_0, f_risk_0_9_0, f_risk_1_9_0, f_risk_2_9_0, f_risk_3_9_0, f_risk_4_9_0, f_risk_5_9_0, f_risk_6_9_0, f_risk_7_9_0, f_risk_8_9_0, f_risk_9_9_0, f_risk_10_9_0, f_risk_11_9_0, f_risk_12_9_0, f_risk_13_9_0, f_risk_14_9_0, f_risk_15_9_0, f_risk_16_9_0, f_risk_17_9_0, f_risk_18_9_0, f_risk_19_9_0, f_risk_20_9_0, f_risk_21_9_0, f_risk_22_9_0, f_risk_23_9_0, f_risk_24_9_0, f_risk_25_9_0, f_risk_26_9_0, f_risk_27_9_0, f_risk_28_9_0, f_risk_29_9_0, f_risk_30_9_0, f_risk_31_9_0, f_risk_32_9_0, f_risk_33_9_0, f_risk_34_9_0, f_risk_35_9_0, f_risk_0_10_0, f_risk_1_10_0, f_risk_2_10_0, f_risk_3_10_0, f_risk_4_10_0, f_risk_5_10_0, f_risk_6_10_0, f_risk_7_10_0, f_risk_8_10_0, f_risk_9_10_0, f_risk_10_10_0, f_risk_11_10_0, f_risk_12_10_0, f_risk_13_10_0, f_risk_14_10_0, f_risk_15_10_0, f_risk_16_10_0, f_risk_17_10_0, f_risk_18_10_0, f_risk_19_10_0, f_risk_20_10_0, f_risk_21_10_0, f_risk_22_10_0, f_risk_23_10_0, f_risk_24_10_0, f_risk_25_10_0, f_risk_26_10_0, f_risk_27_10_0, f_risk_28_10_0, f_risk_29_10_0, f_risk_30_10_0, f_risk_31_10_0, f_risk_32_10_0, f_risk_33_10_0, f_risk_34_10_0, f_risk_35_10_0, f_observe_0_7_0, f_observe_1_7_0, f_observe_2_7_0, f_observe_3_7_0, f_observe_4_7_0, f_observe_5_7_0, f_observe_6_7_0, f_observe_7_7_0, f_observe_8_7_0, f_observe_9_7_0, f_observe_10_7_0, f_observe_11_7_0, f_observe_12_7_0, f_observe_13_7_0, f_observe_14_7_0, f_observe_15_7_0, f_observe_16_7_0, f_observe_17_7_0, f_observe_18_7_0, f_observe_19_7_0, f_observe_20_7_0, f_observe_21_7_0, f_observe_22_7_0, f_observe_23_7_0, f_observe_24_7_0, f_observe_25_7_0, f_observe_26_7_0, f_observe_27_7_0, f_observe_28_7_0, f_observe_29_7_0, f_observe_30_7_0, f_observe_31_7_0, f_observe_32_7_0, f_observe_33_7_0, f_observe_34_7_0, f_observe_35_7_0, f_person_0_8_0, f_observe_0_8_0, f_person_1_8_0, f_observe_1_8_0, f_person_2_8_0, f_observe_2_8_0, f_person_3_8_0, f_observe_3_8_0, f_person_4_8_0, f_observe_4_8_0, f_person_5_8_0, f_observe_5_8_0, f_person_6_8_0, f_observe_6_8_0, f_person_7_8_0, f_observe_7_8_0, f_person_8_8_0, f_observe_8_8_0, f_person_9_8_0, f_observe_9_8_0, f_person_10_8_0, f_observe_10_8_0, f_person_11_8_0, f_observe_11_8_0, f_person_12_8_0, f_observe_12_8_0, f_person_13_8_0, f_observe_13_8_0, f_person_14_8_0, f_observe_14_8_0, f_person_15_8_0, f_observe_15_8_0, f_person_16_8_0, f_observe_16_8_0, f_person_17_8_0, f_observe_17_8_0, f_person_18_8_0, f_observe_18_8_0, f_person_19_8_0, f_observe_19_8_0, f_person_20_8_0, f_observe_20_8_0, f_person_21_8_0, f_observe_21_8_0, f_person_22_8_0, f_observe_22_8_0, f_person_23_8_0, f_observe_23_8_0, f_person_24_8_0, f_observe_24_8_0, f_person_25_8_0, f_observe_25_8_0, f_person_26_8_0, f_observe_26_8_0, f_person_27_8_0, f_observe_27_8_0, f_person_28_8_0, f_observe_28_8_0, f_person_29_8_0, f_observe_29_8_0, f_person_30_8_0, f_observe_30_8_0, f_person_31_8_0, f_observe_31_8_0, f_person_32_8_0, f_observe_32_8_0, f_person_33_8_0, f_observe_33_8_0, f_person_34_8_0, f_observe_34_8_0, f_person_35_8_0, f_observe_35_8_0, f_person_0_9_0, f_observe_0_9_0, f_person_1_9_0, f_observe_1_9_0, f_person_2_9_0, f_observe_2_9_0, f_person_3_9_0, f_observe_3_9_0, f_person_4_9_0, f_observe_4_9_0, f_person_5_9_0, f_observe_5_9_0, f_person_6_9_0, f_observe_6_9_0, f_person_7_9_0, f_observe_7_9_0, f_person_8_9_0, f_observe_8_9_0, f_person_9_9_0, f_observe_9_9_0, f_person_10_9_0, f_observe_10_9_0, f_person_11_9_0, f_observe_11_9_0, f_person_12_9_0, f_observe_12_9_0, f_person_13_9_0, f_observe_13_9_0, f_person_14_9_0, f_observe_14_9_0, f_person_15_9_0, f_observe_15_9_0, f_person_16_9_0, f_observe_16_9_0, f_person_17_9_0, f_observe_17_9_0, f_person_18_9_0, f_observe_18_9_0, f_person_19_9_0, f_observe_19_9_0, f_person_20_9_0, f_observe_20_9_0, f_person_21_9_0, f_observe_21_9_0, f_person_22_9_0, f_observe_22_9_0, f_person_23_9_0, f_observe_23_9_0, f_person_24_9_0, f_observe_24_9_0, f_person_25_9_0, f_observe_25_9_0, f_person_26_9_0, f_observe_26_9_0, f_person_27_9_0, f_observe_27_9_0, f_person_28_9_0, f_observe_28_9_0, f_person_29_9_0, f_observe_29_9_0, f_person_30_9_0, f_observe_30_9_0, f_person_31_9_0, f_observe_31_9_0, f_person_32_9_0, f_observe_32_9_0, f_person_33_9_0, f_observe_33_9_0, f_person_34_9_0, f_observe_34_9_0, f_person_35_9_0, f_observe_35_9_0, f_person_0_10_0, f_observe_0_10_0, f_person_1_10_0, f_observe_1_10_0, f_person_2_10_0, f_observe_2_10_0, f_person_3_10_0, f_observe_3_10_0, f_person_4_10_0, f_observe_4_10_0, f_person_5_10_0, f_observe_5_10_0, f_person_6_10_0, f_observe_6_10_0, f_person_7_10_0, f_observe_7_10_0, f_person_8_10_0, f_observe_8_10_0, f_person_9_10_0, f_observe_9_10_0, f_person_10_10_0, f_observe_10_10_0, f_person_11_10_0, f_observe_11_10_0, f_person_12_10_0, f_observe_12_10_0, f_person_13_10_0, f_observe_13_10_0, f_person_14_10_0, f_observe_14_10_0, f_person_15_10_0, f_observe_15_10_0, f_person_16_10_0, f_observe_16_10_0, f_person_17_10_0, f_observe_17_10_0, f_person_18_10_0, f_observe_18_10_0, f_person_19_10_0, f_observe_19_10_0, f_person_20_10_0, f_observe_20_10_0, f_person_21_10_0, f_observe_21_10_0, f_person_22_10_0, f_observe_22_10_0, f_person_23_10_0, f_observe_23_10_0, f_person_24_10_0, f_observe_24_10_0, f_person_25_10_0, f_observe_25_10_0, f_person_26_10_0, f_observe_26_10_0, f_person_27_10_0, f_observe_27_10_0, f_person_28_10_0, f_observe_28_10_0, f_person_29_10_0, f_observe_29_10_0, f_person_30_10_0, f_observe_30_10_0, f_person_31_10_0, f_observe_31_10_0, f_person_32_10_0, f_observe_32_10_0, f_person_33_10_0, f_observe_33_10_0, f_person_34_10_0, f_observe_34_10_0, f_person_35_10_0, f_observe_35_10_0]
domains_dict = {'person_33_7_0': ['false', 'true'], 'person_4_7_0': ['false', 'true'], 'risk_13_8_0': ['false', 'true'], 'risk_6_8_0': ['false', 'true'], 'person_31_7_0': ['false', 'true'], 'risk_2_9_0': ['false', 'true'], 'person_17_8_0': ['false', 'true'], 'risk_10_9_0': ['false', 'true'], 'observe_23_9_0': ['false', 'true'], 'risk_13_10_0': ['false', 'true'], 'observe_0_10_0': ['false', 'true'], 'person_4_9_0': ['false', 'true'], 'observe_3_10_0': ['false', 'true'], 'person_34_8_0': ['false', 'true'], 'person_31_9_0': ['false', 'true'], 'person_29_10_0': ['false', 'true'], 'person_17_10_0': ['false', 'true'], 'risk_5_10_0': ['false', 'true'], 'risk_23_9_0': ['false', 'true'], 'person_33_10_0': ['false', 'true'], 'person_32_8_0': ['false', 'true'], 'risk_31_10_0': ['false', 'true'], 'person_0_8_0': ['false', 'true'], 'person_9_10_0': ['false', 'true'], 'observe_21_10_0': ['false', 'true'], 'person_27_7_0': ['false', 'true'], 'risk_12_10_0': ['false', 'true'], 'risk_27_10_0': ['false', 'true'], 'risk_26_8_0': ['false', 'true'], 'observe_30_8_0': ['false', 'true'], 'risk_21_9_0': ['false', 'true'], 'person_25_7_0': ['false', 'true'], 'person_2_8_0': ['false', 'true'], 'observe_4_10_0': ['false', 'true'], 'person_31_10_0': ['false', 'true'], 'person_5_10_0': ['false', 'true'], 'person_18_10_0': ['false', 'true'], 'observe_7_8_0': ['false', 'true'], 'person_25_9_0': ['false', 'true'], 'person_29_9_0': ['false', 'true'], 'person_16_9_0': ['false', 'true'], 'observe_15_8_0': ['false', 'true'], 'risk_28_9_0': ['false', 'true'], 'observe_35_9_0': ['false', 'true'], 'observe_35_7_0': ['false', 'true'], 'risk_0_9_0': ['false', 'true'], 'observe_25_8_0': ['false', 'true'], 'person_7_9_0': ['false', 'true'], 'person_27_8_0': ['false', 'true'], 'person_10_8_0': ['false', 'true'], 'risk_18_9_0': ['false', 'true'], 'person_29_7_0': ['false', 'true'], 'person_1_10_0': ['false', 'true'], 'observe_18_8_0': ['false', 'true'], 'person_26_9_0': ['false', 'true'], 'risk_34_8_0': ['false', 'true'], 'risk_29_8_0': ['false', 'true'], 'risk_24_9_0': ['false', 'true'], 'person_22_10_0': ['false', 'true'], 'observe_25_7_0': ['false', 'true'], 'person_24_9_0': ['false', 'true'], 'observe_1_8_0': ['false', 'true'], 'person_21_8_0': ['false', 'true'], 'risk_11_9_0': ['false', 'true'], 'observe_21_8_0': ['false', 'true'], 'observe_23_10_0': ['false', 'true'], 'observe_27_7_0': ['false', 'true'], 'person_15_8_0': ['false', 'true'], 'risk_8_8_0': ['false', 'true'], 'person_25_10_0': ['false', 'true'], 'risk_34_10_0': ['false', 'true'], 'observe_13_10_0': ['false', 'true'], 'observe_1_10_0': ['false', 'true'], 'person_7_10_0': ['false', 'true'], 'observe_17_9_0': ['false', 'true'], 'person_24_7_0': ['false', 'true'], 'observe_35_10_0': ['false', 'true'], 'person_7_7_0': ['false', 'true'], 'person_11_9_0': ['false', 'true'], 'risk_1_10_0': ['false', 'true'], 'observe_23_8_0': ['false', 'true'], 'observe_18_7_0': ['false', 'true'], 'person_17_9_0': ['false', 'true'], 'observe_27_9_0': ['false', 'true'], 'risk_2_8_0': ['false', 'true'], 'risk_3_9_0': ['false', 'true'], 'person_14_10_0': ['false', 'true'], 'person_34_9_0': ['false', 'true'], 'risk_23_8_0': ['false', 'true'], 'person_12_10_0': ['false', 'true'], 'person_11_7_0': ['false', 'true'], 'observe_7_10_0': ['false', 'true'], 'risk_13_9_0': ['false', 'true'], 'observe_32_10_0': ['false', 'true'], 'person_32_7_0': ['false', 'true'], 'person_3_10_0': ['false', 'true'], 'person_0_9_0': ['false', 'true'], 'person_32_9_0': ['false', 'true'], 'person_14_8_0': ['false', 'true'], 'person_0_7_0': ['false', 'true'], 'observe_23_7_0': ['false', 'true'], 'observe_5_10_0': ['false', 'true'], 'observe_33_10_0': ['false', 'true'], 'risk_21_8_0': ['false', 'true'], 'risk_7_10_0': ['false', 'true'], 'observe_9_8_0': ['false', 'true'], 'person_3_8_0': ['false', 'true'], 'person_8_9_0': ['false', 'true'], 'observe_32_7_0': ['false', 'true'], 'observe_32_9_0': ['false', 'true'], 'risk_22_9_0': ['false', 'true'], 'person_6_7_0': ['false', 'true'], 'risk_28_8_0': ['false', 'true'], 'person_11_10_0': ['false', 'true'], 'observe_25_9_0': ['false', 'true'], 'person_7_8_0': ['false', 'true'], 'risk_14_10_0': ['false', 'true'], 'person_20_8_0': ['false', 'true'], 'person_3_7_0': ['false', 'true'], 'risk_18_8_0': ['false', 'true'], 'risk_30_10_0': ['false', 'true'], 'person_14_7_0': ['false', 'true'], 'person_1_7_0': ['false', 'true'], 'observe_1_7_0': ['false', 'true'], 'risk_20_8_1': ['false', 'true'], 'observe_16_9_0': ['false', 'true'], 'observe_11_9_0': ['false', 'true'], 'risk_34_9_0': ['false', 'true'], 'risk_29_9_0': ['false', 'true'], 'observe_16_7_0': ['false', 'true'], 'person_19_9_0': ['false', 'true'], 'person_20_7_0': ['false', 'true'], 'observe_0_8_0': ['false', 'true'], 'person_5_8_0': ['false', 'true'], 'person_24_8_0': ['false', 'true'], 'risk_8_9_0': ['false', 'true'], 'person_22_7_0': ['false', 'true'], 'risk_11_8_0': ['false', 'true'], 'person_1_9_0': ['false', 'true'], 'risk_10_10_0': ['false', 'true'], 'observe_34_9_0': ['false', 'true'], 'observe_13_8_0': ['false', 'true'], 'risk_31_8_0': ['false', 'true'], 'person_6_9_0': ['false', 'true'], 'risk_2_10_0': ['false', 'true'], 'observe_2_8_0': ['false', 'true'], 'risk_19_8_0': ['false', 'true'], 'person_26_8_0': ['false', 'true'], 'person_11_8_0': ['false', 'true'], 'person_22_9_0': ['false', 'true'], 'observe_27_8_0': ['false', 'true'], 'risk_32_10_0': ['false', 'true'], 'risk_3_8_0': ['false', 'true'], 'observe_26_9_0': ['false', 'true'], 'risk_3_10_0': ['false', 'true'], 'observe_34_7_0': ['false', 'true'], 'observe_25_10_0': ['false', 'true'], 'person_27_10_0': ['false', 'true'], 'observe_26_7_0': ['false', 'true'], 'risk_8_10_0': ['false', 'true'], 'observe_1_9_0': ['false', 'true'], 'observe_29_10_0': ['false', 'true'], 'risk_17_8_0': ['false', 'true'], 'person_32_10_0': ['false', 'true'], 'observe_28_9_0': ['false', 'true'], 'person_5_7_0': ['false', 'true'], 'risk_25_8_0': ['false', 'true'], 'risk_33_9_0': ['false', 'true'], 'risk_23_10_0': ['false', 'true'], 'person_8_7_0': ['false', 'true'], 'person_26_7_0': ['false', 'true'], 'person_14_9_0': ['false', 'true'], 'observe_34_8_0': ['false', 'true'], 'observe_2_7_0': ['false', 'true'], 'person_6_10_0': ['false', 'true'], 'observe_9_9_0': ['false', 'true'], 'risk_22_10_0': ['false', 'true'], 'person_3_9_0': ['false', 'true'], 'person_8_8_0': ['false', 'true'], 'observe_34_10_0': ['false', 'true'], 'observe_32_8_0': ['false', 'true'], 'observe_33_9_0': ['false', 'true'], 'risk_22_8_0': ['false', 'true'], 'person_20_9_0': ['false', 'true'], 'person_6_8_0': ['false', 'true'], 'observe_10_7_0': ['false', 'true'], 'observe_4_9_0': ['false', 'true'], 'risk_4_10_0': ['false', 'true'], 'risk_20_9_0': ['false', 'true'], 'person_23_10_0': ['false', 'true'], 'observe_11_8_0': ['false', 'true'], 'observe_33_7_0': ['false', 'true'], 'observe_9_7_0': ['false', 'true'], 'observe_16_8_0': ['false', 'true'], 'person_28_10_0': ['false', 'true'], 'observe_31_7_0': ['false', 'true'], 'person_19_8_0': ['false', 'true'], 'risk_5_8_0': ['false', 'true'], 'observe_0_9_0': ['false', 'true'], 'person_28_8_0': ['false', 'true'], 'person_1_8_0': ['false', 'true'], 'risk_9_8_0': ['false', 'true'], 'observe_30_10_0': ['false', 'true'], 'person_12_8_0': ['false', 'true'], 'risk_31_9_0': ['false', 'true'], 'observe_13_9_0': ['false', 'true'], 'risk_27_8_0': ['false', 'true'], 'observe_31_8_0': ['false', 'true'], 'observe_17_10_0': ['false', 'true'], 'person_19_7_0': ['false', 'true'], 'risk_19_9_0': ['false', 'true'], 'observe_13_7_0': ['false', 'true'], 'observe_9_10_0': ['false', 'true'], 'observe_2_10_0': ['false', 'true'], 'observe_2_9_0': ['false', 'true'], 'risk_7_9_0': ['false', 'true'], 'observe_6_8_0': ['false', 'true'], 'observe_26_8_0': ['false', 'true'], 'person_22_8_0': ['false', 'true'], 'risk_30_8_0': ['false', 'true'], 'person_23_9_0': ['false', 'true'], 'observe_11_7_0': ['false', 'true'], 'observe_15_10_0': ['false', 'true'], 'observe_10_8_0': ['false', 'true'], 'observe_8_7_0': ['false', 'true'], 'person_23_7_0': ['false', 'true'], 'risk_16_8_0': ['false', 'true'], 'observe_8_9_0': ['false', 'true'], 'observe_0_7_0': ['false', 'true'], 'risk_6_10_0': ['false', 'true'], 'risk_1_9_0': ['false', 'true'], 'observe_28_8_0': ['false', 'true'], 'observe_20_10_0': ['false', 'true'], 'observe_6_10_0': ['false', 'true'], 'risk_20_10_0': ['false', 'true'], 'risk_33_8_0': ['false', 'true'], 'risk_14_8_0': ['false', 'true'], 'person_18_8_0': ['false', 'true'], 'person_24_10_0': ['false', 'true'], 'risk_24_10_0': ['false', 'true'], 'observe_12_10_0': ['false', 'true'], 'risk_30_9_0': ['false', 'true'], 'risk_17_9_0': ['false', 'true'], 'observe_3_7_0': ['false', 'true'], 'risk_25_9_0': ['false', 'true'], 'person_9_8_0': ['false', 'true'], 'person_35_8_0': ['false', 'true'], 'observe_28_7_0': ['false', 'true'], 'person_30_8_0': ['false', 'true'], 'observe_33_8_0': ['false', 'true'], 'person_35_10_0': ['false', 'true'], 'risk_35_10_0': ['false', 'true'], 'person_17_7_0': ['false', 'true'], 'observe_3_9_0': ['false', 'true'], 'observe_4_8_0': ['false', 'true'], 'person_33_9_0': ['false', 'true'], 'person_4_10_0': ['false', 'true'], 'observe_18_9_0': ['false', 'true'], 'observe_19_9_0': ['false', 'true'], 'person_12_7_0': ['false', 'true'], 'risk_16_9_0': ['false', 'true'], 'person_28_9_0': ['false', 'true'], 'observe_14_7_0': ['false', 'true'], 'observe_4_7_0': ['false', 'true'], 'observe_20_8_0': ['false', 'true'], 'person_26_10_0': ['false', 'true'], 'risk_5_9_0': ['false', 'true'], 'observe_6_7_0': ['false', 'true'], 'observe_14_9_0': ['false', 'true'], 'person_35_7_0': ['false', 'true'], 'risk_9_9_0': ['false', 'true'], 'person_12_9_0': ['false', 'true'], 'person_8_10_0': ['false', 'true'], 'risk_27_9_0': ['false', 'true'], 'observe_31_9_0': ['false', 'true'], 'observe_5_8_0': ['false', 'true'], 'person_20_10_0': ['false', 'true'], 'risk_7_8_0': ['false', 'true'], 'observe_24_10_0': ['false', 'true'], 'risk_12_9_0': ['false', 'true'], 'observe_22_9_0': ['false', 'true'], 'observe_29_8_0': ['false', 'true'], 'person_23_8_0': ['false', 'true'], 'observe_6_9_0': ['false', 'true'], 'person_16_10_0': ['false', 'true'], 'observe_10_9_0': ['false', 'true'], 'observe_19_10_0': ['false', 'true'], 'risk_35_8_0': ['false', 'true'], 'risk_16_10_0': ['false', 'true'], 'person_28_7_0': ['false', 'true'], 'risk_28_10_0': ['false', 'true'], 'observe_31_10_0': ['false', 'true'], 'observe_24_7_0': ['false', 'true'], 'risk_4_9_0': ['false', 'true'], 'risk_15_10_0': ['false', 'true'], 'risk_1_8_0': ['false', 'true'], 'observe_24_9_0': ['false', 'true'], 'person_13_9_0': ['false', 'true'], 'observe_12_9_0': ['false', 'true'], 'observe_18_10_0': ['false', 'true'], 'person_13_7_0': ['false', 'true'], 'risk_32_8_0': ['false', 'true'], 'risk_6_9_0': ['false', 'true'], 'person_18_7_0': ['false', 'true'], 'risk_14_9_0': ['false', 'true'], 'observe_19_7_0': ['false', 'true'], 'person_13_10_0': ['false', 'true'], 'person_18_9_0': ['false', 'true'], 'risk_10_8_0': ['false', 'true'], 'observe_12_7_0': ['false', 'true'], 'risk_0_10_0': ['false', 'true'], 'observe_22_10_0': ['false', 'true'], 'risk_19_10_0': ['false', 'true'], 'observe_8_8_0': ['false', 'true'], 'person_35_9_0': ['false', 'true'], 'risk_26_10_0': ['false', 'true'], 'observe_10_10_0': ['false', 'true'], 'person_9_9_0': ['false', 'true'], 'person_31_8_0': ['false', 'true'], 'observe_16_10_0': ['false', 'true'], 'person_9_7_0': ['false', 'true'], 'person_30_9_0': ['false', 'true'], 'risk_33_10_0': ['false', 'true'], 'person_19_10_0': ['false', 'true'], 'person_30_7_0': ['false', 'true'], 'person_34_10_0': ['false', 'true'], 'person_15_10_0': ['false', 'true'], 'observe_28_10_0': ['false', 'true'], 'person_4_8_0': ['false', 'true'], 'observe_22_7_0': ['false', 'true'], 'observe_19_8_0': ['false', 'true'], 'observe_12_8_0': ['false', 'true'], 'risk_26_9_0': ['false', 'true'], 'observe_30_9_0': ['false', 'true'], 'observe_30_7_0': ['false', 'true'], 'observe_20_7_0': ['false', 'true'], 'person_0_10_0': ['false', 'true'], 'observe_3_8_0': ['false', 'true'], 'person_21_10_0': ['false', 'true'], 'observe_7_9_0': ['false', 'true'], 'person_25_8_0': ['false', 'true'], 'person_29_8_0': ['false', 'true'], 'risk_9_10_0': ['false', 'true'], 'observe_20_9_0': ['false', 'true'], 'person_16_8_0': ['false', 'true'], 'observe_7_7_0': ['false', 'true'], 'person_2_10_0': ['false', 'true'], 'observe_14_8_0': ['false', 'true'], 'observe_35_8_0': ['false', 'true'], 'observe_15_9_0': ['false', 'true'], 'risk_17_10_0': ['false', 'true'], 'observe_29_7_0': ['false', 'true'], 'risk_15_9_0': ['false', 'true'], 'observe_27_10_0': ['false', 'true'], 'risk_32_9_0': ['false', 'true'], 'risk_12_8_0': ['false', 'true'], 'risk_15_8_0': ['false', 'true'], 'observe_22_8_0': ['false', 'true'], 'risk_0_8_0': ['false', 'true'], 'observe_29_9_0': ['false', 'true'], 'observe_11_10_0': ['false', 'true'], 'person_10_10_0': ['false', 'true'], 'person_27_9_0': ['false', 'true'], 'person_10_9_0': ['false', 'true'], 'risk_35_9_0': ['false', 'true'], 'observe_14_10_0': ['false', 'true'], 'observe_26_10_0': ['false', 'true'], 'observe_15_7_0': ['false', 'true'], 'person_2_7_0': ['false', 'true'], 'person_15_7_0': ['false', 'true'], 'risk_29_10_0': ['false', 'true'], 'person_2_9_0': ['false', 'true'], 'observe_17_7_0': ['false', 'true'], 'risk_24_8_0': ['false', 'true'], 'person_21_7_0': ['false', 'true'], 'risk_25_10_0': ['false', 'true'], 'observe_21_9_0': ['false', 'true'], 'observe_8_10_0': ['false', 'true'], 'person_33_8_0': ['false', 'true'], 'risk_4_8_0': ['false', 'true'], 'observe_24_8_0': ['false', 'true'], 'person_15_9_0': ['false', 'true'], 'risk_21_10_0': ['false', 'true'], 'person_21_9_0': ['false', 'true'], 'person_5_9_0': ['false', 'true'], 'person_10_7_0': ['false', 'true'], 'person_34_7_0': ['false', 'true'], 'person_13_8_0': ['false', 'true'], 'person_30_10_0': ['false', 'true'], 'observe_5_7_0': ['false', 'true'], 'observe_17_8_0': ['false', 'true'], 'person_16_7_0': ['false', 'true'], 'risk_20_8_0': ['false', 'true'], 'observe_5_9_0': ['false', 'true'], 'risk_18_10_0': ['false', 'true'], 'observe_21_7_0': ['false', 'true'], 'risk_11_10_0': ['false', 'true']}

def create_graph():
    g = build_graph(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/d5/data42/infection0'
    return g

def create_bbn():
    g = build_bbn(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/d5/data42/infection0'
    return g

