from bayesian.factor_graph import *
from bayesian.bbn import *

dictionary_person_0_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_0_7_0(person_0_7_0):
    return dictionary_person_0_7_0[person_0_7_0]

dictionary_person_1_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_1_7_0(person_1_7_0):
    return dictionary_person_1_7_0[person_1_7_0]

dictionary_person_2_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_2_7_0(person_2_7_0):
    return dictionary_person_2_7_0[person_2_7_0]

dictionary_person_3_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_3_7_0(person_3_7_0):
    return dictionary_person_3_7_0[person_3_7_0]

dictionary_person_4_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_4_7_0(person_4_7_0):
    return dictionary_person_4_7_0[person_4_7_0]

dictionary_person_5_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_5_7_0(person_5_7_0):
    return dictionary_person_5_7_0[person_5_7_0]

dictionary_person_6_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_6_7_0(person_6_7_0):
    return dictionary_person_6_7_0[person_6_7_0]

dictionary_person_7_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_7_7_0(person_7_7_0):
    return dictionary_person_7_7_0[person_7_7_0]

dictionary_person_8_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_8_7_0(person_8_7_0):
    return dictionary_person_8_7_0[person_8_7_0]

dictionary_person_9_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_9_7_0(person_9_7_0):
    return dictionary_person_9_7_0[person_9_7_0]

dictionary_person_10_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_10_7_0(person_10_7_0):
    return dictionary_person_10_7_0[person_10_7_0]

dictionary_person_11_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_11_7_0(person_11_7_0):
    return dictionary_person_11_7_0[person_11_7_0]

dictionary_person_12_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_12_7_0(person_12_7_0):
    return dictionary_person_12_7_0[person_12_7_0]

dictionary_person_13_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_13_7_0(person_13_7_0):
    return dictionary_person_13_7_0[person_13_7_0]

dictionary_person_14_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_14_7_0(person_14_7_0):
    return dictionary_person_14_7_0[person_14_7_0]

dictionary_person_15_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_15_7_0(person_15_7_0):
    return dictionary_person_15_7_0[person_15_7_0]

dictionary_person_16_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_16_7_0(person_16_7_0):
    return dictionary_person_16_7_0[person_16_7_0]

dictionary_person_17_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_17_7_0(person_17_7_0):
    return dictionary_person_17_7_0[person_17_7_0]

dictionary_person_18_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_18_7_0(person_18_7_0):
    return dictionary_person_18_7_0[person_18_7_0]

dictionary_person_19_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_19_7_0(person_19_7_0):
    return dictionary_person_19_7_0[person_19_7_0]

dictionary_person_20_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_20_7_0(person_20_7_0):
    return dictionary_person_20_7_0[person_20_7_0]

dictionary_person_21_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_21_7_0(person_21_7_0):
    return dictionary_person_21_7_0[person_21_7_0]

dictionary_person_22_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_22_7_0(person_22_7_0):
    return dictionary_person_22_7_0[person_22_7_0]

dictionary_person_23_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_23_7_0(person_23_7_0):
    return dictionary_person_23_7_0[person_23_7_0]

dictionary_person_24_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_24_7_0(person_24_7_0):
    return dictionary_person_24_7_0[person_24_7_0]

dictionary_person_25_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_25_7_0(person_25_7_0):
    return dictionary_person_25_7_0[person_25_7_0]

dictionary_person_26_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_26_7_0(person_26_7_0):
    return dictionary_person_26_7_0[person_26_7_0]

dictionary_person_27_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_27_7_0(person_27_7_0):
    return dictionary_person_27_7_0[person_27_7_0]

dictionary_person_28_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_28_7_0(person_28_7_0):
    return dictionary_person_28_7_0[person_28_7_0]

dictionary_person_29_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_29_7_0(person_29_7_0):
    return dictionary_person_29_7_0[person_29_7_0]

dictionary_person_30_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_30_7_0(person_30_7_0):
    return dictionary_person_30_7_0[person_30_7_0]

dictionary_person_31_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_31_7_0(person_31_7_0):
    return dictionary_person_31_7_0[person_31_7_0]

dictionary_person_32_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_32_7_0(person_32_7_0):
    return dictionary_person_32_7_0[person_32_7_0]

dictionary_person_33_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_33_7_0(person_33_7_0):
    return dictionary_person_33_7_0[person_33_7_0]

dictionary_person_34_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_34_7_0(person_34_7_0):
    return dictionary_person_34_7_0[person_34_7_0]

dictionary_person_35_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_35_7_0(person_35_7_0):
    return dictionary_person_35_7_0[person_35_7_0]

dictionary_risk_0_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_8_0(risk_0_8_0):
    return dictionary_risk_0_8_0[risk_0_8_0]

dictionary_risk_1_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_8_0(risk_1_8_0):
    return dictionary_risk_1_8_0[risk_1_8_0]

dictionary_risk_2_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_8_0(risk_2_8_0):
    return dictionary_risk_2_8_0[risk_2_8_0]

dictionary_risk_3_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_8_0(risk_3_8_0):
    return dictionary_risk_3_8_0[risk_3_8_0]

dictionary_risk_4_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_8_0(risk_4_8_0):
    return dictionary_risk_4_8_0[risk_4_8_0]

dictionary_risk_5_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_8_0(risk_5_8_0):
    return dictionary_risk_5_8_0[risk_5_8_0]

dictionary_risk_6_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_8_0(risk_6_8_0):
    return dictionary_risk_6_8_0[risk_6_8_0]

dictionary_risk_7_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_8_0(risk_7_8_0):
    return dictionary_risk_7_8_0[risk_7_8_0]

dictionary_risk_8_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_8_0(risk_8_8_0):
    return dictionary_risk_8_8_0[risk_8_8_0]

dictionary_risk_9_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_8_0(risk_9_8_0):
    return dictionary_risk_9_8_0[risk_9_8_0]

dictionary_risk_10_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_8_0(risk_10_8_0):
    return dictionary_risk_10_8_0[risk_10_8_0]

dictionary_risk_11_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_8_0(risk_11_8_0):
    return dictionary_risk_11_8_0[risk_11_8_0]

dictionary_risk_12_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_8_0(risk_12_8_0):
    return dictionary_risk_12_8_0[risk_12_8_0]

dictionary_risk_13_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_8_0(risk_13_8_0):
    return dictionary_risk_13_8_0[risk_13_8_0]

dictionary_risk_14_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_8_0(risk_14_8_0):
    return dictionary_risk_14_8_0[risk_14_8_0]

dictionary_risk_15_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_8_0(risk_15_8_0):
    return dictionary_risk_15_8_0[risk_15_8_0]

dictionary_risk_16_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_8_0(risk_16_8_0):
    return dictionary_risk_16_8_0[risk_16_8_0]

dictionary_risk_17_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_8_0(risk_17_8_0):
    return dictionary_risk_17_8_0[risk_17_8_0]

dictionary_risk_18_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_8_0(risk_18_8_0):
    return dictionary_risk_18_8_0[risk_18_8_0]

dictionary_risk_19_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_8_0(risk_19_8_0):
    return dictionary_risk_19_8_0[risk_19_8_0]

dictionary_risk_20_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_8_0(risk_20_8_0):
    return dictionary_risk_20_8_0[risk_20_8_0]

dictionary_risk_21_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_8_0(risk_21_8_0):
    return dictionary_risk_21_8_0[risk_21_8_0]

dictionary_risk_22_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_8_0(risk_22_8_0):
    return dictionary_risk_22_8_0[risk_22_8_0]

dictionary_risk_23_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_8_0(risk_23_8_0):
    return dictionary_risk_23_8_0[risk_23_8_0]

dictionary_risk_24_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_8_0(risk_24_8_0):
    return dictionary_risk_24_8_0[risk_24_8_0]

dictionary_risk_25_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_8_0(risk_25_8_0):
    return dictionary_risk_25_8_0[risk_25_8_0]

dictionary_risk_26_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_8_0(risk_26_8_0):
    return dictionary_risk_26_8_0[risk_26_8_0]

dictionary_risk_27_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_8_0(risk_27_8_0):
    return dictionary_risk_27_8_0[risk_27_8_0]

dictionary_risk_28_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_8_0(risk_28_8_0):
    return dictionary_risk_28_8_0[risk_28_8_0]

dictionary_risk_29_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_8_0(risk_29_8_0):
    return dictionary_risk_29_8_0[risk_29_8_0]

dictionary_risk_30_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_8_0(risk_30_8_0):
    return dictionary_risk_30_8_0[risk_30_8_0]

dictionary_risk_31_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_8_0(risk_31_8_0):
    return dictionary_risk_31_8_0[risk_31_8_0]

dictionary_risk_32_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_8_0(risk_32_8_0):
    return dictionary_risk_32_8_0[risk_32_8_0]

dictionary_risk_33_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_8_0(risk_33_8_0):
    return dictionary_risk_33_8_0[risk_33_8_0]

dictionary_risk_34_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_8_0(risk_34_8_0):
    return dictionary_risk_34_8_0[risk_34_8_0]

dictionary_risk_35_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_8_0(risk_35_8_0):
    return dictionary_risk_35_8_0[risk_35_8_0]

dictionary_risk_0_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_9_0(risk_0_9_0):
    return dictionary_risk_0_9_0[risk_0_9_0]

dictionary_risk_1_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_9_0(risk_1_9_0):
    return dictionary_risk_1_9_0[risk_1_9_0]

dictionary_risk_2_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_9_0(risk_2_9_0):
    return dictionary_risk_2_9_0[risk_2_9_0]

dictionary_risk_3_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_9_0(risk_3_9_0):
    return dictionary_risk_3_9_0[risk_3_9_0]

dictionary_risk_4_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_9_0(risk_4_9_0):
    return dictionary_risk_4_9_0[risk_4_9_0]

dictionary_risk_5_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_9_0(risk_5_9_0):
    return dictionary_risk_5_9_0[risk_5_9_0]

dictionary_risk_6_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_9_0(risk_6_9_0):
    return dictionary_risk_6_9_0[risk_6_9_0]

dictionary_risk_7_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_9_0(risk_7_9_0):
    return dictionary_risk_7_9_0[risk_7_9_0]

dictionary_risk_8_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_9_0(risk_8_9_0):
    return dictionary_risk_8_9_0[risk_8_9_0]

dictionary_risk_9_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_9_0(risk_9_9_0):
    return dictionary_risk_9_9_0[risk_9_9_0]

dictionary_risk_10_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_9_0(risk_10_9_0):
    return dictionary_risk_10_9_0[risk_10_9_0]

dictionary_risk_11_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_9_0(risk_11_9_0):
    return dictionary_risk_11_9_0[risk_11_9_0]

dictionary_risk_12_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_9_0(risk_12_9_0):
    return dictionary_risk_12_9_0[risk_12_9_0]

dictionary_risk_13_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_9_0(risk_13_9_0):
    return dictionary_risk_13_9_0[risk_13_9_0]

dictionary_risk_14_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_9_0(risk_14_9_0):
    return dictionary_risk_14_9_0[risk_14_9_0]

dictionary_risk_15_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_9_0(risk_15_9_0):
    return dictionary_risk_15_9_0[risk_15_9_0]

dictionary_risk_16_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_9_0(risk_16_9_0):
    return dictionary_risk_16_9_0[risk_16_9_0]

dictionary_risk_17_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_9_0(risk_17_9_0):
    return dictionary_risk_17_9_0[risk_17_9_0]

dictionary_risk_17_9_1 = {'true': 1.0, 'false': 0.0}

def f_risk_17_9_1(risk_17_9_1):
    return dictionary_risk_17_9_1[risk_17_9_1]

dictionary_risk_18_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_9_0(risk_18_9_0):
    return dictionary_risk_18_9_0[risk_18_9_0]

dictionary_risk_19_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_9_0(risk_19_9_0):
    return dictionary_risk_19_9_0[risk_19_9_0]

dictionary_risk_20_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_9_0(risk_20_9_0):
    return dictionary_risk_20_9_0[risk_20_9_0]

dictionary_risk_21_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_9_0(risk_21_9_0):
    return dictionary_risk_21_9_0[risk_21_9_0]

dictionary_risk_22_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_9_0(risk_22_9_0):
    return dictionary_risk_22_9_0[risk_22_9_0]

dictionary_risk_23_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_9_0(risk_23_9_0):
    return dictionary_risk_23_9_0[risk_23_9_0]

dictionary_risk_24_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_9_0(risk_24_9_0):
    return dictionary_risk_24_9_0[risk_24_9_0]

dictionary_risk_25_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_9_0(risk_25_9_0):
    return dictionary_risk_25_9_0[risk_25_9_0]

dictionary_risk_26_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_9_0(risk_26_9_0):
    return dictionary_risk_26_9_0[risk_26_9_0]

dictionary_risk_27_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_9_0(risk_27_9_0):
    return dictionary_risk_27_9_0[risk_27_9_0]

dictionary_risk_28_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_9_0(risk_28_9_0):
    return dictionary_risk_28_9_0[risk_28_9_0]

dictionary_risk_29_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_9_0(risk_29_9_0):
    return dictionary_risk_29_9_0[risk_29_9_0]

dictionary_risk_30_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_9_0(risk_30_9_0):
    return dictionary_risk_30_9_0[risk_30_9_0]

dictionary_risk_31_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_9_0(risk_31_9_0):
    return dictionary_risk_31_9_0[risk_31_9_0]

dictionary_risk_32_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_9_0(risk_32_9_0):
    return dictionary_risk_32_9_0[risk_32_9_0]

dictionary_risk_33_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_9_0(risk_33_9_0):
    return dictionary_risk_33_9_0[risk_33_9_0]

dictionary_risk_34_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_9_0(risk_34_9_0):
    return dictionary_risk_34_9_0[risk_34_9_0]

dictionary_risk_34_9_1 = {'true': 1.0, 'false': 0.0}

def f_risk_34_9_1(risk_34_9_1):
    return dictionary_risk_34_9_1[risk_34_9_1]

dictionary_risk_35_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_9_0(risk_35_9_0):
    return dictionary_risk_35_9_0[risk_35_9_0]

dictionary_risk_0_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_10_0(risk_0_10_0):
    return dictionary_risk_0_10_0[risk_0_10_0]

dictionary_risk_1_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_10_0(risk_1_10_0):
    return dictionary_risk_1_10_0[risk_1_10_0]

dictionary_risk_2_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_10_0(risk_2_10_0):
    return dictionary_risk_2_10_0[risk_2_10_0]

dictionary_risk_3_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_10_0(risk_3_10_0):
    return dictionary_risk_3_10_0[risk_3_10_0]

dictionary_risk_4_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_10_0(risk_4_10_0):
    return dictionary_risk_4_10_0[risk_4_10_0]

dictionary_risk_5_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_10_0(risk_5_10_0):
    return dictionary_risk_5_10_0[risk_5_10_0]

dictionary_risk_6_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_10_0(risk_6_10_0):
    return dictionary_risk_6_10_0[risk_6_10_0]

dictionary_risk_7_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_10_0(risk_7_10_0):
    return dictionary_risk_7_10_0[risk_7_10_0]

dictionary_risk_8_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_10_0(risk_8_10_0):
    return dictionary_risk_8_10_0[risk_8_10_0]

dictionary_risk_9_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_10_0(risk_9_10_0):
    return dictionary_risk_9_10_0[risk_9_10_0]

dictionary_risk_10_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_10_0(risk_10_10_0):
    return dictionary_risk_10_10_0[risk_10_10_0]

dictionary_risk_11_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_10_0(risk_11_10_0):
    return dictionary_risk_11_10_0[risk_11_10_0]

dictionary_risk_12_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_10_0(risk_12_10_0):
    return dictionary_risk_12_10_0[risk_12_10_0]

dictionary_risk_13_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_10_0(risk_13_10_0):
    return dictionary_risk_13_10_0[risk_13_10_0]

dictionary_risk_14_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_10_0(risk_14_10_0):
    return dictionary_risk_14_10_0[risk_14_10_0]

dictionary_risk_15_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_10_0(risk_15_10_0):
    return dictionary_risk_15_10_0[risk_15_10_0]

dictionary_risk_16_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_10_0(risk_16_10_0):
    return dictionary_risk_16_10_0[risk_16_10_0]

dictionary_risk_17_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_10_0(risk_17_10_0):
    return dictionary_risk_17_10_0[risk_17_10_0]

dictionary_risk_18_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_10_0(risk_18_10_0):
    return dictionary_risk_18_10_0[risk_18_10_0]

dictionary_risk_19_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_10_0(risk_19_10_0):
    return dictionary_risk_19_10_0[risk_19_10_0]

dictionary_risk_20_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_10_0(risk_20_10_0):
    return dictionary_risk_20_10_0[risk_20_10_0]

dictionary_risk_21_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_10_0(risk_21_10_0):
    return dictionary_risk_21_10_0[risk_21_10_0]

dictionary_risk_22_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_10_0(risk_22_10_0):
    return dictionary_risk_22_10_0[risk_22_10_0]

dictionary_risk_23_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_10_0(risk_23_10_0):
    return dictionary_risk_23_10_0[risk_23_10_0]

dictionary_risk_24_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_10_0(risk_24_10_0):
    return dictionary_risk_24_10_0[risk_24_10_0]

dictionary_risk_24_10_1 = {'true': 1.0, 'false': 0.0}

def f_risk_24_10_1(risk_24_10_1):
    return dictionary_risk_24_10_1[risk_24_10_1]

dictionary_risk_25_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_10_0(risk_25_10_0):
    return dictionary_risk_25_10_0[risk_25_10_0]

dictionary_risk_26_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_10_0(risk_26_10_0):
    return dictionary_risk_26_10_0[risk_26_10_0]

dictionary_risk_27_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_10_0(risk_27_10_0):
    return dictionary_risk_27_10_0[risk_27_10_0]

dictionary_risk_28_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_10_0(risk_28_10_0):
    return dictionary_risk_28_10_0[risk_28_10_0]

dictionary_risk_29_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_10_0(risk_29_10_0):
    return dictionary_risk_29_10_0[risk_29_10_0]

dictionary_risk_30_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_10_0(risk_30_10_0):
    return dictionary_risk_30_10_0[risk_30_10_0]

dictionary_risk_31_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_10_0(risk_31_10_0):
    return dictionary_risk_31_10_0[risk_31_10_0]

dictionary_risk_32_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_10_0(risk_32_10_0):
    return dictionary_risk_32_10_0[risk_32_10_0]

dictionary_risk_33_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_10_0(risk_33_10_0):
    return dictionary_risk_33_10_0[risk_33_10_0]

dictionary_risk_34_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_10_0(risk_34_10_0):
    return dictionary_risk_34_10_0[risk_34_10_0]

dictionary_risk_35_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_10_0(risk_35_10_0):
    return dictionary_risk_35_10_0[risk_35_10_0]

dictionary_observe_0_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.858379029325156, ('false', 'false'): 1.0, ('true', 'true'): 0.14162097067484403}
def f_observe_0_7_0(person_0_7_0, observe_0_7_0):
    return dictionary_observe_0_7_0[(person_0_7_0, observe_0_7_0)]

dictionary_observe_1_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6612728991871955, ('false', 'false'): 1.0, ('true', 'true'): 0.33872710081280455}
def f_observe_1_7_0(person_1_7_0, observe_1_7_0):
    return dictionary_observe_1_7_0[(person_1_7_0, observe_1_7_0)]

dictionary_observe_2_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5128776735058138, ('false', 'false'): 1.0, ('true', 'true'): 0.4871223264941862}
def f_observe_2_7_0(person_2_7_0, observe_2_7_0):
    return dictionary_observe_2_7_0[(person_2_7_0, observe_2_7_0)]

dictionary_observe_3_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5280630036087813, ('false', 'false'): 1.0, ('true', 'true'): 0.47193699639121867}
def f_observe_3_7_0(person_3_7_0, observe_3_7_0):
    return dictionary_observe_3_7_0[(person_3_7_0, observe_3_7_0)]

dictionary_observe_4_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7475176428795471, ('false', 'false'): 1.0, ('true', 'true'): 0.25248235712045286}
def f_observe_4_7_0(person_4_7_0, observe_4_7_0):
    return dictionary_observe_4_7_0[(person_4_7_0, observe_4_7_0)]

dictionary_observe_5_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.803302646694144, ('false', 'false'): 1.0, ('true', 'true'): 0.19669735330585603}
def f_observe_5_7_0(person_5_7_0, observe_5_7_0):
    return dictionary_observe_5_7_0[(person_5_7_0, observe_5_7_0)]

dictionary_observe_6_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6543543859239934, ('false', 'false'): 1.0, ('true', 'true'): 0.3456456140760066}
def f_observe_6_7_0(person_6_7_0, observe_6_7_0):
    return dictionary_observe_6_7_0[(person_6_7_0, observe_6_7_0)]

dictionary_observe_7_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4590945489977125, ('false', 'false'): 1.0, ('true', 'true'): 0.5409054510022875}
def f_observe_7_7_0(person_7_7_0, observe_7_7_0):
    return dictionary_observe_7_7_0[(person_7_7_0, observe_7_7_0)]

dictionary_observe_8_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5591399193518878, ('false', 'false'): 1.0, ('true', 'true'): 0.4408600806481122}
def f_observe_8_7_0(person_8_7_0, observe_8_7_0):
    return dictionary_observe_8_7_0[(person_8_7_0, observe_8_7_0)]

dictionary_observe_9_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5236908021915617, ('false', 'false'): 1.0, ('true', 'true'): 0.4763091978084383}
def f_observe_9_7_0(person_9_7_0, observe_9_7_0):
    return dictionary_observe_9_7_0[(person_9_7_0, observe_9_7_0)]

dictionary_observe_10_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6485130272061546, ('false', 'false'): 1.0, ('true', 'true'): 0.35148697279384544}
def f_observe_10_7_0(person_10_7_0, observe_10_7_0):
    return dictionary_observe_10_7_0[(person_10_7_0, observe_10_7_0)]

dictionary_observe_11_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4165139536853024, ('false', 'false'): 1.0, ('true', 'true'): 0.5834860463146976}
def f_observe_11_7_0(person_11_7_0, observe_11_7_0):
    return dictionary_observe_11_7_0[(person_11_7_0, observe_11_7_0)]

dictionary_observe_12_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4087495679654154, ('false', 'false'): 1.0, ('true', 'true'): 0.5912504320345846}
def f_observe_12_7_0(person_12_7_0, observe_12_7_0):
    return dictionary_observe_12_7_0[(person_12_7_0, observe_12_7_0)]

dictionary_observe_13_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8052848812805311, ('false', 'false'): 1.0, ('true', 'true'): 0.1947151187194689}
def f_observe_13_7_0(person_13_7_0, observe_13_7_0):
    return dictionary_observe_13_7_0[(person_13_7_0, observe_13_7_0)]

dictionary_observe_14_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7346664844899307, ('false', 'false'): 1.0, ('true', 'true'): 0.26533351551006934}
def f_observe_14_7_0(person_14_7_0, observe_14_7_0):
    return dictionary_observe_14_7_0[(person_14_7_0, observe_14_7_0)]

dictionary_observe_15_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5188514784905365, ('false', 'false'): 1.0, ('true', 'true'): 0.4811485215094635}
def f_observe_15_7_0(person_15_7_0, observe_15_7_0):
    return dictionary_observe_15_7_0[(person_15_7_0, observe_15_7_0)]

dictionary_observe_16_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5172734715010381, ('false', 'false'): 1.0, ('true', 'true'): 0.4827265284989619}
def f_observe_16_7_0(person_16_7_0, observe_16_7_0):
    return dictionary_observe_16_7_0[(person_16_7_0, observe_16_7_0)]

dictionary_observe_17_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.999311717415604, ('false', 'false'): 1.0, ('true', 'true'): 0.0006882825843960161}
def f_observe_17_7_0(person_17_7_0, observe_17_7_0):
    return dictionary_observe_17_7_0[(person_17_7_0, observe_17_7_0)]

dictionary_observe_18_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6687659267165398, ('false', 'false'): 1.0, ('true', 'true'): 0.3312340732834602}
def f_observe_18_7_0(person_18_7_0, observe_18_7_0):
    return dictionary_observe_18_7_0[(person_18_7_0, observe_18_7_0)]

dictionary_observe_19_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7270248907575474, ('false', 'false'): 1.0, ('true', 'true'): 0.2729751092424526}
def f_observe_19_7_0(person_19_7_0, observe_19_7_0):
    return dictionary_observe_19_7_0[(person_19_7_0, observe_19_7_0)]

dictionary_observe_20_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4934529570508208, ('false', 'false'): 1.0, ('true', 'true'): 0.5065470429491792}
def f_observe_20_7_0(person_20_7_0, observe_20_7_0):
    return dictionary_observe_20_7_0[(person_20_7_0, observe_20_7_0)]

dictionary_observe_21_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6021048010294834, ('false', 'false'): 1.0, ('true', 'true'): 0.3978951989705166}
def f_observe_21_7_0(person_21_7_0, observe_21_7_0):
    return dictionary_observe_21_7_0[(person_21_7_0, observe_21_7_0)]

dictionary_observe_22_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8632141419980716, ('false', 'false'): 1.0, ('true', 'true'): 0.13678585800192844}
def f_observe_22_7_0(person_22_7_0, observe_22_7_0):
    return dictionary_observe_22_7_0[(person_22_7_0, observe_22_7_0)]

dictionary_observe_23_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6159886583113426, ('false', 'false'): 1.0, ('true', 'true'): 0.38401134168865736}
def f_observe_23_7_0(person_23_7_0, observe_23_7_0):
    return dictionary_observe_23_7_0[(person_23_7_0, observe_23_7_0)]

dictionary_observe_24_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6060789463068024, ('false', 'false'): 1.0, ('true', 'true'): 0.39392105369319763}
def f_observe_24_7_0(person_24_7_0, observe_24_7_0):
    return dictionary_observe_24_7_0[(person_24_7_0, observe_24_7_0)]

dictionary_observe_25_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6966753339077307, ('false', 'false'): 1.0, ('true', 'true'): 0.30332466609226927}
def f_observe_25_7_0(person_25_7_0, observe_25_7_0):
    return dictionary_observe_25_7_0[(person_25_7_0, observe_25_7_0)]

dictionary_observe_26_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8665223901867102, ('false', 'false'): 1.0, ('true', 'true'): 0.13347760981328982}
def f_observe_26_7_0(person_26_7_0, observe_26_7_0):
    return dictionary_observe_26_7_0[(person_26_7_0, observe_26_7_0)]

dictionary_observe_27_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7612268877208216, ('false', 'false'): 1.0, ('true', 'true'): 0.2387731122791784}
def f_observe_27_7_0(person_27_7_0, observe_27_7_0):
    return dictionary_observe_27_7_0[(person_27_7_0, observe_27_7_0)]

dictionary_observe_28_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5460707931601592, ('false', 'false'): 1.0, ('true', 'true'): 0.45392920683984084}
def f_observe_28_7_0(person_28_7_0, observe_28_7_0):
    return dictionary_observe_28_7_0[(person_28_7_0, observe_28_7_0)]

dictionary_observe_29_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5591269854024574, ('false', 'false'): 1.0, ('true', 'true'): 0.4408730145975426}
def f_observe_29_7_0(person_29_7_0, observe_29_7_0):
    return dictionary_observe_29_7_0[(person_29_7_0, observe_29_7_0)]

dictionary_observe_30_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8828112579138669, ('false', 'false'): 1.0, ('true', 'true'): 0.11718874208613306}
def f_observe_30_7_0(person_30_7_0, observe_30_7_0):
    return dictionary_observe_30_7_0[(person_30_7_0, observe_30_7_0)]

dictionary_observe_31_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6400899755766469, ('false', 'false'): 1.0, ('true', 'true'): 0.35991002442335307}
def f_observe_31_7_0(person_31_7_0, observe_31_7_0):
    return dictionary_observe_31_7_0[(person_31_7_0, observe_31_7_0)]

dictionary_observe_32_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7783988935473396, ('false', 'false'): 1.0, ('true', 'true'): 0.2216011064526604}
def f_observe_32_7_0(person_32_7_0, observe_32_7_0):
    return dictionary_observe_32_7_0[(person_32_7_0, observe_32_7_0)]

dictionary_observe_33_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5299144801250956, ('false', 'false'): 1.0, ('true', 'true'): 0.47008551987490443}
def f_observe_33_7_0(person_33_7_0, observe_33_7_0):
    return dictionary_observe_33_7_0[(person_33_7_0, observe_33_7_0)]

dictionary_observe_34_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6311550735347339, ('false', 'false'): 1.0, ('true', 'true'): 0.3688449264652661}
def f_observe_34_7_0(person_34_7_0, observe_34_7_0):
    return dictionary_observe_34_7_0[(person_34_7_0, observe_34_7_0)]

dictionary_observe_35_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.547975030898495, ('false', 'false'): 1.0, ('true', 'true'): 0.452024969101505}
def f_observe_35_7_0(person_35_7_0, observe_35_7_0):
    return dictionary_observe_35_7_0[(person_35_7_0, observe_35_7_0)]

dictionary_person_0_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.885984821490336, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.11401517850966403, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8850988366688456, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.11490116333115441, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_0_8_0(person_0_7_0, person_30_7_0, risk_0_8_0, person_0_8_0):
    return dictionary_person_0_8_0[(person_0_7_0, person_30_7_0, risk_0_8_0, person_0_8_0)]

dictionary_observe_0_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.566749580830124, ('false', 'false'): 1.0, ('true', 'true'): 0.43325041916987606}
def f_observe_0_8_0(person_0_8_0, observe_0_8_0):
    return dictionary_observe_0_8_0[(person_0_8_0, observe_0_8_0)]

dictionary_person_1_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_1_8_0(person_1_7_0, risk_1_8_0, person_1_8_0):
    return dictionary_person_1_8_0[(person_1_7_0, risk_1_8_0, person_1_8_0)]

dictionary_observe_1_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6363358166783569, ('false', 'false'): 1.0, ('true', 'true'): 0.3636641833216431}
def f_observe_1_8_0(person_1_8_0, observe_1_8_0):
    return dictionary_observe_1_8_0[(person_1_8_0, observe_1_8_0)]

dictionary_person_2_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.205963922268934, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.3690475939644632, ('false', 'false', 'true', 'false', 'false'): 0.7954096894819874, ('false', 'true', 'false', 'true', 'true'): 0.2067579583466651, ('false', 'false', 'true', 'false', 'true'): 0.20459031051801257, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7932420416533349, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7946142797925054, ('false', 'true', 'true', 'false', 'true'): 0.3684160099744376, ('false', 'true', 'true', 'false', 'false'): 0.6315839900255624, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.20538572020749457, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.794036077731066, ('false', 'true', 'true', 'true', 'false'): 0.6309524060355368}
def f_person_2_8_0(person_2_7_0, person_3_7_0, person_32_7_0, risk_2_8_0, person_2_8_0):
    return dictionary_person_2_8_0[(person_2_7_0, person_3_7_0, person_32_7_0, risk_2_8_0, person_2_8_0)]

dictionary_observe_2_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9989897800283735, ('false', 'false'): 1.0, ('true', 'true'): 0.0010102199716265359}
def f_observe_2_8_0(person_2_8_0, observe_2_8_0):
    return dictionary_observe_2_8_0[(person_2_8_0, observe_2_8_0)]

dictionary_person_3_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_3_8_0(person_3_7_0, risk_3_8_0, person_3_8_0):
    return dictionary_person_3_8_0[(person_3_7_0, risk_3_8_0, person_3_8_0)]

dictionary_observe_3_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9519421899736699, ('false', 'false'): 1.0, ('true', 'true'): 0.04805781002633014}
def f_observe_3_8_0(person_3_8_0, observe_3_8_0):
    return dictionary_observe_3_8_0[(person_3_8_0, observe_3_8_0)]

dictionary_person_4_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_8_0(person_4_7_0, risk_4_8_0, person_4_8_0):
    return dictionary_person_4_8_0[(person_4_7_0, risk_4_8_0, person_4_8_0)]

dictionary_observe_4_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7624462713047806, ('false', 'false'): 1.0, ('true', 'true'): 0.2375537286952194}
def f_observe_4_8_0(person_4_8_0, observe_4_8_0):
    return dictionary_observe_4_8_0[(person_4_8_0, observe_4_8_0)]

dictionary_person_5_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_5_8_0(person_5_7_0, risk_5_8_0, person_5_8_0):
    return dictionary_person_5_8_0[(person_5_7_0, risk_5_8_0, person_5_8_0)]

dictionary_observe_5_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8821545249395745, ('false', 'false'): 1.0, ('true', 'true'): 0.11784547506042553}
def f_observe_5_8_0(person_5_8_0, observe_5_8_0):
    return dictionary_observe_5_8_0[(person_5_8_0, observe_5_8_0)]

dictionary_person_6_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7424071318459954, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2575928681540046, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7416647247141493, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.25833527528585065, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_6_8_0(person_6_7_0, person_7_7_0, risk_6_8_0, person_6_8_0):
    return dictionary_person_6_8_0[(person_6_7_0, person_7_7_0, risk_6_8_0, person_6_8_0)]

dictionary_observe_6_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8074706751526541, ('false', 'false'): 1.0, ('true', 'true'): 0.19252932484734586}
def f_observe_6_8_0(person_6_8_0, observe_6_8_0):
    return dictionary_observe_6_8_0[(person_6_8_0, observe_6_8_0)]

dictionary_person_7_8_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.40562787407385426, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.218475813057754, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.181276326497407, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.4572923131685288, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.8179049498290905, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.6930339754225937, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.4320287064863947, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.465446620249444, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.4443276310007569, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.5685027015991981, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.6937277031257194, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.39438607340117804, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.360147646735517, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.3069660245774063, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.594967093019165, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.3225703215784825, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.5427076868314712, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.6404928461105935, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.7823064934356817, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.781524186942246, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.534553379750556, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.4958675701781031, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.5872548451244284, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.39399168732777684, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.4325966777799083, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.5350188263708054, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.2176935065643183, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.5674033222200917, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.5679712935136053, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.5041324298218969, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.639852353264483, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.7259740314865383, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.5036282973920749, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.41274515487557156, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.5556723689992431, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.32289321479327576, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.818723673502593, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.3062722968742806, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.2732992677812429, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.40503290698083505, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.6771067852067243, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.6774296784215175, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.49637170260792507, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.2740259685134617, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.4320658011024011, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.5561166966302439, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.18209505017090954, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.605613926598822, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.587667590279304, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.35950715388940646, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.5679341988975989, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.46498117362919456, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.4438833033697561, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.4578350208553603, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.5421649791446397, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.43149729840080187, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.6060083126722231, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.412332409720696, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.5943721259261457, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.7267007322187571}
def f_person_7_8_0(person_7_7_0, person_1_7_0, person_2_7_0, person_6_7_0, person_12_7_0, risk_7_8_0, person_7_8_0):
    return dictionary_person_7_8_0[(person_7_7_0, person_1_7_0, person_2_7_0, person_6_7_0, person_12_7_0, risk_7_8_0, person_7_8_0)]

dictionary_observe_7_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8233465068044669, ('false', 'false'): 1.0, ('true', 'true'): 0.17665349319553314}
def f_observe_7_8_0(person_7_8_0, observe_7_8_0):
    return dictionary_observe_7_8_0[(person_7_8_0, observe_7_8_0)]

dictionary_person_8_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7458622884686135, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.25413771153138653, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7451164261801448, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.25488357381985516, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_8_8_0(person_8_7_0, person_20_7_0, risk_8_8_0, person_8_8_0):
    return dictionary_person_8_8_0[(person_8_7_0, person_20_7_0, risk_8_8_0, person_8_8_0)]

dictionary_observe_8_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6248288527875516, ('false', 'false'): 1.0, ('true', 'true'): 0.3751711472124484}
def f_observe_8_8_0(person_8_8_0, observe_8_8_0):
    return dictionary_observe_8_8_0[(person_8_8_0, observe_8_8_0)]

dictionary_person_9_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.1190333798055514, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.33822078980687187, ('false', 'false', 'true', 'false', 'false'): 0.7519486398914385, ('false', 'true', 'false', 'true', 'true'): 0.11991434642574583, ('false', 'false', 'true', 'false', 'true'): 0.24805136010856155, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.8800856535742542, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.751196691251547, ('false', 'true', 'true', 'false', 'true'): 0.33755834815502694, ('false', 'true', 'true', 'false', 'false'): 0.6624416518449731, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.24880330874845302, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.8809666201944486, ('false', 'true', 'true', 'true', 'false'): 0.6617792101931281}
def f_person_9_8_0(person_9_7_0, person_10_7_0, person_15_7_0, risk_9_8_0, person_9_8_0):
    return dictionary_person_9_8_0[(person_9_7_0, person_10_7_0, person_15_7_0, risk_9_8_0, person_9_8_0)]

dictionary_observe_9_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.43624816616991813, ('false', 'false'): 1.0, ('true', 'true'): 0.5637518338300819}
def f_observe_9_8_0(person_9_8_0, observe_9_8_0):
    return dictionary_observe_9_8_0[(person_9_8_0, observe_9_8_0)]

dictionary_person_10_8_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.608954084637137, ('false', 'true', 'false', 'false', 'false', 'true'): 0.1528846663070037, ('false', 'true', 'true', 'false', 'true', 'true'): 0.32121700345014925, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.6787829965498507, ('false', 'true', 'false', 'false', 'false', 'false'): 0.8471153336929963, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.8462682183593033, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.1979103293447122, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.39104591536286304, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.3904363517145776, ('false', 'false', 'true', 'false', 'false', 'false'): 0.8020896706552878, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.7599694530256496, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.7592094835726239, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.24003054697435044, ('false', 'false', 'false', 'true', 'false', 'true'): 0.10287369051323225, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.15373178164069667, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.6095636482854224, ('false', 'false', 'true', 'false', 'true', 'false'): 0.8012875809846325, ('false', 'true', 'true', 'false', 'false', 'false'): 0.6794624590088596, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.28042425388756465, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.24079051642737614, ('false', 'false', 'false', 'true', 'true', 'false'): 0.896229183177281, ('false', 'false', 'false', 'true', 'false', 'false'): 0.8971263094867677, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.7195757461124354, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.2811438296336771, ('false', 'false', 'true', 'false', 'true', 'true'): 0.19871241901536751, ('false', 'false', 'false', 'true', 'true', 'true'): 0.10377081682271905, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.3205375409911404, ('false', 'false', 'true', 'true', 'true', 'false'): 0.7188561703663229}
def f_person_10_8_0(person_10_7_0, person_11_7_0, person_12_7_0, person_16_7_0, risk_10_8_0, person_10_8_0):
    return dictionary_person_10_8_0[(person_10_7_0, person_11_7_0, person_12_7_0, person_16_7_0, risk_10_8_0, person_10_8_0)]

dictionary_observe_10_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7422759116658468, ('false', 'false'): 1.0, ('true', 'true'): 0.25772408833415317}
def f_observe_10_8_0(person_10_8_0, observe_10_8_0):
    return dictionary_observe_10_8_0[(person_10_8_0, observe_10_8_0)]

dictionary_person_11_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.2660242845371734, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.4438437978504507, ('false', 'false', 'true', 'false', 'false'): 0.7584895567199589, ('false', 'true', 'false', 'true', 'true'): 0.26675826025263627, ('false', 'false', 'true', 'false', 'true'): 0.24151044328004112, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7332417397473637, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7577310671632389, ('false', 'true', 'true', 'false', 'true'): 0.44328708493538604, ('false', 'true', 'true', 'false', 'false'): 0.556712915064614, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.2422689328367611, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7339757154628266, ('false', 'true', 'true', 'true', 'false'): 0.5561562021495493}
def f_person_11_8_0(person_11_7_0, person_10_7_0, person_5_7_0, risk_11_8_0, person_11_8_0):
    return dictionary_person_11_8_0[(person_11_7_0, person_10_7_0, person_5_7_0, risk_11_8_0, person_11_8_0)]

dictionary_observe_11_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9081641344767577, ('false', 'false'): 1.0, ('true', 'true'): 0.0918358655232423}
def f_observe_11_8_0(person_11_8_0, observe_11_8_0):
    return dictionary_observe_11_8_0[(person_11_8_0, observe_11_8_0)]

dictionary_person_12_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7616788580113116, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.23832114198868837, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7609171791533004, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.23908282084669963, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_12_8_0(person_12_7_0, person_18_7_0, risk_12_8_0, person_12_8_0):
    return dictionary_person_12_8_0[(person_12_7_0, person_18_7_0, risk_12_8_0, person_12_8_0)]

dictionary_observe_12_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9983161976158172, ('false', 'false'): 1.0, ('true', 'true'): 0.0016838023841827532}
def f_observe_12_8_0(person_12_8_0, observe_12_8_0):
    return dictionary_observe_12_8_0[(person_12_8_0, observe_12_8_0)]

dictionary_person_13_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7385957144082295, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.26140428559177054, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7378571186938212, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2621428813061788, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_13_8_0(person_13_7_0, person_7_7_0, risk_13_8_0, person_13_8_0):
    return dictionary_person_13_8_0[(person_13_7_0, person_7_7_0, risk_13_8_0, person_13_8_0)]

dictionary_observe_13_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6029239123246424, ('false', 'false'): 1.0, ('true', 'true'): 0.3970760876753576}
def f_observe_13_8_0(person_13_8_0, observe_13_8_0):
    return dictionary_observe_13_8_0[(person_13_8_0, observe_13_8_0)]

dictionary_person_14_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_14_8_0(person_14_7_0, risk_14_8_0, person_14_8_0):
    return dictionary_person_14_8_0[(person_14_7_0, risk_14_8_0, person_14_8_0)]

dictionary_observe_14_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6517421366321698, ('false', 'false'): 1.0, ('true', 'true'): 0.34825786336783016}
def f_observe_14_8_0(person_14_8_0, observe_14_8_0):
    return dictionary_observe_14_8_0[(person_14_8_0, observe_14_8_0)]

dictionary_person_15_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8471118944608489, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.1528881055391511, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.846264782566388, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.15373521743361196, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_15_8_0(person_15_7_0, person_19_7_0, risk_15_8_0, person_15_8_0):
    return dictionary_person_15_8_0[(person_15_7_0, person_19_7_0, risk_15_8_0, person_15_8_0)]

dictionary_observe_15_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.43215770635957895, ('false', 'false'): 1.0, ('true', 'true'): 0.567842293640421}
def f_observe_15_8_0(person_15_8_0, observe_15_8_0):
    return dictionary_observe_15_8_0[(person_15_8_0, observe_15_8_0)]

dictionary_person_16_8_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.4120089834172052, ('false', 'true', 'false', 'false', 'false', 'true'): 0.2526093483458939, ('false', 'true', 'true', 'false', 'true', 'true'): 0.4491865992265158, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.5508134007734842, ('false', 'true', 'false', 'false', 'false', 'false'): 0.7473906516541061, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.746643261002452, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.26228035590389487, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.5879910165827948, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.5875785951779728, ('false', 'false', 'true', 'false', 'false', 'false'): 0.7377196440961051, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.5590489668027597, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.5584899178359569, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.44095103319724027, ('false', 'false', 'false', 'true', 'false', 'true'): 0.25199898397780773, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.25335673899754796, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.4124214048220272, ('false', 'false', 'true', 'false', 'true', 'false'): 0.736981924452009, ('false', 'true', 'true', 'false', 'false', 'false'): 0.5513647655390232, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.4481849566765833, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.4415100821640431, ('false', 'false', 'false', 'true', 'true', 'false'): 0.74725301500617, ('false', 'false', 'false', 'true', 'false', 'false'): 0.7480010160221923, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.5518150433234167, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.4487367717199068, ('false', 'false', 'true', 'false', 'true', 'true'): 0.26301807554799095, ('false', 'false', 'false', 'true', 'true', 'true'): 0.25274698499382997, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.44863523446097675, ('false', 'false', 'true', 'true', 'true', 'false'): 0.5512632282800932}
def f_person_16_8_0(person_16_7_0, person_10_7_0, person_15_7_0, person_17_7_0, risk_16_8_0, person_16_8_0):
    return dictionary_person_16_8_0[(person_16_7_0, person_10_7_0, person_15_7_0, person_17_7_0, risk_16_8_0, person_16_8_0)]

dictionary_observe_16_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5355456753910415, ('false', 'false'): 1.0, ('true', 'true'): 0.4644543246089585}
def f_observe_16_8_0(person_16_8_0, observe_16_8_0):
    return dictionary_observe_16_8_0[(person_16_8_0, observe_16_8_0)]

dictionary_person_17_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8903215817638337, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.10967841823616631, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8894312601820699, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.11056873981793014, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_17_8_0(person_17_7_0, person_11_7_0, risk_17_8_0, person_17_8_0):
    return dictionary_person_17_8_0[(person_17_7_0, person_11_7_0, risk_17_8_0, person_17_8_0)]

dictionary_observe_17_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6314918218324872, ('false', 'false'): 1.0, ('true', 'true'): 0.3685081781675128}
def f_observe_17_8_0(person_17_8_0, observe_17_8_0):
    return dictionary_observe_17_8_0[(person_17_8_0, observe_17_8_0)]

dictionary_person_18_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8819030698600625, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.1180969301399375, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8810211667902025, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.11897883320979752, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_18_8_0(person_18_7_0, person_31_7_0, risk_18_8_0, person_18_8_0):
    return dictionary_person_18_8_0[(person_18_7_0, person_31_7_0, risk_18_8_0, person_18_8_0)]

dictionary_observe_18_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4137959555486259, ('false', 'false'): 1.0, ('true', 'true'): 0.5862040444513741}
def f_observe_18_8_0(person_18_8_0, observe_18_8_0):
    return dictionary_observe_18_8_0[(person_18_8_0, observe_18_8_0)]

dictionary_person_19_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7610436731904022, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.23895632680959777, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7602826295172118, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.23971737048278818, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_19_8_0(person_19_7_0, person_20_7_0, risk_19_8_0, person_19_8_0):
    return dictionary_person_19_8_0[(person_19_7_0, person_20_7_0, risk_19_8_0, person_19_8_0)]

dictionary_observe_19_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7752571441915304, ('false', 'false'): 1.0, ('true', 'true'): 0.22474285580846964}
def f_observe_19_8_0(person_19_8_0, observe_19_8_0):
    return dictionary_observe_19_8_0[(person_19_8_0, observe_19_8_0)]

dictionary_person_20_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_20_8_0(person_20_7_0, risk_20_8_0, person_20_8_0):
    return dictionary_person_20_8_0[(person_20_7_0, risk_20_8_0, person_20_8_0)]

dictionary_observe_20_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4500770915798704, ('false', 'false'): 1.0, ('true', 'true'): 0.5499229084201296}
def f_observe_20_8_0(person_20_8_0, observe_20_8_0):
    return dictionary_observe_20_8_0[(person_20_8_0, observe_20_8_0)]

dictionary_person_21_8_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.526567166199853, ('false', 'true', 'false', 'false', 'false', 'true'): 0.17562280712101186, ('false', 'true', 'true', 'false', 'true', 'true'): 0.32323774242022496, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.676762257579775, ('false', 'true', 'false', 'false', 'false', 'false'): 0.8243771928789881, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.8235528156861092, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.1782406122721365, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.473432833800147, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.47290573953968673, ('false', 'false', 'true', 'false', 'false', 'false'): 0.8217593877278635, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.6414216476646659, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.6407802260170012, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.3585783523353341, ('false', 'false', 'false', 'true', 'false', 'true'): 0.2219318375067887, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.17644718431389084, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.5270942604603133, ('false', 'false', 'true', 'false', 'true', 'false'): 0.8209376283401356, ('false', 'true', 'true', 'false', 'false', 'false'): 0.6774396972770521, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.36061518317903485, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.35921977398299876, ('false', 'false', 'false', 'true', 'true', 'false'): 0.777290094330718, ('false', 'false', 'false', 'true', 'false', 'false'): 0.7780681624932113, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.6393848168209652, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.36125456799585587, ('false', 'false', 'true', 'false', 'true', 'true'): 0.17906237165986438, ('false', 'false', 'false', 'true', 'true', 'true'): 0.22270990566928195, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.3225603027229479, ('false', 'false', 'true', 'true', 'true', 'false'): 0.6387454320041441}
def f_person_21_8_0(person_21_7_0, person_20_7_0, person_27_7_0, person_22_7_0, risk_21_8_0, person_21_8_0):
    return dictionary_person_21_8_0[(person_21_7_0, person_20_7_0, person_27_7_0, person_22_7_0, risk_21_8_0, person_21_8_0)]

dictionary_observe_21_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6133046297560749, ('false', 'false'): 1.0, ('true', 'true'): 0.3866953702439251}
def f_observe_21_8_0(person_21_8_0, observe_21_8_0):
    return dictionary_observe_21_8_0[(person_21_8_0, observe_21_8_0)]

dictionary_person_22_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_22_8_0(person_22_7_0, risk_22_8_0, person_22_8_0):
    return dictionary_person_22_8_0[(person_22_7_0, risk_22_8_0, person_22_8_0)]

dictionary_observe_22_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8460797185128308, ('false', 'false'): 1.0, ('true', 'true'): 0.15392028148716919}
def f_observe_22_8_0(person_22_8_0, observe_22_8_0):
    return dictionary_observe_22_8_0[(person_22_8_0, observe_22_8_0)]

dictionary_person_23_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.30356950766280744, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.40474258187761325, ('false', 'false', 'true', 'false', 'false'): 0.8555818246758855, ('false', 'true', 'false', 'true', 'true'): 0.3042659381551446, ('false', 'false', 'true', 'false', 'true'): 0.1444181753241145, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6957340618448554, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8547262428512096, ('false', 'true', 'true', 'false', 'true'): 0.4041467286062195, ('false', 'true', 'true', 'false', 'false'): 0.5958532713937805, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.14527375714879043, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6964304923371926, ('false', 'true', 'true', 'true', 'false'): 0.5952574181223867}
def f_person_23_8_0(person_23_7_0, person_22_7_0, person_24_7_0, risk_23_8_0, person_23_8_0):
    return dictionary_person_23_8_0[(person_23_7_0, person_22_7_0, person_24_7_0, risk_23_8_0, person_23_8_0)]

dictionary_observe_23_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6635213880088366, ('false', 'false'): 1.0, ('true', 'true'): 0.33647861199116336}
def f_observe_23_8_0(person_23_8_0, observe_23_8_0):
    return dictionary_observe_23_8_0[(person_23_8_0, observe_23_8_0)]

dictionary_person_24_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.848429355029314, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.15157064497068595, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8475809256742848, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.15241907432571522, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_24_8_0(person_24_7_0, person_30_7_0, risk_24_8_0, person_24_8_0):
    return dictionary_person_24_8_0[(person_24_7_0, person_30_7_0, risk_24_8_0, person_24_8_0)]

dictionary_observe_24_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.45894018378547785, ('false', 'false'): 1.0, ('true', 'true'): 0.5410598162145221}
def f_observe_24_8_0(person_24_8_0, observe_24_8_0):
    return dictionary_observe_24_8_0[(person_24_8_0, observe_24_8_0)]

dictionary_person_25_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_25_8_0(person_25_7_0, risk_25_8_0, person_25_8_0):
    return dictionary_person_25_8_0[(person_25_7_0, risk_25_8_0, person_25_8_0)]

dictionary_observe_25_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.44364130684651515, ('false', 'false'): 1.0, ('true', 'true'): 0.5563586931534849}
def f_observe_25_8_0(person_25_8_0, observe_25_8_0):
    return dictionary_observe_25_8_0[(person_25_8_0, observe_25_8_0)]

dictionary_person_26_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_26_8_0(person_26_7_0, risk_26_8_0, person_26_8_0):
    return dictionary_person_26_8_0[(person_26_7_0, risk_26_8_0, person_26_8_0)]

dictionary_observe_26_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7559209288811382, ('false', 'false'): 1.0, ('true', 'true'): 0.24407907111886185}
def f_observe_26_8_0(person_26_8_0, observe_26_8_0):
    return dictionary_observe_26_8_0[(person_26_8_0, observe_26_8_0)]

dictionary_person_27_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.13836571616624027, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.3204678171431783, ('false', 'false', 'true', 'false', 'false'): 0.7894444406570424, ('false', 'true', 'false', 'true', 'true'): 0.13922735045007406, ('false', 'false', 'true', 'false', 'true'): 0.21055555934295755, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.8607726495499259, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7886549962163854, ('false', 'true', 'true', 'false', 'true'): 0.3197876047479262, ('false', 'true', 'true', 'false', 'false'): 0.6802123952520738, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.21134500378361465, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.8616342838337597, ('false', 'true', 'true', 'true', 'false'): 0.6795321828568217}
def f_person_27_8_0(person_27_7_0, person_21_7_0, person_3_7_0, risk_27_8_0, person_27_8_0):
    return dictionary_person_27_8_0[(person_27_7_0, person_21_7_0, person_3_7_0, risk_27_8_0, person_27_8_0)]

dictionary_observe_27_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7759437630923391, ('false', 'false'): 1.0, ('true', 'true'): 0.22405623690766086}
def f_observe_27_8_0(person_27_8_0, observe_27_8_0):
    return dictionary_observe_27_8_0[(person_27_8_0, observe_27_8_0)]

dictionary_person_28_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7692623045731501, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.23073769542684985, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.768493042268577, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.23150695773142305, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_28_8_0(person_28_7_0, person_34_7_0, risk_28_8_0, person_28_8_0):
    return dictionary_person_28_8_0[(person_28_7_0, person_34_7_0, risk_28_8_0, person_28_8_0)]

dictionary_observe_28_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6150260646094636, ('false', 'false'): 1.0, ('true', 'true'): 0.38497393539053637}
def f_observe_28_8_0(person_28_8_0, observe_28_8_0):
    return dictionary_observe_28_8_0[(person_28_8_0, observe_28_8_0)]

dictionary_person_29_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_29_8_0(person_29_7_0, risk_29_8_0, person_29_8_0):
    return dictionary_person_29_8_0[(person_29_7_0, risk_29_8_0, person_29_8_0)]

dictionary_observe_29_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.54843434725908, ('false', 'false'): 1.0, ('true', 'true'): 0.45156565274092}
def f_observe_29_8_0(person_29_8_0, observe_29_8_0):
    return dictionary_observe_29_8_0[(person_29_8_0, observe_29_8_0)]

dictionary_person_30_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_30_8_0(person_30_7_0, risk_30_8_0, person_30_8_0):
    return dictionary_person_30_8_0[(person_30_7_0, risk_30_8_0, person_30_8_0)]

dictionary_observe_30_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6301456007524944, ('false', 'false'): 1.0, ('true', 'true'): 0.3698543992475056}
def f_observe_30_8_0(person_30_8_0, observe_30_8_0):
    return dictionary_observe_30_8_0[(person_30_8_0, observe_30_8_0)]

dictionary_person_31_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7910962943560869, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.20890370564391314, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7903051980617307, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.20969480193826928, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_31_8_0(person_31_7_0, person_1_7_0, risk_31_8_0, person_31_8_0):
    return dictionary_person_31_8_0[(person_31_7_0, person_1_7_0, risk_31_8_0, person_31_8_0)]

dictionary_observe_31_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6661012029804877, ('false', 'false'): 1.0, ('true', 'true'): 0.3338987970195123}
def f_observe_31_8_0(person_31_8_0, observe_31_8_0):
    return dictionary_observe_31_8_0[(person_31_8_0, observe_31_8_0)]

dictionary_person_32_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_32_8_0(person_32_7_0, risk_32_8_0, person_32_8_0):
    return dictionary_person_32_8_0[(person_32_7_0, risk_32_8_0, person_32_8_0)]

dictionary_observe_32_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9293223384130579, ('false', 'false'): 1.0, ('true', 'true'): 0.07067766158694211}
def f_observe_32_8_0(person_32_8_0, observe_32_8_0):
    return dictionary_observe_32_8_0[(person_32_8_0, observe_32_8_0)]

dictionary_person_33_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7367159796354072, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.26328402036459275, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7359792636557718, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2640207363442282, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_33_8_0(person_33_7_0, person_32_7_0, risk_33_8_0, person_33_8_0):
    return dictionary_person_33_8_0[(person_33_7_0, person_32_7_0, risk_33_8_0, person_33_8_0)]

dictionary_observe_33_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.47584082516308635, ('false', 'false'): 1.0, ('true', 'true'): 0.5241591748369137}
def f_observe_33_8_0(person_33_8_0, observe_33_8_0):
    return dictionary_observe_33_8_0[(person_33_8_0, observe_33_8_0)]

dictionary_person_34_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_34_8_0(person_34_7_0, risk_34_8_0, person_34_8_0):
    return dictionary_person_34_8_0[(person_34_7_0, risk_34_8_0, person_34_8_0)]

dictionary_observe_34_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6647350869507457, ('false', 'false'): 1.0, ('true', 'true'): 0.3352649130492543}
def f_observe_34_8_0(person_34_8_0, observe_34_8_0):
    return dictionary_observe_34_8_0[(person_34_8_0, observe_34_8_0)]

dictionary_person_35_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8645835143906486, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.13541648560935138, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.863718930876258, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.13628106912374205, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_35_8_0(person_35_7_0, person_34_7_0, risk_35_8_0, person_35_8_0):
    return dictionary_person_35_8_0[(person_35_7_0, person_34_7_0, risk_35_8_0, person_35_8_0)]

dictionary_observe_35_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8986470916198689, ('false', 'false'): 1.0, ('true', 'true'): 0.10135290838013111}
def f_observe_35_8_0(person_35_8_0, observe_35_8_0):
    return dictionary_observe_35_8_0[(person_35_8_0, observe_35_8_0)]

dictionary_person_0_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7750977288195484, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.22490227118045159, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7743226310907289, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.22567736890927115, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_0_9_0(person_0_8_0, person_29_8_0, risk_0_9_0, person_0_9_0):
    return dictionary_person_0_9_0[(person_0_8_0, person_29_8_0, risk_0_9_0, person_0_9_0)]

dictionary_observe_0_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7999848633660762, ('false', 'false'): 1.0, ('true', 'true'): 0.20001513663392378}
def f_observe_0_9_0(person_0_9_0, observe_0_9_0):
    return dictionary_observe_0_9_0[(person_0_9_0, observe_0_9_0)]

dictionary_person_1_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_1_9_0(person_1_8_0, risk_1_9_0, person_1_9_0):
    return dictionary_person_1_9_0[(person_1_8_0, risk_1_9_0, person_1_9_0)]

dictionary_observe_1_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5358295797428878, ('false', 'false'): 1.0, ('true', 'true'): 0.4641704202571122}
def f_observe_1_9_0(person_1_9_0, observe_1_9_0):
    return dictionary_observe_1_9_0[(person_1_9_0, observe_1_9_0)]

dictionary_person_2_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7907893829250587, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.20921061707494126, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7899985935421336, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.21000140645786636, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_2_9_0(person_2_8_0, person_3_8_0, risk_2_9_0, person_2_9_0):
    return dictionary_person_2_9_0[(person_2_8_0, person_3_8_0, risk_2_9_0, person_2_9_0)]

dictionary_observe_2_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4813350335080071, ('false', 'false'): 1.0, ('true', 'true'): 0.5186649664919929}
def f_observe_2_9_0(person_2_9_0, observe_2_9_0):
    return dictionary_observe_2_9_0[(person_2_9_0, observe_2_9_0)]

dictionary_person_3_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7738811066519439, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.22611889334805613, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7731072255452919, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.22689277445470812, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_3_9_0(person_3_8_0, person_2_8_0, risk_3_9_0, person_3_9_0):
    return dictionary_person_3_9_0[(person_3_8_0, person_2_8_0, risk_3_9_0, person_3_9_0)]

dictionary_observe_3_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9640351678167774, ('false', 'false'): 1.0, ('true', 'true'): 0.03596483218322255}
def f_observe_3_9_0(person_3_9_0, observe_3_9_0):
    return dictionary_observe_3_9_0[(person_3_9_0, observe_3_9_0)]

dictionary_person_4_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_9_0(person_4_8_0, risk_4_9_0, person_4_9_0):
    return dictionary_person_4_9_0[(person_4_8_0, risk_4_9_0, person_4_9_0)]

dictionary_observe_4_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.817209384522238, ('false', 'false'): 1.0, ('true', 'true'): 0.182790615477762}
def f_observe_4_9_0(person_4_9_0, observe_4_9_0):
    return dictionary_observe_4_9_0[(person_4_9_0, observe_4_9_0)]

dictionary_person_5_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8686289890327124, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.13137101096728765, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8677603600436796, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.13223963995632038, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_5_9_0(person_5_8_0, person_11_8_0, risk_5_9_0, person_5_9_0):
    return dictionary_person_5_9_0[(person_5_8_0, person_11_8_0, risk_5_9_0, person_5_9_0)]

dictionary_observe_5_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5201538416444105, ('false', 'false'): 1.0, ('true', 'true'): 0.4798461583555895}
def f_observe_5_9_0(person_5_9_0, observe_5_9_0):
    return dictionary_observe_5_9_0[(person_5_9_0, observe_5_9_0)]

dictionary_person_6_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_6_9_0(person_6_8_0, risk_6_9_0, person_6_9_0):
    return dictionary_person_6_9_0[(person_6_8_0, risk_6_9_0, person_6_9_0)]

dictionary_observe_6_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7496745116164416, ('false', 'false'): 1.0, ('true', 'true'): 0.2503254883835584}
def f_observe_6_9_0(person_6_9_0, observe_6_9_0):
    return dictionary_observe_6_9_0[(person_6_9_0, observe_6_9_0)]

dictionary_person_7_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.16076140656339877, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.27081692200805785, ('false', 'false', 'true', 'false', 'false'): 0.8697323939715422, ('false', 'true', 'false', 'true', 'true'): 0.16160064515683537, ('false', 'false', 'true', 'false', 'true'): 0.13026760602845777, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.8383993548431646, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8688626615775706, ('false', 'true', 'true', 'false', 'true'): 0.27008700901707494, ('false', 'true', 'true', 'false', 'false'): 0.7299129909829251, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.13113733842242936, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.8392385934366012, ('false', 'true', 'true', 'true', 'false'): 0.7291830779919422}
def f_person_7_9_0(person_7_8_0, person_12_8_0, person_6_8_0, risk_7_9_0, person_7_9_0):
    return dictionary_person_7_9_0[(person_7_8_0, person_12_8_0, person_6_8_0, risk_7_9_0, person_7_9_0)]

dictionary_observe_7_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.46503742552283855, ('false', 'false'): 1.0, ('true', 'true'): 0.5349625744771614}
def f_observe_7_9_0(person_7_9_0, observe_7_9_0):
    return dictionary_observe_7_9_0[(person_7_9_0, observe_7_9_0)]

dictionary_person_8_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_8_9_0(person_8_8_0, risk_8_9_0, person_8_9_0):
    return dictionary_person_8_9_0[(person_8_8_0, risk_8_9_0, person_8_9_0)]

dictionary_observe_8_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6179467084344972, ('false', 'false'): 1.0, ('true', 'true'): 0.38205329156550283}
def f_observe_8_9_0(person_8_9_0, observe_8_9_0):
    return dictionary_observe_8_9_0[(person_8_9_0, observe_8_9_0)]

dictionary_person_9_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8829671711791799, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.11703282882082011, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8820842040080007, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.1179157959919993, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_9_9_0(person_9_8_0, person_8_8_0, risk_9_9_0, person_9_9_0):
    return dictionary_person_9_9_0[(person_9_8_0, person_8_8_0, risk_9_9_0, person_9_9_0)]

dictionary_observe_9_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4172078730826456, ('false', 'false'): 1.0, ('true', 'true'): 0.5827921269173544}
def f_observe_9_9_0(person_9_9_0, observe_9_9_0):
    return dictionary_observe_9_9_0[(person_9_9_0, observe_9_9_0)]

dictionary_person_10_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_10_9_0(person_10_8_0, risk_10_9_0, person_10_9_0):
    return dictionary_person_10_9_0[(person_10_8_0, risk_10_9_0, person_10_9_0)]

dictionary_observe_10_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5845689234495883, ('false', 'false'): 1.0, ('true', 'true'): 0.41543107655041167}
def f_observe_10_9_0(person_10_9_0, observe_10_9_0):
    return dictionary_observe_10_9_0[(person_10_9_0, observe_10_9_0)]

dictionary_person_11_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.778250471324529, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.22174952867547104, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7774722208532044, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.22252777914679556, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_11_9_0(person_11_8_0, person_12_8_0, risk_11_9_0, person_11_9_0):
    return dictionary_person_11_9_0[(person_11_8_0, person_12_8_0, risk_11_9_0, person_11_9_0)]

dictionary_observe_11_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8138182288099954, ('false', 'false'): 1.0, ('true', 'true'): 0.18618177119000456}
def f_observe_11_9_0(person_11_9_0, observe_11_9_0):
    return dictionary_observe_11_9_0[(person_11_9_0, observe_11_9_0)]

dictionary_person_12_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8306435950055117, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.16935640499448834, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8298129514105061, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.17018704858949385, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_12_9_0(person_12_8_0, person_18_8_0, risk_12_9_0, person_12_9_0):
    return dictionary_person_12_9_0[(person_12_8_0, person_18_8_0, risk_12_9_0, person_12_9_0)]

dictionary_observe_12_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4895541457186703, ('false', 'false'): 1.0, ('true', 'true'): 0.5104458542813297}
def f_observe_12_9_0(person_12_9_0, observe_12_9_0):
    return dictionary_observe_12_9_0[(person_12_9_0, observe_12_9_0)]

dictionary_person_13_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_13_9_0(person_13_8_0, risk_13_9_0, person_13_9_0):
    return dictionary_person_13_9_0[(person_13_8_0, risk_13_9_0, person_13_9_0)]

dictionary_observe_13_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4351267579511312, ('false', 'false'): 1.0, ('true', 'true'): 0.5648732420488688}
def f_observe_13_9_0(person_13_9_0, observe_13_9_0):
    return dictionary_observe_13_9_0[(person_13_9_0, observe_13_9_0)]

dictionary_person_14_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7303507487473739, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.26964925125262607, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7296203979986265, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.27037960200137345, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_14_9_0(person_14_8_0, person_20_8_0, risk_14_9_0, person_14_9_0):
    return dictionary_person_14_9_0[(person_14_8_0, person_20_8_0, risk_14_9_0, person_14_9_0)]

dictionary_observe_14_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.44108879471175244, ('false', 'false'): 1.0, ('true', 'true'): 0.5589112052882476}
def f_observe_14_9_0(person_14_9_0, observe_14_9_0):
    return dictionary_observe_14_9_0[(person_14_9_0, observe_14_9_0)]

dictionary_person_15_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.18514859897772018, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.3452364316041586, ('false', 'false', 'true', 'false', 'false'): 0.8043417321992234, ('false', 'true', 'false', 'true', 'true'): 0.1859634503787425, ('false', 'false', 'true', 'false', 'true'): 0.19565826780077655, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.8140365496212575, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8035373904670242, ('false', 'true', 'true', 'false', 'true'): 0.34458101261677543, ('false', 'true', 'true', 'false', 'false'): 0.6554189873832246, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.19646260953297578, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.8148514010222798, ('false', 'true', 'true', 'true', 'false'): 0.6547635683958414}
def f_person_15_9_0(person_15_8_0, person_9_8_0, person_16_8_0, risk_15_9_0, person_15_9_0):
    return dictionary_person_15_9_0[(person_15_8_0, person_9_8_0, person_16_8_0, risk_15_9_0, person_15_9_0)]

dictionary_observe_15_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9760780128553408, ('false', 'false'): 1.0, ('true', 'true'): 0.023921987144659207}
def f_observe_15_9_0(person_15_9_0, observe_15_9_0):
    return dictionary_observe_15_9_0[(person_15_9_0, observe_15_9_0)]

dictionary_person_16_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7692719943725355, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.23072800562746454, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.768502722378163, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.23149727762183703, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_16_9_0(person_16_8_0, person_17_8_0, risk_16_9_0, person_16_9_0):
    return dictionary_person_16_9_0[(person_16_8_0, person_17_8_0, risk_16_9_0, person_16_9_0)]

dictionary_observe_16_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4013898789192556, ('false', 'false'): 1.0, ('true', 'true'): 0.5986101210807444}
def f_observe_16_9_0(person_16_9_0, observe_16_9_0):
    return dictionary_observe_16_9_0[(person_16_9_0, observe_16_9_0)]

dictionary_person_17_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.16080609336036522, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.24548075854030438, ('false', 'false', 'true', 'false', 'false'): 0.999, ('false', 'true', 'false', 'true', 'true'): 0.2447254840243287, ('false', 'false', 'true', 'false', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.9, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7552745159756713, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8991, ('false', 'true', 'true', 'false', 'true'): 0.1616452872670049, ('false', 'true', 'true', 'false', 'false'): 0.8383547127329951, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.09999999999999998, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.8391939066396348, ('false', 'true', 'true', 'true', 'false'): 0.7545192414596956}
def f_person_17_9_0(person_17_8_0, person_16_8_0, risk_17_9_0, risk_17_9_1, person_17_9_0):
    return dictionary_person_17_9_0[(person_17_8_0, person_16_8_0, risk_17_9_0, risk_17_9_1, person_17_9_0)]

dictionary_observe_17_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7985846686324592, ('false', 'false'): 1.0, ('true', 'true'): 0.20141533136754075}
def f_observe_17_9_0(person_17_9_0, observe_17_9_0):
    return dictionary_observe_17_9_0[(person_17_9_0, observe_17_9_0)]

dictionary_person_18_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7839684784312603, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.21603152156873973, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7831845099528291, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.21681549004717093, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_18_9_0(person_18_8_0, person_16_8_0, risk_18_9_0, person_18_9_0):
    return dictionary_person_18_9_0[(person_18_8_0, person_16_8_0, risk_18_9_0, person_18_9_0)]

dictionary_observe_18_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7763098153456245, ('false', 'false'): 1.0, ('true', 'true'): 0.2236901846543755}
def f_observe_18_9_0(person_18_9_0, observe_18_9_0):
    return dictionary_observe_18_9_0[(person_18_9_0, observe_18_9_0)]

dictionary_person_19_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_19_9_0(person_19_8_0, risk_19_9_0, person_19_9_0):
    return dictionary_person_19_9_0[(person_19_8_0, risk_19_9_0, person_19_9_0)]

dictionary_observe_19_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9481035966675816, ('false', 'false'): 1.0, ('true', 'true'): 0.051896403332418406}
def f_observe_19_9_0(person_19_9_0, observe_19_9_0):
    return dictionary_observe_19_9_0[(person_19_9_0, observe_19_9_0)]

dictionary_person_20_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_20_9_0(person_20_8_0, risk_20_9_0, person_20_9_0):
    return dictionary_person_20_9_0[(person_20_8_0, risk_20_9_0, person_20_9_0)]

dictionary_observe_20_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7672824555453829, ('false', 'false'): 1.0, ('true', 'true'): 0.23271754445461712}
def f_observe_20_9_0(person_20_9_0, observe_20_9_0):
    return dictionary_observe_20_9_0[(person_20_9_0, observe_20_9_0)]

dictionary_person_21_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.9365388186535092, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.06346118134649081, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.9356022798348557, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.06439772016514433, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_21_9_0(person_21_8_0, person_20_8_0, risk_21_9_0, person_21_9_0):
    return dictionary_person_21_9_0[(person_21_8_0, person_20_8_0, risk_21_9_0, person_21_9_0)]

dictionary_observe_21_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.46810036202657557, ('false', 'false'): 1.0, ('true', 'true'): 0.5318996379734244}
def f_observe_21_9_0(person_21_9_0, observe_21_9_0):
    return dictionary_observe_21_9_0[(person_21_9_0, observe_21_9_0)]

dictionary_person_22_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_22_9_0(person_22_8_0, risk_22_9_0, person_22_9_0):
    return dictionary_person_22_9_0[(person_22_8_0, risk_22_9_0, person_22_9_0)]

dictionary_observe_22_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9942042058394642, ('false', 'false'): 1.0, ('true', 'true'): 0.005795794160535772}
def f_observe_22_9_0(person_22_9_0, observe_22_9_0):
    return dictionary_observe_22_9_0[(person_22_9_0, observe_22_9_0)]

dictionary_person_23_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7972907207648958, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.20270927923510418, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.796493430044131, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.20350656995586902, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_23_9_0(person_23_8_0, person_22_8_0, risk_23_9_0, person_23_9_0):
    return dictionary_person_23_9_0[(person_23_8_0, person_22_8_0, risk_23_9_0, person_23_9_0)]

dictionary_observe_23_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7959954478921805, ('false', 'false'): 1.0, ('true', 'true'): 0.20400455210781954}
def f_observe_23_9_0(person_23_9_0, observe_23_9_0):
    return dictionary_observe_23_9_0[(person_23_9_0, observe_23_9_0)]

dictionary_person_24_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8031270142227744, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.19687298577722556, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8023238872085516, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.19767611279144837, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_24_9_0(person_24_8_0, person_18_8_0, risk_24_9_0, person_24_9_0):
    return dictionary_person_24_9_0[(person_24_8_0, person_18_8_0, risk_24_9_0, person_24_9_0)]

dictionary_observe_24_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8478440064150757, ('false', 'false'): 1.0, ('true', 'true'): 0.15215599358492427}
def f_observe_24_9_0(person_24_9_0, observe_24_9_0):
    return dictionary_observe_24_9_0[(person_24_9_0, observe_24_9_0)]

dictionary_person_25_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_25_9_0(person_25_8_0, risk_25_9_0, person_25_9_0):
    return dictionary_person_25_9_0[(person_25_8_0, risk_25_9_0, person_25_9_0)]

dictionary_observe_25_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7741863260090561, ('false', 'false'): 1.0, ('true', 'true'): 0.22581367399094388}
def f_observe_25_9_0(person_25_9_0, observe_25_9_0):
    return dictionary_observe_25_9_0[(person_25_9_0, observe_25_9_0)]

dictionary_person_26_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7931903826838373, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.20680961731616265, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7923971923011535, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.20760280769884654, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_26_9_0(person_26_8_0, person_20_8_0, risk_26_9_0, person_26_9_0):
    return dictionary_person_26_9_0[(person_26_8_0, person_20_8_0, risk_26_9_0, person_26_9_0)]

dictionary_observe_26_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9803757753149813, ('false', 'false'): 1.0, ('true', 'true'): 0.019624224685018676}
def f_observe_26_9_0(person_26_9_0, observe_26_9_0):
    return dictionary_observe_26_9_0[(person_26_9_0, observe_26_9_0)]

dictionary_person_27_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_27_9_0(person_27_8_0, risk_27_9_0, person_27_9_0):
    return dictionary_person_27_9_0[(person_27_8_0, risk_27_9_0, person_27_9_0)]

dictionary_observe_27_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5597388148583661, ('false', 'false'): 1.0, ('true', 'true'): 0.4402611851416339}
def f_observe_27_9_0(person_27_9_0, observe_27_9_0):
    return dictionary_observe_27_9_0[(person_27_9_0, observe_27_9_0)]

dictionary_person_28_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8097480023914683, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.19025199760853173, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8089382543890768, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.19106174561092315, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_28_9_0(person_28_8_0, person_29_8_0, risk_28_9_0, person_28_9_0):
    return dictionary_person_28_9_0[(person_28_8_0, person_29_8_0, risk_28_9_0, person_28_9_0)]

dictionary_observe_28_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.49262723848165424, ('false', 'false'): 1.0, ('true', 'true'): 0.5073727615183458}
def f_observe_28_9_0(person_28_9_0, observe_28_9_0):
    return dictionary_observe_28_9_0[(person_28_9_0, observe_28_9_0)]

dictionary_person_29_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7914594923644068, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.20854050763559318, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7906680328720425, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.20933196712795754, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_29_9_0(person_29_8_0, person_23_8_0, risk_29_9_0, person_29_9_0):
    return dictionary_person_29_9_0[(person_29_8_0, person_23_8_0, risk_29_9_0, person_29_9_0)]

dictionary_observe_29_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4663417327815509, ('false', 'false'): 1.0, ('true', 'true'): 0.5336582672184491}
def f_observe_29_9_0(person_29_9_0, observe_29_9_0):
    return dictionary_observe_29_9_0[(person_29_9_0, observe_29_9_0)]

dictionary_person_30_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7335032968684531, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.26649670313154694, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7327697935715846, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.26723020642841544, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_30_9_0(person_30_8_0, person_24_8_0, risk_30_9_0, person_30_9_0):
    return dictionary_person_30_9_0[(person_30_8_0, person_24_8_0, risk_30_9_0, person_30_9_0)]

dictionary_observe_30_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7266388010360165, ('false', 'false'): 1.0, ('true', 'true'): 0.2733611989639835}
def f_observe_30_9_0(person_30_9_0, observe_30_9_0):
    return dictionary_observe_30_9_0[(person_30_9_0, observe_30_9_0)]

dictionary_person_31_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.18925272333890786, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.37581459914499893, ('false', 'false', 'true', 'false', 'false'): 0.7706596482682355, ('false', 'true', 'false', 'true', 'true'): 0.19006347061556894, ('false', 'false', 'true', 'false', 'true'): 0.22934035173176448, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.8099365293844311, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7698889886199672, ('false', 'true', 'true', 'false', 'true'): 0.37518978893393284, ('false', 'true', 'true', 'false', 'false'): 0.6248102110660672, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.23011101138003276, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.8107472766610921, ('false', 'true', 'true', 'true', 'false'): 0.6241854008550011}
def f_person_31_9_0(person_31_8_0, person_30_8_0, person_32_8_0, risk_31_9_0, person_31_9_0):
    return dictionary_person_31_9_0[(person_31_8_0, person_30_8_0, person_32_8_0, risk_31_9_0, person_31_9_0)]

dictionary_observe_31_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7221184263546746, ('false', 'false'): 1.0, ('true', 'true'): 0.2778815736453254}
def f_observe_31_9_0(person_31_9_0, observe_31_9_0):
    return dictionary_observe_31_9_0[(person_31_9_0, observe_31_9_0)]

dictionary_person_32_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8112981535759866, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.18870184642401344, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8104868554224106, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.1895131445775894, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_32_9_0(person_32_8_0, person_31_8_0, risk_32_9_0, person_32_9_0):
    return dictionary_person_32_9_0[(person_32_8_0, person_31_8_0, risk_32_9_0, person_32_9_0)]

dictionary_observe_32_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7221261708498425, ('false', 'false'): 1.0, ('true', 'true'): 0.27787382915015746}
def f_observe_32_9_0(person_32_9_0, observe_32_9_0):
    return dictionary_observe_32_9_0[(person_32_9_0, observe_32_9_0)]

dictionary_person_33_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_33_9_0(person_33_8_0, risk_33_9_0, person_33_9_0):
    return dictionary_person_33_9_0[(person_33_8_0, risk_33_9_0, person_33_9_0)]

dictionary_observe_33_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.47688903371150526, ('false', 'false'): 1.0, ('true', 'true'): 0.5231109662884947}
def f_observe_33_9_0(person_33_9_0, observe_33_9_0):
    return dictionary_observe_33_9_0[(person_33_9_0, observe_33_9_0)]

dictionary_person_34_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.999, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8991, ('false', 'false', 'true', 'false'): 0.9, ('false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.09999999999999998}
def f_person_34_9_0(person_34_8_0, risk_34_9_0, risk_34_9_1, person_34_9_0):
    return dictionary_person_34_9_0[(person_34_8_0, risk_34_9_0, risk_34_9_1, person_34_9_0)]

dictionary_observe_34_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7454406354607067, ('false', 'false'): 1.0, ('true', 'true'): 0.2545593645392933}
def f_observe_34_9_0(person_34_9_0, observe_34_9_0):
    return dictionary_observe_34_9_0[(person_34_9_0, observe_34_9_0)]

dictionary_person_35_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_35_9_0(person_35_8_0, risk_35_9_0, person_35_9_0):
    return dictionary_person_35_9_0[(person_35_8_0, risk_35_9_0, person_35_9_0)]

dictionary_observe_35_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5424770854684523, ('false', 'false'): 1.0, ('true', 'true'): 0.4575229145315477}
def f_observe_35_9_0(person_35_9_0, observe_35_9_0):
    return dictionary_observe_35_9_0[(person_35_9_0, observe_35_9_0)]

dictionary_person_0_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8915243347752535, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.1084756652247465, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8906328104404783, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.10936718955952174, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_0_10_0(person_0_9_0, person_35_9_0, risk_0_10_0, person_0_10_0):
    return dictionary_person_0_10_0[(person_0_9_0, person_35_9_0, risk_0_10_0, person_0_10_0)]

dictionary_observe_0_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5197296675242433, ('false', 'false'): 1.0, ('true', 'true'): 0.4802703324757567}
def f_observe_0_10_0(person_0_10_0, observe_0_10_0):
    return dictionary_observe_0_10_0[(person_0_10_0, observe_0_10_0)]

dictionary_person_1_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7269071936597906, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2730928063402094, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7261802864661309, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.27381971353386914, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_1_10_0(person_1_9_0, person_7_9_0, risk_1_10_0, person_1_10_0):
    return dictionary_person_1_10_0[(person_1_9_0, person_7_9_0, risk_1_10_0, person_1_10_0)]

dictionary_observe_1_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6037906210085953, ('false', 'false'): 1.0, ('true', 'true'): 0.39620937899140474}
def f_observe_1_10_0(person_1_10_0, observe_1_10_0):
    return dictionary_observe_1_10_0[(person_1_10_0, observe_1_10_0)]

dictionary_person_2_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_2_10_0(person_2_9_0, risk_2_10_0, person_2_10_0):
    return dictionary_person_2_10_0[(person_2_9_0, risk_2_10_0, person_2_10_0)]

dictionary_observe_2_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9924452166607418, ('false', 'false'): 1.0, ('true', 'true'): 0.0075547833392581865}
def f_observe_2_10_0(person_2_10_0, observe_2_10_0):
    return dictionary_observe_2_10_0[(person_2_10_0, observe_2_10_0)]

dictionary_person_3_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7945459259690066, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.20545407403099336, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7937513800430376, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.20624861995696242, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_3_10_0(person_3_9_0, person_33_9_0, risk_3_10_0, person_3_10_0):
    return dictionary_person_3_10_0[(person_3_9_0, person_33_9_0, risk_3_10_0, person_3_10_0)]

dictionary_observe_3_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6111352175471836, ('false', 'false'): 1.0, ('true', 'true'): 0.3888647824528164}
def f_observe_3_10_0(person_3_10_0, observe_3_10_0):
    return dictionary_observe_3_10_0[(person_3_10_0, observe_3_10_0)]

dictionary_person_4_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8039977282760716, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.19600227172392837, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8031937305477955, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.19680626945220447, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_4_10_0(person_4_9_0, person_34_9_0, risk_4_10_0, person_4_10_0):
    return dictionary_person_4_10_0[(person_4_9_0, person_34_9_0, risk_4_10_0, person_4_10_0)]

dictionary_observe_4_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6026338127441342, ('false', 'false'): 1.0, ('true', 'true'): 0.3973661872558658}
def f_observe_4_10_0(person_4_10_0, observe_4_10_0):
    return dictionary_observe_4_10_0[(person_4_10_0, observe_4_10_0)]

dictionary_person_5_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.758633281298708, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.241366718701292, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7578746480174093, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.24212535198259066, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_5_10_0(person_5_9_0, person_35_9_0, risk_5_10_0, person_5_10_0):
    return dictionary_person_5_10_0[(person_5_9_0, person_35_9_0, risk_5_10_0, person_5_10_0)]

dictionary_observe_5_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5714621385172589, ('false', 'false'): 1.0, ('true', 'true'): 0.4285378614827411}
def f_observe_5_10_0(person_5_10_0, observe_5_10_0):
    return dictionary_observe_5_10_0[(person_5_10_0, observe_5_10_0)]

dictionary_person_6_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.5911940684520887, ('false', 'true', 'false', 'false', 'false', 'true'): 0.17568496057698768, ('false', 'true', 'true', 'false', 'true', 'true'): 0.3404457122534077, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.6595542877465923, ('false', 'true', 'false', 'false', 'false', 'false'): 0.8243150394230123, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.8234907243835893, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.19907502511301378, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.40880593154791134, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.4082141456936049, ('false', 'false', 'true', 'false', 'false', 'false'): 0.8009249748869862, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.738878013374347, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.7381391353609726, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.261121986625653, ('false', 'false', 'false', 'true', 'false', 'true'): 0.10364608427921906, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.17650927561641072, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.5917858543063951, ('false', 'false', 'true', 'false', 'true', 'false'): 0.8001240499120992, ('false', 'true', 'true', 'false', 'false', 'false'): 0.6602145022488412, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.2820877625614817, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.26186086463902736, ('false', 'false', 'false', 'true', 'true', 'false'): 0.8954575618050602, ('false', 'false', 'false', 'true', 'false', 'false'): 0.8963539157207809, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.7179122374385183, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.28280567479892027, ('false', 'false', 'true', 'false', 'true', 'true'): 0.19987595008790082, ('false', 'false', 'false', 'true', 'true', 'true'): 0.1045424381949398, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.33978549775115885, ('false', 'false', 'true', 'true', 'true', 'false'): 0.7171943252010797}
def f_person_6_10_0(person_6_9_0, person_5_9_0, person_0_9_0, person_31_9_0, risk_6_10_0, person_6_10_0):
    return dictionary_person_6_10_0[(person_6_9_0, person_5_9_0, person_0_9_0, person_31_9_0, risk_6_10_0, person_6_10_0)]

dictionary_observe_6_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6476912501580228, ('false', 'false'): 1.0, ('true', 'true'): 0.35230874984197724}
def f_observe_6_10_0(person_6_10_0, observe_6_10_0):
    return dictionary_observe_6_10_0[(person_6_10_0, observe_6_10_0)]

dictionary_person_7_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.5696838131238927, ('false', 'true', 'false', 'false', 'false', 'true'): 0.09112563408992225, ('false', 'true', 'true', 'false', 'true', 'true'): 0.2902495450535739, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.7097504549464261, ('false', 'true', 'false', 'false', 'false', 'false'): 0.9088743659100778, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.9079654915441677, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.21830679518517748, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.4303161868761073, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.42974593280891615, ('false', 'false', 'true', 'false', 'false', 'false'): 0.7816932048148225, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.7295113526363236, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.7287818412836873, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.2704886473636764, ('false', 'false', 'false', 'true', 'false', 'true'): 0.1973463220014503, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.09203450845583228, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.5702540671910838, ('false', 'false', 'true', 'false', 'true', 'false'): 0.7809115116100077, ('false', 'true', 'true', 'false', 'false', 'false'): 0.7104609158622883, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.3725710740889091, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.2712181587163127, ('false', 'false', 'false', 'true', 'true', 'false'): 0.8018510243205511, ('false', 'false', 'false', 'true', 'false', 'false'): 0.8026536779985497, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.6274289259110909, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.37319850301482016, ('false', 'false', 'true', 'false', 'true', 'true'): 0.2190884883899923, ('false', 'false', 'false', 'true', 'true', 'true'): 0.1981489756794489, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.2895390841377117, ('false', 'false', 'true', 'true', 'true', 'false'): 0.6268014969851798}
def f_person_7_10_0(person_7_9_0, person_6_9_0, person_8_9_0, person_13_9_0, risk_7_10_0, person_7_10_0):
    return dictionary_person_7_10_0[(person_7_9_0, person_6_9_0, person_8_9_0, person_13_9_0, risk_7_10_0, person_7_10_0)]

dictionary_observe_7_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8387511789138563, ('false', 'false'): 1.0, ('true', 'true'): 0.1612488210861437}
def f_observe_7_10_0(person_7_10_0, observe_7_10_0):
    return dictionary_observe_7_10_0[(person_7_10_0, observe_7_10_0)]

dictionary_person_8_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8280473637372241, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.1719526362627759, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8272193163734869, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.1727806836265131, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_8_10_0(person_8_9_0, person_9_9_0, risk_8_10_0, person_8_10_0):
    return dictionary_person_8_10_0[(person_8_9_0, person_9_9_0, risk_8_10_0, person_8_10_0)]

dictionary_observe_8_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7165799496274381, ('false', 'false'): 1.0, ('true', 'true'): 0.2834200503725619}
def f_observe_8_10_0(person_8_10_0, observe_8_10_0):
    return dictionary_observe_8_10_0[(person_8_10_0, observe_8_10_0)]

dictionary_person_9_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.237721848506101, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.3153773208560998, ('false', 'false', 'true', 'false', 'false'): 0.8990261439186955, ('false', 'true', 'false', 'true', 'true'): 0.23848412665759489, ('false', 'false', 'true', 'false', 'true'): 0.10097385608130449, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7615158733424051, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8981271177747768, ('false', 'true', 'true', 'false', 'true'): 0.31469201286896875, ('false', 'true', 'true', 'false', 'false'): 0.6853079871310312, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.10187288222522317, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.762278151493899, ('false', 'true', 'true', 'true', 'false'): 0.6846226791439002}
def f_person_9_10_0(person_9_9_0, person_10_9_0, person_8_9_0, risk_9_10_0, person_9_10_0):
    return dictionary_person_9_10_0[(person_9_9_0, person_10_9_0, person_8_9_0, risk_9_10_0, person_9_10_0)]

dictionary_observe_9_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4349062615330811, ('false', 'false'): 1.0, ('true', 'true'): 0.5650937384669189}
def f_observe_9_10_0(person_9_10_0, observe_9_10_0):
    return dictionary_observe_9_10_0[(person_9_10_0, observe_9_10_0)]

dictionary_person_10_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.21305317479110375, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.3923857867259266, ('false', 'false', 'true', 'false', 'false'): 0.7728888613894969, ('false', 'true', 'false', 'true', 'true'): 0.2138401216163126, ('false', 'false', 'true', 'false', 'true'): 0.22711113861050314, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7861598783836874, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7721159725281074, ('false', 'true', 'true', 'false', 'true'): 0.3917775642902168, ('false', 'true', 'true', 'false', 'false'): 0.6082224357097832, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.22788402747189263, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7869468252088963, ('false', 'true', 'true', 'true', 'false'): 0.6076142132740734}
def f_person_10_10_0(person_10_9_0, person_4_9_0, person_5_9_0, risk_10_10_0, person_10_10_0):
    return dictionary_person_10_10_0[(person_10_9_0, person_4_9_0, person_5_9_0, risk_10_10_0, person_10_10_0)]

dictionary_observe_10_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9876703941803192, ('false', 'false'): 1.0, ('true', 'true'): 0.012329605819680789}
def f_observe_10_10_0(person_10_10_0, observe_10_10_0):
    return dictionary_observe_10_10_0[(person_10_10_0, observe_10_10_0)]

dictionary_person_11_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_11_10_0(person_11_9_0, risk_11_10_0, person_11_10_0):
    return dictionary_person_11_10_0[(person_11_9_0, risk_11_10_0, person_11_10_0)]

dictionary_observe_11_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5045488999546761, ('false', 'false'): 1.0, ('true', 'true'): 0.4954511000453239}
def f_observe_11_10_0(person_11_10_0, observe_11_10_0):
    return dictionary_observe_11_10_0[(person_11_10_0, observe_11_10_0)]

dictionary_person_12_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.22700136130538318, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.37399987133759893, ('false', 'false', 'true', 'false', 'false'): 0.8106440607398998, ('false', 'true', 'false', 'true', 'true'): 0.2277743599440778, ('false', 'false', 'true', 'false', 'true'): 0.1893559392601002, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7722256400559222, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8098334166791599, ('false', 'true', 'true', 'false', 'true'): 0.37337324458218113, ('false', 'true', 'true', 'false', 'false'): 0.6266267554178189, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.19016658332084013, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7729986386946168, ('false', 'true', 'true', 'true', 'false'): 0.6260001286624011}
def f_person_12_10_0(person_12_9_0, person_6_9_0, person_17_9_0, risk_12_10_0, person_12_10_0):
    return dictionary_person_12_10_0[(person_12_9_0, person_6_9_0, person_17_9_0, risk_12_10_0, person_12_10_0)]

dictionary_observe_12_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4332598288467573, ('false', 'false'): 1.0, ('true', 'true'): 0.5667401711532427}
def f_observe_12_10_0(person_12_10_0, observe_12_10_0):
    return dictionary_observe_12_10_0[(person_12_10_0, observe_12_10_0)]

dictionary_person_13_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.21157427323036815, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.36160414721377077, ('false', 'false', 'true', 'false', 'false'): 0.810520085756437, ('false', 'true', 'false', 'true', 'true'): 0.21236269895713777, ('false', 'false', 'true', 'false', 'true'): 0.18947991424356303, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7876373010428622, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8097095656706805, ('false', 'true', 'true', 'false', 'true'): 0.36096511232609685, ('false', 'true', 'true', 'false', 'false'): 0.6390348876739032, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.19029043432931947, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7884257267696319, ('false', 'true', 'true', 'true', 'false'): 0.6383958527862292}
def f_person_13_10_0(person_13_9_0, person_8_9_0, person_7_9_0, risk_13_10_0, person_13_10_0):
    return dictionary_person_13_10_0[(person_13_9_0, person_8_9_0, person_7_9_0, risk_13_10_0, person_13_10_0)]

dictionary_observe_13_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4807855628624105, ('false', 'false'): 1.0, ('true', 'true'): 0.5192144371375895}
def f_observe_13_10_0(person_13_10_0, observe_13_10_0):
    return dictionary_observe_13_10_0[(person_13_10_0, observe_13_10_0)]

dictionary_person_14_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3437552517635124, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.4637981103690747, ('false', 'false', 'true', 'false', 'false'): 0.8178939788875274, ('false', 'true', 'false', 'true', 'true'): 0.34441149651174885, ('false', 'false', 'true', 'false', 'true'): 0.18210602111247265, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6555885034882512, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8170760849086398, ('false', 'true', 'true', 'false', 'true'): 0.4632613717408155, ('false', 'true', 'true', 'false', 'false'): 0.5367386282591845, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.1829239150913602, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6562447482364876, ('false', 'true', 'true', 'true', 'false'): 0.5362018896309253}
def f_person_14_10_0(person_14_9_0, person_13_9_0, person_8_9_0, risk_14_10_0, person_14_10_0):
    return dictionary_person_14_10_0[(person_14_9_0, person_13_9_0, person_8_9_0, risk_14_10_0, person_14_10_0)]

dictionary_observe_14_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7768619982987499, ('false', 'false'): 1.0, ('true', 'true'): 0.2231380017012501}
def f_observe_14_10_0(person_14_10_0, observe_14_10_0):
    return dictionary_observe_14_10_0[(person_14_10_0, observe_14_10_0)]

dictionary_person_15_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_15_10_0(person_15_9_0, risk_15_10_0, person_15_10_0):
    return dictionary_person_15_10_0[(person_15_9_0, risk_15_10_0, person_15_10_0)]

dictionary_observe_15_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4830431307650165, ('false', 'false'): 1.0, ('true', 'true'): 0.5169568692349835}
def f_observe_15_10_0(person_15_10_0, observe_15_10_0):
    return dictionary_observe_15_10_0[(person_15_10_0, observe_15_10_0)]

dictionary_person_16_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7436156786653935, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.25638432133460654, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.742872062986728, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.25712793701327197, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_16_10_0(person_16_9_0, person_17_9_0, risk_16_10_0, person_16_10_0):
    return dictionary_person_16_10_0[(person_16_9_0, person_17_9_0, risk_16_10_0, person_16_10_0)]

dictionary_observe_16_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.99936152899515, ('false', 'false'): 1.0, ('true', 'true'): 0.0006384710048500386}
def f_observe_16_10_0(person_16_10_0, observe_16_10_0):
    return dictionary_observe_16_10_0[(person_16_10_0, observe_16_10_0)]

dictionary_person_17_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8817666509190938, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.11823334908090621, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8808848842681747, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.11911511573182532, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_17_10_0(person_17_9_0, person_19_9_0, risk_17_10_0, person_17_10_0):
    return dictionary_person_17_10_0[(person_17_9_0, person_19_9_0, risk_17_10_0, person_17_10_0)]

dictionary_observe_17_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8180657622273042, ('false', 'false'): 1.0, ('true', 'true'): 0.1819342377726958}
def f_observe_17_10_0(person_17_10_0, observe_17_10_0):
    return dictionary_observe_17_10_0[(person_17_10_0, observe_17_10_0)]

dictionary_person_18_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.2858308851250919, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.41352769608044704, ('false', 'false', 'true', 'false', 'false'): 0.8220172940209877, ('false', 'true', 'false', 'true', 'true'): 0.2865450542399668, ('false', 'false', 'true', 'false', 'true'): 0.17798270597901233, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7134549457600332, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8211952767269667, ('false', 'true', 'true', 'false', 'true'): 0.4129406367171642, ('false', 'true', 'true', 'false', 'false'): 0.5870593632828358, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.17880472327303332, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7141691148749081, ('false', 'true', 'true', 'true', 'false'): 0.586472303919553}
def f_person_18_10_0(person_18_9_0, person_19_9_0, person_24_9_0, risk_18_10_0, person_18_10_0):
    return dictionary_person_18_10_0[(person_18_9_0, person_19_9_0, person_24_9_0, risk_18_10_0, person_18_10_0)]

dictionary_observe_18_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9401269133188328, ('false', 'false'): 1.0, ('true', 'true'): 0.0598730866811672}
def f_observe_18_10_0(person_18_10_0, observe_18_10_0):
    return dictionary_observe_18_10_0[(person_18_10_0, observe_18_10_0)]

dictionary_person_19_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7473466543682832, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2526533456317168, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7465993077139149, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2534006922860851, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_19_10_0(person_19_9_0, person_12_9_0, risk_19_10_0, person_19_10_0):
    return dictionary_person_19_10_0[(person_19_9_0, person_12_9_0, risk_19_10_0, person_19_10_0)]

dictionary_observe_19_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.40516732938174205, ('false', 'false'): 1.0, ('true', 'true'): 0.594832670618258}
def f_observe_19_10_0(person_19_10_0, observe_19_10_0):
    return dictionary_observe_19_10_0[(person_19_10_0, observe_19_10_0)]

dictionary_person_20_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_20_10_0(person_20_9_0, risk_20_10_0, person_20_10_0):
    return dictionary_person_20_10_0[(person_20_9_0, risk_20_10_0, person_20_10_0)]

dictionary_observe_20_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.889175653096936, ('false', 'false'): 1.0, ('true', 'true'): 0.11082434690306397}
def f_observe_20_10_0(person_20_10_0, observe_20_10_0):
    return dictionary_observe_20_10_0[(person_20_10_0, observe_20_10_0)]

dictionary_person_21_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.45865525438405824, ('false', 'true', 'false', 'false', 'false', 'true'): 0.25322364050058654, ('false', 'true', 'true', 'false', 'true', 'true'): 0.4585397072898847, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.5414602927101153, ('false', 'true', 'false', 'false', 'false', 'false'): 0.7467763594994135, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.7460295831399141, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.27421069492821015, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.5413447456159417, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.540885631247189, ('false', 'false', 'true', 'false', 'false', 'false'): 0.7257893050717898, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.6325725186972805, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.6319399461785832, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.3674274813027195, ('false', 'false', 'false', 'true', 'false', 'true'): 0.15292910568123397, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.2539704168600859, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.45911436875281103, ('false', 'false', 'true', 'false', 'true', 'false'): 0.725063515766718, ('false', 'true', 'true', 'false', 'false', 'false'): 0.5420022950051204, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.38520500426584325, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.3680600538214168, ('false', 'false', 'false', 'true', 'true', 'false'): 0.8462238234244472, ('false', 'false', 'false', 'true', 'false', 'false'): 0.847070894318766, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.6147949957341567, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.3858197992615774, ('false', 'false', 'true', 'false', 'true', 'true'): 0.274936484233282, ('false', 'false', 'false', 'true', 'true', 'true'): 0.15377617657555276, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.4579977049948796, ('false', 'false', 'true', 'true', 'true', 'false'): 0.6141802007384226}
def f_person_21_10_0(person_21_9_0, person_23_9_0, person_26_9_0, person_22_9_0, risk_21_10_0, person_21_10_0):
    return dictionary_person_21_10_0[(person_21_9_0, person_23_9_0, person_26_9_0, person_22_9_0, risk_21_10_0, person_21_10_0)]

dictionary_observe_21_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8968328515888401, ('false', 'false'): 1.0, ('true', 'true'): 0.10316714841115993}
def f_observe_21_10_0(person_21_10_0, observe_21_10_0):
    return dictionary_observe_21_10_0[(person_21_10_0, observe_21_10_0)]

dictionary_person_22_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_22_10_0(person_22_9_0, risk_22_10_0, person_22_10_0):
    return dictionary_person_22_10_0[(person_22_9_0, risk_22_10_0, person_22_10_0)]

dictionary_observe_22_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.41648549763945575, ('false', 'false'): 1.0, ('true', 'true'): 0.5835145023605443}
def f_observe_22_10_0(person_22_10_0, observe_22_10_0):
    return dictionary_observe_22_10_0[(person_22_10_0, observe_22_10_0)]

dictionary_person_23_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7555529314974386, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.24444706850256137, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7547973785659412, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2452026214340588, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_23_10_0(person_23_9_0, person_29_9_0, risk_23_10_0, person_23_10_0):
    return dictionary_person_23_10_0[(person_23_9_0, person_29_9_0, risk_23_10_0, person_23_10_0)]

dictionary_observe_23_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6157627785625888, ('false', 'false'): 1.0, ('true', 'true'): 0.38423722143741124}
def f_observe_23_10_0(person_23_10_0, observe_23_10_0):
    return dictionary_observe_23_10_0[(person_23_10_0, observe_23_10_0)]

dictionary_person_24_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.6855199894675295, ('false', 'true', 'false', 'false', 'false', 'true'): 0.06349213911737595, ('false', 'true', 'true', 'false', 'true', 'true'): 0.31379380433680726, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.6862061956631927, ('false', 'true', 'false', 'false', 'false', 'false'): 0.936507860882624, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.8428570747943617, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.09999999999999998, ('false', 'false', 'false', 'false', 'true', 'false'): 0.9, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.18585699024877766, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.31448001053247054, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.23831112281385614, ('false', 'false', 'true', 'false', 'false', 'false'): 0.8141430097512223, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.9355713530217414, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.8420142177195673, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.06442864697825856, ('false', 'false', 'false', 'true', 'false', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.15714292520563833, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.7616888771861439, ('false', 'false', 'true', 'false', 'true', 'false'): 0.7327287087761001, ('false', 'true', 'true', 'false', 'false', 'false'): 0.7624513285146586, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.1866711332585289, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.1579857822804327, ('false', 'false', 'false', 'true', 'true', 'false'): 0.8991, ('false', 'false', 'false', 'true', 'false', 'false'): 0.999, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.8133288667414711, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.268004019932676, ('false', 'false', 'true', 'false', 'true', 'true'): 0.2672712912238999, ('false', 'false', 'false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.23754867148534142, ('false', 'false', 'true', 'true', 'true', 'false'): 0.731995980067324}
def f_person_24_10_0(person_24_9_0, person_29_9_0, person_18_9_0, risk_24_10_0, risk_24_10_1, person_24_10_0):
    return dictionary_person_24_10_0[(person_24_9_0, person_29_9_0, person_18_9_0, risk_24_10_0, risk_24_10_1, person_24_10_0)]

dictionary_observe_24_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4345452934539149, ('false', 'false'): 1.0, ('true', 'true'): 0.5654547065460851}
def f_observe_24_10_0(person_24_10_0, observe_24_10_0):
    return dictionary_observe_24_10_0[(person_24_10_0, observe_24_10_0)]

dictionary_person_25_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.07590473313035917, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.2213556065336827, ('false', 'false', 'true', 'false', 'false'): 0.8434453083218223, ('false', 'true', 'false', 'true', 'true'): 0.07682882839722882, ('false', 'false', 'true', 'false', 'true'): 0.1565546916781777, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.9231711716027712, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8426018630135005, ('false', 'true', 'true', 'false', 'true'): 0.22057618271639912, ('false', 'true', 'true', 'false', 'false'): 0.7794238172836009, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.15739813698649952, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.9240952668696408, ('false', 'true', 'true', 'true', 'false'): 0.7786443934663173}
def f_person_25_10_0(person_25_9_0, person_23_9_0, person_19_9_0, risk_25_10_0, person_25_10_0):
    return dictionary_person_25_10_0[(person_25_9_0, person_23_9_0, person_19_9_0, risk_25_10_0, person_25_10_0)]

dictionary_observe_25_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9794540301565644, ('false', 'false'): 1.0, ('true', 'true'): 0.020545969843435596}
def f_observe_25_10_0(person_25_10_0, observe_25_10_0):
    return dictionary_observe_25_10_0[(person_25_10_0, observe_25_10_0)]

dictionary_person_26_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.17521030584219632, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.3860280853131479, ('false', 'false', 'true', 'false', 'false'): 0.7451432838471594, ('false', 'true', 'false', 'true', 'true'): 0.1760350955363541, ('false', 'false', 'true', 'false', 'true'): 0.25485671615284056, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.8239649044636459, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7443981405633123, ('false', 'true', 'true', 'false', 'true'): 0.38541349881195985, ('false', 'true', 'true', 'false', 'false'): 0.6145865011880401, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.2556018594366877, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.8247896941578037, ('false', 'true', 'true', 'true', 'false'): 0.6139719146868521}
def f_person_26_10_0(person_26_9_0, person_25_9_0, person_27_9_0, risk_26_10_0, person_26_10_0):
    return dictionary_person_26_10_0[(person_26_9_0, person_25_9_0, person_27_9_0, risk_26_10_0, person_26_10_0)]

dictionary_observe_26_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6402394835894021, ('false', 'false'): 1.0, ('true', 'true'): 0.3597605164105979}
def f_observe_26_10_0(person_26_10_0, observe_26_10_0):
    return dictionary_observe_26_10_0[(person_26_10_0, observe_26_10_0)]

dictionary_person_27_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7987129017341466, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.20128709826585345, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7979141888324124, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.20208581116758761, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_27_10_0(person_27_9_0, person_28_9_0, risk_27_10_0, person_27_10_0):
    return dictionary_person_27_10_0[(person_27_9_0, person_28_9_0, risk_27_10_0, person_27_10_0)]

dictionary_observe_27_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8334112462659506, ('false', 'false'): 1.0, ('true', 'true'): 0.16658875373404936}
def f_observe_27_10_0(person_27_10_0, observe_27_10_0):
    return dictionary_observe_27_10_0[(person_27_10_0, observe_27_10_0)]

dictionary_person_28_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.19381968499845392, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.3752753347556208, ('false', 'false', 'true', 'false', 'false'): 0.7756949699999057, ('false', 'true', 'false', 'true', 'true'): 0.1946258653134555, ('false', 'false', 'true', 'false', 'true'): 0.22430503000009427, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.8053741346865445, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7749192750299059, ('false', 'true', 'true', 'false', 'true'): 0.37464998474036115, ('false', 'true', 'true', 'false', 'false'): 0.6253500152596388, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.22508072497009413, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.8061803150015461, ('false', 'true', 'true', 'true', 'false'): 0.6247246652443792}
def f_person_28_10_0(person_28_9_0, person_22_9_0, person_34_9_0, risk_28_10_0, person_28_10_0):
    return dictionary_person_28_10_0[(person_28_9_0, person_22_9_0, person_34_9_0, risk_28_10_0, person_28_10_0)]

dictionary_observe_28_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8321597245938634, ('false', 'false'): 1.0, ('true', 'true'): 0.16784027540613655}
def f_observe_28_10_0(person_28_10_0, observe_28_10_0):
    return dictionary_observe_28_10_0[(person_28_10_0, observe_28_10_0)]

dictionary_person_29_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7747674637214902, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2252325362785098, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7739926962577687, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.22600730374223132, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_29_10_0(person_29_9_0, person_30_9_0, risk_29_10_0, person_29_10_0):
    return dictionary_person_29_10_0[(person_29_9_0, person_30_9_0, risk_29_10_0, person_29_10_0)]

dictionary_observe_29_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4640823015625797, ('false', 'false'): 1.0, ('true', 'true'): 0.5359176984374203}
def f_observe_29_10_0(person_29_10_0, observe_29_10_0):
    return dictionary_observe_29_10_0[(person_29_10_0, observe_29_10_0)]

dictionary_person_30_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.27308277808387726, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.3461754989172279, ('false', 'false', 'true', 'false', 'false'): 0.9003487059195769, ('false', 'true', 'false', 'true', 'true'): 0.27380969530579335, ('false', 'false', 'true', 'false', 'true'): 0.09965129408042306, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7261903046942066, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8994483572136573, ('false', 'true', 'true', 'false', 'true'): 0.345521019937165, ('false', 'true', 'true', 'false', 'false'): 0.654478980062835, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.10055164278634265, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7269172219161227, ('false', 'true', 'true', 'true', 'false'): 0.6538245010827721}
def f_person_30_10_0(person_30_9_0, person_31_9_0, person_29_9_0, risk_30_10_0, person_30_10_0):
    return dictionary_person_30_10_0[(person_30_9_0, person_31_9_0, person_29_9_0, risk_30_10_0, person_30_10_0)]

dictionary_observe_30_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9494375472792379, ('false', 'false'): 1.0, ('true', 'true'): 0.0505624527207621}
def f_observe_30_10_0(person_30_10_0, observe_30_10_0):
    return dictionary_observe_30_10_0[(person_30_10_0, observe_30_10_0)]

dictionary_person_31_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.28920421464527535, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.4212502544142638, ('false', 'false', 'true', 'false', 'false'): 0.8150429231530696, ('false', 'true', 'false', 'true', 'true'): 0.28991501043063006, ('false', 'false', 'true', 'false', 'true'): 0.1849570768469304, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7100849895693699, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8142278802299165, ('false', 'true', 'true', 'false', 'true'): 0.4206709253396034, ('false', 'true', 'true', 'false', 'false'): 0.5793290746603966, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.18577211977008345, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7107957853547247, ('false', 'true', 'true', 'true', 'false'): 0.5787497455857362}
def f_person_31_10_0(person_31_9_0, person_32_9_0, person_30_9_0, risk_31_10_0, person_31_10_0):
    return dictionary_person_31_10_0[(person_31_9_0, person_32_9_0, person_30_9_0, risk_31_10_0, person_31_10_0)]

dictionary_observe_31_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6126115608699897, ('false', 'false'): 1.0, ('true', 'true'): 0.3873884391300103}
def f_observe_31_10_0(person_31_10_0, observe_31_10_0):
    return dictionary_observe_31_10_0[(person_31_10_0, observe_31_10_0)]

dictionary_person_32_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.6025612472165992, ('false', 'true', 'false', 'false', 'false', 'true'): 0.18139570471554767, ('false', 'true', 'true', 'false', 'true', 'true'): 0.27937000455893224, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.7206299954410678, ('false', 'true', 'false', 'false', 'false', 'false'): 0.8186042952844523, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.8177856909891679, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.11880336941403757, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.3974387527834008, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.3968355883717726, ('false', 'false', 'true', 'false', 'false', 'false'): 0.8811966305859624, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.6844833385565102, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.6837988552179537, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.3155166614434898, ('false', 'false', 'false', 'true', 'false', 'true'): 0.16384101268530127, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.18221430901083213, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.6031644116282274, ('false', 'false', 'true', 'false', 'true', 'false'): 0.8803154339553765, ('false', 'true', 'true', 'false', 'false', 'false'): 0.7213513467878556, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.26317951774411696, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.3162011447820463, ('false', 'false', 'false', 'true', 'true', 'false'): 0.835322828327384, ('false', 'false', 'false', 'true', 'false', 'false'): 0.8361589873146987, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.736820482255883, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.26391633822637284, ('false', 'false', 'true', 'false', 'true', 'true'): 0.11968456604462352, ('false', 'false', 'false', 'true', 'true', 'true'): 0.16467717167261597, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.2786486532121444, ('false', 'false', 'true', 'true', 'true', 'false'): 0.7360836617736272}
def f_person_32_10_0(person_32_9_0, person_33_9_0, person_31_9_0, person_1_9_0, risk_32_10_0, person_32_10_0):
    return dictionary_person_32_10_0[(person_32_9_0, person_33_9_0, person_31_9_0, person_1_9_0, risk_32_10_0, person_32_10_0)]

dictionary_observe_32_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8281918287916581, ('false', 'false'): 1.0, ('true', 'true'): 0.1718081712083419}
def f_observe_32_10_0(person_32_10_0, observe_32_10_0):
    return dictionary_observe_32_10_0[(person_32_10_0, observe_32_10_0)]

dictionary_person_33_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6834727552306907, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.31652724476930927, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.68278928247546, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.31721071752454, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_33_10_0(person_33_9_0, person_27_9_0, risk_33_10_0, person_33_10_0):
    return dictionary_person_33_10_0[(person_33_9_0, person_27_9_0, risk_33_10_0, person_33_10_0)]

dictionary_observe_33_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5605048717810699, ('false', 'false'): 1.0, ('true', 'true'): 0.4394951282189301}
def f_observe_33_10_0(person_33_10_0, observe_33_10_0):
    return dictionary_observe_33_10_0[(person_33_10_0, observe_33_10_0)]

dictionary_person_34_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_34_10_0(person_34_9_0, risk_34_10_0, person_34_10_0):
    return dictionary_person_34_10_0[(person_34_9_0, risk_34_10_0, person_34_10_0)]

dictionary_observe_34_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8216846311423929, ('false', 'false'): 1.0, ('true', 'true'): 0.17831536885760713}
def f_observe_34_10_0(person_34_10_0, observe_34_10_0):
    return dictionary_observe_34_10_0[(person_34_10_0, observe_34_10_0)]

dictionary_person_35_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8588002595668939, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.14119974043310612, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.857941459307327, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.14205854069267299, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_35_10_0(person_35_9_0, person_29_9_0, risk_35_10_0, person_35_10_0):
    return dictionary_person_35_10_0[(person_35_9_0, person_29_9_0, risk_35_10_0, person_35_10_0)]

dictionary_observe_35_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.708299846321211, ('false', 'false'): 1.0, ('true', 'true'): 0.291700153678789}
def f_observe_35_10_0(person_35_10_0, observe_35_10_0):
    return dictionary_observe_35_10_0[(person_35_10_0, observe_35_10_0)]

functions = [f_person_0_7_0, f_person_1_7_0, f_person_2_7_0, f_person_3_7_0, f_person_4_7_0, f_person_5_7_0, f_person_6_7_0, f_person_7_7_0, f_person_8_7_0, f_person_9_7_0, f_person_10_7_0, f_person_11_7_0, f_person_12_7_0, f_person_13_7_0, f_person_14_7_0, f_person_15_7_0, f_person_16_7_0, f_person_17_7_0, f_person_18_7_0, f_person_19_7_0, f_person_20_7_0, f_person_21_7_0, f_person_22_7_0, f_person_23_7_0, f_person_24_7_0, f_person_25_7_0, f_person_26_7_0, f_person_27_7_0, f_person_28_7_0, f_person_29_7_0, f_person_30_7_0, f_person_31_7_0, f_person_32_7_0, f_person_33_7_0, f_person_34_7_0, f_person_35_7_0, f_risk_0_8_0, f_risk_1_8_0, f_risk_2_8_0, f_risk_3_8_0, f_risk_4_8_0, f_risk_5_8_0, f_risk_6_8_0, f_risk_7_8_0, f_risk_8_8_0, f_risk_9_8_0, f_risk_10_8_0, f_risk_11_8_0, f_risk_12_8_0, f_risk_13_8_0, f_risk_14_8_0, f_risk_15_8_0, f_risk_16_8_0, f_risk_17_8_0, f_risk_18_8_0, f_risk_19_8_0, f_risk_20_8_0, f_risk_21_8_0, f_risk_22_8_0, f_risk_23_8_0, f_risk_24_8_0, f_risk_25_8_0, f_risk_26_8_0, f_risk_27_8_0, f_risk_28_8_0, f_risk_29_8_0, f_risk_30_8_0, f_risk_31_8_0, f_risk_32_8_0, f_risk_33_8_0, f_risk_34_8_0, f_risk_35_8_0, f_risk_0_9_0, f_risk_1_9_0, f_risk_2_9_0, f_risk_3_9_0, f_risk_4_9_0, f_risk_5_9_0, f_risk_6_9_0, f_risk_7_9_0, f_risk_8_9_0, f_risk_9_9_0, f_risk_10_9_0, f_risk_11_9_0, f_risk_12_9_0, f_risk_13_9_0, f_risk_14_9_0, f_risk_15_9_0, f_risk_16_9_0, f_risk_17_9_0, f_risk_17_9_1, f_risk_18_9_0, f_risk_19_9_0, f_risk_20_9_0, f_risk_21_9_0, f_risk_22_9_0, f_risk_23_9_0, f_risk_24_9_0, f_risk_25_9_0, f_risk_26_9_0, f_risk_27_9_0, f_risk_28_9_0, f_risk_29_9_0, f_risk_30_9_0, f_risk_31_9_0, f_risk_32_9_0, f_risk_33_9_0, f_risk_34_9_0, f_risk_34_9_1, f_risk_35_9_0, f_risk_0_10_0, f_risk_1_10_0, f_risk_2_10_0, f_risk_3_10_0, f_risk_4_10_0, f_risk_5_10_0, f_risk_6_10_0, f_risk_7_10_0, f_risk_8_10_0, f_risk_9_10_0, f_risk_10_10_0, f_risk_11_10_0, f_risk_12_10_0, f_risk_13_10_0, f_risk_14_10_0, f_risk_15_10_0, f_risk_16_10_0, f_risk_17_10_0, f_risk_18_10_0, f_risk_19_10_0, f_risk_20_10_0, f_risk_21_10_0, f_risk_22_10_0, f_risk_23_10_0, f_risk_24_10_0, f_risk_24_10_1, f_risk_25_10_0, f_risk_26_10_0, f_risk_27_10_0, f_risk_28_10_0, f_risk_29_10_0, f_risk_30_10_0, f_risk_31_10_0, f_risk_32_10_0, f_risk_33_10_0, f_risk_34_10_0, f_risk_35_10_0, f_observe_0_7_0, f_observe_1_7_0, f_observe_2_7_0, f_observe_3_7_0, f_observe_4_7_0, f_observe_5_7_0, f_observe_6_7_0, f_observe_7_7_0, f_observe_8_7_0, f_observe_9_7_0, f_observe_10_7_0, f_observe_11_7_0, f_observe_12_7_0, f_observe_13_7_0, f_observe_14_7_0, f_observe_15_7_0, f_observe_16_7_0, f_observe_17_7_0, f_observe_18_7_0, f_observe_19_7_0, f_observe_20_7_0, f_observe_21_7_0, f_observe_22_7_0, f_observe_23_7_0, f_observe_24_7_0, f_observe_25_7_0, f_observe_26_7_0, f_observe_27_7_0, f_observe_28_7_0, f_observe_29_7_0, f_observe_30_7_0, f_observe_31_7_0, f_observe_32_7_0, f_observe_33_7_0, f_observe_34_7_0, f_observe_35_7_0, f_person_0_8_0, f_observe_0_8_0, f_person_1_8_0, f_observe_1_8_0, f_person_2_8_0, f_observe_2_8_0, f_person_3_8_0, f_observe_3_8_0, f_person_4_8_0, f_observe_4_8_0, f_person_5_8_0, f_observe_5_8_0, f_person_6_8_0, f_observe_6_8_0, f_person_7_8_0, f_observe_7_8_0, f_person_8_8_0, f_observe_8_8_0, f_person_9_8_0, f_observe_9_8_0, f_person_10_8_0, f_observe_10_8_0, f_person_11_8_0, f_observe_11_8_0, f_person_12_8_0, f_observe_12_8_0, f_person_13_8_0, f_observe_13_8_0, f_person_14_8_0, f_observe_14_8_0, f_person_15_8_0, f_observe_15_8_0, f_person_16_8_0, f_observe_16_8_0, f_person_17_8_0, f_observe_17_8_0, f_person_18_8_0, f_observe_18_8_0, f_person_19_8_0, f_observe_19_8_0, f_person_20_8_0, f_observe_20_8_0, f_person_21_8_0, f_observe_21_8_0, f_person_22_8_0, f_observe_22_8_0, f_person_23_8_0, f_observe_23_8_0, f_person_24_8_0, f_observe_24_8_0, f_person_25_8_0, f_observe_25_8_0, f_person_26_8_0, f_observe_26_8_0, f_person_27_8_0, f_observe_27_8_0, f_person_28_8_0, f_observe_28_8_0, f_person_29_8_0, f_observe_29_8_0, f_person_30_8_0, f_observe_30_8_0, f_person_31_8_0, f_observe_31_8_0, f_person_32_8_0, f_observe_32_8_0, f_person_33_8_0, f_observe_33_8_0, f_person_34_8_0, f_observe_34_8_0, f_person_35_8_0, f_observe_35_8_0, f_person_0_9_0, f_observe_0_9_0, f_person_1_9_0, f_observe_1_9_0, f_person_2_9_0, f_observe_2_9_0, f_person_3_9_0, f_observe_3_9_0, f_person_4_9_0, f_observe_4_9_0, f_person_5_9_0, f_observe_5_9_0, f_person_6_9_0, f_observe_6_9_0, f_person_7_9_0, f_observe_7_9_0, f_person_8_9_0, f_observe_8_9_0, f_person_9_9_0, f_observe_9_9_0, f_person_10_9_0, f_observe_10_9_0, f_person_11_9_0, f_observe_11_9_0, f_person_12_9_0, f_observe_12_9_0, f_person_13_9_0, f_observe_13_9_0, f_person_14_9_0, f_observe_14_9_0, f_person_15_9_0, f_observe_15_9_0, f_person_16_9_0, f_observe_16_9_0, f_person_17_9_0, f_observe_17_9_0, f_person_18_9_0, f_observe_18_9_0, f_person_19_9_0, f_observe_19_9_0, f_person_20_9_0, f_observe_20_9_0, f_person_21_9_0, f_observe_21_9_0, f_person_22_9_0, f_observe_22_9_0, f_person_23_9_0, f_observe_23_9_0, f_person_24_9_0, f_observe_24_9_0, f_person_25_9_0, f_observe_25_9_0, f_person_26_9_0, f_observe_26_9_0, f_person_27_9_0, f_observe_27_9_0, f_person_28_9_0, f_observe_28_9_0, f_person_29_9_0, f_observe_29_9_0, f_person_30_9_0, f_observe_30_9_0, f_person_31_9_0, f_observe_31_9_0, f_person_32_9_0, f_observe_32_9_0, f_person_33_9_0, f_observe_33_9_0, f_person_34_9_0, f_observe_34_9_0, f_person_35_9_0, f_observe_35_9_0, f_person_0_10_0, f_observe_0_10_0, f_person_1_10_0, f_observe_1_10_0, f_person_2_10_0, f_observe_2_10_0, f_person_3_10_0, f_observe_3_10_0, f_person_4_10_0, f_observe_4_10_0, f_person_5_10_0, f_observe_5_10_0, f_person_6_10_0, f_observe_6_10_0, f_person_7_10_0, f_observe_7_10_0, f_person_8_10_0, f_observe_8_10_0, f_person_9_10_0, f_observe_9_10_0, f_person_10_10_0, f_observe_10_10_0, f_person_11_10_0, f_observe_11_10_0, f_person_12_10_0, f_observe_12_10_0, f_person_13_10_0, f_observe_13_10_0, f_person_14_10_0, f_observe_14_10_0, f_person_15_10_0, f_observe_15_10_0, f_person_16_10_0, f_observe_16_10_0, f_person_17_10_0, f_observe_17_10_0, f_person_18_10_0, f_observe_18_10_0, f_person_19_10_0, f_observe_19_10_0, f_person_20_10_0, f_observe_20_10_0, f_person_21_10_0, f_observe_21_10_0, f_person_22_10_0, f_observe_22_10_0, f_person_23_10_0, f_observe_23_10_0, f_person_24_10_0, f_observe_24_10_0, f_person_25_10_0, f_observe_25_10_0, f_person_26_10_0, f_observe_26_10_0, f_person_27_10_0, f_observe_27_10_0, f_person_28_10_0, f_observe_28_10_0, f_person_29_10_0, f_observe_29_10_0, f_person_30_10_0, f_observe_30_10_0, f_person_31_10_0, f_observe_31_10_0, f_person_32_10_0, f_observe_32_10_0, f_person_33_10_0, f_observe_33_10_0, f_person_34_10_0, f_observe_34_10_0, f_person_35_10_0, f_observe_35_10_0]
domains_dict = {'person_33_7_0': ['false', 'true'], 'person_4_7_0': ['false', 'true'], 'risk_13_8_0': ['false', 'true'], 'risk_6_8_0': ['false', 'true'], 'person_31_7_0': ['false', 'true'], 'risk_2_9_0': ['false', 'true'], 'person_17_8_0': ['false', 'true'], 'risk_10_9_0': ['false', 'true'], 'observe_23_9_0': ['false', 'true'], 'risk_13_10_0': ['false', 'true'], 'observe_0_10_0': ['false', 'true'], 'person_4_9_0': ['false', 'true'], 'observe_3_10_0': ['false', 'true'], 'person_34_8_0': ['false', 'true'], 'person_31_9_0': ['false', 'true'], 'person_29_10_0': ['false', 'true'], 'person_17_10_0': ['false', 'true'], 'risk_5_10_0': ['false', 'true'], 'risk_23_9_0': ['false', 'true'], 'person_33_10_0': ['false', 'true'], 'person_32_8_0': ['false', 'true'], 'risk_31_10_0': ['false', 'true'], 'person_0_8_0': ['false', 'true'], 'person_9_10_0': ['false', 'true'], 'observe_21_10_0': ['false', 'true'], 'person_27_7_0': ['false', 'true'], 'risk_12_10_0': ['false', 'true'], 'risk_27_10_0': ['false', 'true'], 'risk_26_8_0': ['false', 'true'], 'observe_30_8_0': ['false', 'true'], 'risk_21_9_0': ['false', 'true'], 'person_25_7_0': ['false', 'true'], 'person_2_8_0': ['false', 'true'], 'observe_4_10_0': ['false', 'true'], 'person_31_10_0': ['false', 'true'], 'person_5_10_0': ['false', 'true'], 'person_18_10_0': ['false', 'true'], 'observe_7_8_0': ['false', 'true'], 'person_25_9_0': ['false', 'true'], 'person_29_9_0': ['false', 'true'], 'person_16_9_0': ['false', 'true'], 'observe_15_8_0': ['false', 'true'], 'risk_28_9_0': ['false', 'true'], 'observe_35_9_0': ['false', 'true'], 'observe_35_7_0': ['false', 'true'], 'risk_0_9_0': ['false', 'true'], 'observe_25_8_0': ['false', 'true'], 'person_7_9_0': ['false', 'true'], 'person_27_8_0': ['false', 'true'], 'person_10_8_0': ['false', 'true'], 'risk_18_9_0': ['false', 'true'], 'person_29_7_0': ['false', 'true'], 'person_1_10_0': ['false', 'true'], 'observe_18_8_0': ['false', 'true'], 'person_26_9_0': ['false', 'true'], 'risk_34_8_0': ['false', 'true'], 'risk_29_8_0': ['false', 'true'], 'risk_24_9_0': ['false', 'true'], 'person_22_10_0': ['false', 'true'], 'observe_25_7_0': ['false', 'true'], 'person_24_9_0': ['false', 'true'], 'observe_1_8_0': ['false', 'true'], 'person_21_8_0': ['false', 'true'], 'risk_11_9_0': ['false', 'true'], 'observe_21_8_0': ['false', 'true'], 'observe_23_10_0': ['false', 'true'], 'observe_27_7_0': ['false', 'true'], 'person_15_8_0': ['false', 'true'], 'risk_8_8_0': ['false', 'true'], 'person_25_10_0': ['false', 'true'], 'risk_34_10_0': ['false', 'true'], 'observe_13_10_0': ['false', 'true'], 'observe_1_10_0': ['false', 'true'], 'person_7_10_0': ['false', 'true'], 'observe_17_9_0': ['false', 'true'], 'person_24_7_0': ['false', 'true'], 'observe_35_10_0': ['false', 'true'], 'person_7_7_0': ['false', 'true'], 'person_11_9_0': ['false', 'true'], 'risk_1_10_0': ['false', 'true'], 'observe_23_8_0': ['false', 'true'], 'observe_18_7_0': ['false', 'true'], 'person_17_9_0': ['false', 'true'], 'observe_27_9_0': ['false', 'true'], 'risk_2_8_0': ['false', 'true'], 'risk_3_9_0': ['false', 'true'], 'person_14_10_0': ['false', 'true'], 'person_34_9_0': ['false', 'true'], 'risk_23_8_0': ['false', 'true'], 'person_12_10_0': ['false', 'true'], 'person_11_7_0': ['false', 'true'], 'observe_7_10_0': ['false', 'true'], 'risk_13_9_0': ['false', 'true'], 'observe_32_10_0': ['false', 'true'], 'person_32_7_0': ['false', 'true'], 'person_3_10_0': ['false', 'true'], 'person_0_9_0': ['false', 'true'], 'person_32_9_0': ['false', 'true'], 'person_14_8_0': ['false', 'true'], 'person_0_7_0': ['false', 'true'], 'observe_23_7_0': ['false', 'true'], 'observe_5_10_0': ['false', 'true'], 'observe_33_10_0': ['false', 'true'], 'risk_21_8_0': ['false', 'true'], 'risk_7_10_0': ['false', 'true'], 'observe_9_8_0': ['false', 'true'], 'person_3_8_0': ['false', 'true'], 'person_8_9_0': ['false', 'true'], 'observe_32_7_0': ['false', 'true'], 'observe_32_9_0': ['false', 'true'], 'risk_22_9_0': ['false', 'true'], 'person_6_7_0': ['false', 'true'], 'risk_28_8_0': ['false', 'true'], 'person_11_10_0': ['false', 'true'], 'observe_25_9_0': ['false', 'true'], 'person_7_8_0': ['false', 'true'], 'risk_14_10_0': ['false', 'true'], 'person_20_8_0': ['false', 'true'], 'person_3_7_0': ['false', 'true'], 'risk_18_8_0': ['false', 'true'], 'risk_30_10_0': ['false', 'true'], 'person_14_7_0': ['false', 'true'], 'person_1_7_0': ['false', 'true'], 'observe_1_7_0': ['false', 'true'], 'observe_34_10_0': ['false', 'true'], 'observe_16_9_0': ['false', 'true'], 'observe_11_9_0': ['false', 'true'], 'risk_34_9_1': ['false', 'true'], 'risk_34_9_0': ['false', 'true'], 'risk_29_9_0': ['false', 'true'], 'observe_16_7_0': ['false', 'true'], 'person_19_9_0': ['false', 'true'], 'person_20_7_0': ['false', 'true'], 'observe_0_8_0': ['false', 'true'], 'person_5_8_0': ['false', 'true'], 'person_24_8_0': ['false', 'true'], 'risk_8_9_0': ['false', 'true'], 'person_22_7_0': ['false', 'true'], 'risk_11_8_0': ['false', 'true'], 'person_1_9_0': ['false', 'true'], 'risk_10_10_0': ['false', 'true'], 'observe_34_9_0': ['false', 'true'], 'observe_13_8_0': ['false', 'true'], 'risk_31_8_0': ['false', 'true'], 'person_6_9_0': ['false', 'true'], 'risk_2_10_0': ['false', 'true'], 'observe_2_8_0': ['false', 'true'], 'risk_19_8_0': ['false', 'true'], 'person_26_8_0': ['false', 'true'], 'person_11_8_0': ['false', 'true'], 'person_22_9_0': ['false', 'true'], 'observe_27_8_0': ['false', 'true'], 'risk_32_10_0': ['false', 'true'], 'risk_3_8_0': ['false', 'true'], 'observe_26_9_0': ['false', 'true'], 'risk_3_10_0': ['false', 'true'], 'observe_34_7_0': ['false', 'true'], 'observe_25_10_0': ['false', 'true'], 'person_27_10_0': ['false', 'true'], 'observe_26_7_0': ['false', 'true'], 'risk_8_10_0': ['false', 'true'], 'observe_1_9_0': ['false', 'true'], 'observe_29_10_0': ['false', 'true'], 'risk_17_8_0': ['false', 'true'], 'person_32_10_0': ['false', 'true'], 'observe_28_9_0': ['false', 'true'], 'person_5_7_0': ['false', 'true'], 'risk_25_8_0': ['false', 'true'], 'risk_33_9_0': ['false', 'true'], 'risk_23_10_0': ['false', 'true'], 'person_8_7_0': ['false', 'true'], 'person_26_7_0': ['false', 'true'], 'person_14_9_0': ['false', 'true'], 'observe_34_8_0': ['false', 'true'], 'observe_2_7_0': ['false', 'true'], 'person_6_10_0': ['false', 'true'], 'observe_9_9_0': ['false', 'true'], 'risk_22_10_0': ['false', 'true'], 'person_3_9_0': ['false', 'true'], 'person_8_8_0': ['false', 'true'], 'observe_32_8_0': ['false', 'true'], 'observe_33_9_0': ['false', 'true'], 'risk_22_8_0': ['false', 'true'], 'person_20_9_0': ['false', 'true'], 'person_6_8_0': ['false', 'true'], 'observe_10_7_0': ['false', 'true'], 'observe_4_9_0': ['false', 'true'], 'risk_4_10_0': ['false', 'true'], 'risk_20_9_0': ['false', 'true'], 'person_23_10_0': ['false', 'true'], 'observe_11_8_0': ['false', 'true'], 'observe_33_7_0': ['false', 'true'], 'observe_9_7_0': ['false', 'true'], 'observe_16_8_0': ['false', 'true'], 'person_28_10_0': ['false', 'true'], 'observe_31_7_0': ['false', 'true'], 'person_19_8_0': ['false', 'true'], 'risk_5_8_0': ['false', 'true'], 'observe_0_9_0': ['false', 'true'], 'person_28_8_0': ['false', 'true'], 'person_1_8_0': ['false', 'true'], 'risk_9_8_0': ['false', 'true'], 'observe_30_10_0': ['false', 'true'], 'person_12_8_0': ['false', 'true'], 'risk_31_9_0': ['false', 'true'], 'observe_13_9_0': ['false', 'true'], 'risk_27_8_0': ['false', 'true'], 'observe_31_8_0': ['false', 'true'], 'observe_17_10_0': ['false', 'true'], 'person_19_7_0': ['false', 'true'], 'risk_19_9_0': ['false', 'true'], 'observe_13_7_0': ['false', 'true'], 'observe_9_10_0': ['false', 'true'], 'observe_2_10_0': ['false', 'true'], 'observe_2_9_0': ['false', 'true'], 'risk_7_9_0': ['false', 'true'], 'observe_6_8_0': ['false', 'true'], 'observe_26_8_0': ['false', 'true'], 'person_22_8_0': ['false', 'true'], 'risk_30_8_0': ['false', 'true'], 'person_23_9_0': ['false', 'true'], 'observe_11_7_0': ['false', 'true'], 'observe_15_10_0': ['false', 'true'], 'observe_10_8_0': ['false', 'true'], 'observe_8_7_0': ['false', 'true'], 'person_23_7_0': ['false', 'true'], 'risk_16_8_0': ['false', 'true'], 'observe_8_9_0': ['false', 'true'], 'observe_0_7_0': ['false', 'true'], 'risk_6_10_0': ['false', 'true'], 'risk_1_9_0': ['false', 'true'], 'observe_28_8_0': ['false', 'true'], 'observe_20_10_0': ['false', 'true'], 'observe_6_10_0': ['false', 'true'], 'risk_20_10_0': ['false', 'true'], 'risk_33_8_0': ['false', 'true'], 'risk_14_8_0': ['false', 'true'], 'person_18_8_0': ['false', 'true'], 'person_24_10_0': ['false', 'true'], 'risk_24_10_1': ['false', 'true'], 'risk_24_10_0': ['false', 'true'], 'observe_12_10_0': ['false', 'true'], 'risk_30_9_0': ['false', 'true'], 'risk_17_9_0': ['false', 'true'], 'risk_17_9_1': ['false', 'true'], 'observe_3_7_0': ['false', 'true'], 'risk_25_9_0': ['false', 'true'], 'person_9_8_0': ['false', 'true'], 'person_35_8_0': ['false', 'true'], 'observe_28_7_0': ['false', 'true'], 'person_30_8_0': ['false', 'true'], 'observe_33_8_0': ['false', 'true'], 'person_35_10_0': ['false', 'true'], 'risk_35_10_0': ['false', 'true'], 'person_17_7_0': ['false', 'true'], 'observe_3_9_0': ['false', 'true'], 'observe_4_8_0': ['false', 'true'], 'person_33_9_0': ['false', 'true'], 'person_4_10_0': ['false', 'true'], 'observe_18_9_0': ['false', 'true'], 'observe_19_9_0': ['false', 'true'], 'person_12_7_0': ['false', 'true'], 'risk_16_9_0': ['false', 'true'], 'person_28_9_0': ['false', 'true'], 'observe_14_7_0': ['false', 'true'], 'observe_4_7_0': ['false', 'true'], 'observe_20_8_0': ['false', 'true'], 'person_26_10_0': ['false', 'true'], 'risk_5_9_0': ['false', 'true'], 'observe_6_7_0': ['false', 'true'], 'observe_14_9_0': ['false', 'true'], 'person_35_7_0': ['false', 'true'], 'risk_9_9_0': ['false', 'true'], 'person_12_9_0': ['false', 'true'], 'person_8_10_0': ['false', 'true'], 'risk_27_9_0': ['false', 'true'], 'observe_31_9_0': ['false', 'true'], 'observe_5_8_0': ['false', 'true'], 'person_20_10_0': ['false', 'true'], 'risk_7_8_0': ['false', 'true'], 'observe_24_10_0': ['false', 'true'], 'risk_12_9_0': ['false', 'true'], 'observe_22_9_0': ['false', 'true'], 'observe_29_8_0': ['false', 'true'], 'person_23_8_0': ['false', 'true'], 'observe_6_9_0': ['false', 'true'], 'person_16_10_0': ['false', 'true'], 'observe_10_9_0': ['false', 'true'], 'observe_19_10_0': ['false', 'true'], 'risk_35_8_0': ['false', 'true'], 'risk_16_10_0': ['false', 'true'], 'person_28_7_0': ['false', 'true'], 'risk_28_10_0': ['false', 'true'], 'observe_31_10_0': ['false', 'true'], 'observe_24_7_0': ['false', 'true'], 'risk_4_9_0': ['false', 'true'], 'risk_15_10_0': ['false', 'true'], 'risk_1_8_0': ['false', 'true'], 'observe_24_9_0': ['false', 'true'], 'person_13_9_0': ['false', 'true'], 'observe_12_9_0': ['false', 'true'], 'observe_18_10_0': ['false', 'true'], 'person_13_7_0': ['false', 'true'], 'risk_32_8_0': ['false', 'true'], 'risk_6_9_0': ['false', 'true'], 'person_18_7_0': ['false', 'true'], 'risk_14_9_0': ['false', 'true'], 'observe_19_7_0': ['false', 'true'], 'person_13_10_0': ['false', 'true'], 'person_18_9_0': ['false', 'true'], 'risk_10_8_0': ['false', 'true'], 'observe_12_7_0': ['false', 'true'], 'risk_0_10_0': ['false', 'true'], 'observe_22_10_0': ['false', 'true'], 'risk_19_10_0': ['false', 'true'], 'observe_8_8_0': ['false', 'true'], 'person_35_9_0': ['false', 'true'], 'risk_26_10_0': ['false', 'true'], 'observe_10_10_0': ['false', 'true'], 'person_9_9_0': ['false', 'true'], 'person_31_8_0': ['false', 'true'], 'observe_16_10_0': ['false', 'true'], 'person_9_7_0': ['false', 'true'], 'person_30_9_0': ['false', 'true'], 'risk_33_10_0': ['false', 'true'], 'person_19_10_0': ['false', 'true'], 'person_30_7_0': ['false', 'true'], 'person_34_10_0': ['false', 'true'], 'person_15_10_0': ['false', 'true'], 'observe_28_10_0': ['false', 'true'], 'person_4_8_0': ['false', 'true'], 'observe_22_7_0': ['false', 'true'], 'observe_19_8_0': ['false', 'true'], 'observe_12_8_0': ['false', 'true'], 'risk_26_9_0': ['false', 'true'], 'observe_30_9_0': ['false', 'true'], 'observe_30_7_0': ['false', 'true'], 'observe_20_7_0': ['false', 'true'], 'person_0_10_0': ['false', 'true'], 'observe_3_8_0': ['false', 'true'], 'person_21_10_0': ['false', 'true'], 'observe_7_9_0': ['false', 'true'], 'person_25_8_0': ['false', 'true'], 'person_29_8_0': ['false', 'true'], 'risk_9_10_0': ['false', 'true'], 'observe_20_9_0': ['false', 'true'], 'person_16_8_0': ['false', 'true'], 'observe_7_7_0': ['false', 'true'], 'person_2_10_0': ['false', 'true'], 'observe_14_8_0': ['false', 'true'], 'observe_35_8_0': ['false', 'true'], 'observe_15_9_0': ['false', 'true'], 'risk_17_10_0': ['false', 'true'], 'observe_29_7_0': ['false', 'true'], 'risk_15_9_0': ['false', 'true'], 'observe_27_10_0': ['false', 'true'], 'risk_32_9_0': ['false', 'true'], 'risk_12_8_0': ['false', 'true'], 'risk_15_8_0': ['false', 'true'], 'observe_22_8_0': ['false', 'true'], 'risk_0_8_0': ['false', 'true'], 'observe_29_9_0': ['false', 'true'], 'observe_11_10_0': ['false', 'true'], 'person_10_10_0': ['false', 'true'], 'person_27_9_0': ['false', 'true'], 'person_10_9_0': ['false', 'true'], 'risk_35_9_0': ['false', 'true'], 'observe_14_10_0': ['false', 'true'], 'observe_26_10_0': ['false', 'true'], 'observe_15_7_0': ['false', 'true'], 'person_2_7_0': ['false', 'true'], 'person_15_7_0': ['false', 'true'], 'risk_29_10_0': ['false', 'true'], 'person_2_9_0': ['false', 'true'], 'observe_17_7_0': ['false', 'true'], 'risk_24_8_0': ['false', 'true'], 'person_21_7_0': ['false', 'true'], 'risk_25_10_0': ['false', 'true'], 'observe_21_9_0': ['false', 'true'], 'observe_8_10_0': ['false', 'true'], 'person_33_8_0': ['false', 'true'], 'risk_4_8_0': ['false', 'true'], 'observe_24_8_0': ['false', 'true'], 'person_15_9_0': ['false', 'true'], 'risk_21_10_0': ['false', 'true'], 'person_21_9_0': ['false', 'true'], 'person_5_9_0': ['false', 'true'], 'person_10_7_0': ['false', 'true'], 'person_34_7_0': ['false', 'true'], 'person_13_8_0': ['false', 'true'], 'person_30_10_0': ['false', 'true'], 'observe_5_7_0': ['false', 'true'], 'observe_17_8_0': ['false', 'true'], 'person_16_7_0': ['false', 'true'], 'risk_20_8_0': ['false', 'true'], 'observe_5_9_0': ['false', 'true'], 'risk_18_10_0': ['false', 'true'], 'observe_21_7_0': ['false', 'true'], 'risk_11_10_0': ['false', 'true']}

def create_graph():
    g = build_graph(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/data/data98/infection0'
    return g

def create_bbn():
    g = build_bbn(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/data/data98/infection0'
    return g

