from bayesian.factor_graph import *
from bayesian.bbn import *

dictionary_person_0_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_0_7_0(person_0_7_0):
    return dictionary_person_0_7_0[person_0_7_0]

dictionary_person_1_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_1_7_0(person_1_7_0):
    return dictionary_person_1_7_0[person_1_7_0]

dictionary_person_2_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_2_7_0(person_2_7_0):
    return dictionary_person_2_7_0[person_2_7_0]

dictionary_person_3_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_3_7_0(person_3_7_0):
    return dictionary_person_3_7_0[person_3_7_0]

dictionary_person_4_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_4_7_0(person_4_7_0):
    return dictionary_person_4_7_0[person_4_7_0]

dictionary_person_5_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_5_7_0(person_5_7_0):
    return dictionary_person_5_7_0[person_5_7_0]

dictionary_person_6_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_6_7_0(person_6_7_0):
    return dictionary_person_6_7_0[person_6_7_0]

dictionary_person_7_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_7_7_0(person_7_7_0):
    return dictionary_person_7_7_0[person_7_7_0]

dictionary_person_8_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_8_7_0(person_8_7_0):
    return dictionary_person_8_7_0[person_8_7_0]

dictionary_person_9_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_9_7_0(person_9_7_0):
    return dictionary_person_9_7_0[person_9_7_0]

dictionary_person_10_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_10_7_0(person_10_7_0):
    return dictionary_person_10_7_0[person_10_7_0]

dictionary_person_11_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_11_7_0(person_11_7_0):
    return dictionary_person_11_7_0[person_11_7_0]

dictionary_person_12_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_12_7_0(person_12_7_0):
    return dictionary_person_12_7_0[person_12_7_0]

dictionary_person_13_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_13_7_0(person_13_7_0):
    return dictionary_person_13_7_0[person_13_7_0]

dictionary_person_14_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_14_7_0(person_14_7_0):
    return dictionary_person_14_7_0[person_14_7_0]

dictionary_person_18_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_18_7_0(person_18_7_0):
    return dictionary_person_18_7_0[person_18_7_0]

dictionary_person_19_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_19_7_0(person_19_7_0):
    return dictionary_person_19_7_0[person_19_7_0]

dictionary_person_20_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_20_7_0(person_20_7_0):
    return dictionary_person_20_7_0[person_20_7_0]

dictionary_person_21_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_21_7_0(person_21_7_0):
    return dictionary_person_21_7_0[person_21_7_0]

dictionary_person_24_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_24_7_0(person_24_7_0):
    return dictionary_person_24_7_0[person_24_7_0]

dictionary_person_25_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_25_7_0(person_25_7_0):
    return dictionary_person_25_7_0[person_25_7_0]

dictionary_person_26_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_26_7_0(person_26_7_0):
    return dictionary_person_26_7_0[person_26_7_0]

dictionary_person_27_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_27_7_0(person_27_7_0):
    return dictionary_person_27_7_0[person_27_7_0]

dictionary_person_28_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_28_7_0(person_28_7_0):
    return dictionary_person_28_7_0[person_28_7_0]

dictionary_person_29_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_29_7_0(person_29_7_0):
    return dictionary_person_29_7_0[person_29_7_0]

dictionary_person_31_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_31_7_0(person_31_7_0):
    return dictionary_person_31_7_0[person_31_7_0]

dictionary_person_32_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_32_7_0(person_32_7_0):
    return dictionary_person_32_7_0[person_32_7_0]

dictionary_person_33_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_33_7_0(person_33_7_0):
    return dictionary_person_33_7_0[person_33_7_0]

dictionary_person_34_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_34_7_0(person_34_7_0):
    return dictionary_person_34_7_0[person_34_7_0]

dictionary_person_35_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_35_7_0(person_35_7_0):
    return dictionary_person_35_7_0[person_35_7_0]

dictionary_risk_0_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_8_0(risk_0_8_0):
    return dictionary_risk_0_8_0[risk_0_8_0]

dictionary_risk_1_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_8_0(risk_1_8_0):
    return dictionary_risk_1_8_0[risk_1_8_0]

dictionary_risk_2_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_8_0(risk_2_8_0):
    return dictionary_risk_2_8_0[risk_2_8_0]

dictionary_risk_3_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_8_0(risk_3_8_0):
    return dictionary_risk_3_8_0[risk_3_8_0]

dictionary_risk_4_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_8_0(risk_4_8_0):
    return dictionary_risk_4_8_0[risk_4_8_0]

dictionary_risk_5_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_8_0(risk_5_8_0):
    return dictionary_risk_5_8_0[risk_5_8_0]

dictionary_risk_6_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_8_0(risk_6_8_0):
    return dictionary_risk_6_8_0[risk_6_8_0]

dictionary_risk_7_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_8_0(risk_7_8_0):
    return dictionary_risk_7_8_0[risk_7_8_0]

dictionary_risk_8_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_8_0(risk_8_8_0):
    return dictionary_risk_8_8_0[risk_8_8_0]

dictionary_risk_9_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_8_0(risk_9_8_0):
    return dictionary_risk_9_8_0[risk_9_8_0]

dictionary_risk_10_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_8_0(risk_10_8_0):
    return dictionary_risk_10_8_0[risk_10_8_0]

dictionary_risk_11_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_8_0(risk_11_8_0):
    return dictionary_risk_11_8_0[risk_11_8_0]

dictionary_risk_12_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_8_0(risk_12_8_0):
    return dictionary_risk_12_8_0[risk_12_8_0]

dictionary_risk_13_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_8_0(risk_13_8_0):
    return dictionary_risk_13_8_0[risk_13_8_0]

dictionary_risk_14_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_8_0(risk_14_8_0):
    return dictionary_risk_14_8_0[risk_14_8_0]

dictionary_risk_18_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_8_0(risk_18_8_0):
    return dictionary_risk_18_8_0[risk_18_8_0]

dictionary_risk_19_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_8_0(risk_19_8_0):
    return dictionary_risk_19_8_0[risk_19_8_0]

dictionary_risk_20_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_8_0(risk_20_8_0):
    return dictionary_risk_20_8_0[risk_20_8_0]

dictionary_risk_21_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_8_0(risk_21_8_0):
    return dictionary_risk_21_8_0[risk_21_8_0]

dictionary_risk_24_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_8_0(risk_24_8_0):
    return dictionary_risk_24_8_0[risk_24_8_0]

dictionary_risk_25_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_8_0(risk_25_8_0):
    return dictionary_risk_25_8_0[risk_25_8_0]

dictionary_risk_26_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_8_0(risk_26_8_0):
    return dictionary_risk_26_8_0[risk_26_8_0]

dictionary_risk_27_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_8_0(risk_27_8_0):
    return dictionary_risk_27_8_0[risk_27_8_0]

dictionary_risk_28_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_8_0(risk_28_8_0):
    return dictionary_risk_28_8_0[risk_28_8_0]

dictionary_risk_29_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_8_0(risk_29_8_0):
    return dictionary_risk_29_8_0[risk_29_8_0]

dictionary_risk_31_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_8_0(risk_31_8_0):
    return dictionary_risk_31_8_0[risk_31_8_0]

dictionary_risk_32_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_8_0(risk_32_8_0):
    return dictionary_risk_32_8_0[risk_32_8_0]

dictionary_risk_33_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_8_0(risk_33_8_0):
    return dictionary_risk_33_8_0[risk_33_8_0]

dictionary_risk_34_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_8_0(risk_34_8_0):
    return dictionary_risk_34_8_0[risk_34_8_0]

dictionary_risk_35_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_8_0(risk_35_8_0):
    return dictionary_risk_35_8_0[risk_35_8_0]

dictionary_risk_0_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_9_0(risk_0_9_0):
    return dictionary_risk_0_9_0[risk_0_9_0]

dictionary_risk_1_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_9_0(risk_1_9_0):
    return dictionary_risk_1_9_0[risk_1_9_0]

dictionary_risk_2_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_9_0(risk_2_9_0):
    return dictionary_risk_2_9_0[risk_2_9_0]

dictionary_risk_3_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_9_0(risk_3_9_0):
    return dictionary_risk_3_9_0[risk_3_9_0]

dictionary_risk_4_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_9_0(risk_4_9_0):
    return dictionary_risk_4_9_0[risk_4_9_0]

dictionary_risk_5_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_9_0(risk_5_9_0):
    return dictionary_risk_5_9_0[risk_5_9_0]

dictionary_risk_6_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_9_0(risk_6_9_0):
    return dictionary_risk_6_9_0[risk_6_9_0]

dictionary_risk_7_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_9_0(risk_7_9_0):
    return dictionary_risk_7_9_0[risk_7_9_0]

dictionary_risk_8_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_9_0(risk_8_9_0):
    return dictionary_risk_8_9_0[risk_8_9_0]

dictionary_risk_9_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_9_0(risk_9_9_0):
    return dictionary_risk_9_9_0[risk_9_9_0]

dictionary_risk_10_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_9_0(risk_10_9_0):
    return dictionary_risk_10_9_0[risk_10_9_0]

dictionary_risk_11_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_9_0(risk_11_9_0):
    return dictionary_risk_11_9_0[risk_11_9_0]

dictionary_risk_12_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_9_0(risk_12_9_0):
    return dictionary_risk_12_9_0[risk_12_9_0]

dictionary_risk_13_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_9_0(risk_13_9_0):
    return dictionary_risk_13_9_0[risk_13_9_0]

dictionary_risk_14_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_9_0(risk_14_9_0):
    return dictionary_risk_14_9_0[risk_14_9_0]

dictionary_risk_18_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_9_0(risk_18_9_0):
    return dictionary_risk_18_9_0[risk_18_9_0]

dictionary_risk_19_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_9_0(risk_19_9_0):
    return dictionary_risk_19_9_0[risk_19_9_0]

dictionary_risk_20_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_9_0(risk_20_9_0):
    return dictionary_risk_20_9_0[risk_20_9_0]

dictionary_risk_21_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_9_0(risk_21_9_0):
    return dictionary_risk_21_9_0[risk_21_9_0]

dictionary_risk_24_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_9_0(risk_24_9_0):
    return dictionary_risk_24_9_0[risk_24_9_0]

dictionary_risk_25_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_9_0(risk_25_9_0):
    return dictionary_risk_25_9_0[risk_25_9_0]

dictionary_risk_26_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_9_0(risk_26_9_0):
    return dictionary_risk_26_9_0[risk_26_9_0]

dictionary_risk_27_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_9_0(risk_27_9_0):
    return dictionary_risk_27_9_0[risk_27_9_0]

dictionary_risk_28_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_9_0(risk_28_9_0):
    return dictionary_risk_28_9_0[risk_28_9_0]

dictionary_risk_29_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_9_0(risk_29_9_0):
    return dictionary_risk_29_9_0[risk_29_9_0]

dictionary_risk_31_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_9_0(risk_31_9_0):
    return dictionary_risk_31_9_0[risk_31_9_0]

dictionary_risk_32_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_9_0(risk_32_9_0):
    return dictionary_risk_32_9_0[risk_32_9_0]

dictionary_risk_33_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_9_0(risk_33_9_0):
    return dictionary_risk_33_9_0[risk_33_9_0]

dictionary_risk_34_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_9_0(risk_34_9_0):
    return dictionary_risk_34_9_0[risk_34_9_0]

dictionary_risk_35_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_9_0(risk_35_9_0):
    return dictionary_risk_35_9_0[risk_35_9_0]

dictionary_risk_0_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_10_0(risk_0_10_0):
    return dictionary_risk_0_10_0[risk_0_10_0]

dictionary_risk_1_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_10_0(risk_1_10_0):
    return dictionary_risk_1_10_0[risk_1_10_0]

dictionary_risk_2_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_10_0(risk_2_10_0):
    return dictionary_risk_2_10_0[risk_2_10_0]

dictionary_risk_3_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_10_0(risk_3_10_0):
    return dictionary_risk_3_10_0[risk_3_10_0]

dictionary_risk_4_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_10_0(risk_4_10_0):
    return dictionary_risk_4_10_0[risk_4_10_0]

dictionary_risk_5_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_10_0(risk_5_10_0):
    return dictionary_risk_5_10_0[risk_5_10_0]

dictionary_risk_6_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_10_0(risk_6_10_0):
    return dictionary_risk_6_10_0[risk_6_10_0]

dictionary_risk_7_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_10_0(risk_7_10_0):
    return dictionary_risk_7_10_0[risk_7_10_0]

dictionary_risk_8_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_10_0(risk_8_10_0):
    return dictionary_risk_8_10_0[risk_8_10_0]

dictionary_risk_9_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_10_0(risk_9_10_0):
    return dictionary_risk_9_10_0[risk_9_10_0]

dictionary_risk_10_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_10_0(risk_10_10_0):
    return dictionary_risk_10_10_0[risk_10_10_0]

dictionary_risk_11_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_10_0(risk_11_10_0):
    return dictionary_risk_11_10_0[risk_11_10_0]

dictionary_risk_12_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_10_0(risk_12_10_0):
    return dictionary_risk_12_10_0[risk_12_10_0]

dictionary_risk_13_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_10_0(risk_13_10_0):
    return dictionary_risk_13_10_0[risk_13_10_0]

dictionary_risk_14_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_10_0(risk_14_10_0):
    return dictionary_risk_14_10_0[risk_14_10_0]

dictionary_risk_18_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_10_0(risk_18_10_0):
    return dictionary_risk_18_10_0[risk_18_10_0]

dictionary_risk_19_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_10_0(risk_19_10_0):
    return dictionary_risk_19_10_0[risk_19_10_0]

dictionary_risk_20_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_10_0(risk_20_10_0):
    return dictionary_risk_20_10_0[risk_20_10_0]

dictionary_risk_21_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_10_0(risk_21_10_0):
    return dictionary_risk_21_10_0[risk_21_10_0]

dictionary_risk_24_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_10_0(risk_24_10_0):
    return dictionary_risk_24_10_0[risk_24_10_0]

dictionary_risk_25_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_10_0(risk_25_10_0):
    return dictionary_risk_25_10_0[risk_25_10_0]

dictionary_risk_26_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_10_0(risk_26_10_0):
    return dictionary_risk_26_10_0[risk_26_10_0]

dictionary_risk_27_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_10_0(risk_27_10_0):
    return dictionary_risk_27_10_0[risk_27_10_0]

dictionary_risk_28_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_10_0(risk_28_10_0):
    return dictionary_risk_28_10_0[risk_28_10_0]

dictionary_risk_29_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_10_0(risk_29_10_0):
    return dictionary_risk_29_10_0[risk_29_10_0]

dictionary_risk_31_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_10_0(risk_31_10_0):
    return dictionary_risk_31_10_0[risk_31_10_0]

dictionary_risk_32_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_10_0(risk_32_10_0):
    return dictionary_risk_32_10_0[risk_32_10_0]

dictionary_risk_32_10_1 = {'true': 1.0, 'false': 0.0}

def f_risk_32_10_1(risk_32_10_1):
    return dictionary_risk_32_10_1[risk_32_10_1]

dictionary_risk_33_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_10_0(risk_33_10_0):
    return dictionary_risk_33_10_0[risk_33_10_0]

dictionary_risk_34_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_10_0(risk_34_10_0):
    return dictionary_risk_34_10_0[risk_34_10_0]

dictionary_risk_35_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_10_0(risk_35_10_0):
    return dictionary_risk_35_10_0[risk_35_10_0]

dictionary_observe_0_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7712758692874719, ('false', 'false'): 1.0, ('true', 'true'): 0.22872413071252806}
def f_observe_0_7_0(person_0_7_0, observe_0_7_0):
    return dictionary_observe_0_7_0[(person_0_7_0, observe_0_7_0)]

dictionary_observe_1_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5242217073455422, ('false', 'false'): 1.0, ('true', 'true'): 0.4757782926544578}
def f_observe_1_7_0(person_1_7_0, observe_1_7_0):
    return dictionary_observe_1_7_0[(person_1_7_0, observe_1_7_0)]

dictionary_observe_2_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6124118386265447, ('false', 'false'): 1.0, ('true', 'true'): 0.3875881613734553}
def f_observe_2_7_0(person_2_7_0, observe_2_7_0):
    return dictionary_observe_2_7_0[(person_2_7_0, observe_2_7_0)]

dictionary_observe_3_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8930737811039315, ('false', 'false'): 1.0, ('true', 'true'): 0.10692621889606846}
def f_observe_3_7_0(person_3_7_0, observe_3_7_0):
    return dictionary_observe_3_7_0[(person_3_7_0, observe_3_7_0)]

dictionary_observe_4_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7176967581300686, ('false', 'false'): 1.0, ('true', 'true'): 0.2823032418699314}
def f_observe_4_7_0(person_4_7_0, observe_4_7_0):
    return dictionary_observe_4_7_0[(person_4_7_0, observe_4_7_0)]

dictionary_observe_5_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.968230424266501, ('false', 'false'): 1.0, ('true', 'true'): 0.031769575733499034}
def f_observe_5_7_0(person_5_7_0, observe_5_7_0):
    return dictionary_observe_5_7_0[(person_5_7_0, observe_5_7_0)]

dictionary_observe_6_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.939396351838248, ('false', 'false'): 1.0, ('true', 'true'): 0.06060364816175201}
def f_observe_6_7_0(person_6_7_0, observe_6_7_0):
    return dictionary_observe_6_7_0[(person_6_7_0, observe_6_7_0)]

dictionary_observe_7_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.698819741018698, ('false', 'false'): 1.0, ('true', 'true'): 0.30118025898130196}
def f_observe_7_7_0(person_7_7_0, observe_7_7_0):
    return dictionary_observe_7_7_0[(person_7_7_0, observe_7_7_0)]

dictionary_observe_8_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.40415039857323, ('false', 'false'): 1.0, ('true', 'true'): 0.59584960142677}
def f_observe_8_7_0(person_8_7_0, observe_8_7_0):
    return dictionary_observe_8_7_0[(person_8_7_0, observe_8_7_0)]

dictionary_observe_9_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8725523579403456, ('false', 'false'): 1.0, ('true', 'true'): 0.12744764205965442}
def f_observe_9_7_0(person_9_7_0, observe_9_7_0):
    return dictionary_observe_9_7_0[(person_9_7_0, observe_9_7_0)]

dictionary_observe_10_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.48290281234232, ('false', 'false'): 1.0, ('true', 'true'): 0.51709718765768}
def f_observe_10_7_0(person_10_7_0, observe_10_7_0):
    return dictionary_observe_10_7_0[(person_10_7_0, observe_10_7_0)]

dictionary_observe_11_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8447519262258962, ('false', 'false'): 1.0, ('true', 'true'): 0.15524807377410377}
def f_observe_11_7_0(person_11_7_0, observe_11_7_0):
    return dictionary_observe_11_7_0[(person_11_7_0, observe_11_7_0)]

dictionary_observe_12_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7905558556989429, ('false', 'false'): 1.0, ('true', 'true'): 0.20944414430105707}
def f_observe_12_7_0(person_12_7_0, observe_12_7_0):
    return dictionary_observe_12_7_0[(person_12_7_0, observe_12_7_0)]

dictionary_observe_13_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5389064911337691, ('false', 'false'): 1.0, ('true', 'true'): 0.4610935088662309}
def f_observe_13_7_0(person_13_7_0, observe_13_7_0):
    return dictionary_observe_13_7_0[(person_13_7_0, observe_13_7_0)]

dictionary_observe_14_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5364421853857595, ('false', 'false'): 1.0, ('true', 'true'): 0.4635578146142405}
def f_observe_14_7_0(person_14_7_0, observe_14_7_0):
    return dictionary_observe_14_7_0[(person_14_7_0, observe_14_7_0)]

dictionary_observe_18_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6297049549855772, ('false', 'false'): 1.0, ('true', 'true'): 0.3702950450144228}
def f_observe_18_7_0(person_18_7_0, observe_18_7_0):
    return dictionary_observe_18_7_0[(person_18_7_0, observe_18_7_0)]

dictionary_observe_19_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5339893953073813, ('false', 'false'): 1.0, ('true', 'true'): 0.4660106046926187}
def f_observe_19_7_0(person_19_7_0, observe_19_7_0):
    return dictionary_observe_19_7_0[(person_19_7_0, observe_19_7_0)]

dictionary_observe_20_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7054725591641495, ('false', 'false'): 1.0, ('true', 'true'): 0.2945274408358505}
def f_observe_20_7_0(person_20_7_0, observe_20_7_0):
    return dictionary_observe_20_7_0[(person_20_7_0, observe_20_7_0)]

dictionary_observe_21_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.610482863363845, ('false', 'false'): 1.0, ('true', 'true'): 0.38951713663615495}
def f_observe_21_7_0(person_21_7_0, observe_21_7_0):
    return dictionary_observe_21_7_0[(person_21_7_0, observe_21_7_0)]

dictionary_observe_24_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6183161955518208, ('false', 'false'): 1.0, ('true', 'true'): 0.3816838044481792}
def f_observe_24_7_0(person_24_7_0, observe_24_7_0):
    return dictionary_observe_24_7_0[(person_24_7_0, observe_24_7_0)]

dictionary_observe_25_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7068414336594061, ('false', 'false'): 1.0, ('true', 'true'): 0.2931585663405939}
def f_observe_25_7_0(person_25_7_0, observe_25_7_0):
    return dictionary_observe_25_7_0[(person_25_7_0, observe_25_7_0)]

dictionary_observe_26_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9885877962581802, ('false', 'false'): 1.0, ('true', 'true'): 0.011412203741819837}
def f_observe_26_7_0(person_26_7_0, observe_26_7_0):
    return dictionary_observe_26_7_0[(person_26_7_0, observe_26_7_0)]

dictionary_observe_27_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9872786675647351, ('false', 'false'): 1.0, ('true', 'true'): 0.012721332435264854}
def f_observe_27_7_0(person_27_7_0, observe_27_7_0):
    return dictionary_observe_27_7_0[(person_27_7_0, observe_27_7_0)]

dictionary_observe_28_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7631919667692666, ('false', 'false'): 1.0, ('true', 'true'): 0.2368080332307334}
def f_observe_28_7_0(person_28_7_0, observe_28_7_0):
    return dictionary_observe_28_7_0[(person_28_7_0, observe_28_7_0)]

dictionary_observe_29_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6058423348701978, ('false', 'false'): 1.0, ('true', 'true'): 0.3941576651298022}
def f_observe_29_7_0(person_29_7_0, observe_29_7_0):
    return dictionary_observe_29_7_0[(person_29_7_0, observe_29_7_0)]

dictionary_observe_31_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6916843997629649, ('false', 'false'): 1.0, ('true', 'true'): 0.3083156002370351}
def f_observe_31_7_0(person_31_7_0, observe_31_7_0):
    return dictionary_observe_31_7_0[(person_31_7_0, observe_31_7_0)]

dictionary_observe_32_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.45475976723179623, ('false', 'false'): 1.0, ('true', 'true'): 0.5452402327682038}
def f_observe_32_7_0(person_32_7_0, observe_32_7_0):
    return dictionary_observe_32_7_0[(person_32_7_0, observe_32_7_0)]

dictionary_observe_33_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.47191512542661285, ('false', 'false'): 1.0, ('true', 'true'): 0.5280848745733872}
def f_observe_33_7_0(person_33_7_0, observe_33_7_0):
    return dictionary_observe_33_7_0[(person_33_7_0, observe_33_7_0)]

dictionary_observe_34_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8700912349220966, ('false', 'false'): 1.0, ('true', 'true'): 0.1299087650779034}
def f_observe_34_7_0(person_34_7_0, observe_34_7_0):
    return dictionary_observe_34_7_0[(person_34_7_0, observe_34_7_0)]

dictionary_observe_35_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4010730222770398, ('false', 'false'): 1.0, ('true', 'true'): 0.5989269777229602}
def f_observe_35_7_0(person_35_7_0, observe_35_7_0):
    return dictionary_observe_35_7_0[(person_35_7_0, observe_35_7_0)]

dictionary_person_0_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7415170203401242, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.25848297965987577, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7407755033197841, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.25922449668021585, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_0_8_0(person_0_7_0, person_6_7_0, risk_0_8_0, person_0_8_0):
    return dictionary_person_0_8_0[(person_0_7_0, person_6_7_0, risk_0_8_0, person_0_8_0)]

dictionary_observe_0_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4924401037368563, ('false', 'false'): 1.0, ('true', 'true'): 0.5075598962631437}
def f_observe_0_8_0(person_0_8_0, observe_0_8_0):
    return dictionary_observe_0_8_0[(person_0_8_0, observe_0_8_0)]

dictionary_person_1_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6395780776226818, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3604219223773182, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6389384995450591, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3610615004549409, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_1_8_0(person_1_7_0, person_2_7_0, risk_1_8_0, person_1_8_0):
    return dictionary_person_1_8_0[(person_1_7_0, person_2_7_0, risk_1_8_0, person_1_8_0)]

dictionary_observe_1_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8678279912426528, ('false', 'false'): 1.0, ('true', 'true'): 0.13217200875734725}
def f_observe_1_8_0(person_1_8_0, observe_1_8_0):
    return dictionary_observe_1_8_0[(person_1_8_0, observe_1_8_0)]

dictionary_person_2_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_2_8_0(person_2_7_0, risk_2_8_0, person_2_8_0):
    return dictionary_person_2_8_0[(person_2_7_0, risk_2_8_0, person_2_8_0)]

dictionary_observe_2_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7553640837832798, ('false', 'false'): 1.0, ('true', 'true'): 0.2446359162167202}
def f_observe_2_8_0(person_2_8_0, observe_2_8_0):
    return dictionary_observe_2_8_0[(person_2_8_0, observe_2_8_0)]

dictionary_person_3_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.3912848532856431, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.6087151467143569, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.39089356843235745, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.6091064315676425, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_3_8_0(person_3_7_0, person_4_7_0, risk_3_8_0, person_3_8_0):
    return dictionary_person_3_8_0[(person_3_7_0, person_4_7_0, risk_3_8_0, person_3_8_0)]

dictionary_observe_3_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4940499291387169, ('false', 'false'): 1.0, ('true', 'true'): 0.5059500708612831}
def f_observe_3_8_0(person_3_8_0, observe_3_8_0):
    return dictionary_observe_3_8_0[(person_3_8_0, observe_3_8_0)]

dictionary_person_4_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_8_0(person_4_7_0, risk_4_8_0, person_4_8_0):
    return dictionary_person_4_8_0[(person_4_7_0, risk_4_8_0, person_4_8_0)]

dictionary_observe_4_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4547169961007975, ('false', 'false'): 1.0, ('true', 'true'): 0.5452830038992025}
def f_observe_4_8_0(person_4_8_0, observe_4_8_0):
    return dictionary_observe_4_8_0[(person_4_8_0, observe_4_8_0)]

dictionary_person_5_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.40722756586437936, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7223428944328856, ('false', 'false', 'true', 'false', 'false'): 0.4688730862004513, ('false', 'true', 'false', 'true', 'true'): 0.40782033829851494, ('false', 'false', 'true', 'false', 'true'): 0.5311269137995487, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5921796617014851, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.46840421311425084, ('false', 'true', 'true', 'false', 'true'): 0.7220649593922778, ('false', 'true', 'true', 'false', 'false'): 0.27793504060772223, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5315957868857492, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5927724341356206, ('false', 'true', 'true', 'true', 'false'): 0.2776571055671145}
def f_person_5_8_0(person_5_7_0, person_7_7_0, person_6_7_0, risk_5_8_0, person_5_8_0):
    return dictionary_person_5_8_0[(person_5_7_0, person_7_7_0, person_6_7_0, risk_5_8_0, person_5_8_0)]

dictionary_observe_5_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6697140000195987, ('false', 'false'): 1.0, ('true', 'true'): 0.3302859999804013}
def f_observe_5_8_0(person_5_8_0, observe_5_8_0):
    return dictionary_observe_5_8_0[(person_5_8_0, observe_5_8_0)]

dictionary_person_6_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_6_8_0(person_6_7_0, risk_6_8_0, person_6_8_0):
    return dictionary_person_6_8_0[(person_6_7_0, risk_6_8_0, person_6_8_0)]

dictionary_observe_6_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6039797335029794, ('false', 'false'): 1.0, ('true', 'true'): 0.3960202664970206}
def f_observe_6_8_0(person_6_8_0, observe_6_8_0):
    return dictionary_observe_6_8_0[(person_6_8_0, observe_6_8_0)]

dictionary_person_7_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.48006559198558096, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.519934408014419, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.47958552639359536, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5204144736064047, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_7_8_0(person_7_7_0, person_6_7_0, risk_7_8_0, person_7_8_0):
    return dictionary_person_7_8_0[(person_7_7_0, person_6_7_0, risk_7_8_0, person_7_8_0)]

dictionary_observe_7_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.533095875048956, ('false', 'false'): 1.0, ('true', 'true'): 0.46690412495104405}
def f_observe_7_8_0(person_7_8_0, observe_7_8_0):
    return dictionary_observe_7_8_0[(person_7_8_0, observe_7_8_0)]

dictionary_person_8_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5107340520593223, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4892659479406777, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.510223318007263, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.48977668199273705, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_8_8_0(person_8_7_0, person_3_7_0, risk_8_8_0, person_8_8_0):
    return dictionary_person_8_8_0[(person_8_7_0, person_3_7_0, risk_8_8_0, person_8_8_0)]

dictionary_observe_8_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6507501128021451, ('false', 'false'): 1.0, ('true', 'true'): 0.3492498871978549}
def f_observe_8_8_0(person_8_8_0, observe_8_8_0):
    return dictionary_observe_8_8_0[(person_8_8_0, observe_8_8_0)]

dictionary_person_9_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6834776544114951, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3165223455885049, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6827941767570836, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.31720582324291635, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_9_8_0(person_9_7_0, person_10_7_0, risk_9_8_0, person_9_8_0):
    return dictionary_person_9_8_0[(person_9_7_0, person_10_7_0, risk_9_8_0, person_9_8_0)]

dictionary_observe_9_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.553625983129378, ('false', 'false'): 1.0, ('true', 'true'): 0.44637401687062195}
def f_observe_9_8_0(person_9_8_0, observe_9_8_0):
    return dictionary_observe_9_8_0[(person_9_8_0, observe_9_8_0)]

dictionary_person_10_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.5592321928671657, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7080572063130336, ('false', 'false', 'true', 'false', 'false'): 0.6630135504147905, ('false', 'true', 'false', 'true', 'true'): 0.5596729606742985, ('false', 'false', 'true', 'false', 'true'): 0.3369864495852095, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.44032703932570144, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6623505368643757, ('false', 'true', 'true', 'false', 'true'): 0.7077649712843179, ('false', 'true', 'true', 'false', 'false'): 0.2922350287156821, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3376494631356243, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.44076780713283426, ('false', 'true', 'true', 'true', 'false'): 0.2919427936869664}
def f_person_10_8_0(person_10_7_0, person_4_7_0, person_11_7_0, risk_10_8_0, person_10_8_0):
    return dictionary_person_10_8_0[(person_10_7_0, person_4_7_0, person_11_7_0, risk_10_8_0, person_10_8_0)]

dictionary_observe_10_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9460717892627606, ('false', 'false'): 1.0, ('true', 'true'): 0.05392821073723941}
def f_observe_10_8_0(person_10_8_0, observe_10_8_0):
    return dictionary_observe_10_8_0[(person_10_8_0, observe_10_8_0)]

dictionary_person_11_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7629647874375332, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.23703521256246685, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7622018226500956, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.23779817734990438, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_11_8_0(person_11_7_0, person_12_7_0, risk_11_8_0, person_11_8_0):
    return dictionary_person_11_8_0[(person_11_7_0, person_12_7_0, risk_11_8_0, person_11_8_0)]

dictionary_observe_11_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6699866639877278, ('false', 'false'): 1.0, ('true', 'true'): 0.33001333601227223}
def f_observe_11_8_0(person_11_8_0, observe_11_8_0):
    return dictionary_observe_11_8_0[(person_11_8_0, observe_11_8_0)]

dictionary_person_12_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.47271543023717344, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5272845697628266, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.47224271480693625, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5277572851930638, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_12_8_0(person_12_7_0, person_11_7_0, risk_12_8_0, person_12_8_0):
    return dictionary_person_12_8_0[(person_12_7_0, person_11_7_0, risk_12_8_0, person_12_8_0)]

dictionary_observe_12_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8971981752693499, ('false', 'false'): 1.0, ('true', 'true'): 0.10280182473065014}
def f_observe_12_8_0(person_12_8_0, observe_12_8_0):
    return dictionary_observe_12_8_0[(person_12_8_0, observe_12_8_0)]

dictionary_person_13_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6214123569761569, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.37858764302384307, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6207909446191808, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.37920905538081917, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_13_8_0(person_13_7_0, person_19_7_0, risk_13_8_0, person_13_8_0):
    return dictionary_person_13_8_0[(person_13_7_0, person_19_7_0, risk_13_8_0, person_13_8_0)]

dictionary_observe_13_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7221913159531792, ('false', 'false'): 1.0, ('true', 'true'): 0.2778086840468208}
def f_observe_13_8_0(person_13_8_0, observe_13_8_0):
    return dictionary_observe_13_8_0[(person_13_8_0, observe_13_8_0)]

dictionary_person_14_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_14_8_0(person_14_7_0, risk_14_8_0, person_14_8_0):
    return dictionary_person_14_8_0[(person_14_7_0, risk_14_8_0, person_14_8_0)]

dictionary_observe_14_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6623851994377532, ('false', 'false'): 1.0, ('true', 'true'): 0.3376148005622468}
def f_observe_14_8_0(person_14_8_0, observe_14_8_0):
    return dictionary_observe_14_8_0[(person_14_8_0, observe_14_8_0)]

dictionary_person_18_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_18_8_0(person_18_7_0, risk_18_8_0, person_18_8_0):
    return dictionary_person_18_8_0[(person_18_7_0, risk_18_8_0, person_18_8_0)]

dictionary_observe_18_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6046855863586733, ('false', 'false'): 1.0, ('true', 'true'): 0.3953144136413267}
def f_observe_18_8_0(person_18_8_0, observe_18_8_0):
    return dictionary_observe_18_8_0[(person_18_8_0, observe_18_8_0)]

dictionary_person_19_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.483283419804745, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.516716580195255, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.48280013638494024, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5171998636150598, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_19_8_0(person_19_7_0, person_25_7_0, risk_19_8_0, person_19_8_0):
    return dictionary_person_19_8_0[(person_19_7_0, person_25_7_0, risk_19_8_0, person_19_8_0)]

dictionary_observe_19_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6784996084339414, ('false', 'false'): 1.0, ('true', 'true'): 0.3215003915660586}
def f_observe_19_8_0(person_19_8_0, observe_19_8_0):
    return dictionary_observe_19_8_0[(person_19_8_0, observe_19_8_0)]

dictionary_person_20_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5433175568741242, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4566824431258758, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5427742393172501, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4572257606827499, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_20_8_0(person_20_7_0, person_14_7_0, risk_20_8_0, person_20_8_0):
    return dictionary_person_20_8_0[(person_20_7_0, person_14_7_0, risk_20_8_0, person_20_8_0)]

dictionary_observe_20_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5167364102899431, ('false', 'false'): 1.0, ('true', 'true'): 0.4832635897100569}
def f_observe_20_8_0(person_20_8_0, observe_20_8_0):
    return dictionary_observe_20_8_0[(person_20_8_0, observe_20_8_0)]

dictionary_person_21_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_21_8_0(person_21_7_0, risk_21_8_0, person_21_8_0):
    return dictionary_person_21_8_0[(person_21_7_0, risk_21_8_0, person_21_8_0)]

dictionary_observe_21_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5084677910335211, ('false', 'false'): 1.0, ('true', 'true'): 0.49153220896647887}
def f_observe_21_8_0(person_21_8_0, observe_21_8_0):
    return dictionary_observe_21_8_0[(person_21_8_0, observe_21_8_0)]

dictionary_person_24_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6597493024442862, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3402506975557138, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6590895531418419, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3409104468581581, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_24_8_0(person_24_7_0, person_18_7_0, risk_24_8_0, person_24_8_0):
    return dictionary_person_24_8_0[(person_24_7_0, person_18_7_0, risk_24_8_0, person_24_8_0)]

dictionary_observe_24_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5642367087159801, ('false', 'false'): 1.0, ('true', 'true'): 0.4357632912840199}
def f_observe_24_8_0(person_24_8_0, observe_24_8_0):
    return dictionary_observe_24_8_0[(person_24_8_0, observe_24_8_0)]

dictionary_person_25_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_25_8_0(person_25_7_0, risk_25_8_0, person_25_8_0):
    return dictionary_person_25_8_0[(person_25_7_0, risk_25_8_0, person_25_8_0)]

dictionary_observe_25_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4564481253605619, ('false', 'false'): 1.0, ('true', 'true'): 0.5435518746394381}
def f_observe_25_8_0(person_25_8_0, observe_25_8_0):
    return dictionary_observe_25_8_0[(person_25_8_0, observe_25_8_0)]

dictionary_person_26_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.666309632752468, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.333690367247532, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6656433231197155, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3343566768802845, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_26_8_0(person_26_7_0, person_25_7_0, risk_26_8_0, person_26_8_0):
    return dictionary_person_26_8_0[(person_26_7_0, person_25_7_0, risk_26_8_0, person_26_8_0)]

dictionary_observe_26_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.598761146216519, ('false', 'false'): 1.0, ('true', 'true'): 0.401238853783481}
def f_observe_26_8_0(person_26_8_0, observe_26_8_0):
    return dictionary_observe_26_8_0[(person_26_8_0, observe_26_8_0)]

dictionary_person_27_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.639022761995448, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.36097723800455195, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6383837392334526, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3616162607665474, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_27_8_0(person_27_7_0, person_28_7_0, risk_27_8_0, person_27_8_0):
    return dictionary_person_27_8_0[(person_27_7_0, person_28_7_0, risk_27_8_0, person_27_8_0)]

dictionary_observe_27_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6886385262919912, ('false', 'false'): 1.0, ('true', 'true'): 0.3113614737080088}
def f_observe_27_8_0(person_27_8_0, observe_27_8_0):
    return dictionary_observe_27_8_0[(person_27_8_0, observe_27_8_0)]

dictionary_person_28_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7621423658390967, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.23785763416090333, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7613802234732576, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.23861977652674238, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_28_8_0(person_28_7_0, person_29_7_0, risk_28_8_0, person_28_8_0):
    return dictionary_person_28_8_0[(person_28_7_0, person_29_7_0, risk_28_8_0, person_28_8_0)]

dictionary_observe_28_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.44216112786079975, ('false', 'false'): 1.0, ('true', 'true'): 0.5578388721392002}
def f_observe_28_8_0(person_28_8_0, observe_28_8_0):
    return dictionary_observe_28_8_0[(person_28_8_0, observe_28_8_0)]

dictionary_person_29_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_29_8_0(person_29_7_0, risk_29_8_0, person_29_8_0):
    return dictionary_person_29_8_0[(person_29_7_0, risk_29_8_0, person_29_8_0)]

dictionary_observe_29_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4944809886245001, ('false', 'false'): 1.0, ('true', 'true'): 0.5055190113754999}
def f_observe_29_8_0(person_29_8_0, observe_29_8_0):
    return dictionary_observe_29_8_0[(person_29_8_0, observe_29_8_0)]

dictionary_person_31_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_31_8_0(person_31_7_0, risk_31_8_0, person_31_8_0):
    return dictionary_person_31_8_0[(person_31_7_0, risk_31_8_0, person_31_8_0)]

dictionary_observe_31_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9054542545176059, ('false', 'false'): 1.0, ('true', 'true'): 0.09454574548239414}
def f_observe_31_8_0(person_31_8_0, observe_31_8_0):
    return dictionary_observe_31_8_0[(person_31_8_0, observe_31_8_0)]

dictionary_person_32_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.5513694109929016, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7564205495149458, ('false', 'false', 'true', 'false', 'false'): 0.5434833908638255, ('false', 'true', 'false', 'true', 'true'): 0.5518180415819087, ('false', 'false', 'true', 'false', 'true'): 0.45651660913617453, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.4481819584180913, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5429399074729616, ('false', 'true', 'true', 'false', 'true'): 0.7561767262411869, ('false', 'true', 'true', 'false', 'false'): 0.2438232737588131, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4570600925270384, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.4486305890070984, ('false', 'true', 'true', 'true', 'false'): 0.24357945048505428}
def f_person_32_8_0(person_32_7_0, person_2_7_0, person_33_7_0, risk_32_8_0, person_32_8_0):
    return dictionary_person_32_8_0[(person_32_7_0, person_2_7_0, person_33_7_0, risk_32_8_0, person_32_8_0)]

dictionary_observe_32_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5018279759019353, ('false', 'false'): 1.0, ('true', 'true'): 0.4981720240980647}
def f_observe_32_8_0(person_32_8_0, observe_32_8_0):
    return dictionary_observe_32_8_0[(person_32_8_0, observe_32_8_0)]

dictionary_person_33_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.520270107597224, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.47972989240277597, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5197498374896268, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4802501625103732, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_33_8_0(person_33_7_0, person_27_7_0, risk_33_8_0, person_33_8_0):
    return dictionary_person_33_8_0[(person_33_7_0, person_27_7_0, risk_33_8_0, person_33_8_0)]

dictionary_observe_33_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5847907347521224, ('false', 'false'): 1.0, ('true', 'true'): 0.4152092652478776}
def f_observe_33_8_0(person_33_8_0, observe_33_8_0):
    return dictionary_observe_33_8_0[(person_33_8_0, observe_33_8_0)]

dictionary_person_34_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5475083346046404, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.45249166539535957, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5469608262700358, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.45303917372996416, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_34_8_0(person_34_7_0, person_28_7_0, risk_34_8_0, person_34_8_0):
    return dictionary_person_34_8_0[(person_34_7_0, person_28_7_0, risk_34_8_0, person_34_8_0)]

dictionary_observe_34_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7124579547116292, ('false', 'false'): 1.0, ('true', 'true'): 0.2875420452883708}
def f_observe_34_8_0(person_34_8_0, observe_34_8_0):
    return dictionary_observe_34_8_0[(person_34_8_0, observe_34_8_0)]

dictionary_person_35_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.24107760180028426, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.4623420316082274, ('false', 'false', 'true', 'false', 'false'): 0.7091583616889099, ('false', 'true', 'false', 'true', 'true'): 0.241836524198484, ('false', 'false', 'true', 'false', 'true'): 0.2908416383110901, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.758163475801516, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7084492033272209, ('false', 'true', 'true', 'false', 'true'): 0.4618038354436711, ('false', 'true', 'true', 'false', 'false'): 0.5381961645563289, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.29155079667277906, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7589223981997157, ('false', 'true', 'true', 'true', 'false'): 0.5376579683917726}
def f_person_35_8_0(person_35_7_0, person_0_7_0, person_29_7_0, risk_35_8_0, person_35_8_0):
    return dictionary_person_35_8_0[(person_35_7_0, person_0_7_0, person_29_7_0, risk_35_8_0, person_35_8_0)]

dictionary_observe_35_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9105443631047783, ('false', 'false'): 1.0, ('true', 'true'): 0.08945563689522174}
def f_observe_35_8_0(person_35_8_0, observe_35_8_0):
    return dictionary_observe_35_8_0[(person_35_8_0, observe_35_8_0)]

dictionary_person_0_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_0_9_0(person_0_8_0, risk_0_9_0, person_0_9_0):
    return dictionary_person_0_9_0[(person_0_8_0, risk_0_9_0, person_0_9_0)]

dictionary_observe_0_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5535134535169741, ('false', 'false'): 1.0, ('true', 'true'): 0.4464865464830259}
def f_observe_0_9_0(person_0_9_0, observe_0_9_0):
    return dictionary_observe_0_9_0[(person_0_9_0, observe_0_9_0)]

dictionary_person_1_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_1_9_0(person_1_8_0, risk_1_9_0, person_1_9_0):
    return dictionary_person_1_9_0[(person_1_8_0, risk_1_9_0, person_1_9_0)]

dictionary_observe_1_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9033343174244506, ('false', 'false'): 1.0, ('true', 'true'): 0.09666568257554942}
def f_observe_1_9_0(person_1_9_0, observe_1_9_0):
    return dictionary_observe_1_9_0[(person_1_9_0, observe_1_9_0)]

dictionary_person_2_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_2_9_0(person_2_8_0, risk_2_9_0, person_2_9_0):
    return dictionary_person_2_9_0[(person_2_8_0, risk_2_9_0, person_2_9_0)]

dictionary_observe_2_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4233700904843043, ('false', 'false'): 1.0, ('true', 'true'): 0.5766299095156957}
def f_observe_2_9_0(person_2_9_0, observe_2_9_0):
    return dictionary_observe_2_9_0[(person_2_9_0, observe_2_9_0)]

dictionary_person_3_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6745188793078736, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3254811206921264, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6738443604285657, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.32615563957143434, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_3_9_0(person_3_8_0, person_9_8_0, risk_3_9_0, person_3_9_0):
    return dictionary_person_3_9_0[(person_3_8_0, person_9_8_0, risk_3_9_0, person_3_9_0)]

dictionary_observe_3_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.828129877765115, ('false', 'false'): 1.0, ('true', 'true'): 0.17187012223488496}
def f_observe_3_9_0(person_3_9_0, observe_3_9_0):
    return dictionary_observe_3_9_0[(person_3_9_0, observe_3_9_0)]

dictionary_person_4_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_9_0(person_4_8_0, risk_4_9_0, person_4_9_0):
    return dictionary_person_4_9_0[(person_4_8_0, risk_4_9_0, person_4_9_0)]

dictionary_observe_4_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5501846453358178, ('false', 'false'): 1.0, ('true', 'true'): 0.4498153546641822}
def f_observe_4_9_0(person_4_9_0, observe_4_9_0):
    return dictionary_observe_4_9_0[(person_4_9_0, observe_4_9_0)]

dictionary_person_5_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_5_9_0(person_5_8_0, risk_5_9_0, person_5_9_0):
    return dictionary_person_5_9_0[(person_5_8_0, risk_5_9_0, person_5_9_0)]

dictionary_observe_5_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4054503767275144, ('false', 'false'): 1.0, ('true', 'true'): 0.5945496232724856}
def f_observe_5_9_0(person_5_9_0, observe_5_9_0):
    return dictionary_observe_5_9_0[(person_5_9_0, observe_5_9_0)]

dictionary_person_6_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_6_9_0(person_6_8_0, risk_6_9_0, person_6_9_0):
    return dictionary_person_6_9_0[(person_6_8_0, risk_6_9_0, person_6_9_0)]

dictionary_observe_6_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.579121614567085, ('false', 'false'): 1.0, ('true', 'true'): 0.420878385432915}
def f_observe_6_9_0(person_6_9_0, observe_6_9_0):
    return dictionary_observe_6_9_0[(person_6_9_0, observe_6_9_0)]

dictionary_person_7_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_7_9_0(person_7_8_0, risk_7_9_0, person_7_9_0):
    return dictionary_person_7_9_0[(person_7_8_0, risk_7_9_0, person_7_9_0)]

dictionary_observe_7_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8300274832609711, ('false', 'false'): 1.0, ('true', 'true'): 0.1699725167390289}
def f_observe_7_9_0(person_7_9_0, observe_7_9_0):
    return dictionary_observe_7_9_0[(person_7_9_0, observe_7_9_0)]

dictionary_person_8_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_8_9_0(person_8_8_0, risk_8_9_0, person_8_9_0):
    return dictionary_person_8_9_0[(person_8_8_0, risk_8_9_0, person_8_9_0)]

dictionary_observe_8_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4602058400053435, ('false', 'false'): 1.0, ('true', 'true'): 0.5397941599946565}
def f_observe_8_9_0(person_8_9_0, observe_8_9_0):
    return dictionary_observe_8_9_0[(person_8_9_0, observe_8_9_0)]

dictionary_person_9_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_9_9_0(person_9_8_0, risk_9_9_0, person_9_9_0):
    return dictionary_person_9_9_0[(person_9_8_0, risk_9_9_0, person_9_9_0)]

dictionary_observe_9_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8642648011323485, ('false', 'false'): 1.0, ('true', 'true'): 0.1357351988676515}
def f_observe_9_9_0(person_9_9_0, observe_9_9_0):
    return dictionary_observe_9_9_0[(person_9_9_0, observe_9_9_0)]

dictionary_person_10_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_10_9_0(person_10_8_0, risk_10_9_0, person_10_9_0):
    return dictionary_person_10_9_0[(person_10_8_0, risk_10_9_0, person_10_9_0)]

dictionary_observe_10_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5596238146748178, ('false', 'false'): 1.0, ('true', 'true'): 0.4403761853251822}
def f_observe_10_9_0(person_10_9_0, observe_10_9_0):
    return dictionary_observe_10_9_0[(person_10_9_0, observe_10_9_0)]

dictionary_person_11_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_11_9_0(person_11_8_0, risk_11_9_0, person_11_9_0):
    return dictionary_person_11_9_0[(person_11_8_0, risk_11_9_0, person_11_9_0)]

dictionary_observe_11_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5040007901667555, ('false', 'false'): 1.0, ('true', 'true'): 0.4959992098332445}
def f_observe_11_9_0(person_11_9_0, observe_11_9_0):
    return dictionary_observe_11_9_0[(person_11_9_0, observe_11_9_0)]

dictionary_person_12_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_12_9_0(person_12_8_0, risk_12_9_0, person_12_9_0):
    return dictionary_person_12_9_0[(person_12_8_0, risk_12_9_0, person_12_9_0)]

dictionary_observe_12_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6305341198665428, ('false', 'false'): 1.0, ('true', 'true'): 0.36946588013345716}
def f_observe_12_9_0(person_12_9_0, observe_12_9_0):
    return dictionary_observe_12_9_0[(person_12_9_0, observe_12_9_0)]

dictionary_person_13_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8243993938046557, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.17560060619534434, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.823574994410851, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.17642500558914898, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_13_9_0(person_13_8_0, person_19_8_0, risk_13_9_0, person_13_9_0):
    return dictionary_person_13_9_0[(person_13_8_0, person_19_8_0, risk_13_9_0, person_13_9_0)]

dictionary_observe_13_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6737028445146251, ('false', 'false'): 1.0, ('true', 'true'): 0.32629715548537486}
def f_observe_13_9_0(person_13_9_0, observe_13_9_0):
    return dictionary_observe_13_9_0[(person_13_9_0, observe_13_9_0)]

dictionary_person_14_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_14_9_0(person_14_8_0, risk_14_9_0, person_14_9_0):
    return dictionary_person_14_9_0[(person_14_8_0, risk_14_9_0, person_14_9_0)]

dictionary_observe_14_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7207310299690064, ('false', 'false'): 1.0, ('true', 'true'): 0.2792689700309936}
def f_observe_14_9_0(person_14_9_0, observe_14_9_0):
    return dictionary_observe_14_9_0[(person_14_9_0, observe_14_9_0)]

dictionary_person_18_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_18_9_0(person_18_8_0, risk_18_9_0, person_18_9_0):
    return dictionary_person_18_9_0[(person_18_8_0, risk_18_9_0, person_18_9_0)]

dictionary_observe_18_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7960424367395741, ('false', 'false'): 1.0, ('true', 'true'): 0.2039575632604259}
def f_observe_18_9_0(person_18_9_0, observe_18_9_0):
    return dictionary_observe_18_9_0[(person_18_9_0, observe_18_9_0)]

dictionary_person_19_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_19_9_0(person_19_8_0, risk_19_9_0, person_19_9_0):
    return dictionary_person_19_9_0[(person_19_8_0, risk_19_9_0, person_19_9_0)]

dictionary_observe_19_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7942350691753806, ('false', 'false'): 1.0, ('true', 'true'): 0.20576493082461944}
def f_observe_19_9_0(person_19_9_0, observe_19_9_0):
    return dictionary_observe_19_9_0[(person_19_9_0, observe_19_9_0)]

dictionary_person_20_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_20_9_0(person_20_8_0, risk_20_9_0, person_20_9_0):
    return dictionary_person_20_9_0[(person_20_8_0, risk_20_9_0, person_20_9_0)]

dictionary_observe_20_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6317129929097999, ('false', 'false'): 1.0, ('true', 'true'): 0.3682870070902001}
def f_observe_20_9_0(person_20_9_0, observe_20_9_0):
    return dictionary_observe_20_9_0[(person_20_9_0, observe_20_9_0)]

dictionary_person_21_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_21_9_0(person_21_8_0, risk_21_9_0, person_21_9_0):
    return dictionary_person_21_9_0[(person_21_8_0, risk_21_9_0, person_21_9_0)]

dictionary_observe_21_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8778646302080787, ('false', 'false'): 1.0, ('true', 'true'): 0.1221353697919213}
def f_observe_21_9_0(person_21_9_0, observe_21_9_0):
    return dictionary_observe_21_9_0[(person_21_9_0, observe_21_9_0)]

dictionary_person_24_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_24_9_0(person_24_8_0, risk_24_9_0, person_24_9_0):
    return dictionary_person_24_9_0[(person_24_8_0, risk_24_9_0, person_24_9_0)]

dictionary_observe_24_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8364890641863613, ('false', 'false'): 1.0, ('true', 'true'): 0.16351093581363874}
def f_observe_24_9_0(person_24_9_0, observe_24_9_0):
    return dictionary_observe_24_9_0[(person_24_9_0, observe_24_9_0)]

dictionary_person_25_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_25_9_0(person_25_8_0, risk_25_9_0, person_25_9_0):
    return dictionary_person_25_9_0[(person_25_8_0, risk_25_9_0, person_25_9_0)]

dictionary_observe_25_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6909614481036055, ('false', 'false'): 1.0, ('true', 'true'): 0.3090385518963945}
def f_observe_25_9_0(person_25_9_0, observe_25_9_0):
    return dictionary_observe_25_9_0[(person_25_9_0, observe_25_9_0)]

dictionary_person_26_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_26_9_0(person_26_8_0, risk_26_9_0, person_26_9_0):
    return dictionary_person_26_9_0[(person_26_8_0, risk_26_9_0, person_26_9_0)]

dictionary_observe_26_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.931063194814794, ('false', 'false'): 1.0, ('true', 'true'): 0.06893680518520595}
def f_observe_26_9_0(person_26_9_0, observe_26_9_0):
    return dictionary_observe_26_9_0[(person_26_9_0, observe_26_9_0)]

dictionary_person_27_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_27_9_0(person_27_8_0, risk_27_9_0, person_27_9_0):
    return dictionary_person_27_9_0[(person_27_8_0, risk_27_9_0, person_27_9_0)]

dictionary_observe_27_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8139091923679793, ('false', 'false'): 1.0, ('true', 'true'): 0.18609080763202068}
def f_observe_27_9_0(person_27_9_0, observe_27_9_0):
    return dictionary_observe_27_9_0[(person_27_9_0, observe_27_9_0)]

dictionary_person_28_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_28_9_0(person_28_8_0, risk_28_9_0, person_28_9_0):
    return dictionary_person_28_9_0[(person_28_8_0, risk_28_9_0, person_28_9_0)]

dictionary_observe_28_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9449675965881139, ('false', 'false'): 1.0, ('true', 'true'): 0.05503240341188609}
def f_observe_28_9_0(person_28_9_0, observe_28_9_0):
    return dictionary_observe_28_9_0[(person_28_9_0, observe_28_9_0)]

dictionary_person_29_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_29_9_0(person_29_8_0, risk_29_9_0, person_29_9_0):
    return dictionary_person_29_9_0[(person_29_8_0, risk_29_9_0, person_29_9_0)]

dictionary_observe_29_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4850193351680482, ('false', 'false'): 1.0, ('true', 'true'): 0.5149806648319518}
def f_observe_29_9_0(person_29_9_0, observe_29_9_0):
    return dictionary_observe_29_9_0[(person_29_9_0, observe_29_9_0)]

dictionary_person_31_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_31_9_0(person_31_8_0, risk_31_9_0, person_31_9_0):
    return dictionary_person_31_9_0[(person_31_8_0, risk_31_9_0, person_31_9_0)]

dictionary_observe_31_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5364482108197086, ('false', 'false'): 1.0, ('true', 'true'): 0.4635517891802914}
def f_observe_31_9_0(person_31_9_0, observe_31_9_0):
    return dictionary_observe_31_9_0[(person_31_9_0, observe_31_9_0)]

dictionary_person_32_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_32_9_0(person_32_8_0, risk_32_9_0, person_32_9_0):
    return dictionary_person_32_9_0[(person_32_8_0, risk_32_9_0, person_32_9_0)]

dictionary_observe_32_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6707502808648879, ('false', 'false'): 1.0, ('true', 'true'): 0.32924971913511214}
def f_observe_32_9_0(person_32_9_0, observe_32_9_0):
    return dictionary_observe_32_9_0[(person_32_9_0, observe_32_9_0)]

dictionary_person_33_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_33_9_0(person_33_8_0, risk_33_9_0, person_33_9_0):
    return dictionary_person_33_9_0[(person_33_8_0, risk_33_9_0, person_33_9_0)]

dictionary_observe_33_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6652599922970113, ('false', 'false'): 1.0, ('true', 'true'): 0.33474000770298873}
def f_observe_33_9_0(person_33_9_0, observe_33_9_0):
    return dictionary_observe_33_9_0[(person_33_9_0, observe_33_9_0)]

dictionary_person_34_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_34_9_0(person_34_8_0, risk_34_9_0, person_34_9_0):
    return dictionary_person_34_9_0[(person_34_8_0, risk_34_9_0, person_34_9_0)]

dictionary_observe_34_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8670013104368487, ('false', 'false'): 1.0, ('true', 'true'): 0.1329986895631513}
def f_observe_34_9_0(person_34_9_0, observe_34_9_0):
    return dictionary_observe_34_9_0[(person_34_9_0, observe_34_9_0)]

dictionary_person_35_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_35_9_0(person_35_8_0, risk_35_9_0, person_35_9_0):
    return dictionary_person_35_9_0[(person_35_8_0, risk_35_9_0, person_35_9_0)]

dictionary_observe_35_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9070508680572947, ('false', 'false'): 1.0, ('true', 'true'): 0.09294913194270527}
def f_observe_35_9_0(person_35_9_0, observe_35_9_0):
    return dictionary_observe_35_9_0[(person_35_9_0, observe_35_9_0)]

dictionary_person_0_10_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.5028067418742566, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.4195245335968195, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.2916763756943943, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.6813291057668412, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.7076153006813001, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.5478851209444399, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.6115315569865057, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.28918657236120787, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.22572212276393935, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.4082689923616589, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.5484335544989388, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.2239084146726047, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.5888355138168124, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.45211487905556014, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.4976909490748183, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.1584410201736284, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.31867089423315875, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.411576062245433, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.5810565229261065, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.5804754664031805, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.7108134276387921, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.6146529539931189, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.7270495837569471, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.2236845062579321, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.6119200254295192, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.7111026142111534, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.41894347707389346, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.38807997457048077, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.38846844301349426, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.385347046006881, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.41116448618318757, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.7019295150760492, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.3849616989608741, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.27295041624305294, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.7742778772360607, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.15859961979342183, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.7083236243056057, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.4515664455010612, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.2973678527767275, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.5023090509251817, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.8414003802065781, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.8415589798263716, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.6150383010391258, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.29807048492395083, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.5921392766307028, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.7745035993588246, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.2923846993186999, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.7760915853273953, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.7273225341731901, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.588423937754567, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.40786072336929724, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.28889738578884666, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.2254964006411754, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.6816477766610745, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.3183522233389256, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.5917310076383411, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.7763154937420679, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.2726774658268099, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.4971932581257435, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.7026321472232725}
def f_person_0_10_0(person_0_9_0, person_29_9_0, person_1_9_0, person_6_9_0, person_24_9_0, risk_0_10_0, person_0_10_0):
    return dictionary_person_0_10_0[(person_0_9_0, person_29_9_0, person_1_9_0, person_6_9_0, person_24_9_0, risk_0_10_0, person_0_10_0)]

dictionary_observe_0_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.998423258467065, ('false', 'false'): 1.0, ('true', 'true'): 0.0015767415329349665}
def f_observe_0_10_0(person_0_10_0, observe_0_10_0):
    return dictionary_observe_0_10_0[(person_0_10_0, observe_0_10_0)]

dictionary_person_1_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_1_10_0(person_1_9_0, risk_1_10_0, person_1_10_0):
    return dictionary_person_1_10_0[(person_1_9_0, risk_1_10_0, person_1_10_0)]

dictionary_observe_1_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7675775073054547, ('false', 'false'): 1.0, ('true', 'true'): 0.2324224926945453}
def f_observe_1_10_0(person_1_10_0, observe_1_10_0):
    return dictionary_observe_1_10_0[(person_1_10_0, observe_1_10_0)]

dictionary_person_2_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_2_10_0(person_2_9_0, risk_2_10_0, person_2_10_0):
    return dictionary_person_2_10_0[(person_2_9_0, risk_2_10_0, person_2_10_0)]

dictionary_observe_2_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.40441037422662696, ('false', 'false'): 1.0, ('true', 'true'): 0.595589625773373}
def f_observe_2_10_0(person_2_10_0, observe_2_10_0):
    return dictionary_observe_2_10_0[(person_2_10_0, observe_2_10_0)]

dictionary_person_3_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_3_10_0(person_3_9_0, risk_3_10_0, person_3_10_0):
    return dictionary_person_3_10_0[(person_3_9_0, risk_3_10_0, person_3_10_0)]

dictionary_observe_3_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8500133772806642, ('false', 'false'): 1.0, ('true', 'true'): 0.14998662271933583}
def f_observe_3_10_0(person_3_10_0, observe_3_10_0):
    return dictionary_observe_3_10_0[(person_3_10_0, observe_3_10_0)]

dictionary_person_4_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_10_0(person_4_9_0, risk_4_10_0, person_4_10_0):
    return dictionary_person_4_10_0[(person_4_9_0, risk_4_10_0, person_4_10_0)]

dictionary_observe_4_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6401893008435592, ('false', 'false'): 1.0, ('true', 'true'): 0.3598106991564408}
def f_observe_4_10_0(person_4_10_0, observe_4_10_0):
    return dictionary_observe_4_10_0[(person_4_10_0, observe_4_10_0)]

dictionary_person_5_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6989498938004175, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3010501061995825, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6982509439066171, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3017490560933829, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_5_10_0(person_5_9_0, person_4_9_0, risk_5_10_0, person_5_10_0):
    return dictionary_person_5_10_0[(person_5_9_0, person_4_9_0, risk_5_10_0, person_5_10_0)]

dictionary_observe_5_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6556871891473601, ('false', 'false'): 1.0, ('true', 'true'): 0.3443128108526399}
def f_observe_5_10_0(person_5_10_0, observe_5_10_0):
    return dictionary_observe_5_10_0[(person_5_10_0, observe_5_10_0)]

dictionary_person_6_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5766184510385476, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4233815489614524, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5760418325875091, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4239581674124909, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_6_10_0(person_6_9_0, person_29_9_0, risk_6_10_0, person_6_10_0):
    return dictionary_person_6_10_0[(person_6_9_0, person_29_9_0, risk_6_10_0, person_6_10_0)]

dictionary_observe_6_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.47132090601674004, ('false', 'false'): 1.0, ('true', 'true'): 0.52867909398326}
def f_observe_6_10_0(person_6_10_0, observe_6_10_0):
    return dictionary_observe_6_10_0[(person_6_10_0, observe_6_10_0)]

dictionary_person_7_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_7_10_0(person_7_9_0, risk_7_10_0, person_7_10_0):
    return dictionary_person_7_10_0[(person_7_9_0, risk_7_10_0, person_7_10_0)]

dictionary_observe_7_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4149759837146276, ('false', 'false'): 1.0, ('true', 'true'): 0.5850240162853724}
def f_observe_7_10_0(person_7_10_0, observe_7_10_0):
    return dictionary_observe_7_10_0[(person_7_10_0, observe_7_10_0)]

dictionary_person_8_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_8_10_0(person_8_9_0, risk_8_10_0, person_8_10_0):
    return dictionary_person_8_10_0[(person_8_9_0, risk_8_10_0, person_8_10_0)]

dictionary_observe_8_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7324703134261823, ('false', 'false'): 1.0, ('true', 'true'): 0.2675296865738177}
def f_observe_8_10_0(person_8_10_0, observe_8_10_0):
    return dictionary_observe_8_10_0[(person_8_10_0, observe_8_10_0)]

dictionary_person_9_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_9_10_0(person_9_9_0, risk_9_10_0, person_9_10_0):
    return dictionary_person_9_10_0[(person_9_9_0, risk_9_10_0, person_9_10_0)]

dictionary_observe_9_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9079452442183251, ('false', 'false'): 1.0, ('true', 'true'): 0.09205475578167488}
def f_observe_9_10_0(person_9_10_0, observe_9_10_0):
    return dictionary_observe_9_10_0[(person_9_10_0, observe_9_10_0)]

dictionary_person_10_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_10_10_0(person_10_9_0, risk_10_10_0, person_10_10_0):
    return dictionary_person_10_10_0[(person_10_9_0, risk_10_10_0, person_10_10_0)]

dictionary_observe_10_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8119243735035913, ('false', 'false'): 1.0, ('true', 'true'): 0.18807562649640874}
def f_observe_10_10_0(person_10_10_0, observe_10_10_0):
    return dictionary_observe_10_10_0[(person_10_10_0, observe_10_10_0)]

dictionary_person_11_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_11_10_0(person_11_9_0, risk_11_10_0, person_11_10_0):
    return dictionary_person_11_10_0[(person_11_9_0, risk_11_10_0, person_11_10_0)]

dictionary_observe_11_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5403886778261323, ('false', 'false'): 1.0, ('true', 'true'): 0.4596113221738677}
def f_observe_11_10_0(person_11_10_0, observe_11_10_0):
    return dictionary_observe_11_10_0[(person_11_10_0, observe_11_10_0)]

dictionary_person_12_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5770359046434739, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4229640953565261, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5764588687388305, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.42354113126116955, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_12_10_0(person_12_9_0, person_11_9_0, risk_12_10_0, person_12_10_0):
    return dictionary_person_12_10_0[(person_12_9_0, person_11_9_0, risk_12_10_0, person_12_10_0)]

dictionary_observe_12_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7681770299081461, ('false', 'false'): 1.0, ('true', 'true'): 0.23182297009185393}
def f_observe_12_10_0(person_12_10_0, observe_12_10_0):
    return dictionary_observe_12_10_0[(person_12_10_0, observe_12_10_0)]

dictionary_person_13_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6516211127130666, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.34837888728693345, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6509694916003534, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.34903050839964656, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_13_10_0(person_13_9_0, person_12_9_0, risk_13_10_0, person_13_10_0):
    return dictionary_person_13_10_0[(person_13_9_0, person_12_9_0, risk_13_10_0, person_13_10_0)]

dictionary_observe_13_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9687326058850034, ('false', 'false'): 1.0, ('true', 'true'): 0.03126739411499657}
def f_observe_13_10_0(person_13_10_0, observe_13_10_0):
    return dictionary_observe_13_10_0[(person_13_10_0, observe_13_10_0)]

dictionary_person_14_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4134805916984373, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5865194083015627, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4130671111067389, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5869328888932611, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_14_10_0(person_14_9_0, person_26_9_0, risk_14_10_0, person_14_10_0):
    return dictionary_person_14_10_0[(person_14_9_0, person_26_9_0, risk_14_10_0, person_14_10_0)]

dictionary_observe_14_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5496762475042991, ('false', 'false'): 1.0, ('true', 'true'): 0.4503237524957009}
def f_observe_14_10_0(person_14_10_0, observe_14_10_0):
    return dictionary_observe_14_10_0[(person_14_10_0, observe_14_10_0)]

dictionary_person_18_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_18_10_0(person_18_9_0, risk_18_10_0, person_18_10_0):
    return dictionary_person_18_10_0[(person_18_9_0, risk_18_10_0, person_18_10_0)]

dictionary_observe_18_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.591339777012184, ('false', 'false'): 1.0, ('true', 'true'): 0.408660222987816}
def f_observe_18_10_0(person_18_10_0, observe_18_10_0):
    return dictionary_observe_18_10_0[(person_18_10_0, observe_18_10_0)]

dictionary_person_19_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6292189027100106, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3707810972899894, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6285896838073005, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3714103161926995, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_19_10_0(person_19_9_0, person_31_9_0, risk_19_10_0, person_19_10_0):
    return dictionary_person_19_10_0[(person_19_9_0, person_31_9_0, risk_19_10_0, person_19_10_0)]

dictionary_observe_19_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8535011969197, ('false', 'false'): 1.0, ('true', 'true'): 0.14649880308030006}
def f_observe_19_10_0(person_19_10_0, observe_19_10_0):
    return dictionary_observe_19_10_0[(person_19_10_0, observe_19_10_0)]

dictionary_person_20_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7214222345734395, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.27857776542656054, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7207008123388661, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.27929918766113393, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_20_10_0(person_20_9_0, person_21_9_0, risk_20_10_0, person_20_10_0):
    return dictionary_person_20_10_0[(person_20_9_0, person_21_9_0, risk_20_10_0, person_20_10_0)]

dictionary_observe_20_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8920307357488226, ('false', 'false'): 1.0, ('true', 'true'): 0.10796926425117737}
def f_observe_20_10_0(person_20_10_0, observe_20_10_0):
    return dictionary_observe_20_10_0[(person_20_10_0, observe_20_10_0)]

dictionary_person_21_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_21_10_0(person_21_9_0, risk_21_10_0, person_21_10_0):
    return dictionary_person_21_10_0[(person_21_9_0, risk_21_10_0, person_21_10_0)]

dictionary_observe_21_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5223191684509454, ('false', 'false'): 1.0, ('true', 'true'): 0.4776808315490546}
def f_observe_21_10_0(person_21_10_0, observe_21_10_0):
    return dictionary_observe_21_10_0[(person_21_10_0, observe_21_10_0)]

dictionary_person_24_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_24_10_0(person_24_9_0, risk_24_10_0, person_24_10_0):
    return dictionary_person_24_10_0[(person_24_9_0, risk_24_10_0, person_24_10_0)]

dictionary_observe_24_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5913302592942042, ('false', 'false'): 1.0, ('true', 'true'): 0.40866974070579576}
def f_observe_24_10_0(person_24_10_0, observe_24_10_0):
    return dictionary_observe_24_10_0[(person_24_10_0, observe_24_10_0)]

dictionary_person_25_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_25_10_0(person_25_9_0, risk_25_10_0, person_25_10_0):
    return dictionary_person_25_10_0[(person_25_9_0, risk_25_10_0, person_25_10_0)]

dictionary_observe_25_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9999739731777086, ('false', 'false'): 1.0, ('true', 'true'): 2.6026822291358442e-05}
def f_observe_25_10_0(person_25_10_0, observe_25_10_0):
    return dictionary_observe_25_10_0[(person_25_10_0, observe_25_10_0)]

dictionary_person_26_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8147853711149395, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.18521462888506046, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8139705857438246, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.18602941425617536, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_26_10_0(person_26_9_0, person_25_9_0, risk_26_10_0, person_26_10_0):
    return dictionary_person_26_10_0[(person_26_9_0, person_25_9_0, risk_26_10_0, person_26_10_0)]

dictionary_observe_26_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6093028453960477, ('false', 'false'): 1.0, ('true', 'true'): 0.39069715460395227}
def f_observe_26_10_0(person_26_10_0, observe_26_10_0):
    return dictionary_observe_26_10_0[(person_26_10_0, observe_26_10_0)]

dictionary_person_27_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_27_10_0(person_27_9_0, risk_27_10_0, person_27_10_0):
    return dictionary_person_27_10_0[(person_27_9_0, risk_27_10_0, person_27_10_0)]

dictionary_observe_27_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8287697204883094, ('false', 'false'): 1.0, ('true', 'true'): 0.17123027951169056}
def f_observe_27_10_0(person_27_10_0, observe_27_10_0):
    return dictionary_observe_27_10_0[(person_27_10_0, observe_27_10_0)]

dictionary_person_28_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_28_10_0(person_28_9_0, risk_28_10_0, person_28_10_0):
    return dictionary_person_28_10_0[(person_28_9_0, risk_28_10_0, person_28_10_0)]

dictionary_observe_28_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9783698086925547, ('false', 'false'): 1.0, ('true', 'true'): 0.021630191307445257}
def f_observe_28_10_0(person_28_10_0, observe_28_10_0):
    return dictionary_observe_28_10_0[(person_28_10_0, observe_28_10_0)]

dictionary_person_29_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.47753940056728705, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7121728098903093, ('false', 'false', 'true', 'false', 'false'): 0.5514584367279389, ('false', 'true', 'false', 'true', 'true'): 0.4780618611667198, ('false', 'false', 'true', 'false', 'true'): 0.4485415632720611, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5219381388332802, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5509069782912109, ('false', 'true', 'true', 'false', 'true'): 0.7118846945848942, ('false', 'true', 'true', 'false', 'false'): 0.28811530541510577, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.44909302170878906, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.522460599432713, ('false', 'true', 'true', 'true', 'false'): 0.28782719010969066}
def f_person_29_10_0(person_29_9_0, person_35_9_0, person_34_9_0, risk_29_10_0, person_29_10_0):
    return dictionary_person_29_10_0[(person_29_9_0, person_35_9_0, person_34_9_0, risk_29_10_0, person_29_10_0)]

dictionary_observe_29_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7478004374468941, ('false', 'false'): 1.0, ('true', 'true'): 0.25219956255310594}
def f_observe_29_10_0(person_29_10_0, observe_29_10_0):
    return dictionary_observe_29_10_0[(person_29_10_0, observe_29_10_0)]

dictionary_person_31_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.35142093538722363, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.6485790646127764, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.35106951445183643, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.6489304855481636, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_31_10_0(person_31_9_0, person_25_9_0, risk_31_10_0, person_31_10_0):
    return dictionary_person_31_10_0[(person_31_9_0, person_25_9_0, risk_31_10_0, person_31_10_0)]

dictionary_observe_31_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6689753185369967, ('false', 'false'): 1.0, ('true', 'true'): 0.33102468146300335}
def f_observe_31_10_0(person_31_10_0, observe_31_10_0):
    return dictionary_observe_31_10_0[(person_31_10_0, observe_31_10_0)]

dictionary_person_32_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.999, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8991, ('false', 'false', 'true', 'false'): 0.9, ('false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.09999999999999998}
def f_person_32_10_0(person_32_9_0, risk_32_10_0, risk_32_10_1, person_32_10_0):
    return dictionary_person_32_10_0[(person_32_9_0, risk_32_10_0, risk_32_10_1, person_32_10_0)]

dictionary_observe_32_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.737419025644473, ('false', 'false'): 1.0, ('true', 'true'): 0.26258097435552696}
def f_observe_32_10_0(person_32_10_0, observe_32_10_0):
    return dictionary_observe_32_10_0[(person_32_10_0, observe_32_10_0)]

dictionary_person_33_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_33_10_0(person_33_9_0, risk_33_10_0, person_33_10_0):
    return dictionary_person_33_10_0[(person_33_9_0, risk_33_10_0, person_33_10_0)]

dictionary_observe_33_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9820666765351747, ('false', 'false'): 1.0, ('true', 'true'): 0.017933323464825346}
def f_observe_33_10_0(person_33_10_0, observe_33_10_0):
    return dictionary_observe_33_10_0[(person_33_10_0, observe_33_10_0)]

dictionary_person_34_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_34_10_0(person_34_9_0, risk_34_10_0, person_34_10_0):
    return dictionary_person_34_10_0[(person_34_9_0, risk_34_10_0, person_34_10_0)]

dictionary_observe_34_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5987829338565331, ('false', 'false'): 1.0, ('true', 'true'): 0.40121706614346686}
def f_observe_34_10_0(person_34_10_0, observe_34_10_0):
    return dictionary_observe_34_10_0[(person_34_10_0, observe_34_10_0)]

dictionary_person_35_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6043063245835951, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3956936754164049, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6037020182590115, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3962979817409885, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_35_10_0(person_35_9_0, person_29_9_0, risk_35_10_0, person_35_10_0):
    return dictionary_person_35_10_0[(person_35_9_0, person_29_9_0, risk_35_10_0, person_35_10_0)]

dictionary_observe_35_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8593140458398543, ('false', 'false'): 1.0, ('true', 'true'): 0.14068595416014573}
def f_observe_35_10_0(person_35_10_0, observe_35_10_0):
    return dictionary_observe_35_10_0[(person_35_10_0, observe_35_10_0)]

functions = [f_person_0_7_0, f_person_1_7_0, f_person_2_7_0, f_person_3_7_0, f_person_4_7_0, f_person_5_7_0, f_person_6_7_0, f_person_7_7_0, f_person_8_7_0, f_person_9_7_0, f_person_10_7_0, f_person_11_7_0, f_person_12_7_0, f_person_13_7_0, f_person_14_7_0, f_person_18_7_0, f_person_19_7_0, f_person_20_7_0, f_person_21_7_0, f_person_24_7_0, f_person_25_7_0, f_person_26_7_0, f_person_27_7_0, f_person_28_7_0, f_person_29_7_0, f_person_31_7_0, f_person_32_7_0, f_person_33_7_0, f_person_34_7_0, f_person_35_7_0, f_risk_0_8_0, f_risk_1_8_0, f_risk_2_8_0, f_risk_3_8_0, f_risk_4_8_0, f_risk_5_8_0, f_risk_6_8_0, f_risk_7_8_0, f_risk_8_8_0, f_risk_9_8_0, f_risk_10_8_0, f_risk_11_8_0, f_risk_12_8_0, f_risk_13_8_0, f_risk_14_8_0, f_risk_18_8_0, f_risk_19_8_0, f_risk_20_8_0, f_risk_21_8_0, f_risk_24_8_0, f_risk_25_8_0, f_risk_26_8_0, f_risk_27_8_0, f_risk_28_8_0, f_risk_29_8_0, f_risk_31_8_0, f_risk_32_8_0, f_risk_33_8_0, f_risk_34_8_0, f_risk_35_8_0, f_risk_0_9_0, f_risk_1_9_0, f_risk_2_9_0, f_risk_3_9_0, f_risk_4_9_0, f_risk_5_9_0, f_risk_6_9_0, f_risk_7_9_0, f_risk_8_9_0, f_risk_9_9_0, f_risk_10_9_0, f_risk_11_9_0, f_risk_12_9_0, f_risk_13_9_0, f_risk_14_9_0, f_risk_18_9_0, f_risk_19_9_0, f_risk_20_9_0, f_risk_21_9_0, f_risk_24_9_0, f_risk_25_9_0, f_risk_26_9_0, f_risk_27_9_0, f_risk_28_9_0, f_risk_29_9_0, f_risk_31_9_0, f_risk_32_9_0, f_risk_33_9_0, f_risk_34_9_0, f_risk_35_9_0, f_risk_0_10_0, f_risk_1_10_0, f_risk_2_10_0, f_risk_3_10_0, f_risk_4_10_0, f_risk_5_10_0, f_risk_6_10_0, f_risk_7_10_0, f_risk_8_10_0, f_risk_9_10_0, f_risk_10_10_0, f_risk_11_10_0, f_risk_12_10_0, f_risk_13_10_0, f_risk_14_10_0, f_risk_18_10_0, f_risk_19_10_0, f_risk_20_10_0, f_risk_21_10_0, f_risk_24_10_0, f_risk_25_10_0, f_risk_26_10_0, f_risk_27_10_0, f_risk_28_10_0, f_risk_29_10_0, f_risk_31_10_0, f_risk_32_10_0, f_risk_32_10_1, f_risk_33_10_0, f_risk_34_10_0, f_risk_35_10_0, f_observe_0_7_0, f_observe_1_7_0, f_observe_2_7_0, f_observe_3_7_0, f_observe_4_7_0, f_observe_5_7_0, f_observe_6_7_0, f_observe_7_7_0, f_observe_8_7_0, f_observe_9_7_0, f_observe_10_7_0, f_observe_11_7_0, f_observe_12_7_0, f_observe_13_7_0, f_observe_14_7_0, f_observe_18_7_0, f_observe_19_7_0, f_observe_20_7_0, f_observe_21_7_0, f_observe_24_7_0, f_observe_25_7_0, f_observe_26_7_0, f_observe_27_7_0, f_observe_28_7_0, f_observe_29_7_0, f_observe_31_7_0, f_observe_32_7_0, f_observe_33_7_0, f_observe_34_7_0, f_observe_35_7_0, f_person_0_8_0, f_observe_0_8_0, f_person_1_8_0, f_observe_1_8_0, f_person_2_8_0, f_observe_2_8_0, f_person_3_8_0, f_observe_3_8_0, f_person_4_8_0, f_observe_4_8_0, f_person_5_8_0, f_observe_5_8_0, f_person_6_8_0, f_observe_6_8_0, f_person_7_8_0, f_observe_7_8_0, f_person_8_8_0, f_observe_8_8_0, f_person_9_8_0, f_observe_9_8_0, f_person_10_8_0, f_observe_10_8_0, f_person_11_8_0, f_observe_11_8_0, f_person_12_8_0, f_observe_12_8_0, f_person_13_8_0, f_observe_13_8_0, f_person_14_8_0, f_observe_14_8_0, f_person_18_8_0, f_observe_18_8_0, f_person_19_8_0, f_observe_19_8_0, f_person_20_8_0, f_observe_20_8_0, f_person_21_8_0, f_observe_21_8_0, f_person_24_8_0, f_observe_24_8_0, f_person_25_8_0, f_observe_25_8_0, f_person_26_8_0, f_observe_26_8_0, f_person_27_8_0, f_observe_27_8_0, f_person_28_8_0, f_observe_28_8_0, f_person_29_8_0, f_observe_29_8_0, f_person_31_8_0, f_observe_31_8_0, f_person_32_8_0, f_observe_32_8_0, f_person_33_8_0, f_observe_33_8_0, f_person_34_8_0, f_observe_34_8_0, f_person_35_8_0, f_observe_35_8_0, f_person_0_9_0, f_observe_0_9_0, f_person_1_9_0, f_observe_1_9_0, f_person_2_9_0, f_observe_2_9_0, f_person_3_9_0, f_observe_3_9_0, f_person_4_9_0, f_observe_4_9_0, f_person_5_9_0, f_observe_5_9_0, f_person_6_9_0, f_observe_6_9_0, f_person_7_9_0, f_observe_7_9_0, f_person_8_9_0, f_observe_8_9_0, f_person_9_9_0, f_observe_9_9_0, f_person_10_9_0, f_observe_10_9_0, f_person_11_9_0, f_observe_11_9_0, f_person_12_9_0, f_observe_12_9_0, f_person_13_9_0, f_observe_13_9_0, f_person_14_9_0, f_observe_14_9_0, f_person_18_9_0, f_observe_18_9_0, f_person_19_9_0, f_observe_19_9_0, f_person_20_9_0, f_observe_20_9_0, f_person_21_9_0, f_observe_21_9_0, f_person_24_9_0, f_observe_24_9_0, f_person_25_9_0, f_observe_25_9_0, f_person_26_9_0, f_observe_26_9_0, f_person_27_9_0, f_observe_27_9_0, f_person_28_9_0, f_observe_28_9_0, f_person_29_9_0, f_observe_29_9_0, f_person_31_9_0, f_observe_31_9_0, f_person_32_9_0, f_observe_32_9_0, f_person_33_9_0, f_observe_33_9_0, f_person_34_9_0, f_observe_34_9_0, f_person_35_9_0, f_observe_35_9_0, f_person_0_10_0, f_observe_0_10_0, f_person_1_10_0, f_observe_1_10_0, f_person_2_10_0, f_observe_2_10_0, f_person_3_10_0, f_observe_3_10_0, f_person_4_10_0, f_observe_4_10_0, f_person_5_10_0, f_observe_5_10_0, f_person_6_10_0, f_observe_6_10_0, f_person_7_10_0, f_observe_7_10_0, f_person_8_10_0, f_observe_8_10_0, f_person_9_10_0, f_observe_9_10_0, f_person_10_10_0, f_observe_10_10_0, f_person_11_10_0, f_observe_11_10_0, f_person_12_10_0, f_observe_12_10_0, f_person_13_10_0, f_observe_13_10_0, f_person_14_10_0, f_observe_14_10_0, f_person_18_10_0, f_observe_18_10_0, f_person_19_10_0, f_observe_19_10_0, f_person_20_10_0, f_observe_20_10_0, f_person_21_10_0, f_observe_21_10_0, f_person_24_10_0, f_observe_24_10_0, f_person_25_10_0, f_observe_25_10_0, f_person_26_10_0, f_observe_26_10_0, f_person_27_10_0, f_observe_27_10_0, f_person_28_10_0, f_observe_28_10_0, f_person_29_10_0, f_observe_29_10_0, f_person_31_10_0, f_observe_31_10_0, f_person_32_10_0, f_observe_32_10_0, f_person_33_10_0, f_observe_33_10_0, f_person_34_10_0, f_observe_34_10_0, f_person_35_10_0, f_observe_35_10_0]
domains_dict = {'person_20_9_0': ['false', 'true'], 'observe_5_8_0': ['false', 'true'], 'person_33_7_0': ['false', 'true'], 'person_32_7_0': ['false', 'true'], 'person_6_8_0': ['false', 'true'], 'observe_10_7_0': ['false', 'true'], 'risk_13_8_0': ['false', 'true'], 'risk_6_8_0': ['false', 'true'], 'risk_7_8_0': ['false', 'true'], 'person_0_9_0': ['false', 'true'], 'observe_24_10_0': ['false', 'true'], 'risk_12_9_0': ['false', 'true'], 'person_31_7_0': ['false', 'true'], 'person_32_9_0': ['false', 'true'], 'risk_4_10_0': ['false', 'true'], 'person_14_8_0': ['false', 'true'], 'risk_2_9_0': ['false', 'true'], 'observe_29_8_0': ['false', 'true'], 'person_0_7_0': ['false', 'true'], 'risk_26_8_0': ['false', 'true'], 'person_19_9_0': ['false', 'true'], 'risk_10_9_0': ['false', 'true'], 'person_4_7_0': ['false', 'true'], 'risk_20_9_0': ['false', 'true'], 'risk_13_10_0': ['false', 'true'], 'observe_5_10_0': ['false', 'true'], 'observe_2_8_0': ['false', 'true'], 'observe_11_8_0': ['false', 'true'], 'observe_33_7_0': ['false', 'true'], 'observe_19_10_0': ['false', 'true'], 'risk_35_8_0': ['false', 'true'], 'observe_9_7_0': ['false', 'true'], 'risk_5_10_0': ['false', 'true'], 'observe_0_10_0': ['false', 'true'], 'person_28_10_0': ['false', 'true'], 'observe_4_9_0': ['false', 'true'], 'person_28_7_0': ['false', 'true'], 'risk_28_10_0': ['false', 'true'], 'observe_9_8_0': ['false', 'true'], 'person_4_9_0': ['false', 'true'], 'observe_24_7_0': ['false', 'true'], 'person_3_8_0': ['false', 'true'], 'risk_4_9_0': ['false', 'true'], 'observe_31_9_0': ['false', 'true'], 'observe_32_7_0': ['false', 'true'], 'risk_26_10_0': ['false', 'true'], 'risk_5_8_0': ['false', 'true'], 'observe_0_9_0': ['false', 'true'], 'person_34_8_0': ['false', 'true'], 'risk_1_8_0': ['false', 'true'], 'person_28_8_0': ['false', 'true'], 'observe_24_9_0': ['false', 'true'], 'person_1_8_0': ['false', 'true'], 'person_29_10_0': ['false', 'true'], 'observe_3_10_0': ['false', 'true'], 'risk_9_8_0': ['false', 'true'], 'person_13_9_0': ['false', 'true'], 'observe_32_9_0': ['false', 'true'], 'observe_12_9_0': ['false', 'true'], 'observe_1_9_0': ['false', 'true'], 'observe_33_10_0': ['false', 'true'], 'person_12_8_0': ['false', 'true'], 'observe_18_10_0': ['false', 'true'], 'risk_31_9_0': ['false', 'true'], 'person_6_7_0': ['false', 'true'], 'person_13_7_0': ['false', 'true'], 'observe_13_9_0': ['false', 'true'], 'risk_27_8_0': ['false', 'true'], 'risk_28_8_0': ['false', 'true'], 'person_4_8_0': ['false', 'true'], 'person_11_10_0': ['false', 'true'], 'person_1_10_0': ['false', 'true'], 'person_24_9_0': ['false', 'true'], 'risk_32_8_0': ['false', 'true'], 'observe_11_10_0': ['false', 'true'], 'risk_6_9_0': ['false', 'true'], 'person_19_7_0': ['false', 'true'], 'person_18_7_0': ['false', 'true'], 'risk_19_9_0': ['false', 'true'], 'person_7_8_0': ['false', 'true'], 'observe_13_7_0': ['false', 'true'], 'observe_9_10_0': ['false', 'true'], 'person_32_8_0': ['false', 'true'], 'person_20_8_0': ['false', 'true'], 'person_3_7_0': ['false', 'true'], 'person_24_10_0': ['false', 'true'], 'observe_19_7_0': ['false', 'true'], 'person_13_10_0': ['false', 'true'], 'observe_2_9_0': ['false', 'true'], 'risk_7_9_0': ['false', 'true'], 'person_18_9_0': ['false', 'true'], 'person_0_8_0': ['false', 'true'], 'risk_10_8_0': ['false', 'true'], 'person_9_10_0': ['false', 'true'], 'observe_21_10_0': ['false', 'true'], 'person_14_7_0': ['false', 'true'], 'person_1_7_0': ['false', 'true'], 'observe_26_8_0': ['false', 'true'], 'observe_32_10_0': ['false', 'true'], 'person_27_7_0': ['false', 'true'], 'risk_0_10_0': ['false', 'true'], 'observe_6_9_0': ['false', 'true'], 'observe_11_7_0': ['false', 'true'], 'risk_12_10_0': ['false', 'true'], 'observe_1_7_0': ['false', 'true'], 'observe_12_7_0': ['false', 'true'], 'observe_34_10_0': ['false', 'true'], 'risk_20_8_0': ['false', 'true'], 'observe_0_7_0': ['false', 'true'], 'observe_11_9_0': ['false', 'true'], 'observe_8_7_0': ['false', 'true'], 'person_27_10_0': ['false', 'true'], 'risk_21_9_0': ['false', 'true'], 'risk_34_9_0': ['false', 'true'], 'person_33_8_0': ['false', 'true'], 'risk_29_9_0': ['false', 'true'], 'observe_10_9_0': ['false', 'true'], 'observe_8_8_0': ['false', 'true'], 'risk_4_8_0': ['false', 'true'], 'person_25_7_0': ['false', 'true'], 'person_2_8_0': ['false', 'true'], 'person_20_7_0': ['false', 'true'], 'observe_24_8_0': ['false', 'true'], 'observe_0_8_0': ['false', 'true'], 'observe_8_9_0': ['false', 'true'], 'person_35_9_0': ['false', 'true'], 'person_5_8_0': ['false', 'true'], 'person_32_10_0': ['false', 'true'], 'person_5_10_0': ['false', 'true'], 'person_18_10_0': ['false', 'true'], 'person_24_8_0': ['false', 'true'], 'observe_10_10_0': ['false', 'true'], 'risk_8_9_0': ['false', 'true'], 'person_9_9_0': ['false', 'true'], 'observe_7_8_0': ['false', 'true'], 'risk_6_10_0': ['false', 'true'], 'risk_11_8_0': ['false', 'true'], 'risk_1_9_0': ['false', 'true'], 'observe_28_8_0': ['false', 'true'], 'person_29_9_0': ['false', 'true'], 'person_1_9_0': ['false', 'true'], 'person_31_8_0': ['false', 'true'], 'risk_10_10_0': ['false', 'true'], 'observe_34_9_0': ['false', 'true'], 'observe_6_10_0': ['false', 'true'], 'risk_7_10_0': ['false', 'true'], 'person_9_7_0': ['false', 'true'], 'observe_13_8_0': ['false', 'true'], 'observe_31_8_0': ['false', 'true'], 'risk_28_9_0': ['false', 'true'], 'person_19_10_0': ['false', 'true'], 'observe_35_9_0': ['false', 'true'], 'risk_31_8_0': ['false', 'true'], 'risk_21_8_0': ['false', 'true'], 'person_34_10_0': ['false', 'true'], 'risk_20_10_0': ['false', 'true'], 'observe_8_10_0': ['false', 'true'], 'observe_3_9_0': ['false', 'true'], 'risk_11_9_0': ['false', 'true'], 'risk_3_10_0': ['false', 'true'], 'risk_32_10_0': ['false', 'true'], 'observe_7_10_0': ['false', 'true'], 'risk_33_8_0': ['false', 'true'], 'person_25_9_0': ['false', 'true'], 'risk_14_8_0': ['false', 'true'], 'observe_28_10_0': ['false', 'true'], 'person_21_10_0': ['false', 'true'], 'observe_35_7_0': ['false', 'true'], 'risk_0_9_0': ['false', 'true'], 'person_18_8_0': ['false', 'true'], 'observe_25_8_0': ['false', 'true'], 'person_7_9_0': ['false', 'true'], 'risk_19_8_0': ['false', 'true'], 'person_27_8_0': ['false', 'true'], 'person_26_8_0': ['false', 'true'], 'person_10_8_0': ['false', 'true'], 'person_11_8_0': ['false', 'true'], 'observe_25_9_0': ['false', 'true'], 'risk_18_9_0': ['false', 'true'], 'observe_20_10_0': ['false', 'true'], 'observe_27_8_0': ['false', 'true'], 'observe_31_10_0': ['false', 'true'], 'person_29_7_0': ['false', 'true'], 'risk_3_8_0': ['false', 'true'], 'observe_18_8_0': ['false', 'true'], 'observe_19_8_0': ['false', 'true'], 'observe_26_9_0': ['false', 'true'], 'risk_35_10_0': ['false', 'true'], 'observe_14_9_0': ['false', 'true'], 'observe_12_8_0': ['false', 'true'], 'risk_12_8_0': ['false', 'true'], 'risk_26_9_0': ['false', 'true'], 'observe_34_7_0': ['false', 'true'], 'observe_12_10_0': ['false', 'true'], 'risk_34_8_0': ['false', 'true'], 'risk_31_10_0': ['false', 'true'], 'person_28_9_0': ['false', 'true'], 'risk_34_10_0': ['false', 'true'], 'risk_29_8_0': ['false', 'true'], 'risk_14_10_0': ['false', 'true'], 'observe_26_7_0': ['false', 'true'], 'risk_24_9_0': ['false', 'true'], 'risk_8_10_0': ['false', 'true'], 'risk_14_9_0': ['false', 'true'], 'observe_20_7_0': ['false', 'true'], 'observe_2_10_0': ['false', 'true'], 'person_0_10_0': ['false', 'true'], 'observe_25_7_0': ['false', 'true'], 'observe_3_7_0': ['false', 'true'], 'observe_1_8_0': ['false', 'true'], 'observe_3_8_0': ['false', 'true'], 'person_21_8_0': ['false', 'true'], 'risk_18_8_0': ['false', 'true'], 'observe_7_9_0': ['false', 'true'], 'person_9_8_0': ['false', 'true'], 'person_25_8_0': ['false', 'true'], 'person_20_10_0': ['false', 'true'], 'observe_21_8_0': ['false', 'true'], 'person_35_8_0': ['false', 'true'], 'person_29_8_0': ['false', 'true'], 'risk_9_10_0': ['false', 'true'], 'observe_27_7_0': ['false', 'true'], 'observe_28_7_0': ['false', 'true'], 'risk_8_8_0': ['false', 'true'], 'observe_7_7_0': ['false', 'true'], 'risk_33_10_0': ['false', 'true'], 'observe_31_7_0': ['false', 'true'], 'observe_28_9_0': ['false', 'true'], 'person_2_10_0': ['false', 'true'], 'observe_14_8_0': ['false', 'true'], 'observe_33_8_0': ['false', 'true'], 'person_5_7_0': ['false', 'true'], 'observe_35_8_0': ['false', 'true'], 'risk_27_9_0': ['false', 'true'], 'risk_25_8_0': ['false', 'true'], 'observe_13_10_0': ['false', 'true'], 'observe_6_8_0': ['false', 'true'], 'observe_1_10_0': ['false', 'true'], 'observe_25_10_0': ['false', 'true'], 'person_7_10_0': ['false', 'true'], 'risk_33_9_0': ['false', 'true'], 'observe_29_7_0': ['false', 'true'], 'risk_27_10_0': ['false', 'true'], 'observe_33_9_0': ['false', 'true'], 'person_24_7_0': ['false', 'true'], 'observe_4_8_0': ['false', 'true'], 'person_8_7_0': ['false', 'true'], 'risk_19_10_0': ['false', 'true'], 'observe_27_10_0': ['false', 'true'], 'risk_32_9_0': ['false', 'true'], 'person_7_7_0': ['false', 'true'], 'observe_35_10_0': ['false', 'true'], 'person_11_9_0': ['false', 'true'], 'risk_1_10_0': ['false', 'true'], 'person_4_10_0': ['false', 'true'], 'person_27_9_0': ['false', 'true'], 'risk_3_9_0': ['false', 'true'], 'observe_18_7_0': ['false', 'true'], 'risk_0_8_0': ['false', 'true'], 'observe_29_9_0': ['false', 'true'], 'observe_27_9_0': ['false', 'true'], 'person_8_9_0': ['false', 'true'], 'person_10_10_0': ['false', 'true'], 'observe_18_9_0': ['false', 'true'], 'person_10_9_0': ['false', 'true'], 'person_33_10_0': ['false', 'true'], 'risk_2_8_0': ['false', 'true'], 'person_14_9_0': ['false', 'true'], 'risk_2_10_0': ['false', 'true'], 'risk_25_9_0': ['false', 'true'], 'risk_35_9_0': ['false', 'true'], 'observe_29_10_0': ['false', 'true'], 'observe_34_8_0': ['false', 'true'], 'observe_2_7_0': ['false', 'true'], 'observe_19_9_0': ['false', 'true'], 'observe_26_10_0': ['false', 'true'], 'person_26_7_0': ['false', 'true'], 'person_2_7_0': ['false', 'true'], 'person_6_10_0': ['false', 'true'], 'person_3_10_0': ['false', 'true'], 'person_26_10_0': ['false', 'true'], 'observe_4_10_0': ['false', 'true'], 'observe_9_9_0': ['false', 'true'], 'risk_29_10_0': ['false', 'true'], 'person_19_8_0': ['false', 'true'], 'person_33_9_0': ['false', 'true'], 'person_2_9_0': ['false', 'true'], 'risk_24_8_0': ['false', 'true'], 'observe_20_9_0': ['false', 'true'], 'person_14_10_0': ['false', 'true'], 'risk_24_10_0': ['false', 'true'], 'observe_14_10_0': ['false', 'true'], 'person_21_7_0': ['false', 'true'], 'risk_25_10_0': ['false', 'true'], 'person_31_10_0': ['false', 'true'], 'person_26_9_0': ['false', 'true'], 'observe_21_9_0': ['false', 'true'], 'person_3_9_0': ['false', 'true'], 'observe_14_7_0': ['false', 'true'], 'person_8_8_0': ['false', 'true'], 'observe_4_7_0': ['false', 'true'], 'observe_20_8_0': ['false', 'true'], 'risk_21_10_0': ['false', 'true'], 'person_21_9_0': ['false', 'true'], 'risk_5_9_0': ['false', 'true'], 'person_5_9_0': ['false', 'true'], 'person_25_10_0': ['false', 'true'], 'person_34_9_0': ['false', 'true'], 'observe_6_7_0': ['false', 'true'], 'person_10_7_0': ['false', 'true'], 'person_35_7_0': ['false', 'true'], 'person_34_7_0': ['false', 'true'], 'risk_9_9_0': ['false', 'true'], 'observe_32_8_0': ['false', 'true'], 'person_13_8_0': ['false', 'true'], 'observe_10_8_0': ['false', 'true'], 'risk_32_10_1': ['false', 'true'], 'observe_5_7_0': ['false', 'true'], 'person_12_9_0': ['false', 'true'], 'person_31_9_0': ['false', 'true'], 'person_12_10_0': ['false', 'true'], 'person_6_9_0': ['false', 'true'], 'person_35_10_0': ['false', 'true'], 'person_8_10_0': ['false', 'true'], 'person_12_7_0': ['false', 'true'], 'observe_5_9_0': ['false', 'true'], 'risk_18_10_0': ['false', 'true'], 'person_11_7_0': ['false', 'true'], 'observe_21_7_0': ['false', 'true'], 'risk_13_9_0': ['false', 'true'], 'risk_11_10_0': ['false', 'true']}

def create_graph():
    g = build_graph(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/data/d36/infection0'
    return g

def create_bbn():
    g = build_bbn(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/data/d36/infection0'
    return g

