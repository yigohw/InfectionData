from bayesian.factor_graph import *
from bayesian.bbn import *

dictionary_person_0_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_0_7_0(person_0_7_0):
    return dictionary_person_0_7_0[person_0_7_0]

dictionary_person_1_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_1_7_0(person_1_7_0):
    return dictionary_person_1_7_0[person_1_7_0]

dictionary_person_2_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_2_7_0(person_2_7_0):
    return dictionary_person_2_7_0[person_2_7_0]

dictionary_person_3_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_3_7_0(person_3_7_0):
    return dictionary_person_3_7_0[person_3_7_0]

dictionary_person_4_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_4_7_0(person_4_7_0):
    return dictionary_person_4_7_0[person_4_7_0]

dictionary_person_5_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_5_7_0(person_5_7_0):
    return dictionary_person_5_7_0[person_5_7_0]

dictionary_person_6_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_6_7_0(person_6_7_0):
    return dictionary_person_6_7_0[person_6_7_0]

dictionary_person_7_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_7_7_0(person_7_7_0):
    return dictionary_person_7_7_0[person_7_7_0]

dictionary_person_8_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_8_7_0(person_8_7_0):
    return dictionary_person_8_7_0[person_8_7_0]

dictionary_person_9_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_9_7_0(person_9_7_0):
    return dictionary_person_9_7_0[person_9_7_0]

dictionary_person_10_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_10_7_0(person_10_7_0):
    return dictionary_person_10_7_0[person_10_7_0]

dictionary_person_11_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_11_7_0(person_11_7_0):
    return dictionary_person_11_7_0[person_11_7_0]

dictionary_person_12_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_12_7_0(person_12_7_0):
    return dictionary_person_12_7_0[person_12_7_0]

dictionary_person_13_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_13_7_0(person_13_7_0):
    return dictionary_person_13_7_0[person_13_7_0]

dictionary_person_14_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_14_7_0(person_14_7_0):
    return dictionary_person_14_7_0[person_14_7_0]

dictionary_person_15_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_15_7_0(person_15_7_0):
    return dictionary_person_15_7_0[person_15_7_0]

dictionary_person_16_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_16_7_0(person_16_7_0):
    return dictionary_person_16_7_0[person_16_7_0]

dictionary_person_17_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_17_7_0(person_17_7_0):
    return dictionary_person_17_7_0[person_17_7_0]

dictionary_person_18_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_18_7_0(person_18_7_0):
    return dictionary_person_18_7_0[person_18_7_0]

dictionary_person_19_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_19_7_0(person_19_7_0):
    return dictionary_person_19_7_0[person_19_7_0]

dictionary_person_20_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_20_7_0(person_20_7_0):
    return dictionary_person_20_7_0[person_20_7_0]

dictionary_person_21_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_21_7_0(person_21_7_0):
    return dictionary_person_21_7_0[person_21_7_0]

dictionary_person_22_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_22_7_0(person_22_7_0):
    return dictionary_person_22_7_0[person_22_7_0]

dictionary_person_23_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_23_7_0(person_23_7_0):
    return dictionary_person_23_7_0[person_23_7_0]

dictionary_person_24_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_24_7_0(person_24_7_0):
    return dictionary_person_24_7_0[person_24_7_0]

dictionary_person_25_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_25_7_0(person_25_7_0):
    return dictionary_person_25_7_0[person_25_7_0]

dictionary_person_26_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_26_7_0(person_26_7_0):
    return dictionary_person_26_7_0[person_26_7_0]

dictionary_person_27_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_27_7_0(person_27_7_0):
    return dictionary_person_27_7_0[person_27_7_0]

dictionary_person_28_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_28_7_0(person_28_7_0):
    return dictionary_person_28_7_0[person_28_7_0]

dictionary_person_29_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_29_7_0(person_29_7_0):
    return dictionary_person_29_7_0[person_29_7_0]

dictionary_person_30_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_30_7_0(person_30_7_0):
    return dictionary_person_30_7_0[person_30_7_0]

dictionary_person_31_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_31_7_0(person_31_7_0):
    return dictionary_person_31_7_0[person_31_7_0]

dictionary_person_32_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_32_7_0(person_32_7_0):
    return dictionary_person_32_7_0[person_32_7_0]

dictionary_person_33_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_33_7_0(person_33_7_0):
    return dictionary_person_33_7_0[person_33_7_0]

dictionary_person_34_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_34_7_0(person_34_7_0):
    return dictionary_person_34_7_0[person_34_7_0]

dictionary_person_35_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_35_7_0(person_35_7_0):
    return dictionary_person_35_7_0[person_35_7_0]

dictionary_risk_0_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_8_0(risk_0_8_0):
    return dictionary_risk_0_8_0[risk_0_8_0]

dictionary_risk_1_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_8_0(risk_1_8_0):
    return dictionary_risk_1_8_0[risk_1_8_0]

dictionary_risk_2_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_8_0(risk_2_8_0):
    return dictionary_risk_2_8_0[risk_2_8_0]

dictionary_risk_3_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_8_0(risk_3_8_0):
    return dictionary_risk_3_8_0[risk_3_8_0]

dictionary_risk_4_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_8_0(risk_4_8_0):
    return dictionary_risk_4_8_0[risk_4_8_0]

dictionary_risk_5_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_8_0(risk_5_8_0):
    return dictionary_risk_5_8_0[risk_5_8_0]

dictionary_risk_6_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_8_0(risk_6_8_0):
    return dictionary_risk_6_8_0[risk_6_8_0]

dictionary_risk_7_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_8_0(risk_7_8_0):
    return dictionary_risk_7_8_0[risk_7_8_0]

dictionary_risk_8_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_8_0(risk_8_8_0):
    return dictionary_risk_8_8_0[risk_8_8_0]

dictionary_risk_9_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_8_0(risk_9_8_0):
    return dictionary_risk_9_8_0[risk_9_8_0]

dictionary_risk_10_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_8_0(risk_10_8_0):
    return dictionary_risk_10_8_0[risk_10_8_0]

dictionary_risk_11_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_8_0(risk_11_8_0):
    return dictionary_risk_11_8_0[risk_11_8_0]

dictionary_risk_12_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_8_0(risk_12_8_0):
    return dictionary_risk_12_8_0[risk_12_8_0]

dictionary_risk_13_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_8_0(risk_13_8_0):
    return dictionary_risk_13_8_0[risk_13_8_0]

dictionary_risk_14_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_8_0(risk_14_8_0):
    return dictionary_risk_14_8_0[risk_14_8_0]

dictionary_risk_15_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_8_0(risk_15_8_0):
    return dictionary_risk_15_8_0[risk_15_8_0]

dictionary_risk_16_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_8_0(risk_16_8_0):
    return dictionary_risk_16_8_0[risk_16_8_0]

dictionary_risk_17_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_8_0(risk_17_8_0):
    return dictionary_risk_17_8_0[risk_17_8_0]

dictionary_risk_18_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_8_0(risk_18_8_0):
    return dictionary_risk_18_8_0[risk_18_8_0]

dictionary_risk_19_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_8_0(risk_19_8_0):
    return dictionary_risk_19_8_0[risk_19_8_0]

dictionary_risk_20_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_8_0(risk_20_8_0):
    return dictionary_risk_20_8_0[risk_20_8_0]

dictionary_risk_21_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_8_0(risk_21_8_0):
    return dictionary_risk_21_8_0[risk_21_8_0]

dictionary_risk_22_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_8_0(risk_22_8_0):
    return dictionary_risk_22_8_0[risk_22_8_0]

dictionary_risk_23_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_8_0(risk_23_8_0):
    return dictionary_risk_23_8_0[risk_23_8_0]

dictionary_risk_24_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_8_0(risk_24_8_0):
    return dictionary_risk_24_8_0[risk_24_8_0]

dictionary_risk_25_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_8_0(risk_25_8_0):
    return dictionary_risk_25_8_0[risk_25_8_0]

dictionary_risk_25_8_1 = {'true': 1.0, 'false': 0.0}

def f_risk_25_8_1(risk_25_8_1):
    return dictionary_risk_25_8_1[risk_25_8_1]

dictionary_risk_26_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_8_0(risk_26_8_0):
    return dictionary_risk_26_8_0[risk_26_8_0]

dictionary_risk_27_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_8_0(risk_27_8_0):
    return dictionary_risk_27_8_0[risk_27_8_0]

dictionary_risk_28_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_8_0(risk_28_8_0):
    return dictionary_risk_28_8_0[risk_28_8_0]

dictionary_risk_29_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_8_0(risk_29_8_0):
    return dictionary_risk_29_8_0[risk_29_8_0]

dictionary_risk_30_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_8_0(risk_30_8_0):
    return dictionary_risk_30_8_0[risk_30_8_0]

dictionary_risk_31_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_8_0(risk_31_8_0):
    return dictionary_risk_31_8_0[risk_31_8_0]

dictionary_risk_32_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_8_0(risk_32_8_0):
    return dictionary_risk_32_8_0[risk_32_8_0]

dictionary_risk_33_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_8_0(risk_33_8_0):
    return dictionary_risk_33_8_0[risk_33_8_0]

dictionary_risk_34_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_8_0(risk_34_8_0):
    return dictionary_risk_34_8_0[risk_34_8_0]

dictionary_risk_35_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_8_0(risk_35_8_0):
    return dictionary_risk_35_8_0[risk_35_8_0]

dictionary_risk_0_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_9_0(risk_0_9_0):
    return dictionary_risk_0_9_0[risk_0_9_0]

dictionary_risk_1_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_9_0(risk_1_9_0):
    return dictionary_risk_1_9_0[risk_1_9_0]

dictionary_risk_2_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_9_0(risk_2_9_0):
    return dictionary_risk_2_9_0[risk_2_9_0]

dictionary_risk_3_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_9_0(risk_3_9_0):
    return dictionary_risk_3_9_0[risk_3_9_0]

dictionary_risk_4_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_9_0(risk_4_9_0):
    return dictionary_risk_4_9_0[risk_4_9_0]

dictionary_risk_5_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_9_0(risk_5_9_0):
    return dictionary_risk_5_9_0[risk_5_9_0]

dictionary_risk_6_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_9_0(risk_6_9_0):
    return dictionary_risk_6_9_0[risk_6_9_0]

dictionary_risk_7_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_9_0(risk_7_9_0):
    return dictionary_risk_7_9_0[risk_7_9_0]

dictionary_risk_8_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_9_0(risk_8_9_0):
    return dictionary_risk_8_9_0[risk_8_9_0]

dictionary_risk_9_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_9_0(risk_9_9_0):
    return dictionary_risk_9_9_0[risk_9_9_0]

dictionary_risk_10_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_9_0(risk_10_9_0):
    return dictionary_risk_10_9_0[risk_10_9_0]

dictionary_risk_11_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_9_0(risk_11_9_0):
    return dictionary_risk_11_9_0[risk_11_9_0]

dictionary_risk_12_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_9_0(risk_12_9_0):
    return dictionary_risk_12_9_0[risk_12_9_0]

dictionary_risk_13_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_9_0(risk_13_9_0):
    return dictionary_risk_13_9_0[risk_13_9_0]

dictionary_risk_14_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_9_0(risk_14_9_0):
    return dictionary_risk_14_9_0[risk_14_9_0]

dictionary_risk_15_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_9_0(risk_15_9_0):
    return dictionary_risk_15_9_0[risk_15_9_0]

dictionary_risk_16_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_9_0(risk_16_9_0):
    return dictionary_risk_16_9_0[risk_16_9_0]

dictionary_risk_17_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_9_0(risk_17_9_0):
    return dictionary_risk_17_9_0[risk_17_9_0]

dictionary_risk_18_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_9_0(risk_18_9_0):
    return dictionary_risk_18_9_0[risk_18_9_0]

dictionary_risk_19_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_9_0(risk_19_9_0):
    return dictionary_risk_19_9_0[risk_19_9_0]

dictionary_risk_20_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_9_0(risk_20_9_0):
    return dictionary_risk_20_9_0[risk_20_9_0]

dictionary_risk_20_9_1 = {'true': 1.0, 'false': 0.0}

def f_risk_20_9_1(risk_20_9_1):
    return dictionary_risk_20_9_1[risk_20_9_1]

dictionary_risk_21_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_9_0(risk_21_9_0):
    return dictionary_risk_21_9_0[risk_21_9_0]

dictionary_risk_22_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_9_0(risk_22_9_0):
    return dictionary_risk_22_9_0[risk_22_9_0]

dictionary_risk_23_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_9_0(risk_23_9_0):
    return dictionary_risk_23_9_0[risk_23_9_0]

dictionary_risk_24_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_9_0(risk_24_9_0):
    return dictionary_risk_24_9_0[risk_24_9_0]

dictionary_risk_25_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_9_0(risk_25_9_0):
    return dictionary_risk_25_9_0[risk_25_9_0]

dictionary_risk_26_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_9_0(risk_26_9_0):
    return dictionary_risk_26_9_0[risk_26_9_0]

dictionary_risk_27_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_9_0(risk_27_9_0):
    return dictionary_risk_27_9_0[risk_27_9_0]

dictionary_risk_28_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_9_0(risk_28_9_0):
    return dictionary_risk_28_9_0[risk_28_9_0]

dictionary_risk_29_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_9_0(risk_29_9_0):
    return dictionary_risk_29_9_0[risk_29_9_0]

dictionary_risk_30_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_9_0(risk_30_9_0):
    return dictionary_risk_30_9_0[risk_30_9_0]

dictionary_risk_31_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_9_0(risk_31_9_0):
    return dictionary_risk_31_9_0[risk_31_9_0]

dictionary_risk_32_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_9_0(risk_32_9_0):
    return dictionary_risk_32_9_0[risk_32_9_0]

dictionary_risk_33_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_9_0(risk_33_9_0):
    return dictionary_risk_33_9_0[risk_33_9_0]

dictionary_risk_34_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_9_0(risk_34_9_0):
    return dictionary_risk_34_9_0[risk_34_9_0]

dictionary_risk_35_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_9_0(risk_35_9_0):
    return dictionary_risk_35_9_0[risk_35_9_0]

dictionary_risk_0_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_10_0(risk_0_10_0):
    return dictionary_risk_0_10_0[risk_0_10_0]

dictionary_risk_1_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_10_0(risk_1_10_0):
    return dictionary_risk_1_10_0[risk_1_10_0]

dictionary_risk_2_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_10_0(risk_2_10_0):
    return dictionary_risk_2_10_0[risk_2_10_0]

dictionary_risk_3_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_10_0(risk_3_10_0):
    return dictionary_risk_3_10_0[risk_3_10_0]

dictionary_risk_4_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_10_0(risk_4_10_0):
    return dictionary_risk_4_10_0[risk_4_10_0]

dictionary_risk_5_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_10_0(risk_5_10_0):
    return dictionary_risk_5_10_0[risk_5_10_0]

dictionary_risk_6_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_10_0(risk_6_10_0):
    return dictionary_risk_6_10_0[risk_6_10_0]

dictionary_risk_7_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_10_0(risk_7_10_0):
    return dictionary_risk_7_10_0[risk_7_10_0]

dictionary_risk_8_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_10_0(risk_8_10_0):
    return dictionary_risk_8_10_0[risk_8_10_0]

dictionary_risk_9_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_10_0(risk_9_10_0):
    return dictionary_risk_9_10_0[risk_9_10_0]

dictionary_risk_10_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_10_0(risk_10_10_0):
    return dictionary_risk_10_10_0[risk_10_10_0]

dictionary_risk_11_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_10_0(risk_11_10_0):
    return dictionary_risk_11_10_0[risk_11_10_0]

dictionary_risk_12_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_10_0(risk_12_10_0):
    return dictionary_risk_12_10_0[risk_12_10_0]

dictionary_risk_13_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_10_0(risk_13_10_0):
    return dictionary_risk_13_10_0[risk_13_10_0]

dictionary_risk_14_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_10_0(risk_14_10_0):
    return dictionary_risk_14_10_0[risk_14_10_0]

dictionary_risk_15_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_10_0(risk_15_10_0):
    return dictionary_risk_15_10_0[risk_15_10_0]

dictionary_risk_16_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_10_0(risk_16_10_0):
    return dictionary_risk_16_10_0[risk_16_10_0]

dictionary_risk_17_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_10_0(risk_17_10_0):
    return dictionary_risk_17_10_0[risk_17_10_0]

dictionary_risk_18_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_10_0(risk_18_10_0):
    return dictionary_risk_18_10_0[risk_18_10_0]

dictionary_risk_19_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_10_0(risk_19_10_0):
    return dictionary_risk_19_10_0[risk_19_10_0]

dictionary_risk_20_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_10_0(risk_20_10_0):
    return dictionary_risk_20_10_0[risk_20_10_0]

dictionary_risk_21_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_10_0(risk_21_10_0):
    return dictionary_risk_21_10_0[risk_21_10_0]

dictionary_risk_22_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_10_0(risk_22_10_0):
    return dictionary_risk_22_10_0[risk_22_10_0]

dictionary_risk_23_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_10_0(risk_23_10_0):
    return dictionary_risk_23_10_0[risk_23_10_0]

dictionary_risk_24_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_10_0(risk_24_10_0):
    return dictionary_risk_24_10_0[risk_24_10_0]

dictionary_risk_25_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_10_0(risk_25_10_0):
    return dictionary_risk_25_10_0[risk_25_10_0]

dictionary_risk_26_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_10_0(risk_26_10_0):
    return dictionary_risk_26_10_0[risk_26_10_0]

dictionary_risk_27_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_10_0(risk_27_10_0):
    return dictionary_risk_27_10_0[risk_27_10_0]

dictionary_risk_28_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_10_0(risk_28_10_0):
    return dictionary_risk_28_10_0[risk_28_10_0]

dictionary_risk_29_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_10_0(risk_29_10_0):
    return dictionary_risk_29_10_0[risk_29_10_0]

dictionary_risk_30_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_10_0(risk_30_10_0):
    return dictionary_risk_30_10_0[risk_30_10_0]

dictionary_risk_31_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_10_0(risk_31_10_0):
    return dictionary_risk_31_10_0[risk_31_10_0]

dictionary_risk_32_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_10_0(risk_32_10_0):
    return dictionary_risk_32_10_0[risk_32_10_0]

dictionary_risk_33_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_10_0(risk_33_10_0):
    return dictionary_risk_33_10_0[risk_33_10_0]

dictionary_risk_34_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_10_0(risk_34_10_0):
    return dictionary_risk_34_10_0[risk_34_10_0]

dictionary_risk_35_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_10_0(risk_35_10_0):
    return dictionary_risk_35_10_0[risk_35_10_0]

dictionary_observe_0_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8016602796708001, ('false', 'false'): 1.0, ('true', 'true'): 0.1983397203291999}
def f_observe_0_7_0(person_0_7_0, observe_0_7_0):
    return dictionary_observe_0_7_0[(person_0_7_0, observe_0_7_0)]

dictionary_observe_1_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4995311962708855, ('false', 'false'): 1.0, ('true', 'true'): 0.5004688037291145}
def f_observe_1_7_0(person_1_7_0, observe_1_7_0):
    return dictionary_observe_1_7_0[(person_1_7_0, observe_1_7_0)]

dictionary_observe_2_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7714588370939996, ('false', 'false'): 1.0, ('true', 'true'): 0.22854116290600035}
def f_observe_2_7_0(person_2_7_0, observe_2_7_0):
    return dictionary_observe_2_7_0[(person_2_7_0, observe_2_7_0)]

dictionary_observe_3_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8206144354062549, ('false', 'false'): 1.0, ('true', 'true'): 0.1793855645937451}
def f_observe_3_7_0(person_3_7_0, observe_3_7_0):
    return dictionary_observe_3_7_0[(person_3_7_0, observe_3_7_0)]

dictionary_observe_4_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4957242016881429, ('false', 'false'): 1.0, ('true', 'true'): 0.5042757983118571}
def f_observe_4_7_0(person_4_7_0, observe_4_7_0):
    return dictionary_observe_4_7_0[(person_4_7_0, observe_4_7_0)]

dictionary_observe_5_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7862858314966115, ('false', 'false'): 1.0, ('true', 'true'): 0.21371416850338854}
def f_observe_5_7_0(person_5_7_0, observe_5_7_0):
    return dictionary_observe_5_7_0[(person_5_7_0, observe_5_7_0)]

dictionary_observe_6_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5310408240832099, ('false', 'false'): 1.0, ('true', 'true'): 0.46895917591679015}
def f_observe_6_7_0(person_6_7_0, observe_6_7_0):
    return dictionary_observe_6_7_0[(person_6_7_0, observe_6_7_0)]

dictionary_observe_7_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8188227053850159, ('false', 'false'): 1.0, ('true', 'true'): 0.1811772946149841}
def f_observe_7_7_0(person_7_7_0, observe_7_7_0):
    return dictionary_observe_7_7_0[(person_7_7_0, observe_7_7_0)]

dictionary_observe_8_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7880490883602209, ('false', 'false'): 1.0, ('true', 'true'): 0.21195091163977908}
def f_observe_8_7_0(person_8_7_0, observe_8_7_0):
    return dictionary_observe_8_7_0[(person_8_7_0, observe_8_7_0)]

dictionary_observe_9_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.47702474584661336, ('false', 'false'): 1.0, ('true', 'true'): 0.5229752541533866}
def f_observe_9_7_0(person_9_7_0, observe_9_7_0):
    return dictionary_observe_9_7_0[(person_9_7_0, observe_9_7_0)]

dictionary_observe_10_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4418706104523159, ('false', 'false'): 1.0, ('true', 'true'): 0.5581293895476841}
def f_observe_10_7_0(person_10_7_0, observe_10_7_0):
    return dictionary_observe_10_7_0[(person_10_7_0, observe_10_7_0)]

dictionary_observe_11_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6422923826611944, ('false', 'false'): 1.0, ('true', 'true'): 0.35770761733880563}
def f_observe_11_7_0(person_11_7_0, observe_11_7_0):
    return dictionary_observe_11_7_0[(person_11_7_0, observe_11_7_0)]

dictionary_observe_12_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9975508365423409, ('false', 'false'): 1.0, ('true', 'true'): 0.0024491634576591093}
def f_observe_12_7_0(person_12_7_0, observe_12_7_0):
    return dictionary_observe_12_7_0[(person_12_7_0, observe_12_7_0)]

dictionary_observe_13_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8358942840590609, ('false', 'false'): 1.0, ('true', 'true'): 0.16410571594093915}
def f_observe_13_7_0(person_13_7_0, observe_13_7_0):
    return dictionary_observe_13_7_0[(person_13_7_0, observe_13_7_0)]

dictionary_observe_14_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.40036221749524326, ('false', 'false'): 1.0, ('true', 'true'): 0.5996377825047567}
def f_observe_14_7_0(person_14_7_0, observe_14_7_0):
    return dictionary_observe_14_7_0[(person_14_7_0, observe_14_7_0)]

dictionary_observe_15_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6322673942768832, ('false', 'false'): 1.0, ('true', 'true'): 0.36773260572311683}
def f_observe_15_7_0(person_15_7_0, observe_15_7_0):
    return dictionary_observe_15_7_0[(person_15_7_0, observe_15_7_0)]

dictionary_observe_16_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.430812212134689, ('false', 'false'): 1.0, ('true', 'true'): 0.569187787865311}
def f_observe_16_7_0(person_16_7_0, observe_16_7_0):
    return dictionary_observe_16_7_0[(person_16_7_0, observe_16_7_0)]

dictionary_observe_17_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.48319364445114477, ('false', 'false'): 1.0, ('true', 'true'): 0.5168063555488552}
def f_observe_17_7_0(person_17_7_0, observe_17_7_0):
    return dictionary_observe_17_7_0[(person_17_7_0, observe_17_7_0)]

dictionary_observe_18_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5741994356353406, ('false', 'false'): 1.0, ('true', 'true'): 0.4258005643646594}
def f_observe_18_7_0(person_18_7_0, observe_18_7_0):
    return dictionary_observe_18_7_0[(person_18_7_0, observe_18_7_0)]

dictionary_observe_19_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.41769664976785104, ('false', 'false'): 1.0, ('true', 'true'): 0.582303350232149}
def f_observe_19_7_0(person_19_7_0, observe_19_7_0):
    return dictionary_observe_19_7_0[(person_19_7_0, observe_19_7_0)]

dictionary_observe_20_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9045620672594107, ('false', 'false'): 1.0, ('true', 'true'): 0.09543793274058932}
def f_observe_20_7_0(person_20_7_0, observe_20_7_0):
    return dictionary_observe_20_7_0[(person_20_7_0, observe_20_7_0)]

dictionary_observe_21_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6325025842106269, ('false', 'false'): 1.0, ('true', 'true'): 0.3674974157893731}
def f_observe_21_7_0(person_21_7_0, observe_21_7_0):
    return dictionary_observe_21_7_0[(person_21_7_0, observe_21_7_0)]

dictionary_observe_22_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6728619275862441, ('false', 'false'): 1.0, ('true', 'true'): 0.3271380724137559}
def f_observe_22_7_0(person_22_7_0, observe_22_7_0):
    return dictionary_observe_22_7_0[(person_22_7_0, observe_22_7_0)]

dictionary_observe_23_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.937908603940407, ('false', 'false'): 1.0, ('true', 'true'): 0.06209139605959302}
def f_observe_23_7_0(person_23_7_0, observe_23_7_0):
    return dictionary_observe_23_7_0[(person_23_7_0, observe_23_7_0)]

dictionary_observe_24_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4392483260524991, ('false', 'false'): 1.0, ('true', 'true'): 0.5607516739475009}
def f_observe_24_7_0(person_24_7_0, observe_24_7_0):
    return dictionary_observe_24_7_0[(person_24_7_0, observe_24_7_0)]

dictionary_observe_25_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9739028452459555, ('false', 'false'): 1.0, ('true', 'true'): 0.026097154754044505}
def f_observe_25_7_0(person_25_7_0, observe_25_7_0):
    return dictionary_observe_25_7_0[(person_25_7_0, observe_25_7_0)]

dictionary_observe_26_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7392450934220287, ('false', 'false'): 1.0, ('true', 'true'): 0.2607549065779713}
def f_observe_26_7_0(person_26_7_0, observe_26_7_0):
    return dictionary_observe_26_7_0[(person_26_7_0, observe_26_7_0)]

dictionary_observe_27_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8613795782047917, ('false', 'false'): 1.0, ('true', 'true'): 0.13862042179520828}
def f_observe_27_7_0(person_27_7_0, observe_27_7_0):
    return dictionary_observe_27_7_0[(person_27_7_0, observe_27_7_0)]

dictionary_observe_28_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6237047882443251, ('false', 'false'): 1.0, ('true', 'true'): 0.37629521175567493}
def f_observe_28_7_0(person_28_7_0, observe_28_7_0):
    return dictionary_observe_28_7_0[(person_28_7_0, observe_28_7_0)]

dictionary_observe_29_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9032933497687781, ('false', 'false'): 1.0, ('true', 'true'): 0.09670665023122194}
def f_observe_29_7_0(person_29_7_0, observe_29_7_0):
    return dictionary_observe_29_7_0[(person_29_7_0, observe_29_7_0)]

dictionary_observe_30_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7623737199083901, ('false', 'false'): 1.0, ('true', 'true'): 0.2376262800916099}
def f_observe_30_7_0(person_30_7_0, observe_30_7_0):
    return dictionary_observe_30_7_0[(person_30_7_0, observe_30_7_0)]

dictionary_observe_31_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9005958359947471, ('false', 'false'): 1.0, ('true', 'true'): 0.09940416400525287}
def f_observe_31_7_0(person_31_7_0, observe_31_7_0):
    return dictionary_observe_31_7_0[(person_31_7_0, observe_31_7_0)]

dictionary_observe_32_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9509115672445276, ('false', 'false'): 1.0, ('true', 'true'): 0.049088432755472367}
def f_observe_32_7_0(person_32_7_0, observe_32_7_0):
    return dictionary_observe_32_7_0[(person_32_7_0, observe_32_7_0)]

dictionary_observe_33_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9977991432571084, ('false', 'false'): 1.0, ('true', 'true'): 0.0022008567428916104}
def f_observe_33_7_0(person_33_7_0, observe_33_7_0):
    return dictionary_observe_33_7_0[(person_33_7_0, observe_33_7_0)]

dictionary_observe_34_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6112093202175377, ('false', 'false'): 1.0, ('true', 'true'): 0.3887906797824623}
def f_observe_34_7_0(person_34_7_0, observe_34_7_0):
    return dictionary_observe_34_7_0[(person_34_7_0, observe_34_7_0)]

dictionary_observe_35_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7230093541587335, ('false', 'false'): 1.0, ('true', 'true'): 0.27699064584126654}
def f_observe_35_7_0(person_35_7_0, observe_35_7_0):
    return dictionary_observe_35_7_0[(person_35_7_0, observe_35_7_0)]

dictionary_person_0_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_0_8_0(person_0_7_0, risk_0_8_0, person_0_8_0):
    return dictionary_person_0_8_0[(person_0_7_0, risk_0_8_0, person_0_8_0)]

dictionary_observe_0_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.849259402053683, ('false', 'false'): 1.0, ('true', 'true'): 0.150740597946317}
def f_observe_0_8_0(person_0_8_0, observe_0_8_0):
    return dictionary_observe_0_8_0[(person_0_8_0, observe_0_8_0)]

dictionary_person_1_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_1_8_0(person_1_7_0, risk_1_8_0, person_1_8_0):
    return dictionary_person_1_8_0[(person_1_7_0, risk_1_8_0, person_1_8_0)]

dictionary_observe_1_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.44177592746552474, ('false', 'false'): 1.0, ('true', 'true'): 0.5582240725344753}
def f_observe_1_8_0(person_1_8_0, observe_1_8_0):
    return dictionary_observe_1_8_0[(person_1_8_0, observe_1_8_0)]

dictionary_person_2_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_2_8_0(person_2_7_0, risk_2_8_0, person_2_8_0):
    return dictionary_person_2_8_0[(person_2_7_0, risk_2_8_0, person_2_8_0)]

dictionary_observe_2_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9597438802728355, ('false', 'false'): 1.0, ('true', 'true'): 0.040256119727164474}
def f_observe_2_8_0(person_2_8_0, observe_2_8_0):
    return dictionary_observe_2_8_0[(person_2_8_0, observe_2_8_0)]

dictionary_person_3_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_3_8_0(person_3_7_0, risk_3_8_0, person_3_8_0):
    return dictionary_person_3_8_0[(person_3_7_0, risk_3_8_0, person_3_8_0)]

dictionary_observe_3_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9408035250229461, ('false', 'false'): 1.0, ('true', 'true'): 0.05919647497705394}
def f_observe_3_8_0(person_3_8_0, observe_3_8_0):
    return dictionary_observe_3_8_0[(person_3_8_0, observe_3_8_0)]

dictionary_person_4_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_8_0(person_4_7_0, risk_4_8_0, person_4_8_0):
    return dictionary_person_4_8_0[(person_4_7_0, risk_4_8_0, person_4_8_0)]

dictionary_observe_4_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5088940203873237, ('false', 'false'): 1.0, ('true', 'true'): 0.4911059796126763}
def f_observe_4_8_0(person_4_8_0, observe_4_8_0):
    return dictionary_observe_4_8_0[(person_4_8_0, observe_4_8_0)]

dictionary_person_5_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_5_8_0(person_5_7_0, risk_5_8_0, person_5_8_0):
    return dictionary_person_5_8_0[(person_5_7_0, risk_5_8_0, person_5_8_0)]

dictionary_observe_5_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7878691886025331, ('false', 'false'): 1.0, ('true', 'true'): 0.21213081139746692}
def f_observe_5_8_0(person_5_8_0, observe_5_8_0):
    return dictionary_observe_5_8_0[(person_5_8_0, observe_5_8_0)]

dictionary_person_6_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7416103984074748, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2583896015925252, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7408687880090673, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2591312119909327, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_6_8_0(person_6_7_0, person_0_7_0, risk_6_8_0, person_6_8_0):
    return dictionary_person_6_8_0[(person_6_7_0, person_0_7_0, risk_6_8_0, person_6_8_0)]

dictionary_observe_6_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6198196404652424, ('false', 'false'): 1.0, ('true', 'true'): 0.3801803595347576}
def f_observe_6_8_0(person_6_8_0, observe_6_8_0):
    return dictionary_observe_6_8_0[(person_6_8_0, observe_6_8_0)]

dictionary_person_7_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_7_8_0(person_7_7_0, risk_7_8_0, person_7_8_0):
    return dictionary_person_7_8_0[(person_7_7_0, risk_7_8_0, person_7_8_0)]

dictionary_observe_7_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.694809090844348, ('false', 'false'): 1.0, ('true', 'true'): 0.30519090915565195}
def f_observe_7_8_0(person_7_8_0, observe_7_8_0):
    return dictionary_observe_7_8_0[(person_7_8_0, observe_7_8_0)]

dictionary_person_8_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_8_8_0(person_8_7_0, risk_8_8_0, person_8_8_0):
    return dictionary_person_8_8_0[(person_8_7_0, risk_8_8_0, person_8_8_0)]

dictionary_observe_8_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6461935220356253, ('false', 'false'): 1.0, ('true', 'true'): 0.3538064779643747}
def f_observe_8_8_0(person_8_8_0, observe_8_8_0):
    return dictionary_observe_8_8_0[(person_8_8_0, observe_8_8_0)]

dictionary_person_9_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_9_8_0(person_9_7_0, risk_9_8_0, person_9_8_0):
    return dictionary_person_9_8_0[(person_9_7_0, risk_9_8_0, person_9_8_0)]

dictionary_observe_9_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6819028056837366, ('false', 'false'): 1.0, ('true', 'true'): 0.3180971943162634}
def f_observe_9_8_0(person_9_8_0, observe_9_8_0):
    return dictionary_observe_9_8_0[(person_9_8_0, observe_9_8_0)]

dictionary_person_10_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.5359301638873691, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5894121660797438, ('false', 'false', 'true', 'false', 'false'): 0.8856400497731527, ('false', 'true', 'false', 'true', 'true'): 0.5363942337234817, ('false', 'false', 'true', 'false', 'true'): 0.1143599502268473, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.4636057662765182, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8847544097233795, ('false', 'true', 'true', 'false', 'true'): 0.5890011672469908, ('false', 'true', 'true', 'false', 'false'): 0.4109988327530092, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.11524559027662051, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.46406983611263086, ('false', 'true', 'true', 'true', 'false'): 0.41058783392025616}
def f_person_10_8_0(person_10_7_0, person_4_7_0, person_16_7_0, risk_10_8_0, person_10_8_0):
    return dictionary_person_10_8_0[(person_10_7_0, person_4_7_0, person_16_7_0, risk_10_8_0, person_10_8_0)]

dictionary_observe_10_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5070253711445761, ('false', 'false'): 1.0, ('true', 'true'): 0.49297462885542387}
def f_observe_10_8_0(person_10_8_0, observe_10_8_0):
    return dictionary_observe_10_8_0[(person_10_8_0, observe_10_8_0)]

dictionary_person_11_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_11_8_0(person_11_7_0, risk_11_8_0, person_11_8_0):
    return dictionary_person_11_8_0[(person_11_7_0, risk_11_8_0, person_11_8_0)]

dictionary_observe_11_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8467475090578028, ('false', 'false'): 1.0, ('true', 'true'): 0.15325249094219717}
def f_observe_11_8_0(person_11_8_0, observe_11_8_0):
    return dictionary_observe_11_8_0[(person_11_8_0, observe_11_8_0)]

dictionary_person_12_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_12_8_0(person_12_7_0, risk_12_8_0, person_12_8_0):
    return dictionary_person_12_8_0[(person_12_7_0, risk_12_8_0, person_12_8_0)]

dictionary_observe_12_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.40115966426481187, ('false', 'false'): 1.0, ('true', 'true'): 0.5988403357351881}
def f_observe_12_8_0(person_12_8_0, observe_12_8_0):
    return dictionary_observe_12_8_0[(person_12_8_0, observe_12_8_0)]

dictionary_person_13_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6936471897886793, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.30635281021132066, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6929535425988906, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.30704645740110936, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_13_8_0(person_13_7_0, person_14_7_0, risk_13_8_0, person_13_8_0):
    return dictionary_person_13_8_0[(person_13_7_0, person_14_7_0, risk_13_8_0, person_13_8_0)]

dictionary_observe_13_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5546531206017143, ('false', 'false'): 1.0, ('true', 'true'): 0.44534687939828566}
def f_observe_13_8_0(person_13_8_0, observe_13_8_0):
    return dictionary_observe_13_8_0[(person_13_8_0, observe_13_8_0)]

dictionary_person_14_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_14_8_0(person_14_7_0, risk_14_8_0, person_14_8_0):
    return dictionary_person_14_8_0[(person_14_7_0, risk_14_8_0, person_14_8_0)]

dictionary_observe_14_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6225914985957719, ('false', 'false'): 1.0, ('true', 'true'): 0.3774085014042281}
def f_observe_14_8_0(person_14_8_0, observe_14_8_0):
    return dictionary_observe_14_8_0[(person_14_8_0, observe_14_8_0)]

dictionary_person_15_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.755020447566434, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.24497955243356595, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7542654271188676, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.24573457288113243, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_15_8_0(person_15_7_0, person_21_7_0, risk_15_8_0, person_15_8_0):
    return dictionary_person_15_8_0[(person_15_7_0, person_21_7_0, risk_15_8_0, person_15_8_0)]

dictionary_observe_15_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6466521895948483, ('false', 'false'): 1.0, ('true', 'true'): 0.35334781040515173}
def f_observe_15_8_0(person_15_8_0, observe_15_8_0):
    return dictionary_observe_15_8_0[(person_15_8_0, observe_15_8_0)]

dictionary_person_16_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6939962201763086, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3060037798236914, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6933022239561323, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3066977760438677, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_16_8_0(person_16_7_0, person_17_7_0, risk_16_8_0, person_16_8_0):
    return dictionary_person_16_8_0[(person_16_7_0, person_17_7_0, risk_16_8_0, person_16_8_0)]

dictionary_observe_16_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7476940320848221, ('false', 'false'): 1.0, ('true', 'true'): 0.2523059679151779}
def f_observe_16_8_0(person_16_8_0, observe_16_8_0):
    return dictionary_observe_16_8_0[(person_16_8_0, observe_16_8_0)]

dictionary_person_17_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_17_8_0(person_17_7_0, risk_17_8_0, person_17_8_0):
    return dictionary_person_17_8_0[(person_17_7_0, risk_17_8_0, person_17_8_0)]

dictionary_observe_17_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8112183485333548, ('false', 'false'): 1.0, ('true', 'true'): 0.18878165146664516}
def f_observe_17_8_0(person_17_8_0, observe_17_8_0):
    return dictionary_observe_17_8_0[(person_17_8_0, observe_17_8_0)]

dictionary_person_18_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5248005510330824, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.47519944896691757, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5242757504820493, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.47572424951795067, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_18_8_0(person_18_7_0, person_24_7_0, risk_18_8_0, person_18_8_0):
    return dictionary_person_18_8_0[(person_18_7_0, person_24_7_0, risk_18_8_0, person_18_8_0)]

dictionary_observe_18_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6154513242526707, ('false', 'false'): 1.0, ('true', 'true'): 0.3845486757473293}
def f_observe_18_8_0(person_18_8_0, observe_18_8_0):
    return dictionary_observe_18_8_0[(person_18_8_0, observe_18_8_0)]

dictionary_person_19_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_19_8_0(person_19_7_0, risk_19_8_0, person_19_8_0):
    return dictionary_person_19_8_0[(person_19_7_0, risk_19_8_0, person_19_8_0)]

dictionary_observe_19_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6157869364234724, ('false', 'false'): 1.0, ('true', 'true'): 0.3842130635765276}
def f_observe_19_8_0(person_19_8_0, observe_19_8_0):
    return dictionary_observe_19_8_0[(person_19_8_0, observe_19_8_0)]

dictionary_person_20_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_20_8_0(person_20_7_0, risk_20_8_0, person_20_8_0):
    return dictionary_person_20_8_0[(person_20_7_0, risk_20_8_0, person_20_8_0)]

dictionary_observe_20_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8717902033866621, ('false', 'false'): 1.0, ('true', 'true'): 0.12820979661333787}
def f_observe_20_8_0(person_20_8_0, observe_20_8_0):
    return dictionary_observe_20_8_0[(person_20_8_0, observe_20_8_0)]

dictionary_person_21_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.72676981640281, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.27323018359719, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7260430465864072, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.27395695341359283, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_21_8_0(person_21_7_0, person_27_7_0, risk_21_8_0, person_21_8_0):
    return dictionary_person_21_8_0[(person_21_7_0, person_27_7_0, risk_21_8_0, person_21_8_0)]

dictionary_observe_21_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8441716732866993, ('false', 'false'): 1.0, ('true', 'true'): 0.1558283267133007}
def f_observe_21_8_0(person_21_8_0, observe_21_8_0):
    return dictionary_observe_21_8_0[(person_21_8_0, observe_21_8_0)]

dictionary_person_22_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_22_8_0(person_22_7_0, risk_22_8_0, person_22_8_0):
    return dictionary_person_22_8_0[(person_22_7_0, risk_22_8_0, person_22_8_0)]

dictionary_observe_22_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9991051187065605, ('false', 'false'): 1.0, ('true', 'true'): 0.000894881293439509}
def f_observe_22_8_0(person_22_8_0, observe_22_8_0):
    return dictionary_observe_22_8_0[(person_22_8_0, observe_22_8_0)]

dictionary_person_23_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6132634799831631, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3867365200168369, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.61265021650318, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.38734978349682003, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_23_8_0(person_23_7_0, person_17_7_0, risk_23_8_0, person_23_8_0):
    return dictionary_person_23_8_0[(person_23_7_0, person_17_7_0, risk_23_8_0, person_23_8_0)]

dictionary_observe_23_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7359710103229002, ('false', 'false'): 1.0, ('true', 'true'): 0.26402898967709976}
def f_observe_23_8_0(person_23_8_0, observe_23_8_0):
    return dictionary_observe_23_8_0[(person_23_8_0, observe_23_8_0)]

dictionary_person_24_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.634394085535348, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.36560591446465196, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6337596914498127, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3662403085501873, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_24_8_0(person_24_7_0, person_23_7_0, risk_24_8_0, person_24_8_0):
    return dictionary_person_24_8_0[(person_24_7_0, person_23_7_0, risk_24_8_0, person_24_8_0)]

dictionary_observe_24_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7020695717740486, ('false', 'false'): 1.0, ('true', 'true'): 0.2979304282259514}
def f_observe_24_8_0(person_24_8_0, observe_24_8_0):
    return dictionary_observe_24_8_0[(person_24_8_0, observe_24_8_0)]

dictionary_person_25_8_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.14525837585991985, ('false', 'true', 'false', 'false', 'false', 'true'): 0.5534596026306237, ('false', 'true', 'true', 'false', 'true', 'true'): 0.8545962203604406, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.1454037796395594, ('false', 'true', 'false', 'false', 'false', 'false'): 0.44654039736937634, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.40188635763243874, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.09999999999999998, ('false', 'false', 'false', 'false', 'true', 'false'): 0.9, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.6381967765809452, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.8547416241400801, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.838601804600089, ('false', 'false', 'true', 'false', 'false', 'false'): 0.3618032234190548, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.446093856972007, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.4014844712748063, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.553906143027993, ('false', 'false', 'false', 'true', 'false', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.5981136423675613, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.16139819539991093, ('false', 'false', 'true', 'false', 'true', 'false'): 0.3256229010771493, ('false', 'true', 'true', 'false', 'false', 'false'): 0.161559755155066, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.6385585798043643, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.5985155287251938, ('false', 'false', 'false', 'true', 'true', 'false'): 0.8991, ('false', 'false', 'false', 'true', 'false', 'false'): 0.999, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.36144142019563574, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.6747027218239279, ('false', 'false', 'true', 'false', 'true', 'true'): 0.6743770989228507, ('false', 'false', 'false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.838440244844934, ('false', 'false', 'true', 'true', 'true', 'false'): 0.3252972781760722}
def f_person_25_8_0(person_25_7_0, person_19_7_0, person_31_7_0, risk_25_8_0, risk_25_8_1, person_25_8_0):
    return dictionary_person_25_8_0[(person_25_7_0, person_19_7_0, person_31_7_0, risk_25_8_0, risk_25_8_1, person_25_8_0)]

dictionary_observe_25_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6740580685148878, ('false', 'false'): 1.0, ('true', 'true'): 0.3259419314851122}
def f_observe_25_8_0(person_25_8_0, observe_25_8_0):
    return dictionary_observe_25_8_0[(person_25_8_0, observe_25_8_0)]

dictionary_person_26_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5388564716307034, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4611435283692966, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5383176151590727, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4616823848409273, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_26_8_0(person_26_7_0, person_32_7_0, risk_26_8_0, person_26_8_0):
    return dictionary_person_26_8_0[(person_26_7_0, person_32_7_0, risk_26_8_0, person_26_8_0)]

dictionary_observe_26_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.47082787564418505, ('false', 'false'): 1.0, ('true', 'true'): 0.529172124355815}
def f_observe_26_8_0(person_26_8_0, observe_26_8_0):
    return dictionary_observe_26_8_0[(person_26_8_0, observe_26_8_0)]

dictionary_person_27_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_27_8_0(person_27_7_0, risk_27_8_0, person_27_8_0):
    return dictionary_person_27_8_0[(person_27_7_0, risk_27_8_0, person_27_8_0)]

dictionary_observe_27_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8162477677688162, ('false', 'false'): 1.0, ('true', 'true'): 0.18375223223118375}
def f_observe_27_8_0(person_27_8_0, observe_27_8_0):
    return dictionary_observe_27_8_0[(person_27_8_0, observe_27_8_0)]

dictionary_person_28_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_28_8_0(person_28_7_0, risk_28_8_0, person_28_8_0):
    return dictionary_person_28_8_0[(person_28_7_0, risk_28_8_0, person_28_8_0)]

dictionary_observe_28_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8926610729585038, ('false', 'false'): 1.0, ('true', 'true'): 0.10733892704149617}
def f_observe_28_8_0(person_28_8_0, observe_28_8_0):
    return dictionary_observe_28_8_0[(person_28_8_0, observe_28_8_0)]

dictionary_person_29_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_29_8_0(person_29_7_0, risk_29_8_0, person_29_8_0):
    return dictionary_person_29_8_0[(person_29_7_0, risk_29_8_0, person_29_8_0)]

dictionary_observe_29_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7172349029117384, ('false', 'false'): 1.0, ('true', 'true'): 0.2827650970882616}
def f_observe_29_8_0(person_29_8_0, observe_29_8_0):
    return dictionary_observe_29_8_0[(person_29_8_0, observe_29_8_0)]

dictionary_person_30_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5347396531300815, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.46526034686991846, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5342049134769514, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4657950865230486, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_30_8_0(person_30_7_0, person_29_7_0, risk_30_8_0, person_30_8_0):
    return dictionary_person_30_8_0[(person_30_7_0, person_29_7_0, risk_30_8_0, person_30_8_0)]

dictionary_observe_30_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.43322079277044234, ('false', 'false'): 1.0, ('true', 'true'): 0.5667792072295577}
def f_observe_30_8_0(person_30_8_0, observe_30_8_0):
    return dictionary_observe_30_8_0[(person_30_8_0, observe_30_8_0)]

dictionary_person_31_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_31_8_0(person_31_7_0, risk_31_8_0, person_31_8_0):
    return dictionary_person_31_8_0[(person_31_7_0, risk_31_8_0, person_31_8_0)]

dictionary_observe_31_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9368971217981781, ('false', 'false'): 1.0, ('true', 'true'): 0.06310287820182192}
def f_observe_31_8_0(person_31_8_0, observe_31_8_0):
    return dictionary_observe_31_8_0[(person_31_8_0, observe_31_8_0)]

dictionary_person_32_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7079884596331455, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2920115403668545, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7072804711735123, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.29271952882648766, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_32_8_0(person_32_7_0, person_33_7_0, risk_32_8_0, person_32_8_0):
    return dictionary_person_32_8_0[(person_32_7_0, person_33_7_0, risk_32_8_0, person_32_8_0)]

dictionary_observe_32_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5584245241452578, ('false', 'false'): 1.0, ('true', 'true'): 0.4415754758547422}
def f_observe_32_8_0(person_32_8_0, observe_32_8_0):
    return dictionary_observe_32_8_0[(person_32_8_0, observe_32_8_0)]

dictionary_person_33_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_33_8_0(person_33_7_0, risk_33_8_0, person_33_8_0):
    return dictionary_person_33_8_0[(person_33_7_0, risk_33_8_0, person_33_8_0)]

dictionary_observe_33_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5810562086895528, ('false', 'false'): 1.0, ('true', 'true'): 0.41894379131044723}
def f_observe_33_8_0(person_33_8_0, observe_33_8_0):
    return dictionary_observe_33_8_0[(person_33_8_0, observe_33_8_0)]

dictionary_person_34_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.39518304295126105, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6295041915590314, ('false', 'false', 'true', 'false', 'false'): 0.6131882891077713, ('false', 'true', 'false', 'true', 'true'): 0.3957878599083098, ('false', 'false', 'true', 'false', 'true'): 0.38681171089222866, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6042121400916902, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6125751008186636, ('false', 'true', 'true', 'false', 'true'): 0.6291333248839153, ('false', 'true', 'true', 'false', 'false'): 0.3708666751160847, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3874248991813364, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.604816957048739, ('false', 'true', 'true', 'true', 'false'): 0.3704958084409686}
def f_person_34_8_0(person_34_7_0, person_33_7_0, person_28_7_0, risk_34_8_0, person_34_8_0):
    return dictionary_person_34_8_0[(person_34_7_0, person_33_7_0, person_28_7_0, risk_34_8_0, person_34_8_0)]

dictionary_observe_34_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8181065557116968, ('false', 'false'): 1.0, ('true', 'true'): 0.18189344428830323}
def f_observe_34_8_0(person_34_8_0, observe_34_8_0):
    return dictionary_observe_34_8_0[(person_34_8_0, observe_34_8_0)]

dictionary_person_35_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_35_8_0(person_35_7_0, risk_35_8_0, person_35_8_0):
    return dictionary_person_35_8_0[(person_35_7_0, risk_35_8_0, person_35_8_0)]

dictionary_observe_35_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4707917667390964, ('false', 'false'): 1.0, ('true', 'true'): 0.5292082332609036}
def f_observe_35_8_0(person_35_8_0, observe_35_8_0):
    return dictionary_observe_35_8_0[(person_35_8_0, observe_35_8_0)]

dictionary_person_0_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.721430118506041, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.278569881493959, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.720708688387535, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.279291311612465, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_0_9_0(person_0_8_0, person_7_8_0, risk_0_9_0, person_0_9_0):
    return dictionary_person_0_9_0[(person_0_8_0, person_7_8_0, risk_0_9_0, person_0_9_0)]

dictionary_observe_0_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7591326592519827, ('false', 'false'): 1.0, ('true', 'true'): 0.2408673407480173}
def f_observe_0_9_0(person_0_9_0, observe_0_9_0):
    return dictionary_observe_0_9_0[(person_0_9_0, observe_0_9_0)]

dictionary_person_1_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4730527783764056, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5269472216235944, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4725797255980292, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5274202744019708, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_1_9_0(person_1_8_0, person_0_8_0, risk_1_9_0, person_1_9_0):
    return dictionary_person_1_9_0[(person_1_8_0, person_0_8_0, risk_1_9_0, person_1_9_0)]

dictionary_observe_1_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.510466772348982, ('false', 'false'): 1.0, ('true', 'true'): 0.48953322765101803}
def f_observe_1_9_0(person_1_9_0, observe_1_9_0):
    return dictionary_observe_1_9_0[(person_1_9_0, observe_1_9_0)]

dictionary_person_2_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_2_9_0(person_2_8_0, risk_2_9_0, person_2_9_0):
    return dictionary_person_2_9_0[(person_2_8_0, risk_2_9_0, person_2_9_0)]

dictionary_observe_2_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.40568672638757897, ('false', 'false'): 1.0, ('true', 'true'): 0.594313273612421}
def f_observe_2_9_0(person_2_9_0, observe_2_9_0):
    return dictionary_observe_2_9_0[(person_2_9_0, observe_2_9_0)]

dictionary_person_3_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5220408146609672, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4779591853390328, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5215187738463062, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4784812261536938, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_3_9_0(person_3_8_0, person_9_8_0, risk_3_9_0, person_3_9_0):
    return dictionary_person_3_9_0[(person_3_8_0, person_9_8_0, risk_3_9_0, person_3_9_0)]

dictionary_observe_3_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8759163538925326, ('false', 'false'): 1.0, ('true', 'true'): 0.12408364610746736}
def f_observe_3_9_0(person_3_9_0, observe_3_9_0):
    return dictionary_observe_3_9_0[(person_3_9_0, observe_3_9_0)]

dictionary_person_4_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_9_0(person_4_8_0, risk_4_9_0, person_4_9_0):
    return dictionary_person_4_9_0[(person_4_8_0, risk_4_9_0, person_4_9_0)]

dictionary_observe_4_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5945325333793536, ('false', 'false'): 1.0, ('true', 'true'): 0.40546746662064637}
def f_observe_4_9_0(person_4_9_0, observe_4_9_0):
    return dictionary_observe_4_9_0[(person_4_9_0, observe_4_9_0)]

dictionary_person_5_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_5_9_0(person_5_8_0, risk_5_9_0, person_5_9_0):
    return dictionary_person_5_9_0[(person_5_8_0, risk_5_9_0, person_5_9_0)]

dictionary_observe_5_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5288796346304205, ('false', 'false'): 1.0, ('true', 'true'): 0.47112036536957946}
def f_observe_5_9_0(person_5_9_0, observe_5_9_0):
    return dictionary_observe_5_9_0[(person_5_9_0, observe_5_9_0)]

dictionary_person_6_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_6_9_0(person_6_8_0, risk_6_9_0, person_6_9_0):
    return dictionary_person_6_9_0[(person_6_8_0, risk_6_9_0, person_6_9_0)]

dictionary_observe_6_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6735154007401152, ('false', 'false'): 1.0, ('true', 'true'): 0.3264845992598848}
def f_observe_6_9_0(person_6_9_0, observe_6_9_0):
    return dictionary_observe_6_9_0[(person_6_9_0, observe_6_9_0)]

dictionary_person_7_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_7_9_0(person_7_8_0, risk_7_9_0, person_7_9_0):
    return dictionary_person_7_9_0[(person_7_8_0, risk_7_9_0, person_7_9_0)]

dictionary_observe_7_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9129067188977615, ('false', 'false'): 1.0, ('true', 'true'): 0.08709328110223846}
def f_observe_7_9_0(person_7_9_0, observe_7_9_0):
    return dictionary_observe_7_9_0[(person_7_9_0, observe_7_9_0)]

dictionary_person_8_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_8_9_0(person_8_8_0, risk_8_9_0, person_8_9_0):
    return dictionary_person_8_9_0[(person_8_8_0, risk_8_9_0, person_8_9_0)]

dictionary_observe_8_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8777052306590664, ('false', 'false'): 1.0, ('true', 'true'): 0.12229476934093364}
def f_observe_8_9_0(person_8_9_0, observe_8_9_0):
    return dictionary_observe_8_9_0[(person_8_9_0, observe_8_9_0)]

dictionary_person_9_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.639961680524036, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.360038319475964, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.639321718843512, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.36067828115648803, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_9_9_0(person_9_8_0, person_8_8_0, risk_9_9_0, person_9_9_0):
    return dictionary_person_9_9_0[(person_9_8_0, person_8_8_0, risk_9_9_0, person_9_9_0)]

dictionary_observe_9_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6436930211712689, ('false', 'false'): 1.0, ('true', 'true'): 0.3563069788287311}
def f_observe_9_9_0(person_9_9_0, observe_9_9_0):
    return dictionary_observe_9_9_0[(person_9_9_0, observe_9_9_0)]

dictionary_person_10_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_10_9_0(person_10_8_0, risk_10_9_0, person_10_9_0):
    return dictionary_person_10_9_0[(person_10_8_0, risk_10_9_0, person_10_9_0)]

dictionary_observe_10_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.47620027144424026, ('false', 'false'): 1.0, ('true', 'true'): 0.5237997285557597}
def f_observe_10_9_0(person_10_9_0, observe_10_9_0):
    return dictionary_observe_10_9_0[(person_10_9_0, observe_10_9_0)]

dictionary_person_11_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_11_9_0(person_11_8_0, risk_11_9_0, person_11_9_0):
    return dictionary_person_11_9_0[(person_11_8_0, risk_11_9_0, person_11_9_0)]

dictionary_observe_11_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9452569330391838, ('false', 'false'): 1.0, ('true', 'true'): 0.05474306696081621}
def f_observe_11_9_0(person_11_9_0, observe_11_9_0):
    return dictionary_observe_11_9_0[(person_11_9_0, observe_11_9_0)]

dictionary_person_12_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_12_9_0(person_12_8_0, risk_12_9_0, person_12_9_0):
    return dictionary_person_12_9_0[(person_12_8_0, risk_12_9_0, person_12_9_0)]

dictionary_observe_12_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8279520872641133, ('false', 'false'): 1.0, ('true', 'true'): 0.1720479127358867}
def f_observe_12_9_0(person_12_9_0, observe_12_9_0):
    return dictionary_observe_12_9_0[(person_12_9_0, observe_12_9_0)]

dictionary_person_13_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5628968212615797, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4371031787384203, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5623339244403182, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.43766607555968184, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_13_9_0(person_13_8_0, person_19_8_0, risk_13_9_0, person_13_9_0):
    return dictionary_person_13_9_0[(person_13_8_0, person_19_8_0, risk_13_9_0, person_13_9_0)]

dictionary_observe_13_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8744352850141937, ('false', 'false'): 1.0, ('true', 'true'): 0.12556471498580635}
def f_observe_13_9_0(person_13_9_0, observe_13_9_0):
    return dictionary_observe_13_9_0[(person_13_9_0, observe_13_9_0)]

dictionary_person_14_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_14_9_0(person_14_8_0, risk_14_9_0, person_14_9_0):
    return dictionary_person_14_9_0[(person_14_8_0, risk_14_9_0, person_14_9_0)]

dictionary_observe_14_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5427050089472989, ('false', 'false'): 1.0, ('true', 'true'): 0.4572949910527011}
def f_observe_14_9_0(person_14_9_0, observe_14_9_0):
    return dictionary_observe_14_9_0[(person_14_9_0, observe_14_9_0)]

dictionary_person_15_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6253605329962799, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3746394670037201, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6247351724632836, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3752648275367164, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_15_9_0(person_15_8_0, person_9_8_0, risk_15_9_0, person_15_9_0):
    return dictionary_person_15_9_0[(person_15_8_0, person_9_8_0, risk_15_9_0, person_15_9_0)]

dictionary_observe_15_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.804790546147735, ('false', 'false'): 1.0, ('true', 'true'): 0.19520945385226496}
def f_observe_15_9_0(person_15_9_0, observe_15_9_0):
    return dictionary_observe_15_9_0[(person_15_9_0, observe_15_9_0)]

dictionary_person_16_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5733479682850926, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4266520317149074, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5727746203168075, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4272253796831925, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_16_9_0(person_16_8_0, person_17_8_0, risk_16_9_0, person_16_9_0):
    return dictionary_person_16_9_0[(person_16_8_0, person_17_8_0, risk_16_9_0, person_16_9_0)]

dictionary_observe_16_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6931443809552196, ('false', 'false'): 1.0, ('true', 'true'): 0.3068556190447804}
def f_observe_16_9_0(person_16_9_0, observe_16_9_0):
    return dictionary_observe_16_9_0[(person_16_9_0, observe_16_9_0)]

dictionary_person_17_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5160927723753743, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4839072276246257, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5155766796029989, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4844233203970011, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_17_9_0(person_17_8_0, person_18_8_0, risk_17_9_0, person_17_9_0):
    return dictionary_person_17_9_0[(person_17_8_0, person_18_8_0, risk_17_9_0, person_17_9_0)]

dictionary_observe_17_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9910232506637154, ('false', 'false'): 1.0, ('true', 'true'): 0.008976749336284562}
def f_observe_17_9_0(person_17_9_0, observe_17_9_0):
    return dictionary_observe_17_9_0[(person_17_9_0, observe_17_9_0)]

dictionary_person_18_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.5902416318147761, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7513206131174434, ('false', 'false', 'true', 'false', 'false'): 0.607500259970849, ('false', 'true', 'false', 'true', 'true'): 0.5906513901829613, ('false', 'false', 'true', 'false', 'true'): 0.392499740029151, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.4093486098170387, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6068927597108782, ('false', 'true', 'true', 'false', 'true'): 0.7510716848022456, ('false', 'true', 'true', 'false', 'false'): 0.2489283151977544, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3931072402891218, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.40975836818522393, ('false', 'true', 'true', 'true', 'false'): 0.24867938688255664}
def f_person_18_9_0(person_18_8_0, person_12_8_0, person_24_8_0, risk_18_9_0, person_18_9_0):
    return dictionary_person_18_9_0[(person_18_8_0, person_12_8_0, person_24_8_0, risk_18_9_0, person_18_9_0)]

dictionary_observe_18_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9743467774686461, ('false', 'false'): 1.0, ('true', 'true'): 0.025653222531353936}
def f_observe_18_9_0(person_18_9_0, observe_18_9_0):
    return dictionary_observe_18_9_0[(person_18_9_0, observe_18_9_0)]

dictionary_person_19_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.45098839496959475, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5490116050304052, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.45053740657462515, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5494625934253748, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_19_9_0(person_19_8_0, person_13_8_0, risk_19_9_0, person_19_9_0):
    return dictionary_person_19_9_0[(person_19_8_0, person_13_8_0, risk_19_9_0, person_19_9_0)]

dictionary_observe_19_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7849836616252792, ('false', 'false'): 1.0, ('true', 'true'): 0.21501633837472078}
def f_observe_19_9_0(person_19_9_0, observe_19_9_0):
    return dictionary_observe_19_9_0[(person_19_9_0, observe_19_9_0)]

dictionary_person_20_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3459460910350576, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.4119401304496202, ('false', 'false', 'true', 'false', 'false'): 0.999, ('false', 'true', 'false', 'true', 'true'): 0.4113514819315518, ('false', 'false', 'true', 'false', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.9, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5886485180684482, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8991, ('false', 'true', 'true', 'false', 'true'): 0.34660014494402247, ('false', 'true', 'true', 'false', 'false'): 0.6533998550559775, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.09999999999999998, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6540539089649424, ('false', 'true', 'true', 'true', 'false'): 0.5880598695503798}
def f_person_20_9_0(person_20_8_0, person_21_8_0, risk_20_9_0, risk_20_9_1, person_20_9_0):
    return dictionary_person_20_9_0[(person_20_8_0, person_21_8_0, risk_20_9_0, risk_20_9_1, person_20_9_0)]

dictionary_observe_20_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8566263998849921, ('false', 'false'): 1.0, ('true', 'true'): 0.14337360011500788}
def f_observe_20_9_0(person_20_9_0, observe_20_9_0):
    return dictionary_observe_20_9_0[(person_20_9_0, observe_20_9_0)]

dictionary_person_21_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5729173588802814, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4270826411197186, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5723444415214011, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.42765555847859893, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_21_9_0(person_21_8_0, person_9_8_0, risk_21_9_0, person_21_9_0):
    return dictionary_person_21_9_0[(person_21_8_0, person_9_8_0, risk_21_9_0, person_21_9_0)]

dictionary_observe_21_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6243762368485748, ('false', 'false'): 1.0, ('true', 'true'): 0.3756237631514252}
def f_observe_21_9_0(person_21_9_0, observe_21_9_0):
    return dictionary_observe_21_9_0[(person_21_9_0, observe_21_9_0)]

dictionary_person_22_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5610145317245001, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4389854682754999, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5604535171927756, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4395464828072244, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_22_9_0(person_22_8_0, person_20_8_0, risk_22_9_0, person_22_9_0):
    return dictionary_person_22_9_0[(person_22_8_0, person_20_8_0, risk_22_9_0, person_22_9_0)]

dictionary_observe_22_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7278711818247727, ('false', 'false'): 1.0, ('true', 'true'): 0.27212881817522727}
def f_observe_22_9_0(person_22_9_0, observe_22_9_0):
    return dictionary_observe_22_9_0[(person_22_9_0, observe_22_9_0)]

dictionary_person_23_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_23_9_0(person_23_8_0, risk_23_9_0, person_23_9_0):
    return dictionary_person_23_9_0[(person_23_8_0, risk_23_9_0, person_23_9_0)]

dictionary_observe_23_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6652507684963453, ('false', 'false'): 1.0, ('true', 'true'): 0.33474923150365465}
def f_observe_23_9_0(person_23_9_0, observe_23_9_0):
    return dictionary_observe_23_9_0[(person_23_9_0, observe_23_9_0)]

dictionary_person_24_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6496115043821331, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3503884956178669, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.648961892877751, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.35103810712224903, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_24_9_0(person_24_8_0, person_18_8_0, risk_24_9_0, person_24_9_0):
    return dictionary_person_24_9_0[(person_24_8_0, person_18_8_0, risk_24_9_0, person_24_9_0)]

dictionary_observe_24_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5714622909133534, ('false', 'false'): 1.0, ('true', 'true'): 0.42853770908664657}
def f_observe_24_9_0(person_24_9_0, observe_24_9_0):
    return dictionary_observe_24_9_0[(person_24_9_0, observe_24_9_0)]

dictionary_person_25_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6808839152810827, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3191160847189173, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6802030313658016, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3197969686341984, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_25_9_0(person_25_8_0, person_26_8_0, risk_25_9_0, person_25_9_0):
    return dictionary_person_25_9_0[(person_25_8_0, person_26_8_0, risk_25_9_0, person_25_9_0)]

dictionary_observe_25_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.879373837561227, ('false', 'false'): 1.0, ('true', 'true'): 0.120626162438773}
def f_observe_25_9_0(person_25_9_0, observe_25_9_0):
    return dictionary_observe_25_9_0[(person_25_9_0, observe_25_9_0)]

dictionary_person_26_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_26_9_0(person_26_8_0, risk_26_9_0, person_26_9_0):
    return dictionary_person_26_9_0[(person_26_8_0, risk_26_9_0, person_26_9_0)]

dictionary_observe_26_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.47587101388228525, ('false', 'false'): 1.0, ('true', 'true'): 0.5241289861177147}
def f_observe_26_9_0(person_26_9_0, observe_26_9_0):
    return dictionary_observe_26_9_0[(person_26_9_0, observe_26_9_0)]

dictionary_person_27_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_27_9_0(person_27_8_0, risk_27_9_0, person_27_9_0):
    return dictionary_person_27_9_0[(person_27_8_0, risk_27_9_0, person_27_9_0)]

dictionary_observe_27_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9875744233791348, ('false', 'false'): 1.0, ('true', 'true'): 0.012425576620865186}
def f_observe_27_9_0(person_27_9_0, observe_27_9_0):
    return dictionary_observe_27_9_0[(person_27_9_0, observe_27_9_0)]

dictionary_person_28_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_28_9_0(person_28_8_0, risk_28_9_0, person_28_9_0):
    return dictionary_person_28_9_0[(person_28_8_0, risk_28_9_0, person_28_9_0)]

dictionary_observe_28_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8220265756755494, ('false', 'false'): 1.0, ('true', 'true'): 0.17797342432445062}
def f_observe_28_9_0(person_28_9_0, observe_28_9_0):
    return dictionary_observe_28_9_0[(person_28_9_0, observe_28_9_0)]

dictionary_person_29_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_29_9_0(person_29_8_0, risk_29_9_0, person_29_9_0):
    return dictionary_person_29_9_0[(person_29_8_0, risk_29_9_0, person_29_9_0)]

dictionary_observe_29_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5501573943192408, ('false', 'false'): 1.0, ('true', 'true'): 0.4498426056807592}
def f_observe_29_9_0(person_29_9_0, observe_29_9_0):
    return dictionary_observe_29_9_0[(person_29_9_0, observe_29_9_0)]

dictionary_person_30_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_30_9_0(person_30_8_0, risk_30_9_0, person_30_9_0):
    return dictionary_person_30_9_0[(person_30_8_0, risk_30_9_0, person_30_9_0)]

dictionary_observe_30_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7445486689986336, ('false', 'false'): 1.0, ('true', 'true'): 0.2554513310013664}
def f_observe_30_9_0(person_30_9_0, observe_30_9_0):
    return dictionary_observe_30_9_0[(person_30_9_0, observe_30_9_0)]

dictionary_person_31_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5009924700143433, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4990075299856567, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.500491477544329, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.499508522455671, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_31_9_0(person_31_8_0, person_1_8_0, risk_31_9_0, person_31_9_0):
    return dictionary_person_31_9_0[(person_31_8_0, person_1_8_0, risk_31_9_0, person_31_9_0)]

dictionary_observe_31_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8854785901508214, ('false', 'false'): 1.0, ('true', 'true'): 0.11452140984917858}
def f_observe_31_9_0(person_31_9_0, observe_31_9_0):
    return dictionary_observe_31_9_0[(person_31_9_0, observe_31_9_0)]

dictionary_person_32_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_32_9_0(person_32_8_0, risk_32_9_0, person_32_9_0):
    return dictionary_person_32_9_0[(person_32_8_0, risk_32_9_0, person_32_9_0)]

dictionary_observe_32_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8129385534498034, ('false', 'false'): 1.0, ('true', 'true'): 0.18706144655019663}
def f_observe_32_9_0(person_32_9_0, observe_32_9_0):
    return dictionary_observe_32_9_0[(person_32_9_0, observe_32_9_0)]

dictionary_person_33_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_33_9_0(person_33_8_0, risk_33_9_0, person_33_9_0):
    return dictionary_person_33_9_0[(person_33_8_0, risk_33_9_0, person_33_9_0)]

dictionary_observe_33_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.43777528928870413, ('false', 'false'): 1.0, ('true', 'true'): 0.5622247107112959}
def f_observe_33_9_0(person_33_9_0, observe_33_9_0):
    return dictionary_observe_33_9_0[(person_33_9_0, observe_33_9_0)]

dictionary_person_34_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.3846208826923979, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.6153791173076021, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.3842362618097055, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.6157637381902945, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_34_9_0(person_34_8_0, person_35_8_0, risk_34_9_0, person_34_9_0):
    return dictionary_person_34_9_0[(person_34_8_0, person_35_8_0, risk_34_9_0, person_34_9_0)]

dictionary_observe_34_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.42882234420929666, ('false', 'false'): 1.0, ('true', 'true'): 0.5711776557907033}
def f_observe_34_9_0(person_34_9_0, observe_34_9_0):
    return dictionary_observe_34_9_0[(person_34_9_0, observe_34_9_0)]

dictionary_person_35_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.45437730670505805, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6814816012500884, ('false', 'false', 'true', 'false', 'false'): 0.5843547929806261, ('false', 'true', 'false', 'true', 'true'): 0.454922929398353, ('false', 'false', 'true', 'false', 'true'): 0.4156452070193739, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.545077070601647, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5837704381876455, ('false', 'true', 'true', 'false', 'true'): 0.6811627640141025, ('false', 'true', 'true', 'false', 'false'): 0.31883723598589747, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4162295618123545, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.545622693294942, ('false', 'true', 'true', 'true', 'false'): 0.31851839874991156}
def f_person_35_9_0(person_35_8_0, person_5_8_0, person_29_8_0, risk_35_9_0, person_35_9_0):
    return dictionary_person_35_9_0[(person_35_8_0, person_5_8_0, person_29_8_0, risk_35_9_0, person_35_9_0)]

dictionary_observe_35_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5653458205914236, ('false', 'false'): 1.0, ('true', 'true'): 0.4346541794085764}
def f_observe_35_9_0(person_35_9_0, observe_35_9_0):
    return dictionary_observe_35_9_0[(person_35_9_0, observe_35_9_0)]

dictionary_person_0_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_0_10_0(person_0_9_0, risk_0_10_0, person_0_10_0):
    return dictionary_person_0_10_0[(person_0_9_0, risk_0_10_0, person_0_10_0)]

dictionary_observe_0_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5088791955223043, ('false', 'false'): 1.0, ('true', 'true'): 0.4911208044776957}
def f_observe_0_10_0(person_0_10_0, observe_0_10_0):
    return dictionary_observe_0_10_0[(person_0_10_0, observe_0_10_0)]

dictionary_person_1_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5940339048674957, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.40596609513250426, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5934398709626283, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4065601290373717, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_1_10_0(person_1_9_0, person_7_9_0, risk_1_10_0, person_1_10_0):
    return dictionary_person_1_10_0[(person_1_9_0, person_7_9_0, risk_1_10_0, person_1_10_0)]

dictionary_observe_1_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6900807634450522, ('false', 'false'): 1.0, ('true', 'true'): 0.3099192365549478}
def f_observe_1_10_0(person_1_10_0, observe_1_10_0):
    return dictionary_observe_1_10_0[(person_1_10_0, observe_1_10_0)]

dictionary_person_2_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.4388763486587197, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6562260495042137, ('false', 'false', 'true', 'false', 'false'): 0.613266020317962, ('false', 'true', 'false', 'true', 'true'): 0.43943747231006103, ('false', 'false', 'true', 'false', 'true'): 0.38673397968203804, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.560562527689939, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.612652754297644, ('false', 'true', 'true', 'false', 'true'): 0.6558819314356494, ('false', 'true', 'true', 'false', 'false'): 0.3441180685643506, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.387347245702356, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5611236513412803, ('false', 'true', 'true', 'true', 'false'): 0.3437739504957863}
def f_person_2_10_0(person_2_9_0, person_31_9_0, person_1_9_0, risk_2_10_0, person_2_10_0):
    return dictionary_person_2_10_0[(person_2_9_0, person_31_9_0, person_1_9_0, risk_2_10_0, person_2_10_0)]

dictionary_observe_2_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5241674466631684, ('false', 'false'): 1.0, ('true', 'true'): 0.4758325533368316}
def f_observe_2_10_0(person_2_10_0, observe_2_10_0):
    return dictionary_observe_2_10_0[(person_2_10_0, observe_2_10_0)]

dictionary_person_3_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7620091903504389, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2379908096495611, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7612471811600885, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2387528188399115, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_3_10_0(person_3_9_0, person_2_9_0, risk_3_10_0, person_3_10_0):
    return dictionary_person_3_10_0[(person_3_9_0, person_2_9_0, risk_3_10_0, person_3_10_0)]

dictionary_observe_3_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4916500250201098, ('false', 'false'): 1.0, ('true', 'true'): 0.5083499749798902}
def f_observe_3_10_0(person_3_10_0, observe_3_10_0):
    return dictionary_observe_3_10_0[(person_3_10_0, observe_3_10_0)]

dictionary_person_4_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_10_0(person_4_9_0, risk_4_10_0, person_4_10_0):
    return dictionary_person_4_10_0[(person_4_9_0, risk_4_10_0, person_4_10_0)]

dictionary_observe_4_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7401409556261487, ('false', 'false'): 1.0, ('true', 'true'): 0.2598590443738513}
def f_observe_4_10_0(person_4_10_0, observe_4_10_0):
    return dictionary_observe_4_10_0[(person_4_10_0, observe_4_10_0)]

dictionary_person_5_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_5_10_0(person_5_9_0, risk_5_10_0, person_5_10_0):
    return dictionary_person_5_10_0[(person_5_9_0, risk_5_10_0, person_5_10_0)]

dictionary_observe_5_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8888264616061534, ('false', 'false'): 1.0, ('true', 'true'): 0.11117353839384658}
def f_observe_5_10_0(person_5_10_0, observe_5_10_0):
    return dictionary_observe_5_10_0[(person_5_10_0, observe_5_10_0)]

dictionary_person_6_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_6_10_0(person_6_9_0, risk_6_10_0, person_6_10_0):
    return dictionary_person_6_10_0[(person_6_9_0, risk_6_10_0, person_6_10_0)]

dictionary_observe_6_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8748826191928027, ('false', 'false'): 1.0, ('true', 'true'): 0.12511738080719725}
def f_observe_6_10_0(person_6_10_0, observe_6_10_0):
    return dictionary_observe_6_10_0[(person_6_10_0, observe_6_10_0)]

dictionary_person_7_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_7_10_0(person_7_9_0, risk_7_10_0, person_7_10_0):
    return dictionary_person_7_10_0[(person_7_9_0, risk_7_10_0, person_7_10_0)]

dictionary_observe_7_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6573321045642279, ('false', 'false'): 1.0, ('true', 'true'): 0.34266789543577214}
def f_observe_7_10_0(person_7_10_0, observe_7_10_0):
    return dictionary_observe_7_10_0[(person_7_10_0, observe_7_10_0)]

dictionary_person_8_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5802706993247326, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.41972930067526737, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5796904286254079, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.42030957137459213, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_8_10_0(person_8_9_0, person_14_9_0, risk_8_10_0, person_8_10_0):
    return dictionary_person_8_10_0[(person_8_9_0, person_14_9_0, risk_8_10_0, person_8_10_0)]

dictionary_observe_8_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6725496505246664, ('false', 'false'): 1.0, ('true', 'true'): 0.3274503494753336}
def f_observe_8_10_0(person_8_10_0, observe_8_10_0):
    return dictionary_observe_8_10_0[(person_8_10_0, observe_8_10_0)]

dictionary_person_9_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_9_10_0(person_9_9_0, risk_9_10_0, person_9_10_0):
    return dictionary_person_9_10_0[(person_9_9_0, risk_9_10_0, person_9_10_0)]

dictionary_observe_9_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7830845311658567, ('false', 'false'): 1.0, ('true', 'true'): 0.21691546883414325}
def f_observe_9_10_0(person_9_10_0, observe_9_10_0):
    return dictionary_observe_9_10_0[(person_9_10_0, observe_9_10_0)]

dictionary_person_10_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_10_10_0(person_10_9_0, risk_10_10_0, person_10_10_0):
    return dictionary_person_10_10_0[(person_10_9_0, risk_10_10_0, person_10_10_0)]

dictionary_observe_10_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4776799987171827, ('false', 'false'): 1.0, ('true', 'true'): 0.5223200012828173}
def f_observe_10_10_0(person_10_10_0, observe_10_10_0):
    return dictionary_observe_10_10_0[(person_10_10_0, observe_10_10_0)]

dictionary_person_11_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4967871657469788, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5032128342530212, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4962903785812318, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5037096214187682, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_11_10_0(person_11_9_0, person_5_9_0, risk_11_10_0, person_11_10_0):
    return dictionary_person_11_10_0[(person_11_9_0, person_5_9_0, risk_11_10_0, person_11_10_0)]

dictionary_observe_11_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.46533013584658467, ('false', 'false'): 1.0, ('true', 'true'): 0.5346698641534153}
def f_observe_11_10_0(person_11_10_0, observe_11_10_0):
    return dictionary_observe_11_10_0[(person_11_10_0, observe_11_10_0)]

dictionary_person_12_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_12_10_0(person_12_9_0, risk_12_10_0, person_12_10_0):
    return dictionary_person_12_10_0[(person_12_9_0, risk_12_10_0, person_12_10_0)]

dictionary_observe_12_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9599257574443695, ('false', 'false'): 1.0, ('true', 'true'): 0.040074242555630524}
def f_observe_12_10_0(person_12_10_0, observe_12_10_0):
    return dictionary_observe_12_10_0[(person_12_10_0, observe_12_10_0)]

dictionary_person_13_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_13_10_0(person_13_9_0, risk_13_10_0, person_13_10_0):
    return dictionary_person_13_10_0[(person_13_9_0, risk_13_10_0, person_13_10_0)]

dictionary_observe_13_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.47450146624445255, ('false', 'false'): 1.0, ('true', 'true'): 0.5254985337555474}
def f_observe_13_10_0(person_13_10_0, observe_13_10_0):
    return dictionary_observe_13_10_0[(person_13_10_0, observe_13_10_0)]

dictionary_person_14_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5472742063898844, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.45272579361011556, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5467269321834946, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.45327306781650545, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_14_10_0(person_14_9_0, person_15_9_0, risk_14_10_0, person_14_10_0):
    return dictionary_person_14_10_0[(person_14_9_0, person_15_9_0, risk_14_10_0, person_14_10_0)]

dictionary_observe_14_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.43530781075389535, ('false', 'false'): 1.0, ('true', 'true'): 0.5646921892461046}
def f_observe_14_10_0(person_14_10_0, observe_14_10_0):
    return dictionary_observe_14_10_0[(person_14_10_0, observe_14_10_0)]

dictionary_person_15_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_15_10_0(person_15_9_0, risk_15_10_0, person_15_10_0):
    return dictionary_person_15_10_0[(person_15_9_0, risk_15_10_0, person_15_10_0)]

dictionary_observe_15_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9858923233478158, ('false', 'false'): 1.0, ('true', 'true'): 0.014107676652184153}
def f_observe_15_10_0(person_15_10_0, observe_15_10_0):
    return dictionary_observe_15_10_0[(person_15_10_0, observe_15_10_0)]

dictionary_person_16_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.40734476841543366, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6587507209354426, ('false', 'false', 'true', 'false', 'false'): 0.5763736684162721, ('false', 'true', 'false', 'true', 'true'): 0.40793742364701824, ('false', 'false', 'true', 'false', 'true'): 0.42362633158372787, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5920625763529818, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5757972947478559, ('false', 'true', 'true', 'false', 'true'): 0.6584091300655082, ('false', 'true', 'true', 'false', 'false'): 0.34159086993449184, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4242027052521441, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5926552315845663, ('false', 'true', 'true', 'true', 'false'): 0.3412492790645573}
def f_person_16_10_0(person_16_9_0, person_17_9_0, person_10_9_0, risk_16_10_0, person_16_10_0):
    return dictionary_person_16_10_0[(person_16_9_0, person_17_9_0, person_10_9_0, risk_16_10_0, person_16_10_0)]

dictionary_observe_16_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9800850632970428, ('false', 'false'): 1.0, ('true', 'true'): 0.019914936702957187}
def f_observe_16_10_0(person_16_10_0, observe_16_10_0):
    return dictionary_observe_16_10_0[(person_16_10_0, observe_16_10_0)]

dictionary_person_17_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7016053803388552, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2983946196611448, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7009037749585164, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2990962250414836, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_17_10_0(person_17_9_0, person_19_9_0, risk_17_10_0, person_17_10_0):
    return dictionary_person_17_10_0[(person_17_9_0, person_19_9_0, risk_17_10_0, person_17_10_0)]

dictionary_observe_17_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9602446938806543, ('false', 'false'): 1.0, ('true', 'true'): 0.039755306119345746}
def f_observe_17_10_0(person_17_10_0, observe_17_10_0):
    return dictionary_observe_17_10_0[(person_17_10_0, observe_17_10_0)]

dictionary_person_18_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_18_10_0(person_18_9_0, risk_18_10_0, person_18_10_0):
    return dictionary_person_18_10_0[(person_18_9_0, risk_18_10_0, person_18_10_0)]

dictionary_observe_18_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.48333225718407014, ('false', 'false'): 1.0, ('true', 'true'): 0.5166677428159299}
def f_observe_18_10_0(person_18_10_0, observe_18_10_0):
    return dictionary_observe_18_10_0[(person_18_10_0, observe_18_10_0)]

dictionary_person_19_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7063602821043866, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2936397178956134, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7056539218222823, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.29434607817771774, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_19_10_0(person_19_9_0, person_25_9_0, risk_19_10_0, person_19_10_0):
    return dictionary_person_19_10_0[(person_19_9_0, person_25_9_0, risk_19_10_0, person_19_10_0)]

dictionary_observe_19_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8923408521515681, ('false', 'false'): 1.0, ('true', 'true'): 0.10765914784843189}
def f_observe_19_10_0(person_19_10_0, observe_19_10_0):
    return dictionary_observe_19_10_0[(person_19_10_0, observe_19_10_0)]

dictionary_person_20_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_20_10_0(person_20_9_0, risk_20_10_0, person_20_10_0):
    return dictionary_person_20_10_0[(person_20_9_0, risk_20_10_0, person_20_10_0)]

dictionary_observe_20_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7343199686186077, ('false', 'false'): 1.0, ('true', 'true'): 0.2656800313813923}
def f_observe_20_10_0(person_20_10_0, observe_20_10_0):
    return dictionary_observe_20_10_0[(person_20_10_0, observe_20_10_0)]

dictionary_person_21_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.4444556242586993, ('false', 'true', 'false', 'false', 'false', 'true'): 0.33772833273649416, ('false', 'true', 'true', 'false', 'true', 'true'): 0.44906473513556433, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.5509352648644357, ('false', 'true', 'false', 'false', 'false', 'false'): 0.6622716672635058, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.6616093955962423, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.16728016782782706, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.5555443757413008, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.5550994752165173, ('false', 'false', 'true', 'false', 'false', 'false'): 0.8327198321721729, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.5342739629761756, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.5337396890131993, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.4657260370238244, ('false', 'false', 'false', 'true', 'false', 'true'): 0.19327069330357183, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.3383906044037577, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.44490052478348274, ('false', 'false', 'true', 'false', 'true', 'false'): 0.8318871123400008, ('false', 'true', 'true', 'false', 'false', 'false'): 0.5514867516160518, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.3282205071193769, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.46626031098680065, ('false', 'false', 'false', 'true', 'true', 'false'): 0.8059225773897317, ('false', 'false', 'false', 'true', 'false', 'false'): 0.8067293066964282, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.6717794928806231, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.32889228661225756, ('false', 'false', 'true', 'false', 'true', 'true'): 0.1681128876599992, ('false', 'false', 'false', 'true', 'true', 'true'): 0.19407742261026828, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.44851324838394824, ('false', 'false', 'true', 'true', 'true', 'false'): 0.6711077133877424}
def f_person_21_10_0(person_21_9_0, person_15_9_0, person_20_9_0, person_33_9_0, risk_21_10_0, person_21_10_0):
    return dictionary_person_21_10_0[(person_21_9_0, person_15_9_0, person_20_9_0, person_33_9_0, risk_21_10_0, person_21_10_0)]

dictionary_observe_21_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6986947129056549, ('false', 'false'): 1.0, ('true', 'true'): 0.3013052870943451}
def f_observe_21_10_0(person_21_10_0, observe_21_10_0):
    return dictionary_observe_21_10_0[(person_21_10_0, observe_21_10_0)]

dictionary_person_22_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.501579426484285, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6646232546892799, ('false', 'false', 'true', 'false', 'false'): 0.6735525690692696, ('false', 'true', 'false', 'true', 'true'): 0.5020778470578007, ('false', 'false', 'true', 'false', 'true'): 0.32644743093073036, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.49792215294219927, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6728790165002003, ('false', 'true', 'true', 'false', 'true'): 0.6642875422315113, ('false', 'true', 'true', 'false', 'false'): 0.3357124577684886, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3271209834997997, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.498420573515715, ('false', 'true', 'true', 'true', 'false'): 0.33537674531072015}
def f_person_22_10_0(person_22_9_0, person_10_9_0, person_23_9_0, risk_22_10_0, person_22_10_0):
    return dictionary_person_22_10_0[(person_22_9_0, person_10_9_0, person_23_9_0, risk_22_10_0, person_22_10_0)]

dictionary_observe_22_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5907906300394092, ('false', 'false'): 1.0, ('true', 'true'): 0.40920936996059076}
def f_observe_22_10_0(person_22_10_0, observe_22_10_0):
    return dictionary_observe_22_10_0[(person_22_10_0, observe_22_10_0)]

dictionary_person_23_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_23_10_0(person_23_9_0, risk_23_10_0, person_23_10_0):
    return dictionary_person_23_10_0[(person_23_9_0, risk_23_10_0, person_23_10_0)]

dictionary_observe_23_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.865435991452531, ('false', 'false'): 1.0, ('true', 'true'): 0.13456400854746897}
def f_observe_23_10_0(person_23_10_0, observe_23_10_0):
    return dictionary_observe_23_10_0[(person_23_10_0, observe_23_10_0)]

dictionary_person_24_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.47339191375496625, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5266080862450337, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4729185218412113, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5270814781587887, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_24_10_0(person_24_9_0, person_18_9_0, risk_24_10_0, person_24_10_0):
    return dictionary_person_24_10_0[(person_24_9_0, person_18_9_0, risk_24_10_0, person_24_10_0)]

dictionary_observe_24_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4242243273852859, ('false', 'false'): 1.0, ('true', 'true'): 0.5757756726147141}
def f_observe_24_10_0(person_24_10_0, observe_24_10_0):
    return dictionary_observe_24_10_0[(person_24_10_0, observe_24_10_0)]

dictionary_person_25_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5001795508417266, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4998204491582734, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.49967937129088486, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5003206287091151, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_25_10_0(person_25_9_0, person_31_9_0, risk_25_10_0, person_25_10_0):
    return dictionary_person_25_10_0[(person_25_9_0, person_31_9_0, risk_25_10_0, person_25_10_0)]

dictionary_observe_25_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7274809799184407, ('false', 'false'): 1.0, ('true', 'true'): 0.27251902008155926}
def f_observe_25_10_0(person_25_10_0, observe_25_10_0):
    return dictionary_observe_25_10_0[(person_25_10_0, observe_25_10_0)]

dictionary_person_26_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_26_10_0(person_26_9_0, risk_26_10_0, person_26_10_0):
    return dictionary_person_26_10_0[(person_26_9_0, risk_26_10_0, person_26_10_0)]

dictionary_observe_26_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9881880617493528, ('false', 'false'): 1.0, ('true', 'true'): 0.011811938250647191}
def f_observe_26_10_0(person_26_10_0, observe_26_10_0):
    return dictionary_observe_26_10_0[(person_26_10_0, observe_26_10_0)]

dictionary_person_27_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.616567036273425, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.383432963726575, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6159504692371516, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3840495307628484, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_27_10_0(person_27_9_0, person_28_9_0, risk_27_10_0, person_27_10_0):
    return dictionary_person_27_10_0[(person_27_9_0, person_28_9_0, risk_27_10_0, person_27_10_0)]

dictionary_observe_27_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5000837685869688, ('false', 'false'): 1.0, ('true', 'true'): 0.4999162314130312}
def f_observe_27_10_0(person_27_10_0, observe_27_10_0):
    return dictionary_observe_27_10_0[(person_27_10_0, observe_27_10_0)]

dictionary_person_28_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.44227144581729716, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5577285541827028, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.44182917437147984, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5581708256285202, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_28_10_0(person_28_9_0, person_27_9_0, risk_28_10_0, person_28_10_0):
    return dictionary_person_28_10_0[(person_28_9_0, person_27_9_0, risk_28_10_0, person_28_10_0)]

dictionary_observe_28_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4058622384494579, ('false', 'false'): 1.0, ('true', 'true'): 0.5941377615505421}
def f_observe_28_10_0(person_28_10_0, observe_28_10_0):
    return dictionary_observe_28_10_0[(person_28_10_0, observe_28_10_0)]

dictionary_person_29_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5662901046227097, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4337098953772903, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.565723814518087, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.43427618548191305, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_29_10_0(person_29_9_0, person_23_9_0, risk_29_10_0, person_29_10_0):
    return dictionary_person_29_10_0[(person_29_9_0, person_23_9_0, risk_29_10_0, person_29_10_0)]

dictionary_observe_29_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6338615200106223, ('false', 'false'): 1.0, ('true', 'true'): 0.36613847998937765}
def f_observe_29_10_0(person_29_10_0, observe_29_10_0):
    return dictionary_observe_29_10_0[(person_29_10_0, observe_29_10_0)]

dictionary_person_30_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_30_10_0(person_30_9_0, risk_30_10_0, person_30_10_0):
    return dictionary_person_30_10_0[(person_30_9_0, risk_30_10_0, person_30_10_0)]

dictionary_observe_30_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9228381755989364, ('false', 'false'): 1.0, ('true', 'true'): 0.07716182440106356}
def f_observe_30_10_0(person_30_10_0, observe_30_10_0):
    return dictionary_observe_30_10_0[(person_30_10_0, observe_30_10_0)]

dictionary_person_31_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.4858682119331813, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7259371542258791, ('false', 'false', 'true', 'false', 'false'): 0.5335931162486766, ('false', 'true', 'false', 'true', 'true'): 0.4863823437212481, ('false', 'false', 'true', 'false', 'true'): 0.46640688375132344, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5136176562787519, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5330595231324279, ('false', 'true', 'true', 'false', 'true'): 0.725662817042922, ('false', 'true', 'true', 'false', 'false'): 0.27433718295707793, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4669404768675721, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5141317880668187, ('false', 'true', 'true', 'true', 'false'): 0.2740628457741209}
def f_person_31_10_0(person_31_9_0, person_7_9_0, person_32_9_0, risk_31_10_0, person_31_10_0):
    return dictionary_person_31_10_0[(person_31_9_0, person_7_9_0, person_32_9_0, risk_31_10_0, person_31_10_0)]

dictionary_observe_31_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6143875935653595, ('false', 'false'): 1.0, ('true', 'true'): 0.38561240643464045}
def f_observe_31_10_0(person_31_10_0, observe_31_10_0):
    return dictionary_observe_31_10_0[(person_31_10_0, observe_31_10_0)]

dictionary_person_32_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_32_10_0(person_32_9_0, risk_32_10_0, person_32_10_0):
    return dictionary_person_32_10_0[(person_32_9_0, risk_32_10_0, person_32_10_0)]

dictionary_observe_32_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6212804175563047, ('false', 'false'): 1.0, ('true', 'true'): 0.3787195824436953}
def f_observe_32_10_0(person_32_10_0, observe_32_10_0):
    return dictionary_observe_32_10_0[(person_32_10_0, observe_32_10_0)]

dictionary_person_33_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_33_10_0(person_33_9_0, risk_33_10_0, person_33_10_0):
    return dictionary_person_33_10_0[(person_33_9_0, risk_33_10_0, person_33_10_0)]

dictionary_observe_33_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6774463650587941, ('false', 'false'): 1.0, ('true', 'true'): 0.3225536349412059}
def f_observe_33_10_0(person_33_10_0, observe_33_10_0):
    return dictionary_observe_33_10_0[(person_33_10_0, observe_33_10_0)]

dictionary_person_34_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_34_10_0(person_34_9_0, risk_34_10_0, person_34_10_0):
    return dictionary_person_34_10_0[(person_34_9_0, risk_34_10_0, person_34_10_0)]

dictionary_observe_34_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6415473815874794, ('false', 'false'): 1.0, ('true', 'true'): 0.35845261841252063}
def f_observe_34_10_0(person_34_10_0, observe_34_10_0):
    return dictionary_observe_34_10_0[(person_34_10_0, observe_34_10_0)]

dictionary_person_35_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6052518705165157, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.39474812948348426, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6046466186459992, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3953533813540008, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_35_10_0(person_35_9_0, person_5_9_0, risk_35_10_0, person_35_10_0):
    return dictionary_person_35_10_0[(person_35_9_0, person_5_9_0, risk_35_10_0, person_35_10_0)]

dictionary_observe_35_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4610433915426566, ('false', 'false'): 1.0, ('true', 'true'): 0.5389566084573434}
def f_observe_35_10_0(person_35_10_0, observe_35_10_0):
    return dictionary_observe_35_10_0[(person_35_10_0, observe_35_10_0)]

functions = [f_person_0_7_0, f_person_1_7_0, f_person_2_7_0, f_person_3_7_0, f_person_4_7_0, f_person_5_7_0, f_person_6_7_0, f_person_7_7_0, f_person_8_7_0, f_person_9_7_0, f_person_10_7_0, f_person_11_7_0, f_person_12_7_0, f_person_13_7_0, f_person_14_7_0, f_person_15_7_0, f_person_16_7_0, f_person_17_7_0, f_person_18_7_0, f_person_19_7_0, f_person_20_7_0, f_person_21_7_0, f_person_22_7_0, f_person_23_7_0, f_person_24_7_0, f_person_25_7_0, f_person_26_7_0, f_person_27_7_0, f_person_28_7_0, f_person_29_7_0, f_person_30_7_0, f_person_31_7_0, f_person_32_7_0, f_person_33_7_0, f_person_34_7_0, f_person_35_7_0, f_risk_0_8_0, f_risk_1_8_0, f_risk_2_8_0, f_risk_3_8_0, f_risk_4_8_0, f_risk_5_8_0, f_risk_6_8_0, f_risk_7_8_0, f_risk_8_8_0, f_risk_9_8_0, f_risk_10_8_0, f_risk_11_8_0, f_risk_12_8_0, f_risk_13_8_0, f_risk_14_8_0, f_risk_15_8_0, f_risk_16_8_0, f_risk_17_8_0, f_risk_18_8_0, f_risk_19_8_0, f_risk_20_8_0, f_risk_21_8_0, f_risk_22_8_0, f_risk_23_8_0, f_risk_24_8_0, f_risk_25_8_0, f_risk_25_8_1, f_risk_26_8_0, f_risk_27_8_0, f_risk_28_8_0, f_risk_29_8_0, f_risk_30_8_0, f_risk_31_8_0, f_risk_32_8_0, f_risk_33_8_0, f_risk_34_8_0, f_risk_35_8_0, f_risk_0_9_0, f_risk_1_9_0, f_risk_2_9_0, f_risk_3_9_0, f_risk_4_9_0, f_risk_5_9_0, f_risk_6_9_0, f_risk_7_9_0, f_risk_8_9_0, f_risk_9_9_0, f_risk_10_9_0, f_risk_11_9_0, f_risk_12_9_0, f_risk_13_9_0, f_risk_14_9_0, f_risk_15_9_0, f_risk_16_9_0, f_risk_17_9_0, f_risk_18_9_0, f_risk_19_9_0, f_risk_20_9_0, f_risk_20_9_1, f_risk_21_9_0, f_risk_22_9_0, f_risk_23_9_0, f_risk_24_9_0, f_risk_25_9_0, f_risk_26_9_0, f_risk_27_9_0, f_risk_28_9_0, f_risk_29_9_0, f_risk_30_9_0, f_risk_31_9_0, f_risk_32_9_0, f_risk_33_9_0, f_risk_34_9_0, f_risk_35_9_0, f_risk_0_10_0, f_risk_1_10_0, f_risk_2_10_0, f_risk_3_10_0, f_risk_4_10_0, f_risk_5_10_0, f_risk_6_10_0, f_risk_7_10_0, f_risk_8_10_0, f_risk_9_10_0, f_risk_10_10_0, f_risk_11_10_0, f_risk_12_10_0, f_risk_13_10_0, f_risk_14_10_0, f_risk_15_10_0, f_risk_16_10_0, f_risk_17_10_0, f_risk_18_10_0, f_risk_19_10_0, f_risk_20_10_0, f_risk_21_10_0, f_risk_22_10_0, f_risk_23_10_0, f_risk_24_10_0, f_risk_25_10_0, f_risk_26_10_0, f_risk_27_10_0, f_risk_28_10_0, f_risk_29_10_0, f_risk_30_10_0, f_risk_31_10_0, f_risk_32_10_0, f_risk_33_10_0, f_risk_34_10_0, f_risk_35_10_0, f_observe_0_7_0, f_observe_1_7_0, f_observe_2_7_0, f_observe_3_7_0, f_observe_4_7_0, f_observe_5_7_0, f_observe_6_7_0, f_observe_7_7_0, f_observe_8_7_0, f_observe_9_7_0, f_observe_10_7_0, f_observe_11_7_0, f_observe_12_7_0, f_observe_13_7_0, f_observe_14_7_0, f_observe_15_7_0, f_observe_16_7_0, f_observe_17_7_0, f_observe_18_7_0, f_observe_19_7_0, f_observe_20_7_0, f_observe_21_7_0, f_observe_22_7_0, f_observe_23_7_0, f_observe_24_7_0, f_observe_25_7_0, f_observe_26_7_0, f_observe_27_7_0, f_observe_28_7_0, f_observe_29_7_0, f_observe_30_7_0, f_observe_31_7_0, f_observe_32_7_0, f_observe_33_7_0, f_observe_34_7_0, f_observe_35_7_0, f_person_0_8_0, f_observe_0_8_0, f_person_1_8_0, f_observe_1_8_0, f_person_2_8_0, f_observe_2_8_0, f_person_3_8_0, f_observe_3_8_0, f_person_4_8_0, f_observe_4_8_0, f_person_5_8_0, f_observe_5_8_0, f_person_6_8_0, f_observe_6_8_0, f_person_7_8_0, f_observe_7_8_0, f_person_8_8_0, f_observe_8_8_0, f_person_9_8_0, f_observe_9_8_0, f_person_10_8_0, f_observe_10_8_0, f_person_11_8_0, f_observe_11_8_0, f_person_12_8_0, f_observe_12_8_0, f_person_13_8_0, f_observe_13_8_0, f_person_14_8_0, f_observe_14_8_0, f_person_15_8_0, f_observe_15_8_0, f_person_16_8_0, f_observe_16_8_0, f_person_17_8_0, f_observe_17_8_0, f_person_18_8_0, f_observe_18_8_0, f_person_19_8_0, f_observe_19_8_0, f_person_20_8_0, f_observe_20_8_0, f_person_21_8_0, f_observe_21_8_0, f_person_22_8_0, f_observe_22_8_0, f_person_23_8_0, f_observe_23_8_0, f_person_24_8_0, f_observe_24_8_0, f_person_25_8_0, f_observe_25_8_0, f_person_26_8_0, f_observe_26_8_0, f_person_27_8_0, f_observe_27_8_0, f_person_28_8_0, f_observe_28_8_0, f_person_29_8_0, f_observe_29_8_0, f_person_30_8_0, f_observe_30_8_0, f_person_31_8_0, f_observe_31_8_0, f_person_32_8_0, f_observe_32_8_0, f_person_33_8_0, f_observe_33_8_0, f_person_34_8_0, f_observe_34_8_0, f_person_35_8_0, f_observe_35_8_0, f_person_0_9_0, f_observe_0_9_0, f_person_1_9_0, f_observe_1_9_0, f_person_2_9_0, f_observe_2_9_0, f_person_3_9_0, f_observe_3_9_0, f_person_4_9_0, f_observe_4_9_0, f_person_5_9_0, f_observe_5_9_0, f_person_6_9_0, f_observe_6_9_0, f_person_7_9_0, f_observe_7_9_0, f_person_8_9_0, f_observe_8_9_0, f_person_9_9_0, f_observe_9_9_0, f_person_10_9_0, f_observe_10_9_0, f_person_11_9_0, f_observe_11_9_0, f_person_12_9_0, f_observe_12_9_0, f_person_13_9_0, f_observe_13_9_0, f_person_14_9_0, f_observe_14_9_0, f_person_15_9_0, f_observe_15_9_0, f_person_16_9_0, f_observe_16_9_0, f_person_17_9_0, f_observe_17_9_0, f_person_18_9_0, f_observe_18_9_0, f_person_19_9_0, f_observe_19_9_0, f_person_20_9_0, f_observe_20_9_0, f_person_21_9_0, f_observe_21_9_0, f_person_22_9_0, f_observe_22_9_0, f_person_23_9_0, f_observe_23_9_0, f_person_24_9_0, f_observe_24_9_0, f_person_25_9_0, f_observe_25_9_0, f_person_26_9_0, f_observe_26_9_0, f_person_27_9_0, f_observe_27_9_0, f_person_28_9_0, f_observe_28_9_0, f_person_29_9_0, f_observe_29_9_0, f_person_30_9_0, f_observe_30_9_0, f_person_31_9_0, f_observe_31_9_0, f_person_32_9_0, f_observe_32_9_0, f_person_33_9_0, f_observe_33_9_0, f_person_34_9_0, f_observe_34_9_0, f_person_35_9_0, f_observe_35_9_0, f_person_0_10_0, f_observe_0_10_0, f_person_1_10_0, f_observe_1_10_0, f_person_2_10_0, f_observe_2_10_0, f_person_3_10_0, f_observe_3_10_0, f_person_4_10_0, f_observe_4_10_0, f_person_5_10_0, f_observe_5_10_0, f_person_6_10_0, f_observe_6_10_0, f_person_7_10_0, f_observe_7_10_0, f_person_8_10_0, f_observe_8_10_0, f_person_9_10_0, f_observe_9_10_0, f_person_10_10_0, f_observe_10_10_0, f_person_11_10_0, f_observe_11_10_0, f_person_12_10_0, f_observe_12_10_0, f_person_13_10_0, f_observe_13_10_0, f_person_14_10_0, f_observe_14_10_0, f_person_15_10_0, f_observe_15_10_0, f_person_16_10_0, f_observe_16_10_0, f_person_17_10_0, f_observe_17_10_0, f_person_18_10_0, f_observe_18_10_0, f_person_19_10_0, f_observe_19_10_0, f_person_20_10_0, f_observe_20_10_0, f_person_21_10_0, f_observe_21_10_0, f_person_22_10_0, f_observe_22_10_0, f_person_23_10_0, f_observe_23_10_0, f_person_24_10_0, f_observe_24_10_0, f_person_25_10_0, f_observe_25_10_0, f_person_26_10_0, f_observe_26_10_0, f_person_27_10_0, f_observe_27_10_0, f_person_28_10_0, f_observe_28_10_0, f_person_29_10_0, f_observe_29_10_0, f_person_30_10_0, f_observe_30_10_0, f_person_31_10_0, f_observe_31_10_0, f_person_32_10_0, f_observe_32_10_0, f_person_33_10_0, f_observe_33_10_0, f_person_34_10_0, f_observe_34_10_0, f_person_35_10_0, f_observe_35_10_0]
domains_dict = {'person_33_7_0': ['false', 'true'], 'person_4_7_0': ['false', 'true'], 'risk_13_8_0': ['false', 'true'], 'risk_6_8_0': ['false', 'true'], 'person_31_7_0': ['false', 'true'], 'risk_2_9_0': ['false', 'true'], 'person_17_8_0': ['false', 'true'], 'risk_10_9_0': ['false', 'true'], 'observe_23_9_0': ['false', 'true'], 'risk_13_10_0': ['false', 'true'], 'observe_0_10_0': ['false', 'true'], 'person_4_9_0': ['false', 'true'], 'observe_3_10_0': ['false', 'true'], 'person_34_8_0': ['false', 'true'], 'person_31_9_0': ['false', 'true'], 'person_29_10_0': ['false', 'true'], 'person_17_10_0': ['false', 'true'], 'risk_5_10_0': ['false', 'true'], 'risk_23_9_0': ['false', 'true'], 'person_33_10_0': ['false', 'true'], 'person_32_8_0': ['false', 'true'], 'risk_31_10_0': ['false', 'true'], 'person_0_8_0': ['false', 'true'], 'person_9_10_0': ['false', 'true'], 'observe_21_10_0': ['false', 'true'], 'person_27_7_0': ['false', 'true'], 'risk_12_10_0': ['false', 'true'], 'risk_27_10_0': ['false', 'true'], 'risk_26_8_0': ['false', 'true'], 'observe_30_8_0': ['false', 'true'], 'risk_21_9_0': ['false', 'true'], 'person_25_7_0': ['false', 'true'], 'person_2_8_0': ['false', 'true'], 'observe_4_10_0': ['false', 'true'], 'person_31_10_0': ['false', 'true'], 'person_5_10_0': ['false', 'true'], 'person_18_10_0': ['false', 'true'], 'observe_7_8_0': ['false', 'true'], 'person_25_9_0': ['false', 'true'], 'person_29_9_0': ['false', 'true'], 'person_16_9_0': ['false', 'true'], 'observe_15_8_0': ['false', 'true'], 'risk_28_9_0': ['false', 'true'], 'observe_35_9_0': ['false', 'true'], 'observe_35_7_0': ['false', 'true'], 'risk_0_9_0': ['false', 'true'], 'observe_25_8_0': ['false', 'true'], 'person_7_9_0': ['false', 'true'], 'person_27_8_0': ['false', 'true'], 'person_10_8_0': ['false', 'true'], 'risk_18_9_0': ['false', 'true'], 'person_29_7_0': ['false', 'true'], 'person_1_10_0': ['false', 'true'], 'observe_18_8_0': ['false', 'true'], 'person_26_9_0': ['false', 'true'], 'risk_34_8_0': ['false', 'true'], 'risk_29_8_0': ['false', 'true'], 'risk_24_9_0': ['false', 'true'], 'person_22_10_0': ['false', 'true'], 'observe_25_7_0': ['false', 'true'], 'person_24_9_0': ['false', 'true'], 'observe_1_8_0': ['false', 'true'], 'person_21_8_0': ['false', 'true'], 'risk_11_9_0': ['false', 'true'], 'observe_21_8_0': ['false', 'true'], 'observe_23_10_0': ['false', 'true'], 'observe_27_7_0': ['false', 'true'], 'person_15_8_0': ['false', 'true'], 'risk_8_8_0': ['false', 'true'], 'person_25_10_0': ['false', 'true'], 'risk_34_10_0': ['false', 'true'], 'observe_13_10_0': ['false', 'true'], 'observe_1_10_0': ['false', 'true'], 'person_7_10_0': ['false', 'true'], 'observe_17_9_0': ['false', 'true'], 'person_24_7_0': ['false', 'true'], 'observe_35_10_0': ['false', 'true'], 'person_7_7_0': ['false', 'true'], 'person_11_9_0': ['false', 'true'], 'risk_1_10_0': ['false', 'true'], 'observe_23_8_0': ['false', 'true'], 'observe_18_7_0': ['false', 'true'], 'person_17_9_0': ['false', 'true'], 'observe_27_9_0': ['false', 'true'], 'risk_2_8_0': ['false', 'true'], 'risk_3_9_0': ['false', 'true'], 'person_14_10_0': ['false', 'true'], 'person_34_9_0': ['false', 'true'], 'risk_23_8_0': ['false', 'true'], 'person_12_10_0': ['false', 'true'], 'person_11_7_0': ['false', 'true'], 'observe_7_10_0': ['false', 'true'], 'risk_13_9_0': ['false', 'true'], 'observe_32_10_0': ['false', 'true'], 'person_32_7_0': ['false', 'true'], 'person_3_10_0': ['false', 'true'], 'person_0_9_0': ['false', 'true'], 'person_32_9_0': ['false', 'true'], 'person_14_8_0': ['false', 'true'], 'person_0_7_0': ['false', 'true'], 'observe_23_7_0': ['false', 'true'], 'observe_5_10_0': ['false', 'true'], 'observe_33_10_0': ['false', 'true'], 'risk_21_8_0': ['false', 'true'], 'risk_7_10_0': ['false', 'true'], 'observe_9_8_0': ['false', 'true'], 'person_3_8_0': ['false', 'true'], 'person_8_9_0': ['false', 'true'], 'observe_32_7_0': ['false', 'true'], 'observe_32_9_0': ['false', 'true'], 'risk_22_9_0': ['false', 'true'], 'person_6_7_0': ['false', 'true'], 'risk_28_8_0': ['false', 'true'], 'person_11_10_0': ['false', 'true'], 'observe_25_9_0': ['false', 'true'], 'person_7_8_0': ['false', 'true'], 'risk_14_10_0': ['false', 'true'], 'person_20_8_0': ['false', 'true'], 'person_3_7_0': ['false', 'true'], 'risk_18_8_0': ['false', 'true'], 'risk_30_10_0': ['false', 'true'], 'person_14_7_0': ['false', 'true'], 'person_1_7_0': ['false', 'true'], 'observe_1_7_0': ['false', 'true'], 'observe_34_10_0': ['false', 'true'], 'observe_16_9_0': ['false', 'true'], 'observe_11_9_0': ['false', 'true'], 'risk_34_9_0': ['false', 'true'], 'risk_29_9_0': ['false', 'true'], 'observe_16_7_0': ['false', 'true'], 'person_19_9_0': ['false', 'true'], 'person_20_7_0': ['false', 'true'], 'observe_0_8_0': ['false', 'true'], 'person_5_8_0': ['false', 'true'], 'person_24_8_0': ['false', 'true'], 'risk_8_9_0': ['false', 'true'], 'person_22_7_0': ['false', 'true'], 'risk_11_8_0': ['false', 'true'], 'person_1_9_0': ['false', 'true'], 'risk_10_10_0': ['false', 'true'], 'observe_34_9_0': ['false', 'true'], 'observe_13_8_0': ['false', 'true'], 'risk_31_8_0': ['false', 'true'], 'person_6_9_0': ['false', 'true'], 'risk_2_10_0': ['false', 'true'], 'observe_2_8_0': ['false', 'true'], 'risk_19_8_0': ['false', 'true'], 'person_26_8_0': ['false', 'true'], 'person_11_8_0': ['false', 'true'], 'person_22_9_0': ['false', 'true'], 'observe_27_8_0': ['false', 'true'], 'risk_32_10_0': ['false', 'true'], 'risk_3_8_0': ['false', 'true'], 'observe_26_9_0': ['false', 'true'], 'risk_3_10_0': ['false', 'true'], 'observe_34_7_0': ['false', 'true'], 'observe_25_10_0': ['false', 'true'], 'person_27_10_0': ['false', 'true'], 'observe_26_7_0': ['false', 'true'], 'risk_8_10_0': ['false', 'true'], 'observe_1_9_0': ['false', 'true'], 'observe_29_10_0': ['false', 'true'], 'risk_17_8_0': ['false', 'true'], 'person_32_10_0': ['false', 'true'], 'observe_28_9_0': ['false', 'true'], 'person_5_7_0': ['false', 'true'], 'risk_25_8_0': ['false', 'true'], 'risk_33_9_0': ['false', 'true'], 'risk_23_10_0': ['false', 'true'], 'person_8_7_0': ['false', 'true'], 'person_26_7_0': ['false', 'true'], 'person_14_9_0': ['false', 'true'], 'observe_34_8_0': ['false', 'true'], 'observe_2_7_0': ['false', 'true'], 'person_6_10_0': ['false', 'true'], 'observe_9_9_0': ['false', 'true'], 'risk_22_10_0': ['false', 'true'], 'person_3_9_0': ['false', 'true'], 'person_8_8_0': ['false', 'true'], 'observe_32_8_0': ['false', 'true'], 'observe_33_9_0': ['false', 'true'], 'risk_22_8_0': ['false', 'true'], 'person_20_9_0': ['false', 'true'], 'person_6_8_0': ['false', 'true'], 'observe_10_7_0': ['false', 'true'], 'observe_4_9_0': ['false', 'true'], 'risk_4_10_0': ['false', 'true'], 'risk_20_9_0': ['false', 'true'], 'risk_20_9_1': ['false', 'true'], 'person_23_10_0': ['false', 'true'], 'observe_11_8_0': ['false', 'true'], 'observe_33_7_0': ['false', 'true'], 'observe_9_7_0': ['false', 'true'], 'observe_16_8_0': ['false', 'true'], 'person_28_10_0': ['false', 'true'], 'observe_31_7_0': ['false', 'true'], 'person_19_8_0': ['false', 'true'], 'risk_5_8_0': ['false', 'true'], 'observe_0_9_0': ['false', 'true'], 'person_28_8_0': ['false', 'true'], 'person_1_8_0': ['false', 'true'], 'risk_9_8_0': ['false', 'true'], 'observe_30_10_0': ['false', 'true'], 'person_12_8_0': ['false', 'true'], 'risk_31_9_0': ['false', 'true'], 'observe_13_9_0': ['false', 'true'], 'risk_27_8_0': ['false', 'true'], 'observe_31_8_0': ['false', 'true'], 'observe_17_10_0': ['false', 'true'], 'person_19_7_0': ['false', 'true'], 'risk_19_9_0': ['false', 'true'], 'observe_13_7_0': ['false', 'true'], 'observe_9_10_0': ['false', 'true'], 'observe_2_10_0': ['false', 'true'], 'observe_2_9_0': ['false', 'true'], 'risk_7_9_0': ['false', 'true'], 'observe_6_8_0': ['false', 'true'], 'observe_26_8_0': ['false', 'true'], 'person_22_8_0': ['false', 'true'], 'risk_30_8_0': ['false', 'true'], 'person_23_9_0': ['false', 'true'], 'observe_11_7_0': ['false', 'true'], 'observe_15_10_0': ['false', 'true'], 'observe_10_8_0': ['false', 'true'], 'observe_8_7_0': ['false', 'true'], 'person_23_7_0': ['false', 'true'], 'risk_16_8_0': ['false', 'true'], 'observe_8_9_0': ['false', 'true'], 'observe_0_7_0': ['false', 'true'], 'risk_6_10_0': ['false', 'true'], 'risk_1_9_0': ['false', 'true'], 'observe_28_8_0': ['false', 'true'], 'observe_20_10_0': ['false', 'true'], 'observe_6_10_0': ['false', 'true'], 'risk_20_10_0': ['false', 'true'], 'risk_33_8_0': ['false', 'true'], 'risk_14_8_0': ['false', 'true'], 'person_18_8_0': ['false', 'true'], 'person_24_10_0': ['false', 'true'], 'risk_24_10_0': ['false', 'true'], 'observe_12_10_0': ['false', 'true'], 'risk_30_9_0': ['false', 'true'], 'risk_17_9_0': ['false', 'true'], 'observe_3_7_0': ['false', 'true'], 'risk_25_9_0': ['false', 'true'], 'person_9_8_0': ['false', 'true'], 'person_35_8_0': ['false', 'true'], 'observe_28_7_0': ['false', 'true'], 'person_30_8_0': ['false', 'true'], 'observe_33_8_0': ['false', 'true'], 'person_35_10_0': ['false', 'true'], 'risk_35_10_0': ['false', 'true'], 'person_17_7_0': ['false', 'true'], 'observe_3_9_0': ['false', 'true'], 'observe_4_8_0': ['false', 'true'], 'person_33_9_0': ['false', 'true'], 'person_4_10_0': ['false', 'true'], 'observe_18_9_0': ['false', 'true'], 'observe_19_9_0': ['false', 'true'], 'person_12_7_0': ['false', 'true'], 'risk_16_9_0': ['false', 'true'], 'person_28_9_0': ['false', 'true'], 'observe_14_7_0': ['false', 'true'], 'observe_4_7_0': ['false', 'true'], 'observe_20_8_0': ['false', 'true'], 'person_26_10_0': ['false', 'true'], 'risk_5_9_0': ['false', 'true'], 'observe_6_7_0': ['false', 'true'], 'observe_14_9_0': ['false', 'true'], 'person_35_7_0': ['false', 'true'], 'risk_9_9_0': ['false', 'true'], 'person_12_9_0': ['false', 'true'], 'person_8_10_0': ['false', 'true'], 'risk_27_9_0': ['false', 'true'], 'observe_31_9_0': ['false', 'true'], 'observe_5_8_0': ['false', 'true'], 'person_20_10_0': ['false', 'true'], 'risk_7_8_0': ['false', 'true'], 'observe_24_10_0': ['false', 'true'], 'risk_12_9_0': ['false', 'true'], 'observe_22_9_0': ['false', 'true'], 'observe_29_8_0': ['false', 'true'], 'person_23_8_0': ['false', 'true'], 'observe_6_9_0': ['false', 'true'], 'person_16_10_0': ['false', 'true'], 'observe_10_9_0': ['false', 'true'], 'observe_19_10_0': ['false', 'true'], 'risk_35_8_0': ['false', 'true'], 'risk_16_10_0': ['false', 'true'], 'person_28_7_0': ['false', 'true'], 'risk_28_10_0': ['false', 'true'], 'observe_31_10_0': ['false', 'true'], 'observe_24_7_0': ['false', 'true'], 'risk_4_9_0': ['false', 'true'], 'risk_15_10_0': ['false', 'true'], 'risk_1_8_0': ['false', 'true'], 'observe_24_9_0': ['false', 'true'], 'person_13_9_0': ['false', 'true'], 'observe_12_9_0': ['false', 'true'], 'observe_18_10_0': ['false', 'true'], 'person_13_7_0': ['false', 'true'], 'risk_32_8_0': ['false', 'true'], 'risk_6_9_0': ['false', 'true'], 'person_18_7_0': ['false', 'true'], 'risk_14_9_0': ['false', 'true'], 'observe_19_7_0': ['false', 'true'], 'person_13_10_0': ['false', 'true'], 'person_18_9_0': ['false', 'true'], 'risk_10_8_0': ['false', 'true'], 'observe_12_7_0': ['false', 'true'], 'risk_0_10_0': ['false', 'true'], 'observe_22_10_0': ['false', 'true'], 'risk_19_10_0': ['false', 'true'], 'observe_8_8_0': ['false', 'true'], 'person_35_9_0': ['false', 'true'], 'risk_26_10_0': ['false', 'true'], 'observe_10_10_0': ['false', 'true'], 'person_9_9_0': ['false', 'true'], 'person_31_8_0': ['false', 'true'], 'observe_16_10_0': ['false', 'true'], 'person_9_7_0': ['false', 'true'], 'person_30_9_0': ['false', 'true'], 'risk_33_10_0': ['false', 'true'], 'person_19_10_0': ['false', 'true'], 'person_30_7_0': ['false', 'true'], 'person_34_10_0': ['false', 'true'], 'person_15_10_0': ['false', 'true'], 'observe_28_10_0': ['false', 'true'], 'person_4_8_0': ['false', 'true'], 'observe_22_7_0': ['false', 'true'], 'observe_19_8_0': ['false', 'true'], 'observe_12_8_0': ['false', 'true'], 'risk_26_9_0': ['false', 'true'], 'observe_30_9_0': ['false', 'true'], 'observe_30_7_0': ['false', 'true'], 'observe_20_7_0': ['false', 'true'], 'risk_25_8_1': ['false', 'true'], 'person_0_10_0': ['false', 'true'], 'observe_3_8_0': ['false', 'true'], 'person_21_10_0': ['false', 'true'], 'observe_7_9_0': ['false', 'true'], 'person_25_8_0': ['false', 'true'], 'person_29_8_0': ['false', 'true'], 'risk_9_10_0': ['false', 'true'], 'observe_20_9_0': ['false', 'true'], 'person_16_8_0': ['false', 'true'], 'observe_7_7_0': ['false', 'true'], 'person_2_10_0': ['false', 'true'], 'observe_14_8_0': ['false', 'true'], 'observe_35_8_0': ['false', 'true'], 'observe_15_9_0': ['false', 'true'], 'risk_17_10_0': ['false', 'true'], 'observe_29_7_0': ['false', 'true'], 'risk_15_9_0': ['false', 'true'], 'observe_27_10_0': ['false', 'true'], 'risk_32_9_0': ['false', 'true'], 'risk_12_8_0': ['false', 'true'], 'risk_15_8_0': ['false', 'true'], 'observe_22_8_0': ['false', 'true'], 'risk_0_8_0': ['false', 'true'], 'observe_29_9_0': ['false', 'true'], 'observe_11_10_0': ['false', 'true'], 'person_10_10_0': ['false', 'true'], 'person_27_9_0': ['false', 'true'], 'person_10_9_0': ['false', 'true'], 'risk_35_9_0': ['false', 'true'], 'observe_14_10_0': ['false', 'true'], 'observe_26_10_0': ['false', 'true'], 'observe_15_7_0': ['false', 'true'], 'person_2_7_0': ['false', 'true'], 'person_15_7_0': ['false', 'true'], 'risk_29_10_0': ['false', 'true'], 'person_2_9_0': ['false', 'true'], 'observe_17_7_0': ['false', 'true'], 'risk_24_8_0': ['false', 'true'], 'person_21_7_0': ['false', 'true'], 'risk_25_10_0': ['false', 'true'], 'observe_21_9_0': ['false', 'true'], 'observe_8_10_0': ['false', 'true'], 'person_33_8_0': ['false', 'true'], 'risk_4_8_0': ['false', 'true'], 'observe_24_8_0': ['false', 'true'], 'person_15_9_0': ['false', 'true'], 'risk_21_10_0': ['false', 'true'], 'person_21_9_0': ['false', 'true'], 'person_5_9_0': ['false', 'true'], 'person_10_7_0': ['false', 'true'], 'person_34_7_0': ['false', 'true'], 'person_13_8_0': ['false', 'true'], 'person_30_10_0': ['false', 'true'], 'observe_5_7_0': ['false', 'true'], 'observe_17_8_0': ['false', 'true'], 'person_16_7_0': ['false', 'true'], 'risk_20_8_0': ['false', 'true'], 'observe_5_9_0': ['false', 'true'], 'risk_18_10_0': ['false', 'true'], 'observe_21_7_0': ['false', 'true'], 'risk_11_10_0': ['false', 'true']}

def create_graph():
    g = build_graph(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/data/d48/infection0'
    return g

def create_bbn():
    g = build_bbn(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/data/d48/infection0'
    return g

