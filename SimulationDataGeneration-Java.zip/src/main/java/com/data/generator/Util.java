package com.data.generator;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Util {
    static void setSubGraphFlag(List<Layer> layers){
        Set<BayesNode> nodes = new HashSet<>();
        layers.forEach(layer -> {
            layer.getNodes().forEach(node->{
                nodes.add(node);
                nodes.addAll(node.parents);
                nodes.addAll(node.childern);
            });
        });
        int i=0;
        for(BayesNode node:nodes){
            if(node.flag==-1){
                setFlag(node,i);
                ++i;
            }
        }
    }

    private static void setFlag(BayesNode node, int i) {
        if(node.flag!=-1)return;
        node.flag = i;
        node.parents.forEach(parent->setFlag(parent,i ));
        node.childern.forEach(parent->setFlag(parent,i ));
    }
}
