package com.data.generator;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Test {

    public static void main(String[] args) {

        List<Cow>cows = new ArrayList<>();
        Comparator<Cow> comparator = new Comparator<Cow>() {
            @Override
            public int compare(Cow o1, Cow o2) {
                return o1.x>o2.x?1:-1;
            }
        };
        cows.sort(comparator);
    }
    class Cow{
        int x;
        int s;
    }
}
