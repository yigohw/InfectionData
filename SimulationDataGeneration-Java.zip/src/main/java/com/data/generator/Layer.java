package com.data.generator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Layer {
    private List<BayesNode>nodes = new ArrayList<>();
    private Map<Integer, BayesNode> map = new HashMap<>();

    public List<BayesNode> getNodes() {
        return nodes;
    }
    public BayesNode get(int id){
        return map.get(id);
    }
    public void add(BayesNode node1) {
        nodes.add(node1);
        map.put(node1.id, node1);
    }

    public void remove(BayesNode node) {
        nodes.remove(node);
        map.remove(node.id);
    }
}
