package com.data.generator;

import org.apache.commons.lang3.StringUtils;

import java.util.*;

import static com.data.generator.GraphData.*;


public class BaodiMarket {

    static final int total = 3000, num = 169, positivenum = 60, periods = 24, groupScale = 100;

    public static void main(String args[]) {
        String relationDir = "C:\\Users\\12401\\Desktop\\试剂盒文档\\宝坻关联表.txt";
        String nodeDir = "C:\\Users\\12401\\Desktop\\试剂盒文档\\宝坻疫情数据.txt";

        List<Graph> graphs = new ArrayList();

        int peopleNum = 0;
        while (peopleNum < total) {
            graphs.add(createGraph(relationDir, nodeDir, peopleNum));
            peopleNum += num;
        }
        graphs = mix(graphs);

        String dir = "D:\\zhiyi\\infection\\data\\";
        for (int j = 0; j < graphs.size(); ++j) {
            Parameter parameter = new Parameter();
            Graph g = graphs.get(j);
            getRealData(g.layers, parameter, dir + j + "\\");
            getAnswerData(g.layers, dir + j + "\\");
            getVisibleData(g.layers, parameter, dir + j + "\\");
        }
    }

    private static List<Graph> mix(List<Graph> graphs) {
        Graph[] graphArray = new Graph[total / groupScale];
        for (int i = 0; i < graphArray.length; ++i) {
            Graph newGraph = new Graph();
            graphArray[i] = newGraph;
            for (int j = 0; j < periods; ++j) {
                newGraph.layers.add(new Layer());
            }
        }
        Graph base = graphs.get(0);

        while (base.countPeoson() != 0) {
            Graph testGraph = graphArray[(int) (graphArray.length * Math.random())];
            if (testGraph.count < groupScale) {
                for (int i = 0; i < periods; ++i) {
                    if (base.layers.get(i).getNodes().size() > 0) {
                        move(base, testGraph, base.layers.get(i).getNodes().get(0));
                        testGraph.countPeoson();
                        break;
                    }
                }
            }
        }


        Arrays.sort(graphArray, Comparator.comparingInt(o -> o.count));
        for (int i = 1; i < graphs.size(); ++i) {
            base = graphs.get(i);
            while (base.countPeoson() != 0) {
                for (int j = 0; j < periods; ++j) {
                    Graph testGraph = graphArray[0];
                    if (base.layers.get(j).getNodes().size() > 0) {
                        move(base, testGraph, base.layers.get(j).getNodes().get(0));
                        testGraph.countPeoson();
                        for (int k = 1; k < graphArray.length; ++k) {
                            if (testGraph.count > graphArray[k].count) {
                                graphArray[k - 1] = graphArray[k];
                                graphArray[k] = testGraph;
                            } else break;
                        }
                    }
                }
            }
        }
        int num = 0;
        for (Graph g : graphArray) {
            for (BayesNode node : g.layers.get(g.layers.size() - 1).getNodes()) {
                if (node.isPositive == 1) {
                    System.out.println(node.id);
                }
            }
            num += g.count;
        }
        System.out.println(num);
        return Arrays.asList(graphArray);
    }

    private static void move(Graph source, Graph target, BayesNode node) {
        if (!(node instanceof PersonNode)) return;
        if (target.layers.get(node.otherInfo).getNodes().contains(node)) return;
        source.layers.get(node.otherInfo).remove(node);
        target.layers.get(node.otherInfo).add(node);
        node.parents.forEach(parent -> move(source, target, parent));
        node.childern.forEach(child -> move(source, target, child));
    }


    private static Graph createGraph(String relationDir, String nodeDir, int peopleNum) {
        String nodeStr = TransformUtil.readTxt(nodeDir);

        String[] nodeStrings = nodeStr.split("\r\n");

        Set<Integer> positivePeople = new HashSet<>();
        Map<Integer, Integer> marketDateRecord = new HashMap<>();
        for (int i = 0; i < nodeStrings.length; ++i) {
            String oneNodeString = nodeStrings[i];
            String[] strings = oneNodeString.split("\t");
            if (strings[1].equals("是")) {
                marketDateRecord.put(i, dateToIndex(strings[6]));
            }
            positivePeople.add(i);
        }

        List<List<BayesNode>> nodes = getBaseMatrix(positivePeople, peopleNum);
        addRelationShip(relationDir, nodes);
        connectMarket(nodes, marketDateRecord);
        //mergeNodes(nodes);

        Graph g = new Graph();
        for (int i = 0; i < periods; ++i) {
            Layer layer = new Layer();
            for (List<BayesNode> list : nodes) {
                layer.add(list.get(i));
            }
            g.layers.add(layer);
        }

        /*Layer lastLayer = new Layer();
        for (List<BayesNode> list : nodes) {
            BayesNode first = list.get(0);
            boolean flag = true;
            if (first.parents.size() != 0) {
                flag = false;
            } else {
                for (BayesNode node : first.parents) {
                    if (node instanceof PersonNode) {
                        flag = false;
                        break;
                    }
                }
            }
            if (flag) {
                lastLayer.add(first);
                first.otherFlag = true;
            }
        }
        g.layers.add(lastLayer);
        while (true) {
            Layer newLayer = new Layer();
            for (BayesNode node : lastLayer.getNodes()) {
                for (BayesNode child : node.childern) {
                    if (child instanceof PersonNode) {
                        if (!child.otherFlag) {
                            child.otherFlag = true;
                            newLayer.add(child);
                        }
                    }
                }
            }

            if (newLayer.getNodes().size() == 0) break;
            g.layers.add(newLayer);
            lastLayer = newLayer;
        }*/
        return g;
    }

    private static void connectMarket(List<List<BayesNode>> nodes, Map<Integer, Integer> marketDateRecord) {

        for (Map.Entry<Integer, Integer> entry : marketDateRecord.entrySet()) {
            List<BayesNode> list = nodes.get(entry.getKey());
            BayesNode node = getNodeByDateIndex(entry.getValue(), list);
            BayesNode risk = new RiskNode();
            setUniqueId(risk, node.id, node.otherInfo, risk.getType(), 0);

            Relationship relationship = risk.addChild(node);
            risk.probability = 1;
            risk.isPositive = 1;
            relationship.relevance = 0.02;
        }
    }

    private static BayesNode getNodeByDateIndex(Integer value, List<BayesNode> list) {
        for (int i = 0; i < list.size(); i++) {
            BayesNode node = list.get(i);
            if (node.otherInfo > value || i == list.size() - 1 || list.get(i + 1).otherInfo < value) {
                return node;
            }
        }
        return null;
    }


    private static void mergeNodes(List<List<BayesNode>> nodes) {
        for (int j = 0; j < nodes.size(); ++j) {
            List<BayesNode> list = nodes.get(j);
            List<BayesNode> newList = new ArrayList<>(list);
            for (int i = 0; i < list.size() - 1; ++i) {
                BayesNode node = list.get(i);
                if (i == 0 && node.childern.size() == 1 && node.childern.get(0).id == node.id) {
                    node.childern.get(0).clearParent();
                    newList.remove(node);
                } else if (node.parents.size() == 1 && node.childern.size() == 1 &&
                        node.childern.get(0).id == node.id && node.id == node.parents.get(0).id) {
                    BayesNode parent = node.parents.get(0), child =
                            node.childern.get(0);
                    child.removeParent(node);
                    parent.removeChild(node);
                    Relationship relationship = parent.addChild(child);
                    relationship.relevance = 1;
                    newList.remove(node);
                }
            }
            nodes.set(j, newList);
        }
    }

    private static int dateToIndex(String date) {
        if (StringUtils.isEmpty(date)) return 0;
        String[] strings;
        if (date.contains(".")) {
            strings = date.split("\\.");
        } else {
            strings = date.split("月");
        }
        if (strings[0].equals("1")) {
            return Integer.parseInt(strings[1].replace("日", "")) - 18;
        } else {
            return Integer.parseInt(strings[1].replace("日", "")) + 13;

        }
    }

    private static void addRelationShip(String relationDir, List<List<BayesNode>> nodes) {
        String strings[] = TransformUtil.readTxt(relationDir).split("\r\n");
        for (String string : strings) {
            String[] oneLine = string.split("\t");
            int index = dateToIndex(oneLine[2]);
            int node1Index = idToIndex(oneLine[0]);
            int node2Index = idToIndex(oneLine[1]);
            BayesNode node1 = nodes.get(node1Index).get(index);
            BayesNode node2 = nodes.get(node2Index).get(index);
            BayesNode nextNode1 = nodes.get(node1Index).get(index + 1);
            BayesNode nextNode2 = nodes.get(node2Index).get(index + 1);
            Relationship relationship1 = node1.addChild(nextNode2);
            Relationship relationship2 = node2.addChild(nextNode1);
            relationship1.relevance = Double.parseDouble(oneLine[3]);
            relationship2.relevance = relationship1.relevance;
        }
    }

    private static int idToIndex(String s) {
        return Integer.parseInt(s) - 1;
    }

    private static List<List<BayesNode>> getBaseMatrix(Set<Integer> positivePeople, int peopleNum) {
        List<List<BayesNode>> nodes = new ArrayList<>();
        for (int i = 0; i < num; ++i) {
            List<BayesNode> list = new ArrayList<>();
            nodes.add(list);
            BayesNode lastNode = new PersonNode();
            list.add(lastNode);
            lastNode.id = i + 1 + peopleNum;
            lastNode.isPositive = lastNode.id <= positivenum ? 1 : 0;
            lastNode.otherInfo = 0;
            setUniqueId(lastNode, i + 1, 0, lastNode.getType(), 0);
            for (int j = 1; j < periods; ++j) {
                BayesNode node = new PersonNode();
                node.id = lastNode.id;
                setUniqueId(node, node.id, j, node.getType(), 0);
                node.isPositive = lastNode.isPositive;
                Relationship relationship = lastNode.addChild(node);
                relationship.relevance = 1;
                list.add(node);
                lastNode = node;
                node.otherInfo = j;
            }
            if (positivePeople.contains(i) && peopleNum == 0) {
                ObserveNode observeNode = new ObserveNode();
                setUniqueId(observeNode, lastNode.id, periods - 1, observeNode.getType(), 0);
                observeNode.id = -lastNode.id - 1;
                Relationship relationship = lastNode.addChild(observeNode);
                observeNode.isPositive = 1;
                relationship.relevance = 0.1;
            }
        }
        return nodes;
    }

    public static class Graph {
        List<Layer> layers = new ArrayList<>();

        int countPeoson() {
            HashSet<Integer> ids = new HashSet<>();
            for (Layer layer : layers) {
                for (BayesNode node : layer.getNodes()) {
                    ids.add(node.id);
                }
            }
            count = ids.size();
            return count;
        }

        int count = 0;
    }
}
