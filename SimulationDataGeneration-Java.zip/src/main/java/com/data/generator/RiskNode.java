package com.data.generator;

public class RiskNode extends BayesNode{
    @Override
    String getType() {
        return "risk";
    }
}
