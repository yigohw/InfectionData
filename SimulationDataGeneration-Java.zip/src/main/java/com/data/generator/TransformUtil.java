package com.data.generator;

import org.apache.http.util.ByteArrayBuffer;
import org.apache.http.util.EncodingUtils;

import java.io.*;

public class TransformUtil {
	/**
	 * 将InputStream转为byte[]
	 * 
	 * @param inStream
	 * @return
	 * @throws Exception
	 */
	static public byte[] InputStreamToBytes(InputStream inStream)
			throws Exception {
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		byte[] buffer = new byte[1024];
		int len = 0;
		while ((len = inStream.read(buffer)) > 0) {
			outStream.write(buffer, 0, len);
		}
		outStream.close();
		inStream.close();
		return outStream.toByteArray();
	}
	/**
	 * 将输入流转成UTF8编码格式的String
	 * 
	 * @param uis
	 * @return
	 */
	static public String inputstreamToString(InputStream uis) {
		String string = "";
		try {
			ByteArrayBuffer baf = new ByteArrayBuffer(50);
			int current = 0;
			while ((current = uis.read()) != -1) {
				baf.append((byte) current);
			}
			string = EncodingUtils.getString(baf.toByteArray(), "utf-8");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return string;
	}
	/**
	 * 将文件读出为UTF—8的String
	 * @param absolutePath
	 * @return
	 */
	static public String txtToString(String absolutePath) {
		String string = "";
		File file = new File(absolutePath);
		FileInputStream fis;
		try {
			fis = new FileInputStream(file);		
			string = inputstreamToString(fis);
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return string;
	}

	
	/**
	 * 输入流转化为文件
	 * @param absolutePath
	 */
	static public void inputstreamToFile(String absolutePath,InputStream is)
	{
		FileUtil.makeFile(absolutePath, false);
		File file2 = new File(FileUtil.ToLinuxPath(absolutePath));
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file2);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		byte[] bt = new byte[1024];
		int c;
		try {
			if (is == null)
				return;
			while ((c = is.read(bt)) > 0) {
				fos.write(bt, 0, c);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	static public void StringToFile(String absolutePath,String string)
	{
		FileUtil.makeFile(absolutePath, false);
		File file2 = new File(FileUtil.ToLinuxPath(absolutePath));
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file2);
			fos.write(string.getBytes("utf-8"));
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}static public void StringToFileMoUTF8(String absolutePath,String string)
	{
		FileUtil.makeFile(absolutePath, false);
		File file2 = new File(FileUtil.ToLinuxPath(absolutePath));
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file2);
			fos.write(string.getBytes("gbk"));
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static String resolveCode(String path) throws Exception {
		// String filePath = "D:/article.txt"; //[-76, -85, -71] ANSI
		// String filePath = "D:/article111.txt"; //[-2, -1, 79] unicode big
		// endian
		// String filePath = "D:/article222.txt"; //[-1, -2, 32] unicode
		// String filePath = "D:/article333.txt"; //[-17, -69, -65] UTF-8
		InputStream inputStream = new FileInputStream(path);
		byte[] head = new byte[3];
		inputStream.read(head);
		String code = "gb2312"; // 或GBK
		if (head[0] == -1 && head[1] == -2)
			code = "UTF-16";
		else if (head[0] == -2 && head[1] == -1)
			code = "Unicode";
		else if (head[0] == -17 && head[1] == -69 && head[2] == -65)
			code = "UTF-8";

		inputStream.close();
		return code;
	}

	public static String readTxt(String path) {
		StringBuilder content = new StringBuilder("");
		try {
			String code = resolveCode(path);
			File file = new File(path);
			InputStream is = new FileInputStream(file);
			InputStreamReader isr = new InputStreamReader(is, code);
			BufferedReader br = new BufferedReader(isr);
			// char[] buf = new char[1024];
			// int i = br.read(buf);
			// String s= new String(buf);
			// System.out.println(s);
			String str = "";
			while (null != (str = br.readLine())) {
				content.append(str + "\r\n");
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("读取文件:" + path + "失败!");
		}
		return content.toString();
	}
 
}
