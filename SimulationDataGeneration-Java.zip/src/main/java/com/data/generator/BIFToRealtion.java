package com.data.generator;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class BIFToRealtion {
    public static void main(String[] args) {


        String dir = "D:\\zhiyi\\infection\\data100x36_4\\data";
        for(File file:new File(dir).listFiles())dealDir(file.getAbsolutePath());


    }

    private static void dealDir(String dir) {

        String json = dir + "\\sourceData.json";
        JSONObject jsonObject = JSONObject.parseObject(TransformUtil.txtToString(json));
        JSONArray array = new JSONArray();
        jsonObject.put("edges", array);
        for (File file : new File(dir).listFiles()) {
            try {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    String string = scanner.nextLine();
                    if (string.indexOf("probability") > -1 && string.indexOf("|") > -1) {
                        string = string.replace(" ", "");
                        string = string.replace("probability", "");
                        string = string.replace("{", "");
                        string = string.replace("(", "");
                        string = string.replace(")", "");
                        String[] strs = string.split("\\|");
                        try {

                            String[] parents = strs[1].split(",");
                            for (String parent : parents) {
                                JSONObject object = new JSONObject();
                                object.put("parent", parent);
                                object.put("child", strs[0]);
                                array.add(object);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                System.out.println(file.getAbsolutePath());
            }
        }

        TransformUtil.StringToFile(json, jsonObject.toJSONString());
    }
}
