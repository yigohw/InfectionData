package com.data.generator;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.*;

public class GraphData {
    public static void main(String[] args) {
        String dir = "D:\\zhiyi\\infection\\data\\";
        for(int j=0;j<100;++j) {
            Parameter parameter = new Parameter();
            Layer lastLayer = initLayer(parameter);
            List<Layer> layers = new ArrayList<>();
            layers.add(lastLayer);
            for (int i = 0; i < parameter.spreadLayersNumber; ++i) {
                Layer newLayer = nextLayer(lastLayer, parameter, i + 1);
                layers.add(newLayer);
                lastLayer = newLayer;
            }
            getRealData(layers, parameter,dir+j+"\\");
            getAnswerData(layers,dir+j+"\\");
            getVisibleData(layers, parameter,dir+j+"\\");
        }
    }

    public static void getRealData(List<Layer> layers, Parameter parameter, String dir) {
        JSONObject result = new JSONObject();
        JSONArray nodes = new JSONArray();
        JSONArray relationships = new JSONArray();

        result.put("nodes",nodes );
        result.put("edges",relationships );

        for (int i = 0; i < layers.size(); ++i) {
            Layer layer = layers.get(i);
            layer.getNodes().forEach(node -> {
                addNode(nodes,relationships,node);
                node.childern.forEach(child -> {
                    if (child instanceof ObserveNode) {
                        addNode(nodes, relationships, child);
                    }
                });
                node.parents.forEach(parent -> {
                    if (parent instanceof RiskNode) {
                        addNode(nodes, relationships, parent);
                    }
                });
            });
        }
        TransformUtil.StringToFile(dir+"sourceData.json", result.toJSONString());

    }

    private static void addNode(JSONArray nodes, JSONArray relationships, BayesNode node) {

        JSONObject nodeObject = new JSONObject();
        nodeObject.put("id", node.unique_id);
        nodeObject.put("isPositive",node.isPositive==1 );
        nodes.add(nodeObject);
        for(Relationship relationship:node.childernRelationshipMap.values()){
            JSONObject relationObject = new JSONObject();
            relationObject.put("parent", relationship.parent.unique_id);
            relationObject.put("child", relationship.child.unique_id);
            relationObject.put("relevance", relationship.relevance);
            relationships.add(relationObject);
        }
    }

    public static JSONObject getVisibleData(List<Layer> layers, Parameter parameter, String dir) {

        int i = layers.size() - parameter.visibleLayers;
        if(i<0)i=0;
        Layer firstLayer = layers.get(i);
        firstLayer.getNodes().forEach(node -> {
            node.clearParent();
        });
        List<Layer> newLayers = new ArrayList<>();
        for (int j = i; j < layers.size(); ++j) {
            newLayers.add(layers.get(i));
        }
        Util.setSubGraphFlag(newLayers);

        Map<Integer, BIFBuilder> bifBuilderMap = new HashMap<>();
        firstLayer.getNodes().forEach(node -> {
            node.probability = parameter.visibleInfectionRate;
            BIFBuilder bifBuilder = bifBuilderMap.get(node.flag);
            if (bifBuilder == null) {
                bifBuilder = new BIFBuilder();
                bifBuilderMap.put(node.flag, bifBuilder);
            }
            bifBuilder.addVariable(node.unique_id);
            bifBuilder.addProbability(node);
            BIFBuilder finalBifBuilder = bifBuilder;
            node.childern.forEach(child -> {
                if (child instanceof ObserveNode) {
                    finalBifBuilder.addVariable(child.unique_id);
                    finalBifBuilder.addProbability(child);
                }
            });
        });
        for (++i; i < layers.size(); ++i) {
            Layer layer = layers.get(i);
            layer.getNodes().forEach(node -> {
                if (node.unique_id.equals("person_0_10_0")) {
                    System.out.println(123);
                }
                BIFBuilder bifBuilder = bifBuilderMap.get(node.flag);
                if (bifBuilder == null) {
                    bifBuilder = new BIFBuilder();
                    bifBuilderMap.put(node.flag, bifBuilder);
                }
                BIFBuilder finalBifBuilder = bifBuilder;
                node.parents.forEach(child -> {
                    if (child instanceof RiskNode) {
                        child.isPositive = 1;
                        child.probability = 1;
                        finalBifBuilder.addVariable(child.unique_id);
                        finalBifBuilder.addProbability(child);
                    }
                });
                bifBuilder.addVariable(node.unique_id);
                bifBuilder.addProbability(node);
                BIFBuilder finalBifBuilder1 = bifBuilder;
                node.childern.forEach(child -> {
                    if (child instanceof ObserveNode) {
                        finalBifBuilder1.addVariable(child.unique_id);
                        finalBifBuilder1.addProbability(child);
                    }
                });
            });

        }
        for (Map.Entry<Integer, BIFBuilder> entry : bifBuilderMap.entrySet()) {

            BIFBuilder bifBuilder = entry.getValue();
            TransformUtil.StringToFile(dir+"\\infection" + entry.getKey() + ".bif", bifBuilder.toString());
        }
        return null;
    }

    static void setUniqueId(BayesNode node, int id, int layer, String type, int num) {
        node.unique_id = type + "_" + id + "_" + layer + "_" + num;
    }

    public static JSONObject getAnswerData(List<Layer> layers, String s) {
        JSONArray result = new JSONArray();
        Layer lastLayer = layers.get(layers.size() - 1);
        lastLayer.getNodes().forEach(node -> {
            JSONObject object = new JSONObject();
            object.put("id", node.unique_id);
            object.put("isPositive", node.isPositive);
            result.add(object);
        });
        TransformUtil.StringToFile(s+"answer.json", result.toJSONString());
        return null;
    }

    public static Layer nextLayer(Layer layer, Parameter parameter, int layerNum) {
        final Layer newLayer = new Layer();
        layer.getNodes().forEach(node -> {
            BayesNode node1 = new PersonNode();
            node1.id = node.id;
            setUniqueId(node1, node1.id, layerNum, node1.getType(), 0);
            node1.isPositive = node.isPositive;
            Relationship relationship = node.addChild(node1);
            relationship.relevance = 1;
            newLayer.add(node1);
        });
        createPersonRelationShip(layer, newLayer, parameter);//刷新社交关系


        //增加隐藏风险节点
        newLayer.getNodes().forEach(node -> {
            BayesNode risk = new RiskNode();
            setUniqueId(risk, node.id, layerNum, risk.getType(), 0);
            risk.isPositive = 1;
            Relationship relationship = risk.addChild(node);
            relationship.relevance = parameter.hideRiskFactor;
        });
        //增加显性风险节点,比如去过疫区
        for (int i = 0; i < parameter.peopleNumber; ++i) {
            if (Math.random() > parameter.otherRiskRate) continue;
            BayesNode risk = new RiskNode();
            setUniqueId(risk, newLayer.get(i).id, layerNum, risk.getType(), 1);
            risk.id = -2 * newLayer.get(i).id - 2;
            risk.isPositive = 1;
            Relationship relationship = risk.addChild(newLayer.get(i));
            relationship.relevance = parameter.otherRiskFactor;
        }
        //增加显态节点，在显态节点上加入假阳性因子,每一轮和上一轮相连
        newLayer.getNodes().forEach(node -> {
            BayesNode observeNode = new ObserveNode();
            setUniqueId(observeNode, node.id, layerNum, observeNode.getType(), 0);
            observeNode.id = - node.id - 1;
            Relationship relationship = node.addChild(observeNode);

            double symptomRate = 0.5 - parameter.symptomRate > 0 ? parameter.symptomRate : 1 - parameter.symptomRate;
            symptomRate = parameter.symptomRate + (1 - 2 * Math.random()) * symptomRate;

            relationship.relevance = symptomRate;
            if (Math.random() < relationship.relevance && node.isPositive == 1) {
                observeNode.isPositive = 1;
            }

            double otherPositiveRate = parameter.otherPositiveRate;
            otherPositiveRate = 0.5 - otherPositiveRate > 0 ? otherPositiveRate : 1 - otherPositiveRate;
            otherPositiveRate = otherPositiveRate + (1 - 2 * Math.random()) * otherPositiveRate;
            if (Math.random() < otherPositiveRate) {
                observeNode.isPositive = 1;
            }

        });
        refreshInfection(newLayer, parameter);//刷新感染情况

        //输出感染总数
        int i = (int) layer.getNodes().stream().filter(node -> node.isPositive == 1).count();
        System.out.println(i);
        return newLayer;
    }

    private static void refreshInfection(Layer newLayer, Parameter parameter) {
        newLayer.getNodes().forEach(node -> {
            for (BayesNode parent : node.parents) {
                if (parent.isPositive == 1 && !(node.isPositive == 1)) {
                    Relationship relationship = parent.childernRelationshipMap.get(node.unique_id);
                    for (int i = 0; i < relationship.num; ++i) {
                        node.isPositive = Math.random() > relationship.relevance ? 0 : 1;
                        if (node.isPositive == 1) break;
                    }
                }
            }
        });
    }

    static int getCommonShift(int borderLength) {
        double random = Math.random();
        random = Math.pow(random, 0.1);
        return (int) ((Math.random() > 0.5 ? 1 - random : random - 1) * borderLength);
    }

    static int getSpecialShift(int borderLength) {
        double random = Math.random();
        return (int) ((Math.random() > 0.3 ? 1 - Math.pow(random, 0.1) : Math.pow(random, 0.1) - 1) * borderLength);

    }

    /**
     * 认为人是二维分布的，有个别人长期相见，其它人偶尔相见。
     * 首尾循环相邻的。
     *
     * @param layer
     * @param newLayer
     * @param parameter
     */
    private static void createPersonRelationShip(Layer layer, Layer newLayer, Parameter parameter) {
        double perturbation = Math.pow(Math.random(), 3);
        perturbation *= Math.random() > 0.5 ? -1 : 1;

        int borderLength = (int) Math.sqrt(layer.getNodes().size());
        int allSocial = (int) (parameter.socialBreadth * (1 + perturbation) * parameter.peopleNumber);
        for (int i = 0; i < allSocial; ++i) {
            int position = (int) (parameter.peopleNumber * Math.random());
            BayesNode oldNode = layer.get(position);
            int x = position / borderLength;
            int y = position % borderLength;
            int relX = 0, relY = 0;
            switch ((x + y) % 4) {
                case 0:
                    relX = x + getSpecialShift(borderLength);
                    relY = y + getCommonShift(borderLength);
                    break;
                case 1:
                    relX = x + getCommonShift(borderLength);
                    relY = y + getSpecialShift(borderLength);
                    break;
                case 2:
                    relX = x - getSpecialShift(borderLength);
                    relY = y + getCommonShift(borderLength);
                    break;
                case 3:
                    relX = x + getCommonShift(borderLength);
                    relY = y - getSpecialShift(borderLength);
                    break;
            }
            position = (relX * borderLength + relY) % parameter.peopleNumber;
            position = (position + parameter.peopleNumber) % parameter.peopleNumber;
            BayesNode newNode = newLayer.get(position);
            Relationship relationship = oldNode.addChild(newNode);
            if (relationship.parent == relationship.child) relationship.relevance = 1;
            else if (relationship.relevance < 0) {
                double random = Math.random();
                random = 1 - Math.pow(random, 0.3);
                double range = parameter.infectionRate > 0.5 ? 1 - parameter.infectionRate : parameter.infectionRate;
                double relevance = parameter.infectionRate + (Math.random() > 0.5 ? 1 : -1) * random * range;
                relationship.relevance = relevance;
            }
        }
    }

    public static Layer initLayer(Parameter parameter) {
        Layer layer = new Layer();
        for (int i = 0; i < parameter.peopleNumber; ++i) {
            BayesNode node = new PersonNode();
            node.id = i;
            if (Math.random() < parameter.initialPatientRate) {
                node.isPositive = 1;
            } else {
                node.isPositive = 0;
            }
            layer.add(node);
            setUniqueId(node, i, 0, node.getType(), 0);
        }
        return layer;
    }
}
