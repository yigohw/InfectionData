package com.data.generator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BIFBuilder {
    static String title = "network unknown {\n" +
            "}";
    static String variable = "variable %s {\n" +
            "  type discrete [ %s ] { %s };\n" +
            "}";

    static String singleProbability = "probability ( %s ) {\n" +
            "  table %s, %s;\n" +
            "}";
    static String conditionProbability = "probability ( %s ) {\n" +
            "%s" +
            "}";

    void addVariable(String name, String[] values) {
        String str = String.format(variable, name, values.length, String.join(", ", values));
        variableList.add(str);
    }

    void addVariable(String name) {
        String str = String.format(variable, name, 2, "false, true");
        variableList.add(str);
    }

    void addProbability(BayesNode node) {
        if (node.parents.size() == 0) {
            condTitleList.add(String.format(singleProbability, node.unique_id, 1 - node.probability, node.probability));
        } else {
            String name = "%s | %s";
            List<String> condition = new ArrayList<>();
            node.parents.forEach(parent -> condition.add(parent.unique_id));
            name = String.format(name, node.unique_id, String.join(", ", condition));

            StringBuilder builder = new StringBuilder();
            boolean[] flags = new boolean[node.parents.size()];
            Arrays.fill(flags, false);
            getProbability(node, builder, flags, 0);
            String probabilityInfo = builder.toString();

            conditionList.add(String.format(conditionProbability, name, probabilityInfo));


        }

    }

    private void getProbability(BayesNode node, StringBuilder builder, boolean[] flags, int index) {
        if (index == flags.length) {
            List<String> conditionString = new ArrayList<>();
            for (boolean cond : flags) {
                if (cond) {
                    conditionString.add("true");
                } else {
                    conditionString.add("false");
                }
            }
            double probability = 1;
            for (int i = 0; i < flags.length; ++i) {
                if (!flags[i]) continue;
                BayesNode parent = node.parents.get(i);
                try {

                    Relationship rel = node.parentRelationshipMap.get(parent.unique_id);
                    probability *= (1 - rel.relevance);
                }catch (Exception r){
                    r.printStackTrace();
                }
            }
            String condition = "  (%s) %s, %s;\n";
            condition = String.format(condition, String.join(", ", conditionString), probability, 1 - probability);
            builder.append(condition);
        } else {
            getProbability(node, builder, flags, index + 1);
            boolean[] newFlags = flags.clone();
            newFlags[index] = true;
            getProbability(node, builder, newFlags, index + 1);
        }
    }

    public BIFBuilder() {
    }

    @Override
    public String toString() {
        List<String> all = new ArrayList<>();
        all.add(title);
        all.addAll(variableList);
        all.addAll(condTitleList);
        all.addAll(conditionList);
        return String.join("\n", all) + "\n";
    }

    List<String> variableList = new ArrayList<>();
    List<String> condTitleList = new ArrayList<>();
    List<String> conditionList = new ArrayList<>();
}
