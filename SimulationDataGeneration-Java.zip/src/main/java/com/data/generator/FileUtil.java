package com.data.generator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

public class FileUtil {
	public static final String getResource(String file) {
		return FileUtil.class.getClassLoader().getResource(file).getPath();
	}
	/**
	 * 这个文件是否存在
	 * 
	 * @param filename
	 * @return
	 */
	static public boolean isFileExists(String filename) {
		return new File(ToLinuxPath(filename)).exists();
	}
	/**
	 * 复制文件
	 * @param sourcePath
	 * @param aimPath
	 */
	static public void copyFile(String sourcePath, String aimPath) {
		
		FileInputStream fi = null;
		FileOutputStream fo = null;
		FileChannel in = null;
		FileChannel out = null;
		try {
			fi = new FileInputStream(sourcePath);
			makeFile(aimPath, false);
			fo = new FileOutputStream(aimPath);
			in = fi.getChannel();// 得到对应的文件通道
			out = fo.getChannel();// 得到对应的文件通道
			in.transferTo(0, in.size(), out);// 连接两个通道，并且从in通道读取，然后写入out通道
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fi.close();
				in.close();
				fo.close();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	/**
	 * 获取一个文件的后缀名
	 * 
	 * @param filename
	 * @return
	 */
	static public String getPostfix(String filename) {
		int l = filename.length() - 1;
		for (; 0 <= l; --l) {
			if (filename.charAt(l) == '.') {
				if (l == filename.length() - 1) {
					return "";
				}
				return filename.substring(l + 1, filename.length());
			}
		}
		return "";
	}
	static public String getFileFolder(String filename)
	{
		return filename.substring(0,filename.length()-getFilename(filename).length());
	}

	/**
	 * 删除一个文件的后缀名，标志是"."
	 * 
	 * @param filename
	 * @return
	 */
	static public String deleteFilePostfix(String filename) {
		int l = filename.length() - 1;
		for (; 0 <= l; --l) {
			if (filename.charAt(l) == '.') {
				return filename.substring(0, l);
			}
		}
		return filename;
	}

	/**
	 * 将文件路径换成Linux文件路径
	 * 
	 * @param path
	 */
	static public String ToLinuxPath(String path) {
		return path.replace('\\', '/');
	}

	/**
	 * 获取文件名，包含后缀名
	 * 
	 * @param path
	 * @return
	 */
	static public String getFilename(String path) {
		int l = path.length();
		int i = 0;
		for (; i < l; ++i) {
			if (path.charAt(l - i - 1) == File.separatorChar
					|| path.charAt(l - i - 1) == '\\')
				break;
		}
		String result = path.substring(l - i, l);
		return result;
	}

	/**
	 * 生成一个文件或文件夹
	 * 
	 * @param absolutePath
	 * @param isDictory
	 */
	static public void makeFile(String absolutePath, boolean isDictory) {

		if (absolutePath.isEmpty()) {
			return;
		}
		absolutePath = ToLinuxPath(absolutePath);
		File thefile = new File(absolutePath);
		if (thefile.exists()) {
			return;
		} else {
			int l = absolutePath.length();
			String filePath;
			int i = 0;
			for (; i < l; ++i) {
				if (absolutePath.charAt(l - i - 1) == '/'
						|| absolutePath.charAt(l - i - 1) == '\\')
					break;
			}
			if (i == l) {
				--i;
			}
			filePath = absolutePath.substring(0, l - i - 1);
			makeFile(filePath, true);

			try {
				if (isDictory)
					thefile.mkdirs();
				else
					thefile.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * 从一个路径中剥离出一个完整的文件名
	 * 
	 * @param filename
	 * @return
	 */
	static public String getBareFileName(String filename) {
		filename = FileUtil.getFilename(filename);
		filename = FileUtil.deleteFilePostfix(filename);
		return filename;
	}

	/**
	 * 删除文件或文件夹
	 * 
	 * @param file
	 */
	static public void deleteFile(File file) {
		if (file.isFile()) {
			file.delete();
			return;
		}
		if (file.isDirectory()) {
			File[] childFiles = file.listFiles();
			if (childFiles == null || childFiles.length == 0) {
				file.delete();
				return;
			}

			for (int i = 0; i < childFiles.length; i++) {
				deleteFile(childFiles[i]);
			}
			file.delete();
		}
	}

	/**
	 * 删除文件或文件夹
	 * 
	 * @param absolutePath
	 */
	static public void deleteFile(String absolutePath) {
		deleteFile(new File(absolutePath));
	}

	/**
	 * 遍历文件夹，将得到的文件的绝对路径写入filelist
	 * 
	 * @param filePath
	 * @param filelist
	 * @param postfix
	 */
	static public void getFilesNames(String filePath,
			ArrayList<String> filelist, String postfix) {
		File root = new File(filePath);
		File[] files = root.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				getFilesNames(file.getAbsolutePath(), filelist, postfix);
			} else {
				String pathString = file.getAbsolutePath();
				if (pathString.length() > postfix.length()) {
					if (postfix.equals(pathString.substring(pathString.length()
							- postfix.length(), pathString.length()))) {
						filelist.add(pathString);
					}
				}
			}
		}
	}

	/**
	 * 遍历文件夹，将得到的文件的绝对路径写入filelist
	 * 
	 * @param filePath
	 * @param filelist
	 */
	static public void getFilesNames(String filePath, ArrayList<String> filelist) {
		File root = new File(filePath);
		File[] files = root.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				getFilesNames(file.getAbsolutePath(), filelist);
			} else {
				filelist.add(file.getAbsolutePath());

			}
		}
	}
}
