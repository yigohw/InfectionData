package com.data.generator;

import java.util.*;

/**
 * 将风险评估分为两种，一是社交关系带来的，二是其它因素带来的。
 * 在其它传染病中，第二种因素要单独建模，比如粪口传播，传播地就很重要。
 * 每一种传染病，可能需要单独剥离出不同的其它因素，融入到贝叶斯网络。
 * <p>
 * 在不确定的情况下，可以把其它因素统一起来。比如去过疫区，风险增加0.1，发烧增加0.3。但是这个人有肺结核，发烧很正常，风险减少0.2。
 * 具体情况需要具体的概率模型。
 * <p>
 * 在贝叶斯网络中，先有一个表观风险，然后通过推导出新的风险评估。然后再引入核酸检测得到最终风险。
 * <p>
 * 本质上，其它风险是其它信息，社交关系带来的是社交信息，核酸检测带来的是高质量信息。每一个操作都是在对信息综合利用后重新评估风险、找到人们潜在的感染关系。
 */
public abstract class BayesNode {
    int id;

    abstract String getType();
    int isPositive = -1;

    List<BayesNode> parents = new ArrayList<>();
    List<BayesNode> childern = new ArrayList<>();
    Map<String, Relationship> parentRelationshipMap = new HashMap<String, Relationship>();
    Map<String, Relationship> childernRelationshipMap = new HashMap<String, Relationship>();
    int otherInfo;
    String remarks;
    boolean otherFlag = false;

    public Relationship addChild(BayesNode newNode) {

        Relationship relationship = childernRelationshipMap.get(newNode.unique_id);
        if (relationship == null) {
            relationship = new Relationship();
            relationship.child = newNode;
            relationship.parent = this;
            childernRelationshipMap.put(newNode.unique_id, relationship);
            newNode.parentRelationshipMap.put(unique_id, relationship);
            childern.add(newNode);
            newNode.parents.add(this);
        } else {
        }
        relationship.num++;
        return relationship;
    }

    int flag = -1;
    //输出时使用
    String unique_id;
    double probability;

    public void clearParent() {
        parentRelationshipMap.clear();
        parents.clear();
    }
    public void removeChild(BayesNode node) {
        childernRelationshipMap.remove(node.unique_id);
        childern.remove(node);
    }

    public void removeParent(BayesNode node) {
        parentRelationshipMap.remove(node.unique_id);
        parents.remove(node);
    }
}
