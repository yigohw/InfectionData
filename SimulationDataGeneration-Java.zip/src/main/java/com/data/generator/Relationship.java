package com.data.generator;

public class Relationship {
    /**
     * 对本人的相关性为100%
     */
    double relevance=-1;
    int num = 0;
    BayesNode parent;
    BayesNode child;
}
