package com.data.generator;

public class ObserveNode extends BayesNode{
    @Override
    String getType() {
        return "observe";
    }
    double observedValue = 0;
}
