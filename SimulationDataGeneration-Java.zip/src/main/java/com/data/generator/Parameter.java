package com.data.generator;


public class Parameter {
    /**
     * 真实数据
     */


    /**
     * 总人数。一般取平方数
     */
    int peopleNumber = 36;//10000感染率0.001时比较敏感
    /**
     * 感染轮数
     */
    int spreadLayersNumber = 10;
    /**
     * 初始感染概率
     */
    double initialPatientRate = 0.01;//36时0.04

    /**
     * （2）
     * 社交感染概率,社交导致传染的烈度。比如0.2，那么每次社交感染的概率差不多在0.1~0.3。如果取值0.7，则每次大概在0.5~0.9
     */
    double infectionRate = 0.4;
    /**
     * （2）
     * 平均社交广度，平均每天每人的社交量
     */
    double socialBreadth = 2;

    /**
     * （5）
     * 感染者下一天出现增加症状的概率（更多可以确诊的信息）
     */
    double symptomRate = 0.3;
    /**
     * （5）
     * 感染者下一天症状明显度增加的程度的均值（单次增加的信息量，比如做了个抗体检测，可能就上升一大截。 做了个核酸检测，上升更多）
     */
    double symptomFactor = 0.2;

    /**
     * (1)
     * 莫名其妙染病的概率
     */
    double hideRiskFactor = 0.001;

    /**
     * (3)
     * 其它明面风险指数。
     * 比如去过疫区，指数上升。
     */
    double otherRiskRate = 0.01;
    /**
     * (3)
     * 其它明面风险指数，带来的风险有多高。
     */
    double otherRiskFactor = 0.1;

    /**
     * 其它原因导致会被误判的概率。假阳性，比如有其它病
     */
    double otherPositiveRate = 0.01;


    /**
     * 解码可见数据
     */
    /**
     * 社交遗忘率。收集数据时，很多社交关系会有意无意地收集不到
     */
    double socialForgetRate = 0.2;
    /**
     * 计算机可见的层数
     */
    int visibleLayers=24;
    /**
     * 默认初始感染概率
     */
    double visibleInfectionRate = 0.1;

}
