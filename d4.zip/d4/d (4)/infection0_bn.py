from bayesian.factor_graph import *
from bayesian.bbn import *

dictionary_person_0_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_0_7_0(person_0_7_0):
    return dictionary_person_0_7_0[person_0_7_0]

dictionary_person_1_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_1_7_0(person_1_7_0):
    return dictionary_person_1_7_0[person_1_7_0]

dictionary_person_2_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_2_7_0(person_2_7_0):
    return dictionary_person_2_7_0[person_2_7_0]

dictionary_person_3_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_3_7_0(person_3_7_0):
    return dictionary_person_3_7_0[person_3_7_0]

dictionary_person_4_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_4_7_0(person_4_7_0):
    return dictionary_person_4_7_0[person_4_7_0]

dictionary_person_5_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_5_7_0(person_5_7_0):
    return dictionary_person_5_7_0[person_5_7_0]

dictionary_person_6_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_6_7_0(person_6_7_0):
    return dictionary_person_6_7_0[person_6_7_0]

dictionary_person_7_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_7_7_0(person_7_7_0):
    return dictionary_person_7_7_0[person_7_7_0]

dictionary_person_8_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_8_7_0(person_8_7_0):
    return dictionary_person_8_7_0[person_8_7_0]

dictionary_person_9_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_9_7_0(person_9_7_0):
    return dictionary_person_9_7_0[person_9_7_0]

dictionary_person_10_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_10_7_0(person_10_7_0):
    return dictionary_person_10_7_0[person_10_7_0]

dictionary_person_11_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_11_7_0(person_11_7_0):
    return dictionary_person_11_7_0[person_11_7_0]

dictionary_person_12_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_12_7_0(person_12_7_0):
    return dictionary_person_12_7_0[person_12_7_0]

dictionary_person_13_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_13_7_0(person_13_7_0):
    return dictionary_person_13_7_0[person_13_7_0]

dictionary_person_14_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_14_7_0(person_14_7_0):
    return dictionary_person_14_7_0[person_14_7_0]

dictionary_person_15_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_15_7_0(person_15_7_0):
    return dictionary_person_15_7_0[person_15_7_0]

dictionary_person_16_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_16_7_0(person_16_7_0):
    return dictionary_person_16_7_0[person_16_7_0]

dictionary_person_17_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_17_7_0(person_17_7_0):
    return dictionary_person_17_7_0[person_17_7_0]

dictionary_person_18_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_18_7_0(person_18_7_0):
    return dictionary_person_18_7_0[person_18_7_0]

dictionary_person_19_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_19_7_0(person_19_7_0):
    return dictionary_person_19_7_0[person_19_7_0]

dictionary_person_20_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_20_7_0(person_20_7_0):
    return dictionary_person_20_7_0[person_20_7_0]

dictionary_person_21_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_21_7_0(person_21_7_0):
    return dictionary_person_21_7_0[person_21_7_0]

dictionary_person_22_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_22_7_0(person_22_7_0):
    return dictionary_person_22_7_0[person_22_7_0]

dictionary_person_23_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_23_7_0(person_23_7_0):
    return dictionary_person_23_7_0[person_23_7_0]

dictionary_person_24_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_24_7_0(person_24_7_0):
    return dictionary_person_24_7_0[person_24_7_0]

dictionary_person_25_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_25_7_0(person_25_7_0):
    return dictionary_person_25_7_0[person_25_7_0]

dictionary_person_26_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_26_7_0(person_26_7_0):
    return dictionary_person_26_7_0[person_26_7_0]

dictionary_person_27_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_27_7_0(person_27_7_0):
    return dictionary_person_27_7_0[person_27_7_0]

dictionary_person_28_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_28_7_0(person_28_7_0):
    return dictionary_person_28_7_0[person_28_7_0]

dictionary_person_29_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_29_7_0(person_29_7_0):
    return dictionary_person_29_7_0[person_29_7_0]

dictionary_person_30_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_30_7_0(person_30_7_0):
    return dictionary_person_30_7_0[person_30_7_0]

dictionary_person_31_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_31_7_0(person_31_7_0):
    return dictionary_person_31_7_0[person_31_7_0]

dictionary_person_32_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_32_7_0(person_32_7_0):
    return dictionary_person_32_7_0[person_32_7_0]

dictionary_person_33_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_33_7_0(person_33_7_0):
    return dictionary_person_33_7_0[person_33_7_0]

dictionary_person_34_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_34_7_0(person_34_7_0):
    return dictionary_person_34_7_0[person_34_7_0]

dictionary_person_35_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_35_7_0(person_35_7_0):
    return dictionary_person_35_7_0[person_35_7_0]

dictionary_risk_0_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_8_0(risk_0_8_0):
    return dictionary_risk_0_8_0[risk_0_8_0]

dictionary_risk_1_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_8_0(risk_1_8_0):
    return dictionary_risk_1_8_0[risk_1_8_0]

dictionary_risk_2_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_8_0(risk_2_8_0):
    return dictionary_risk_2_8_0[risk_2_8_0]

dictionary_risk_2_8_1 = {'true': 1.0, 'false': 0.0}

def f_risk_2_8_1(risk_2_8_1):
    return dictionary_risk_2_8_1[risk_2_8_1]

dictionary_risk_3_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_8_0(risk_3_8_0):
    return dictionary_risk_3_8_0[risk_3_8_0]

dictionary_risk_4_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_8_0(risk_4_8_0):
    return dictionary_risk_4_8_0[risk_4_8_0]

dictionary_risk_5_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_8_0(risk_5_8_0):
    return dictionary_risk_5_8_0[risk_5_8_0]

dictionary_risk_6_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_8_0(risk_6_8_0):
    return dictionary_risk_6_8_0[risk_6_8_0]

dictionary_risk_7_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_8_0(risk_7_8_0):
    return dictionary_risk_7_8_0[risk_7_8_0]

dictionary_risk_8_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_8_0(risk_8_8_0):
    return dictionary_risk_8_8_0[risk_8_8_0]

dictionary_risk_9_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_8_0(risk_9_8_0):
    return dictionary_risk_9_8_0[risk_9_8_0]

dictionary_risk_10_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_8_0(risk_10_8_0):
    return dictionary_risk_10_8_0[risk_10_8_0]

dictionary_risk_11_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_8_0(risk_11_8_0):
    return dictionary_risk_11_8_0[risk_11_8_0]

dictionary_risk_12_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_8_0(risk_12_8_0):
    return dictionary_risk_12_8_0[risk_12_8_0]

dictionary_risk_13_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_8_0(risk_13_8_0):
    return dictionary_risk_13_8_0[risk_13_8_0]

dictionary_risk_14_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_8_0(risk_14_8_0):
    return dictionary_risk_14_8_0[risk_14_8_0]

dictionary_risk_15_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_8_0(risk_15_8_0):
    return dictionary_risk_15_8_0[risk_15_8_0]

dictionary_risk_16_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_8_0(risk_16_8_0):
    return dictionary_risk_16_8_0[risk_16_8_0]

dictionary_risk_17_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_8_0(risk_17_8_0):
    return dictionary_risk_17_8_0[risk_17_8_0]

dictionary_risk_18_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_8_0(risk_18_8_0):
    return dictionary_risk_18_8_0[risk_18_8_0]

dictionary_risk_19_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_8_0(risk_19_8_0):
    return dictionary_risk_19_8_0[risk_19_8_0]

dictionary_risk_20_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_8_0(risk_20_8_0):
    return dictionary_risk_20_8_0[risk_20_8_0]

dictionary_risk_21_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_8_0(risk_21_8_0):
    return dictionary_risk_21_8_0[risk_21_8_0]

dictionary_risk_22_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_8_0(risk_22_8_0):
    return dictionary_risk_22_8_0[risk_22_8_0]

dictionary_risk_23_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_8_0(risk_23_8_0):
    return dictionary_risk_23_8_0[risk_23_8_0]

dictionary_risk_24_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_8_0(risk_24_8_0):
    return dictionary_risk_24_8_0[risk_24_8_0]

dictionary_risk_25_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_8_0(risk_25_8_0):
    return dictionary_risk_25_8_0[risk_25_8_0]

dictionary_risk_26_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_8_0(risk_26_8_0):
    return dictionary_risk_26_8_0[risk_26_8_0]

dictionary_risk_27_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_8_0(risk_27_8_0):
    return dictionary_risk_27_8_0[risk_27_8_0]

dictionary_risk_28_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_8_0(risk_28_8_0):
    return dictionary_risk_28_8_0[risk_28_8_0]

dictionary_risk_29_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_8_0(risk_29_8_0):
    return dictionary_risk_29_8_0[risk_29_8_0]

dictionary_risk_30_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_8_0(risk_30_8_0):
    return dictionary_risk_30_8_0[risk_30_8_0]

dictionary_risk_31_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_8_0(risk_31_8_0):
    return dictionary_risk_31_8_0[risk_31_8_0]

dictionary_risk_32_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_8_0(risk_32_8_0):
    return dictionary_risk_32_8_0[risk_32_8_0]

dictionary_risk_33_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_8_0(risk_33_8_0):
    return dictionary_risk_33_8_0[risk_33_8_0]

dictionary_risk_34_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_8_0(risk_34_8_0):
    return dictionary_risk_34_8_0[risk_34_8_0]

dictionary_risk_35_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_8_0(risk_35_8_0):
    return dictionary_risk_35_8_0[risk_35_8_0]

dictionary_risk_0_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_9_0(risk_0_9_0):
    return dictionary_risk_0_9_0[risk_0_9_0]

dictionary_risk_1_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_9_0(risk_1_9_0):
    return dictionary_risk_1_9_0[risk_1_9_0]

dictionary_risk_2_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_9_0(risk_2_9_0):
    return dictionary_risk_2_9_0[risk_2_9_0]

dictionary_risk_3_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_9_0(risk_3_9_0):
    return dictionary_risk_3_9_0[risk_3_9_0]

dictionary_risk_4_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_9_0(risk_4_9_0):
    return dictionary_risk_4_9_0[risk_4_9_0]

dictionary_risk_5_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_9_0(risk_5_9_0):
    return dictionary_risk_5_9_0[risk_5_9_0]

dictionary_risk_6_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_9_0(risk_6_9_0):
    return dictionary_risk_6_9_0[risk_6_9_0]

dictionary_risk_7_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_9_0(risk_7_9_0):
    return dictionary_risk_7_9_0[risk_7_9_0]

dictionary_risk_8_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_9_0(risk_8_9_0):
    return dictionary_risk_8_9_0[risk_8_9_0]

dictionary_risk_9_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_9_0(risk_9_9_0):
    return dictionary_risk_9_9_0[risk_9_9_0]

dictionary_risk_10_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_9_0(risk_10_9_0):
    return dictionary_risk_10_9_0[risk_10_9_0]

dictionary_risk_11_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_9_0(risk_11_9_0):
    return dictionary_risk_11_9_0[risk_11_9_0]

dictionary_risk_12_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_9_0(risk_12_9_0):
    return dictionary_risk_12_9_0[risk_12_9_0]

dictionary_risk_13_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_9_0(risk_13_9_0):
    return dictionary_risk_13_9_0[risk_13_9_0]

dictionary_risk_14_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_9_0(risk_14_9_0):
    return dictionary_risk_14_9_0[risk_14_9_0]

dictionary_risk_15_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_9_0(risk_15_9_0):
    return dictionary_risk_15_9_0[risk_15_9_0]

dictionary_risk_16_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_9_0(risk_16_9_0):
    return dictionary_risk_16_9_0[risk_16_9_0]

dictionary_risk_17_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_9_0(risk_17_9_0):
    return dictionary_risk_17_9_0[risk_17_9_0]

dictionary_risk_18_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_9_0(risk_18_9_0):
    return dictionary_risk_18_9_0[risk_18_9_0]

dictionary_risk_19_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_9_0(risk_19_9_0):
    return dictionary_risk_19_9_0[risk_19_9_0]

dictionary_risk_20_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_9_0(risk_20_9_0):
    return dictionary_risk_20_9_0[risk_20_9_0]

dictionary_risk_21_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_9_0(risk_21_9_0):
    return dictionary_risk_21_9_0[risk_21_9_0]

dictionary_risk_22_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_9_0(risk_22_9_0):
    return dictionary_risk_22_9_0[risk_22_9_0]

dictionary_risk_23_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_9_0(risk_23_9_0):
    return dictionary_risk_23_9_0[risk_23_9_0]

dictionary_risk_24_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_9_0(risk_24_9_0):
    return dictionary_risk_24_9_0[risk_24_9_0]

dictionary_risk_25_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_9_0(risk_25_9_0):
    return dictionary_risk_25_9_0[risk_25_9_0]

dictionary_risk_26_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_9_0(risk_26_9_0):
    return dictionary_risk_26_9_0[risk_26_9_0]

dictionary_risk_27_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_9_0(risk_27_9_0):
    return dictionary_risk_27_9_0[risk_27_9_0]

dictionary_risk_28_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_9_0(risk_28_9_0):
    return dictionary_risk_28_9_0[risk_28_9_0]

dictionary_risk_29_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_9_0(risk_29_9_0):
    return dictionary_risk_29_9_0[risk_29_9_0]

dictionary_risk_30_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_9_0(risk_30_9_0):
    return dictionary_risk_30_9_0[risk_30_9_0]

dictionary_risk_31_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_9_0(risk_31_9_0):
    return dictionary_risk_31_9_0[risk_31_9_0]

dictionary_risk_31_9_1 = {'true': 1.0, 'false': 0.0}

def f_risk_31_9_1(risk_31_9_1):
    return dictionary_risk_31_9_1[risk_31_9_1]

dictionary_risk_32_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_9_0(risk_32_9_0):
    return dictionary_risk_32_9_0[risk_32_9_0]

dictionary_risk_33_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_9_0(risk_33_9_0):
    return dictionary_risk_33_9_0[risk_33_9_0]

dictionary_risk_34_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_9_0(risk_34_9_0):
    return dictionary_risk_34_9_0[risk_34_9_0]

dictionary_risk_35_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_9_0(risk_35_9_0):
    return dictionary_risk_35_9_0[risk_35_9_0]

dictionary_risk_0_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_10_0(risk_0_10_0):
    return dictionary_risk_0_10_0[risk_0_10_0]

dictionary_risk_1_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_10_0(risk_1_10_0):
    return dictionary_risk_1_10_0[risk_1_10_0]

dictionary_risk_2_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_10_0(risk_2_10_0):
    return dictionary_risk_2_10_0[risk_2_10_0]

dictionary_risk_3_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_10_0(risk_3_10_0):
    return dictionary_risk_3_10_0[risk_3_10_0]

dictionary_risk_4_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_10_0(risk_4_10_0):
    return dictionary_risk_4_10_0[risk_4_10_0]

dictionary_risk_5_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_10_0(risk_5_10_0):
    return dictionary_risk_5_10_0[risk_5_10_0]

dictionary_risk_6_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_10_0(risk_6_10_0):
    return dictionary_risk_6_10_0[risk_6_10_0]

dictionary_risk_7_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_10_0(risk_7_10_0):
    return dictionary_risk_7_10_0[risk_7_10_0]

dictionary_risk_8_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_10_0(risk_8_10_0):
    return dictionary_risk_8_10_0[risk_8_10_0]

dictionary_risk_9_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_10_0(risk_9_10_0):
    return dictionary_risk_9_10_0[risk_9_10_0]

dictionary_risk_10_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_10_0(risk_10_10_0):
    return dictionary_risk_10_10_0[risk_10_10_0]

dictionary_risk_11_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_10_0(risk_11_10_0):
    return dictionary_risk_11_10_0[risk_11_10_0]

dictionary_risk_11_10_1 = {'true': 1.0, 'false': 0.0}

def f_risk_11_10_1(risk_11_10_1):
    return dictionary_risk_11_10_1[risk_11_10_1]

dictionary_risk_12_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_10_0(risk_12_10_0):
    return dictionary_risk_12_10_0[risk_12_10_0]

dictionary_risk_13_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_10_0(risk_13_10_0):
    return dictionary_risk_13_10_0[risk_13_10_0]

dictionary_risk_14_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_10_0(risk_14_10_0):
    return dictionary_risk_14_10_0[risk_14_10_0]

dictionary_risk_15_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_10_0(risk_15_10_0):
    return dictionary_risk_15_10_0[risk_15_10_0]

dictionary_risk_16_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_10_0(risk_16_10_0):
    return dictionary_risk_16_10_0[risk_16_10_0]

dictionary_risk_17_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_10_0(risk_17_10_0):
    return dictionary_risk_17_10_0[risk_17_10_0]

dictionary_risk_17_10_1 = {'true': 1.0, 'false': 0.0}

def f_risk_17_10_1(risk_17_10_1):
    return dictionary_risk_17_10_1[risk_17_10_1]

dictionary_risk_18_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_10_0(risk_18_10_0):
    return dictionary_risk_18_10_0[risk_18_10_0]

dictionary_risk_19_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_10_0(risk_19_10_0):
    return dictionary_risk_19_10_0[risk_19_10_0]

dictionary_risk_20_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_10_0(risk_20_10_0):
    return dictionary_risk_20_10_0[risk_20_10_0]

dictionary_risk_21_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_10_0(risk_21_10_0):
    return dictionary_risk_21_10_0[risk_21_10_0]

dictionary_risk_22_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_10_0(risk_22_10_0):
    return dictionary_risk_22_10_0[risk_22_10_0]

dictionary_risk_23_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_10_0(risk_23_10_0):
    return dictionary_risk_23_10_0[risk_23_10_0]

dictionary_risk_24_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_10_0(risk_24_10_0):
    return dictionary_risk_24_10_0[risk_24_10_0]

dictionary_risk_25_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_10_0(risk_25_10_0):
    return dictionary_risk_25_10_0[risk_25_10_0]

dictionary_risk_26_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_10_0(risk_26_10_0):
    return dictionary_risk_26_10_0[risk_26_10_0]

dictionary_risk_26_10_1 = {'true': 1.0, 'false': 0.0}

def f_risk_26_10_1(risk_26_10_1):
    return dictionary_risk_26_10_1[risk_26_10_1]

dictionary_risk_27_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_10_0(risk_27_10_0):
    return dictionary_risk_27_10_0[risk_27_10_0]

dictionary_risk_28_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_10_0(risk_28_10_0):
    return dictionary_risk_28_10_0[risk_28_10_0]

dictionary_risk_29_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_10_0(risk_29_10_0):
    return dictionary_risk_29_10_0[risk_29_10_0]

dictionary_risk_30_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_10_0(risk_30_10_0):
    return dictionary_risk_30_10_0[risk_30_10_0]

dictionary_risk_31_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_10_0(risk_31_10_0):
    return dictionary_risk_31_10_0[risk_31_10_0]

dictionary_risk_32_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_10_0(risk_32_10_0):
    return dictionary_risk_32_10_0[risk_32_10_0]

dictionary_risk_33_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_10_0(risk_33_10_0):
    return dictionary_risk_33_10_0[risk_33_10_0]

dictionary_risk_34_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_10_0(risk_34_10_0):
    return dictionary_risk_34_10_0[risk_34_10_0]

dictionary_risk_35_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_10_0(risk_35_10_0):
    return dictionary_risk_35_10_0[risk_35_10_0]

dictionary_observe_0_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4792375017980738, ('false', 'false'): 1.0, ('true', 'true'): 0.5207624982019262}
def f_observe_0_7_0(person_0_7_0, observe_0_7_0):
    return dictionary_observe_0_7_0[(person_0_7_0, observe_0_7_0)]

dictionary_observe_1_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.840412514737908, ('false', 'false'): 1.0, ('true', 'true'): 0.159587485262092}
def f_observe_1_7_0(person_1_7_0, observe_1_7_0):
    return dictionary_observe_1_7_0[(person_1_7_0, observe_1_7_0)]

dictionary_observe_2_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4800464721271097, ('false', 'false'): 1.0, ('true', 'true'): 0.5199535278728903}
def f_observe_2_7_0(person_2_7_0, observe_2_7_0):
    return dictionary_observe_2_7_0[(person_2_7_0, observe_2_7_0)]

dictionary_observe_3_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5420089631010188, ('false', 'false'): 1.0, ('true', 'true'): 0.45799103689898124}
def f_observe_3_7_0(person_3_7_0, observe_3_7_0):
    return dictionary_observe_3_7_0[(person_3_7_0, observe_3_7_0)]

dictionary_observe_4_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7858546284617787, ('false', 'false'): 1.0, ('true', 'true'): 0.21414537153822133}
def f_observe_4_7_0(person_4_7_0, observe_4_7_0):
    return dictionary_observe_4_7_0[(person_4_7_0, observe_4_7_0)]

dictionary_observe_5_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9645231179326621, ('false', 'false'): 1.0, ('true', 'true'): 0.0354768820673379}
def f_observe_5_7_0(person_5_7_0, observe_5_7_0):
    return dictionary_observe_5_7_0[(person_5_7_0, observe_5_7_0)]

dictionary_observe_6_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4147973152018156, ('false', 'false'): 1.0, ('true', 'true'): 0.5852026847981844}
def f_observe_6_7_0(person_6_7_0, observe_6_7_0):
    return dictionary_observe_6_7_0[(person_6_7_0, observe_6_7_0)]

dictionary_observe_7_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6760658281157924, ('false', 'false'): 1.0, ('true', 'true'): 0.3239341718842076}
def f_observe_7_7_0(person_7_7_0, observe_7_7_0):
    return dictionary_observe_7_7_0[(person_7_7_0, observe_7_7_0)]

dictionary_observe_8_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6207085722168064, ('false', 'false'): 1.0, ('true', 'true'): 0.3792914277831936}
def f_observe_8_7_0(person_8_7_0, observe_8_7_0):
    return dictionary_observe_8_7_0[(person_8_7_0, observe_8_7_0)]

dictionary_observe_9_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8659480490565172, ('false', 'false'): 1.0, ('true', 'true'): 0.13405195094348277}
def f_observe_9_7_0(person_9_7_0, observe_9_7_0):
    return dictionary_observe_9_7_0[(person_9_7_0, observe_9_7_0)]

dictionary_observe_10_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9422824472506848, ('false', 'false'): 1.0, ('true', 'true'): 0.057717552749315226}
def f_observe_10_7_0(person_10_7_0, observe_10_7_0):
    return dictionary_observe_10_7_0[(person_10_7_0, observe_10_7_0)]

dictionary_observe_11_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6176397147830058, ('false', 'false'): 1.0, ('true', 'true'): 0.38236028521699417}
def f_observe_11_7_0(person_11_7_0, observe_11_7_0):
    return dictionary_observe_11_7_0[(person_11_7_0, observe_11_7_0)]

dictionary_observe_12_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9191655620238847, ('false', 'false'): 1.0, ('true', 'true'): 0.08083443797611534}
def f_observe_12_7_0(person_12_7_0, observe_12_7_0):
    return dictionary_observe_12_7_0[(person_12_7_0, observe_12_7_0)]

dictionary_observe_13_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7560817671881394, ('false', 'false'): 1.0, ('true', 'true'): 0.24391823281186065}
def f_observe_13_7_0(person_13_7_0, observe_13_7_0):
    return dictionary_observe_13_7_0[(person_13_7_0, observe_13_7_0)]

dictionary_observe_14_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.42732436621002634, ('false', 'false'): 1.0, ('true', 'true'): 0.5726756337899737}
def f_observe_14_7_0(person_14_7_0, observe_14_7_0):
    return dictionary_observe_14_7_0[(person_14_7_0, observe_14_7_0)]

dictionary_observe_15_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8966948894690717, ('false', 'false'): 1.0, ('true', 'true'): 0.10330511053092828}
def f_observe_15_7_0(person_15_7_0, observe_15_7_0):
    return dictionary_observe_15_7_0[(person_15_7_0, observe_15_7_0)]

dictionary_observe_16_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7360313293025803, ('false', 'false'): 1.0, ('true', 'true'): 0.2639686706974197}
def f_observe_16_7_0(person_16_7_0, observe_16_7_0):
    return dictionary_observe_16_7_0[(person_16_7_0, observe_16_7_0)]

dictionary_observe_17_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8734287702136438, ('false', 'false'): 1.0, ('true', 'true'): 0.12657122978635615}
def f_observe_17_7_0(person_17_7_0, observe_17_7_0):
    return dictionary_observe_17_7_0[(person_17_7_0, observe_17_7_0)]

dictionary_observe_18_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7388132676199222, ('false', 'false'): 1.0, ('true', 'true'): 0.26118673238007784}
def f_observe_18_7_0(person_18_7_0, observe_18_7_0):
    return dictionary_observe_18_7_0[(person_18_7_0, observe_18_7_0)]

dictionary_observe_19_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4731956821152826, ('false', 'false'): 1.0, ('true', 'true'): 0.5268043178847174}
def f_observe_19_7_0(person_19_7_0, observe_19_7_0):
    return dictionary_observe_19_7_0[(person_19_7_0, observe_19_7_0)]

dictionary_observe_20_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.960706043053182, ('false', 'false'): 1.0, ('true', 'true'): 0.03929395694681803}
def f_observe_20_7_0(person_20_7_0, observe_20_7_0):
    return dictionary_observe_20_7_0[(person_20_7_0, observe_20_7_0)]

dictionary_observe_21_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5540320542448314, ('false', 'false'): 1.0, ('true', 'true'): 0.4459679457551686}
def f_observe_21_7_0(person_21_7_0, observe_21_7_0):
    return dictionary_observe_21_7_0[(person_21_7_0, observe_21_7_0)]

dictionary_observe_22_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.49415901408957963, ('false', 'false'): 1.0, ('true', 'true'): 0.5058409859104204}
def f_observe_22_7_0(person_22_7_0, observe_22_7_0):
    return dictionary_observe_22_7_0[(person_22_7_0, observe_22_7_0)]

dictionary_observe_23_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9743318352719894, ('false', 'false'): 1.0, ('true', 'true'): 0.02566816472801059}
def f_observe_23_7_0(person_23_7_0, observe_23_7_0):
    return dictionary_observe_23_7_0[(person_23_7_0, observe_23_7_0)]

dictionary_observe_24_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9659331940837061, ('false', 'false'): 1.0, ('true', 'true'): 0.03406680591629385}
def f_observe_24_7_0(person_24_7_0, observe_24_7_0):
    return dictionary_observe_24_7_0[(person_24_7_0, observe_24_7_0)]

dictionary_observe_25_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5104953846793351, ('false', 'false'): 1.0, ('true', 'true'): 0.4895046153206649}
def f_observe_25_7_0(person_25_7_0, observe_25_7_0):
    return dictionary_observe_25_7_0[(person_25_7_0, observe_25_7_0)]

dictionary_observe_26_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5873368057634769, ('false', 'false'): 1.0, ('true', 'true'): 0.4126631942365231}
def f_observe_26_7_0(person_26_7_0, observe_26_7_0):
    return dictionary_observe_26_7_0[(person_26_7_0, observe_26_7_0)]

dictionary_observe_27_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.49033760442499075, ('false', 'false'): 1.0, ('true', 'true'): 0.5096623955750093}
def f_observe_27_7_0(person_27_7_0, observe_27_7_0):
    return dictionary_observe_27_7_0[(person_27_7_0, observe_27_7_0)]

dictionary_observe_28_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4901420304810258, ('false', 'false'): 1.0, ('true', 'true'): 0.5098579695189742}
def f_observe_28_7_0(person_28_7_0, observe_28_7_0):
    return dictionary_observe_28_7_0[(person_28_7_0, observe_28_7_0)]

dictionary_observe_29_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8195991956184003, ('false', 'false'): 1.0, ('true', 'true'): 0.18040080438159967}
def f_observe_29_7_0(person_29_7_0, observe_29_7_0):
    return dictionary_observe_29_7_0[(person_29_7_0, observe_29_7_0)]

dictionary_observe_30_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7005265562586468, ('false', 'false'): 1.0, ('true', 'true'): 0.2994734437413532}
def f_observe_30_7_0(person_30_7_0, observe_30_7_0):
    return dictionary_observe_30_7_0[(person_30_7_0, observe_30_7_0)]

dictionary_observe_31_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6289045783216936, ('false', 'false'): 1.0, ('true', 'true'): 0.37109542167830645}
def f_observe_31_7_0(person_31_7_0, observe_31_7_0):
    return dictionary_observe_31_7_0[(person_31_7_0, observe_31_7_0)]

dictionary_observe_32_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4533839064243351, ('false', 'false'): 1.0, ('true', 'true'): 0.5466160935756649}
def f_observe_32_7_0(person_32_7_0, observe_32_7_0):
    return dictionary_observe_32_7_0[(person_32_7_0, observe_32_7_0)]

dictionary_observe_33_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9185103724521495, ('false', 'false'): 1.0, ('true', 'true'): 0.0814896275478505}
def f_observe_33_7_0(person_33_7_0, observe_33_7_0):
    return dictionary_observe_33_7_0[(person_33_7_0, observe_33_7_0)]

dictionary_observe_34_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8993460321876285, ('false', 'false'): 1.0, ('true', 'true'): 0.10065396781237146}
def f_observe_34_7_0(person_34_7_0, observe_34_7_0):
    return dictionary_observe_34_7_0[(person_34_7_0, observe_34_7_0)]

dictionary_observe_35_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7281882595301813, ('false', 'false'): 1.0, ('true', 'true'): 0.2718117404698187}
def f_observe_35_7_0(person_35_7_0, observe_35_7_0):
    return dictionary_observe_35_7_0[(person_35_7_0, observe_35_7_0)]

dictionary_person_0_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.4514111278096298, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7162944476622677, ('false', 'false', 'true', 'false', 'false'): 0.5176728079549204, ('false', 'true', 'false', 'true', 'true'): 0.4519597166818201, ('false', 'false', 'true', 'false', 'true'): 0.48232719204507957, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5480402833181799, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5171551351469655, ('false', 'true', 'true', 'false', 'true'): 0.7160104581203881, ('false', 'true', 'true', 'false', 'false'): 0.2839895418796119, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.48284486485303446, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5485888721903702, ('false', 'true', 'true', 'true', 'false'): 0.28370555233773226}
def f_person_0_8_0(person_0_7_0, person_1_7_0, person_35_7_0, risk_0_8_0, person_0_8_0):
    return dictionary_person_0_8_0[(person_0_7_0, person_1_7_0, person_35_7_0, risk_0_8_0, person_0_8_0)]

dictionary_observe_0_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8648585592461397, ('false', 'false'): 1.0, ('true', 'true'): 0.13514144075386025}
def f_observe_0_8_0(person_0_8_0, observe_0_8_0):
    return dictionary_observe_0_8_0[(person_0_8_0, observe_0_8_0)]

dictionary_person_1_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7520342252937969, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.24796577470620307, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7512821910685031, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.24871780893149686, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_1_8_0(person_1_7_0, person_31_7_0, risk_1_8_0, person_1_8_0):
    return dictionary_person_1_8_0[(person_1_7_0, person_31_7_0, risk_1_8_0, person_1_8_0)]

dictionary_observe_1_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7545511092122609, ('false', 'false'): 1.0, ('true', 'true'): 0.24544889078773913}
def f_observe_1_8_0(person_1_8_0, observe_1_8_0):
    return dictionary_observe_1_8_0[(person_1_8_0, observe_1_8_0)]

dictionary_person_2_8_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.7062782545841975, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.406325862457112, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.4491690973095591, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.5343067237885992, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.4962440564778747, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.6726585975107928, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.3260311374115407, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.327014061086718, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.5491752407489499, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.5513822849754163, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.30280549909608034, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.4662275829351894, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.5037559435221253, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.32635749490644717, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.16179101416719832, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.5508309026904409, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.5930804634053451, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.999, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.8991, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.6739688625884592, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.6968913922962159, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.8200522587396304, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.2725249491864723, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.7053927377597136, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.7065719763296133, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.0010000000000000009, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.2946072622402865, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.3273414024892072, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.3031086077037841, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.5337724170648106, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.4947524691431981, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.2727977469334057, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.09999999999999998, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.1799477412603696, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.672985938913282, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.17976779351910924, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.593674137542888, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.4486177150245837, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.45027503428533544, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.6736425050935528, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.8202322064808908, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.8382089858328017, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.9, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.7272022530665943, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.5052475308568019, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.5057422833259451, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.7056873450219538, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.4656932762114008, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.6971945009039197, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.8380470328656673, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.40691953659465485, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.4942577166740549, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.2934280236703867, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.2943126549780462, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.5042521875786032, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.4957478124213968, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.45082475925105014, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.7274750508135277, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.16195296713433266, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.2937217454158025, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.5497249657146646}
def f_person_2_8_0(person_2_7_0, person_8_7_0, person_1_7_0, person_3_7_0, risk_2_8_0, risk_2_8_1, person_2_8_0):
    return dictionary_person_2_8_0[(person_2_7_0, person_8_7_0, person_1_7_0, person_3_7_0, risk_2_8_0, risk_2_8_1, person_2_8_0)]

dictionary_observe_2_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5253433698072012, ('false', 'false'): 1.0, ('true', 'true'): 0.4746566301927988}
def f_observe_2_8_0(person_2_8_0, observe_2_8_0):
    return dictionary_observe_2_8_0[(person_2_8_0, observe_2_8_0)]

dictionary_person_3_8_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.24567560002382346, ('false', 'true', 'false', 'false', 'false', 'true'): 0.5209690705570722, ('false', 'true', 'true', 'false', 'true', 'true'): 0.6924011848830316, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.30759881511696835, ('false', 'true', 'false', 'false', 'false', 'false'): 0.4790309294429278, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.4785518985134849, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.3572299763673372, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.7543243999761765, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.7540784784546312, ('false', 'false', 'true', 'false', 'false', 'false'): 0.6427700236326628, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.3825964380783114, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.3822138416402331, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.6174035619216887, ('false', 'false', 'false', 'true', 'false', 'true'): 0.20131161776288953, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.5214481014865151, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.24592152154536884, ('false', 'false', 'true', 'false', 'true', 'false'): 0.6421272536090301, ('false', 'true', 'true', 'false', 'false', 'false'): 0.30790672183880713, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.48662704967431925, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.6177861583597669, ('false', 'false', 'false', 'true', 'true', 'false'): 0.7978896938548734, ('false', 'false', 'false', 'true', 'false', 'false'): 0.7986883822371105, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.5133729503256808, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.48714042262464496, ('false', 'false', 'true', 'false', 'true', 'true'): 0.3578727463909699, ('false', 'false', 'false', 'true', 'true', 'true'): 0.2021103061451266, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.6920932781611928, ('false', 'false', 'true', 'true', 'true', 'false'): 0.512859577375355}
def f_person_3_8_0(person_3_7_0, person_2_7_0, person_33_7_0, person_9_7_0, risk_3_8_0, person_3_8_0):
    return dictionary_person_3_8_0[(person_3_7_0, person_2_7_0, person_33_7_0, person_9_7_0, risk_3_8_0, person_3_8_0)]

dictionary_observe_3_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9585208559962859, ('false', 'false'): 1.0, ('true', 'true'): 0.04147914400371411}
def f_observe_3_8_0(person_3_8_0, observe_3_8_0):
    return dictionary_observe_3_8_0[(person_3_8_0, observe_3_8_0)]

dictionary_person_4_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.29277665702268596, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.3519468815305761, ('false', 'false', 'true', 'false', 'false'): 0.9172517094228922, ('false', 'true', 'false', 'true', 'true'): 0.2934838803656633, ('false', 'false', 'true', 'false', 'true'): 0.08274829057710775, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7065161196343367, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.9163344577134693, ('false', 'true', 'true', 'false', 'true'): 0.3512981797102863, ('false', 'true', 'true', 'false', 'false'): 0.6487018202897137, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.08366554228653067, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.707223342977314, ('false', 'true', 'true', 'true', 'false'): 0.6480531184694239}
def f_person_4_8_0(person_4_7_0, person_10_7_0, person_34_7_0, risk_4_8_0, person_4_8_0):
    return dictionary_person_4_8_0[(person_4_7_0, person_10_7_0, person_34_7_0, risk_4_8_0, person_4_8_0)]

dictionary_observe_4_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8731578085094581, ('false', 'false'): 1.0, ('true', 'true'): 0.12684219149054188}
def f_observe_4_8_0(person_4_8_0, observe_4_8_0):
    return dictionary_observe_4_8_0[(person_4_8_0, observe_4_8_0)]

dictionary_person_5_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3506044598597351, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5891635651308642, ('false', 'false', 'true', 'false', 'false'): 0.6332776514955135, ('false', 'true', 'false', 'true', 'true'): 0.3512538553998754, ('false', 'false', 'true', 'false', 'true'): 0.3667223485044865, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6487461446001246, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.632644373844018, ('false', 'true', 'true', 'false', 'true'): 0.5887523174483126, ('false', 'true', 'true', 'false', 'false'): 0.4112476825516874, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.36735562615598205, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6493955401402649, ('false', 'true', 'true', 'true', 'false'): 0.41083643486913574}
def f_person_5_8_0(person_5_7_0, person_6_7_0, person_3_7_0, risk_5_8_0, person_5_8_0):
    return dictionary_person_5_8_0[(person_5_7_0, person_6_7_0, person_3_7_0, risk_5_8_0, person_5_8_0)]

dictionary_observe_5_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7927509262890573, ('false', 'false'): 1.0, ('true', 'true'): 0.2072490737109427}
def f_observe_5_8_0(person_5_8_0, observe_5_8_0):
    return dictionary_observe_5_8_0[(person_5_8_0, observe_5_8_0)]

dictionary_person_6_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.44682071525156086, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6162378860910145, ('false', 'false', 'true', 'false', 'false'): 0.6944335602585824, ('false', 'true', 'false', 'true', 'true'): 0.44737389453630927, ('false', 'false', 'true', 'false', 'true'): 0.3055664397414176, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5526261054636907, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6937391266983238, ('false', 'true', 'true', 'false', 'true'): 0.6158537398308452, ('false', 'true', 'true', 'false', 'false'): 0.3841462601691547, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3062608733016762, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5531792847484391, ('false', 'true', 'true', 'true', 'false'): 0.38376211390898557}
def f_person_6_8_0(person_6_7_0, person_0_7_0, person_12_7_0, risk_6_8_0, person_6_8_0):
    return dictionary_person_6_8_0[(person_6_7_0, person_0_7_0, person_12_7_0, risk_6_8_0, person_6_8_0)]

dictionary_observe_6_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9127830535839305, ('false', 'false'): 1.0, ('true', 'true'): 0.08721694641606947}
def f_observe_6_8_0(person_6_8_0, observe_6_8_0):
    return dictionary_observe_6_8_0[(person_6_8_0, observe_6_8_0)]

dictionary_person_7_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.42371660809774414, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7042087824651101, ('false', 'false', 'true', 'false', 'false'): 0.5137876763416243, ('false', 'true', 'false', 'true', 'true'): 0.42429289148964644, ('false', 'false', 'true', 'false', 'true'): 0.48621232365837574, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5757071085103536, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5132738886652827, ('false', 'true', 'true', 'false', 'true'): 0.7039126951602703, ('false', 'true', 'true', 'false', 'false'): 0.2960873048397296, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4867261113347173, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5762833919022559, ('false', 'true', 'true', 'true', 'false'): 0.2957912175348899}
def f_person_7_8_0(person_7_7_0, person_13_7_0, person_8_7_0, risk_7_8_0, person_7_8_0):
    return dictionary_person_7_8_0[(person_7_7_0, person_13_7_0, person_8_7_0, risk_7_8_0, person_7_8_0)]

dictionary_observe_7_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5343716919917069, ('false', 'false'): 1.0, ('true', 'true'): 0.46562830800829313}
def f_observe_7_8_0(person_7_8_0, observe_7_8_0):
    return dictionary_observe_7_8_0[(person_7_8_0, observe_7_8_0)]

dictionary_person_8_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.49455545209038576, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7010038491805377, ('false', 'false', 'true', 'false', 'false'): 0.5921429907663172, ('false', 'true', 'false', 'true', 'true'): 0.49506089663829533, ('false', 'false', 'true', 'false', 'true'): 0.40785700923368284, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5049391033617047, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5915508477755509, ('false', 'true', 'true', 'false', 'true'): 0.700704553734272, ('false', 'true', 'true', 'false', 'false'): 0.29929544626572807, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4084491522244491, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5054445479096142, ('false', 'true', 'true', 'true', 'false'): 0.29899615081946235}
def f_person_8_8_0(person_8_7_0, person_9_7_0, person_7_7_0, risk_8_8_0, person_8_8_0):
    return dictionary_person_8_8_0[(person_8_7_0, person_9_7_0, person_7_7_0, risk_8_8_0, person_8_8_0)]

dictionary_observe_8_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8844308035729926, ('false', 'false'): 1.0, ('true', 'true'): 0.11556919642700736}
def f_observe_8_8_0(person_8_8_0, observe_8_8_0):
    return dictionary_observe_8_8_0[(person_8_8_0, observe_8_8_0)]

dictionary_person_9_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.538263485716296, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.461736514283704, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5377252222305797, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4622747777694203, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_9_8_0(person_9_7_0, person_10_7_0, risk_9_8_0, person_9_8_0):
    return dictionary_person_9_8_0[(person_9_7_0, person_10_7_0, risk_9_8_0, person_9_8_0)]

dictionary_observe_9_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8167979437932409, ('false', 'false'): 1.0, ('true', 'true'): 0.1832020562067591}
def f_observe_9_8_0(person_9_8_0, observe_9_8_0):
    return dictionary_observe_9_8_0[(person_9_8_0, observe_9_8_0)]

dictionary_person_10_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.520178627792854, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.47982137220714605, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5196584491650611, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4803415508349389, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_10_8_0(person_10_7_0, person_11_7_0, risk_10_8_0, person_10_8_0):
    return dictionary_person_10_8_0[(person_10_7_0, person_11_7_0, risk_10_8_0, person_10_8_0)]

dictionary_observe_10_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8815518207517925, ('false', 'false'): 1.0, ('true', 'true'): 0.1184481792482075}
def f_observe_10_8_0(person_10_8_0, observe_10_8_0):
    return dictionary_observe_10_8_0[(person_10_8_0, observe_10_8_0)]

dictionary_person_11_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5024384604329754, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.49756153956702465, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5019360219725424, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4980639780274576, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_11_8_0(person_11_7_0, person_12_7_0, risk_11_8_0, person_11_8_0):
    return dictionary_person_11_8_0[(person_11_7_0, person_12_7_0, risk_11_8_0, person_11_8_0)]

dictionary_observe_11_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8612693683259448, ('false', 'false'): 1.0, ('true', 'true'): 0.1387306316740552}
def f_observe_11_8_0(person_11_8_0, observe_11_8_0):
    return dictionary_observe_11_8_0[(person_11_8_0, observe_11_8_0)]

dictionary_person_12_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.22718633627911267, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.556473940246101, ('false', 'false', 'true', 'false', 'false'): 0.5744852227975473, ('false', 'true', 'false', 'true', 'true'): 0.2279591499428335, ('false', 'false', 'true', 'false', 'true'): 0.4255147772024527, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7720408500571665, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5739107375747498, ('false', 'true', 'true', 'false', 'true'): 0.5560299702163172, ('false', 'true', 'true', 'false', 'false'): 0.4439700297836828, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.42608926242525025, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7728136637208873, ('false', 'true', 'true', 'true', 'false'): 0.4435260597538991}
def f_person_12_8_0(person_12_7_0, person_11_7_0, person_15_7_0, risk_12_8_0, person_12_8_0):
    return dictionary_person_12_8_0[(person_12_7_0, person_11_7_0, person_15_7_0, risk_12_8_0, person_12_8_0)]

dictionary_observe_12_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7032442891306383, ('false', 'false'): 1.0, ('true', 'true'): 0.2967557108693617}
def f_observe_12_8_0(person_12_8_0, observe_12_8_0):
    return dictionary_observe_12_8_0[(person_12_8_0, observe_12_8_0)]

dictionary_person_13_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6728290398791045, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3271709601208955, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6721562108392254, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3278437891607746, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_13_8_0(person_13_7_0, person_14_7_0, risk_13_8_0, person_13_8_0):
    return dictionary_person_13_8_0[(person_13_7_0, person_14_7_0, risk_13_8_0, person_13_8_0)]

dictionary_observe_13_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6257128338723947, ('false', 'false'): 1.0, ('true', 'true'): 0.37428716612760526}
def f_observe_13_8_0(person_13_8_0, observe_13_8_0):
    return dictionary_observe_13_8_0[(person_13_8_0, observe_13_8_0)]

dictionary_person_14_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6825970152295833, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.31740298477041673, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6819144182143537, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3180855817856463, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_14_8_0(person_14_7_0, person_20_7_0, risk_14_8_0, person_14_8_0):
    return dictionary_person_14_8_0[(person_14_7_0, person_20_7_0, risk_14_8_0, person_14_8_0)]

dictionary_observe_14_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6439059509515077, ('false', 'false'): 1.0, ('true', 'true'): 0.3560940490484923}
def f_observe_14_8_0(person_14_8_0, observe_14_8_0):
    return dictionary_observe_14_8_0[(person_14_8_0, observe_14_8_0)]

dictionary_person_15_8_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.1860644742206262, ('false', 'true', 'false', 'false', 'false', 'true'): 0.3323486043745352, ('false', 'true', 'true', 'false', 'true', 'true'): 0.5859368639158506, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.4140631360841494, ('false', 'true', 'false', 'false', 'false', 'false'): 0.6676513956254648, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.6669837442298394, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.3792005582350966, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.8139355257793738, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.8137492750544282, ('false', 'false', 'true', 'false', 'false', 'false'): 0.6207994417649034, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.30001754578913564, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.2997175282433465, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.6999824542108644, ('false', 'false', 'false', 'true', 'false', 'true'): 0.5506374318171309, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.3330162557701606, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.18625072494557177, ('false', 'false', 'true', 'false', 'true', 'false'): 0.6201786423231386, ('false', 'true', 'true', 'false', 'false', 'false'): 0.41447761369784725, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.7210359685220316, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.7002824717566535, ('false', 'false', 'false', 'true', 'true', 'false'): 0.4489132056146863, ('false', 'false', 'false', 'true', 'false', 'false'): 0.4493625681828691, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.2789640314779685, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.7213149325535095, ('false', 'false', 'true', 'false', 'true', 'true'): 0.3798213576768614, ('false', 'false', 'false', 'true', 'true', 'true'): 0.5510867943853137, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.5855223863021528, ('false', 'false', 'true', 'true', 'true', 'false'): 0.2786850674464905}
def f_person_15_8_0(person_15_7_0, person_17_7_0, person_9_7_0, person_21_7_0, risk_15_8_0, person_15_8_0):
    return dictionary_person_15_8_0[(person_15_7_0, person_17_7_0, person_9_7_0, person_21_7_0, risk_15_8_0, person_15_8_0)]

dictionary_observe_15_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6482701680228686, ('false', 'false'): 1.0, ('true', 'true'): 0.35172983197713137}
def f_observe_15_8_0(person_15_8_0, observe_15_8_0):
    return dictionary_observe_15_8_0[(person_15_8_0, observe_15_8_0)]

dictionary_person_16_8_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.8393974137132937, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.3324842619705034, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.5893354487881239, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.5960822198057796, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.4102538866606642, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.6038963961233215, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.7517529104179648, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.10741948546606335, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.16587471392995673, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.261574769843336, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.6045008970203418, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.15812218300818606, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.7258749490152525, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.39610360387667853, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.16076334963634267, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.06487024014637716, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.4039177801942204, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.27439945043518266, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.668183921951448, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.6675157380294966, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.8925805145339366, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.7633553011177129, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.902818410936836, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.1579640608251779, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.7520011575075469, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.8926879340194027, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.33181607804855195, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.24799884249245313, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.24824708958203517, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.23664469888228712, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.2741250509847475, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.391079740904751, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.23640805418340483, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.09718158906316399, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.8341252860700432, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.06493517532169886, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.41066455121187606, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.3954991029796582, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.6085287878831321, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.8392366503636574, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.9350648246783011, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.9351297598536228, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.7635919458165952, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.6089202590952489, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.7386868049265074, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.8342911607839733, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.5897461133393358, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.841877816991814, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.9029155925258991, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.7256005495648173, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.26131319507349265, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.10731206598059728, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.16570883921602678, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.5964861375859738, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.4035138624140262, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.7384252301566641, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.8420359391748221, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.09708440747410083, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.16060258628670632, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.39147121211686786}
def f_person_16_8_0(person_16_7_0, person_22_7_0, person_17_7_0, person_18_7_0, person_10_7_0, risk_16_8_0, person_16_8_0):
    return dictionary_person_16_8_0[(person_16_7_0, person_22_7_0, person_17_7_0, person_18_7_0, person_10_7_0, risk_16_8_0, person_16_8_0)]

dictionary_observe_16_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6724734871479878, ('false', 'false'): 1.0, ('true', 'true'): 0.3275265128520122}
def f_observe_16_8_0(person_16_8_0, observe_16_8_0):
    return dictionary_observe_16_8_0[(person_16_8_0, observe_16_8_0)]

dictionary_person_17_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.30720730910423155, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5178686964920401, ('false', 'false', 'true', 'false', 'false'): 0.6966209715656413, ('false', 'true', 'false', 'true', 'true'): 0.3079001017951273, ('false', 'false', 'true', 'false', 'true'): 0.3033790284343587, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6920998982048727, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6959243505940756, ('false', 'true', 'true', 'false', 'true'): 0.5173860825746148, ('false', 'true', 'true', 'false', 'false'): 0.48261391742538523, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.30407564940592435, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6927926908957684, ('false', 'true', 'true', 'true', 'false'): 0.48213130350795985}
def f_person_17_8_0(person_17_7_0, person_24_7_0, person_11_7_0, risk_17_8_0, person_17_8_0):
    return dictionary_person_17_8_0[(person_17_7_0, person_24_7_0, person_11_7_0, risk_17_8_0, person_17_8_0)]

dictionary_observe_17_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7128352202054866, ('false', 'false'): 1.0, ('true', 'true'): 0.2871647797945134}
def f_observe_17_8_0(person_17_8_0, observe_17_8_0):
    return dictionary_observe_17_8_0[(person_17_8_0, observe_17_8_0)]

dictionary_person_18_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.356689008098266, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7080135216353003, ('false', 'false', 'true', 'false', 'false'): 0.4543350895618883, ('false', 'true', 'false', 'true', 'true'): 0.3573323190901677, ('false', 'false', 'true', 'false', 'true'): 0.5456649104381117, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6426676809098323, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.4538807544723264, ('false', 'true', 'true', 'false', 'true'): 0.7077212428781785, ('false', 'true', 'true', 'false', 'false'): 0.2922787571218215, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5461192455276735, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.643310991901734, ('false', 'true', 'true', 'true', 'false'): 0.29198647836469965}
def f_person_18_8_0(person_18_7_0, person_19_7_0, person_16_7_0, risk_18_8_0, person_18_8_0):
    return dictionary_person_18_8_0[(person_18_7_0, person_19_7_0, person_16_7_0, risk_18_8_0, person_18_8_0)]

dictionary_observe_18_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4035931906184237, ('false', 'false'): 1.0, ('true', 'true'): 0.5964068093815763}
def f_observe_18_8_0(person_18_8_0, observe_18_8_0):
    return dictionary_observe_18_8_0[(person_18_8_0, observe_18_8_0)]

dictionary_person_19_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.47439201068314407, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6834691756128795, ('false', 'false', 'true', 'false', 'false'): 0.6028212631832204, ('false', 'true', 'false', 'true', 'true'): 0.47491761867246096, ('false', 'false', 'true', 'false', 'true'): 0.3971787368167796, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.525082381327539, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6022184419200372, ('false', 'true', 'true', 'false', 'true'): 0.6831523279408203, ('false', 'true', 'true', 'false', 'false'): 0.3168476720591797, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.39778155807996285, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5256079893168559, ('false', 'true', 'true', 'true', 'false'): 0.3165308243871205}
def f_person_19_8_0(person_19_7_0, person_12_7_0, person_20_7_0, risk_19_8_0, person_19_8_0):
    return dictionary_person_19_8_0[(person_19_7_0, person_12_7_0, person_20_7_0, risk_19_8_0, person_19_8_0)]

dictionary_observe_19_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4139439863651897, ('false', 'false'): 1.0, ('true', 'true'): 0.5860560136348103}
def f_observe_19_8_0(person_19_8_0, observe_19_8_0):
    return dictionary_observe_19_8_0[(person_19_8_0, observe_19_8_0)]

dictionary_person_20_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.530150402354236, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.46984959764576395, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5296202519518818, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4703797480481182, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_20_8_0(person_20_7_0, person_8_7_0, risk_20_8_0, person_20_8_0):
    return dictionary_person_20_8_0[(person_20_7_0, person_8_7_0, risk_20_8_0, person_20_8_0)]

dictionary_observe_20_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.613066482718201, ('false', 'false'): 1.0, ('true', 'true'): 0.38693351728179903}
def f_observe_20_8_0(person_20_8_0, observe_20_8_0):
    return dictionary_observe_20_8_0[(person_20_8_0, observe_20_8_0)]

dictionary_person_21_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7183090168455468, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2816909831544532, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7175907078287013, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.28240929217129873, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_21_8_0(person_21_7_0, person_22_7_0, risk_21_8_0, person_21_8_0):
    return dictionary_person_21_8_0[(person_21_7_0, person_22_7_0, risk_21_8_0, person_21_8_0)]

dictionary_observe_21_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6483614590737846, ('false', 'false'): 1.0, ('true', 'true'): 0.3516385409262154}
def f_observe_21_8_0(person_21_8_0, observe_21_8_0):
    return dictionary_observe_21_8_0[(person_21_8_0, observe_21_8_0)]

dictionary_person_22_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5028670404539071, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.49713295954609293, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5023641734134532, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4976358265865468, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_22_8_0(person_22_7_0, person_21_7_0, risk_22_8_0, person_22_8_0):
    return dictionary_person_22_8_0[(person_22_7_0, person_21_7_0, risk_22_8_0, person_22_8_0)]

dictionary_observe_22_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5999140491296895, ('false', 'false'): 1.0, ('true', 'true'): 0.4000859508703105}
def f_observe_22_8_0(person_22_8_0, observe_22_8_0):
    return dictionary_observe_22_8_0[(person_22_8_0, observe_22_8_0)]

dictionary_person_23_8_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.2307703656198847, ('false', 'true', 'false', 'false', 'false', 'true'): 0.3733641048006664, ('false', 'true', 'true', 'false', 'true', 'true'): 0.5754936236739818, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.42450637632601823, ('false', 'true', 'false', 'false', 'false', 'false'): 0.6266358951993336, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.6260092593041343, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.32188482835238674, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.7692296343801153, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.7689986330131284, ('false', 'false', 'true', 'false', 'false', 'false'): 0.6781151716476133, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.34065211433864345, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.3403114622243048, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.6593478856613566, ('false', 'false', 'false', 'true', 'false', 'true'): 0.45637950690602935, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.3739907406958657, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.23100136698687157, ('false', 'false', 'true', 'false', 'true', 'false'): 0.6774370564759656, ('false', 'true', 'true', 'false', 'false', 'false'): 0.4249313076336519, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.631362696014422, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.6596885377756951, ('false', 'false', 'false', 'true', 'true', 'false'): 0.5430768726008767, ('false', 'false', 'false', 'true', 'false', 'false'): 0.5436204930939706, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.36863730398557804, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.6317313333184076, ('false', 'false', 'true', 'false', 'true', 'true'): 0.32256294352403436, ('false', 'false', 'false', 'true', 'true', 'true'): 0.45692312739912333, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.5750686923663482, ('false', 'false', 'true', 'true', 'true', 'false'): 0.36826866668159247}
def f_person_23_8_0(person_23_7_0, person_28_7_0, person_24_7_0, person_29_7_0, risk_23_8_0, person_23_8_0):
    return dictionary_person_23_8_0[(person_23_7_0, person_28_7_0, person_24_7_0, person_29_7_0, risk_23_8_0, person_23_8_0)]

dictionary_observe_23_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.41070903846169315, ('false', 'false'): 1.0, ('true', 'true'): 0.5892909615383068}
def f_observe_23_8_0(person_23_8_0, observe_23_8_0):
    return dictionary_observe_23_8_0[(person_23_8_0, observe_23_8_0)]

dictionary_person_24_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7425082624865564, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.25749173751344356, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7417657542240699, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2582342457759301, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_24_8_0(person_24_7_0, person_26_7_0, risk_24_8_0, person_24_8_0):
    return dictionary_person_24_8_0[(person_24_7_0, person_26_7_0, risk_24_8_0, person_24_8_0)]

dictionary_observe_24_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8474024271477227, ('false', 'false'): 1.0, ('true', 'true'): 0.15259757285227726}
def f_observe_24_8_0(person_24_8_0, observe_24_8_0):
    return dictionary_observe_24_8_0[(person_24_8_0, observe_24_8_0)]

dictionary_person_25_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3664723343997104, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7269089622884028, ('false', 'false', 'true', 'false', 'false'): 0.43149560304472034, ('false', 'true', 'false', 'true', 'true'): 0.3671058620653107, ('false', 'false', 'true', 'false', 'true'): 0.5685043969552797, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6328941379346893, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.4310641074416756, ('false', 'true', 'true', 'false', 'true'): 0.7266355978862891, ('false', 'true', 'true', 'false', 'false'): 0.2733644021137109, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5689358925583243, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6335276656002896, ('false', 'true', 'true', 'true', 'false'): 0.27309103771159715}
def f_person_25_8_0(person_25_7_0, person_31_7_0, person_19_7_0, risk_25_8_0, person_25_8_0):
    return dictionary_person_25_8_0[(person_25_7_0, person_31_7_0, person_19_7_0, risk_25_8_0, person_25_8_0)]

dictionary_observe_25_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8204762343088574, ('false', 'false'): 1.0, ('true', 'true'): 0.1795237656911426}
def f_observe_25_8_0(person_25_8_0, observe_25_8_0):
    return dictionary_observe_25_8_0[(person_25_8_0, observe_25_8_0)]

dictionary_person_26_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3629080758098484, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.627713190061534, ('false', 'false', 'true', 'false', 'false'): 0.5849383036546653, ('false', 'true', 'false', 'true', 'true'): 0.36354516773403855, ('false', 'false', 'true', 'false', 'true'): 0.41506169634533474, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6364548322659614, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5843533653510106, ('false', 'true', 'true', 'false', 'true'): 0.6273405305921261, ('false', 'true', 'true', 'false', 'false'): 0.37265946940787387, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.41564663464898943, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6370919241901516, ('false', 'true', 'true', 'true', 'false'): 0.37228680993846597}
def f_person_26_8_0(person_26_7_0, person_25_7_0, person_27_7_0, risk_26_8_0, person_26_8_0):
    return dictionary_person_26_8_0[(person_26_7_0, person_25_7_0, person_27_7_0, risk_26_8_0, person_26_8_0)]

dictionary_observe_26_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.785376762424608, ('false', 'false'): 1.0, ('true', 'true'): 0.21462323757539203}
def f_observe_26_8_0(person_26_8_0, observe_26_8_0):
    return dictionary_observe_26_8_0[(person_26_8_0, observe_26_8_0)]

dictionary_person_27_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_27_8_0(person_27_7_0, risk_27_8_0, person_27_8_0):
    return dictionary_person_27_8_0[(person_27_7_0, risk_27_8_0, person_27_8_0)]

dictionary_observe_27_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8577603382232476, ('false', 'false'): 1.0, ('true', 'true'): 0.1422396617767524}
def f_observe_27_8_0(person_27_8_0, observe_27_8_0):
    return dictionary_observe_27_8_0[(person_27_8_0, observe_27_8_0)]

dictionary_person_28_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.47139242810217463, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7763808188335786, ('false', 'false', 'true', 'false', 'false'): 0.4234578467859683, ('false', 'true', 'false', 'true', 'true'): 0.4719210356740725, ('false', 'false', 'true', 'false', 'true'): 0.5765421532140317, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5280789643259275, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.4230343889391823, ('false', 'true', 'true', 'false', 'true'): 0.7761569758093879, ('false', 'true', 'true', 'false', 'false'): 0.22384302419061206, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5769656110608177, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5286075718978254, ('false', 'true', 'true', 'true', 'false'): 0.22361918116642143}
def f_person_28_8_0(person_28_7_0, person_22_7_0, person_29_7_0, risk_28_8_0, person_28_8_0):
    return dictionary_person_28_8_0[(person_28_7_0, person_22_7_0, person_29_7_0, risk_28_8_0, person_28_8_0)]

dictionary_observe_28_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8062434018096564, ('false', 'false'): 1.0, ('true', 'true'): 0.19375659819034363}
def f_observe_28_8_0(person_28_8_0, observe_28_8_0):
    return dictionary_observe_28_8_0[(person_28_8_0, observe_28_8_0)]

dictionary_person_29_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.470196685346415, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5722622268989597, ('false', 'false', 'true', 'false', 'false'): 0.8081601741582897, ('false', 'true', 'false', 'true', 'true'): 0.4707264886610686, ('false', 'false', 'true', 'false', 'true'): 0.19183982584171033, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5292735113389314, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8073520139841314, ('false', 'true', 'true', 'false', 'true'): 0.5718340609599196, ('false', 'true', 'true', 'false', 'false'): 0.4281659390400804, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.19264798601586863, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.529803314653585, ('false', 'true', 'true', 'true', 'false'): 0.4277377731010403}
def f_person_29_8_0(person_29_7_0, person_23_7_0, person_30_7_0, risk_29_8_0, person_29_8_0):
    return dictionary_person_29_8_0[(person_29_7_0, person_23_7_0, person_30_7_0, risk_29_8_0, person_29_8_0)]

dictionary_observe_29_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6350779527066177, ('false', 'false'): 1.0, ('true', 'true'): 0.3649220472933823}
def f_observe_29_8_0(person_29_8_0, observe_29_8_0):
    return dictionary_observe_29_8_0[(person_29_8_0, observe_29_8_0)]

dictionary_person_30_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.4759435984231186, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6094313498090081, ('false', 'false', 'true', 'false', 'false'): 0.7460258258927825, ('false', 'true', 'false', 'true', 'true'): 0.47646765482469555, ('false', 'false', 'true', 'false', 'true'): 0.25397417410721745, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5235323451753044, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7452798000668898, ('false', 'true', 'true', 'false', 'true'): 0.6090403901992074, ('false', 'true', 'true', 'false', 'false'): 0.39095960980079264, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.25472019993311024, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5240564015768814, ('false', 'true', 'true', 'true', 'false'): 0.39056865019099185}
def f_person_30_8_0(person_30_7_0, person_29_7_0, person_31_7_0, risk_30_8_0, person_30_8_0):
    return dictionary_person_30_8_0[(person_30_7_0, person_29_7_0, person_31_7_0, risk_30_8_0, person_30_8_0)]

dictionary_observe_30_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4369461610266301, ('false', 'false'): 1.0, ('true', 'true'): 0.5630538389733699}
def f_observe_30_8_0(person_30_8_0, observe_30_8_0):
    return dictionary_observe_30_8_0[(person_30_8_0, observe_30_8_0)]

dictionary_person_31_8_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.18559384227010198, ('false', 'true', 'false', 'false', 'false', 'true'): 0.45860791538765966, ('false', 'true', 'true', 'false', 'true', 'true'): 0.6141881986744088, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.38581180132559123, ('false', 'true', 'false', 'false', 'false', 'false'): 0.5413920846123403, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.540850692527728, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.28665747006358566, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.814406157729898, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.814220378108006, ('false', 'false', 'true', 'false', 'false', 'false'): 0.7133425299364143, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.2604353646326877, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.260174929268055, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.7395646353673123, ('false', 'false', 'false', 'true', 'false', 'true'): 0.5189523969136519, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.459149307472272, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.18577962189199398, ('false', 'false', 'true', 'false', 'true', 'false'): 0.712629187406478, ('false', 'true', 'true', 'false', 'false', 'false'): 0.38619799932491616, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.6568482857945364, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.7398250707319449, ('false', 'false', 'false', 'true', 'true', 'false'): 0.4805665554832617, ('false', 'false', 'false', 'true', 'false', 'false'): 0.4810476030863481, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.34315171420546364, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.6571914375087418, ('false', 'false', 'true', 'false', 'true', 'true'): 0.28737081259352204, ('false', 'false', 'false', 'true', 'true', 'true'): 0.5194334445167383, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.6138020006750838, ('false', 'false', 'true', 'true', 'true', 'false'): 0.3428085624912582}
def f_person_31_8_0(person_31_7_0, person_1_7_0, person_19_7_0, person_32_7_0, risk_31_8_0, person_31_8_0):
    return dictionary_person_31_8_0[(person_31_7_0, person_1_7_0, person_19_7_0, person_32_7_0, risk_31_8_0, person_31_8_0)]

dictionary_observe_31_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5825919263958506, ('false', 'false'): 1.0, ('true', 'true'): 0.41740807360414944}
def f_observe_31_8_0(person_31_8_0, observe_31_8_0):
    return dictionary_observe_31_8_0[(person_31_8_0, observe_31_8_0)]

dictionary_person_32_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_32_8_0(person_32_7_0, risk_32_8_0, person_32_8_0):
    return dictionary_person_32_8_0[(person_32_7_0, risk_32_8_0, person_32_8_0)]

dictionary_observe_32_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9192800724048962, ('false', 'false'): 1.0, ('true', 'true'): 0.08071992759510382}
def f_observe_32_8_0(person_32_8_0, observe_32_8_0):
    return dictionary_observe_32_8_0[(person_32_8_0, observe_32_8_0)]

dictionary_person_33_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.31657500203460076, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.40586859251029306, ('false', 'false', 'true', 'false', 'false'): 0.8702141937942989, ('false', 'true', 'false', 'true', 'true'): 0.3172584270325661, ('false', 'false', 'true', 'false', 'true'): 0.12978580620570113, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6827415729674339, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8693439796005046, ('false', 'true', 'true', 'false', 'true'): 0.40527386637666973, ('false', 'true', 'true', 'false', 'false'): 0.5947261336233303, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.13065602039949542, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6834249979653992, ('false', 'true', 'true', 'true', 'false'): 0.5941314074897069}
def f_person_33_8_0(person_33_7_0, person_28_7_0, person_3_7_0, risk_33_8_0, person_33_8_0):
    return dictionary_person_33_8_0[(person_33_7_0, person_28_7_0, person_3_7_0, risk_33_8_0, person_33_8_0)]

dictionary_observe_33_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6740977655638222, ('false', 'false'): 1.0, ('true', 'true'): 0.32590223443617783}
def f_observe_33_8_0(person_33_8_0, observe_33_8_0):
    return dictionary_observe_33_8_0[(person_33_8_0, observe_33_8_0)]

dictionary_person_34_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.6007567098689278, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.8756492254804411, ('false', 'false', 'true', 'false', 'false'): 0.3117779380298735, ('false', 'true', 'false', 'true', 'true'): 0.6011559531590589, ('false', 'false', 'true', 'false', 'true'): 0.6882220619701265, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.3988440468409411, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.31146616009184364, ('false', 'true', 'true', 'false', 'true'): 0.8755247502306718, ('false', 'true', 'true', 'false', 'false'): 0.12447524976932824, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.6885338399081564, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.3992432901310722, ('false', 'true', 'true', 'true', 'false'): 0.12435077451955891}
def f_person_34_8_0(person_34_7_0, person_4_7_0, person_33_7_0, risk_34_8_0, person_34_8_0):
    return dictionary_person_34_8_0[(person_34_7_0, person_4_7_0, person_33_7_0, risk_34_8_0, person_34_8_0)]

dictionary_observe_34_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8008861161315595, ('false', 'false'): 1.0, ('true', 'true'): 0.19911388386844053}
def f_observe_34_8_0(person_34_8_0, observe_34_8_0):
    return dictionary_observe_34_8_0[(person_34_8_0, observe_34_8_0)]

dictionary_person_35_8_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.5968565674320924, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.3941077546616575, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.3825681902723417, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.6667467754140992, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.6168143779179307, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.5489211224418793, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.6607393773503233, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.24475073627378757, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.20576114155365044, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.3964012420768281, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.5494705930349142, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.2178108255637313, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.6259028544607927, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.4510788775581207, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.4035469795474551, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.13434884887388385, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.33325322458590073, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.37447161715636357, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.606498744082425, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.6058922453383425, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.7552492637262125, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.6408717615841755, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.7782628018306115, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.21759301473816756, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.661078637972973, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.7554940144624862, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.393501255917575, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.33892136202702705, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.3392606226496767, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.3591282384158246, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.3740971455392072, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.6529359618606779, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.35876911017740876, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.22173719816938853, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.7942388584463496, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.13448333220608993, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.6174318097276583, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.4505294069650858, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.34641044858791004, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.5964530204525449, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.8655166677939101, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.8656511511261161, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.6412308898225912, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.3470640381393221, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.6039951591652488, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.7944446195879032, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.3831856220820693, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.7821891744362687, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.7784845390287809, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.6255283828436364, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.39600484083475124, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.2445059855375138, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.20555538041209678, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.6670800286386851, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.33291997136131485, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.6035987579231719, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.7824069852618325, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.22151546097121913, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.40314343256790763, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.65358955141209}
def f_person_35_8_0(person_35_7_0, person_7_7_0, person_5_7_0, person_34_7_0, person_0_7_0, risk_35_8_0, person_35_8_0):
    return dictionary_person_35_8_0[(person_35_7_0, person_7_7_0, person_5_7_0, person_34_7_0, person_0_7_0, risk_35_8_0, person_35_8_0)]

dictionary_observe_35_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9711128342396644, ('false', 'false'): 1.0, ('true', 'true'): 0.028887165760335565}
def f_observe_35_8_0(person_35_8_0, observe_35_8_0):
    return dictionary_observe_35_8_0[(person_35_8_0, observe_35_8_0)]

dictionary_person_0_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7038128026655277, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2961871973344723, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7031089898628622, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2968910101371378, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_0_9_0(person_0_8_0, person_12_8_0, risk_0_9_0, person_0_9_0):
    return dictionary_person_0_9_0[(person_0_8_0, person_12_8_0, risk_0_9_0, person_0_9_0)]

dictionary_observe_0_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6976091105097855, ('false', 'false'): 1.0, ('true', 'true'): 0.30239088949021453}
def f_observe_0_9_0(person_0_9_0, observe_0_9_0):
    return dictionary_observe_0_9_0[(person_0_9_0, observe_0_9_0)]

dictionary_person_1_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_1_9_0(person_1_8_0, risk_1_9_0, person_1_9_0):
    return dictionary_person_1_9_0[(person_1_8_0, risk_1_9_0, person_1_9_0)]

dictionary_observe_1_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.42118025883075094, ('false', 'false'): 1.0, ('true', 'true'): 0.5788197411692491}
def f_observe_1_9_0(person_1_9_0, observe_1_9_0):
    return dictionary_observe_1_9_0[(person_1_9_0, observe_1_9_0)]

dictionary_person_2_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_2_9_0(person_2_8_0, risk_2_9_0, person_2_9_0):
    return dictionary_person_2_9_0[(person_2_8_0, risk_2_9_0, person_2_9_0)]

dictionary_observe_2_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8073320596337695, ('false', 'false'): 1.0, ('true', 'true'): 0.19266794036623047}
def f_observe_2_9_0(person_2_9_0, observe_2_9_0):
    return dictionary_observe_2_9_0[(person_2_9_0, observe_2_9_0)]

dictionary_person_3_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_3_9_0(person_3_8_0, risk_3_9_0, person_3_9_0):
    return dictionary_person_3_9_0[(person_3_8_0, risk_3_9_0, person_3_9_0)]

dictionary_observe_3_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5589966386451999, ('false', 'false'): 1.0, ('true', 'true'): 0.4410033613548001}
def f_observe_3_9_0(person_3_9_0, observe_3_9_0):
    return dictionary_observe_3_9_0[(person_3_9_0, observe_3_9_0)]

dictionary_person_4_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_9_0(person_4_8_0, risk_4_9_0, person_4_9_0):
    return dictionary_person_4_9_0[(person_4_8_0, risk_4_9_0, person_4_9_0)]

dictionary_observe_4_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7019891576443075, ('false', 'false'): 1.0, ('true', 'true'): 0.29801084235569253}
def f_observe_4_9_0(person_4_9_0, observe_4_9_0):
    return dictionary_observe_4_9_0[(person_4_9_0, observe_4_9_0)]

dictionary_person_5_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_5_9_0(person_5_8_0, risk_5_9_0, person_5_9_0):
    return dictionary_person_5_9_0[(person_5_8_0, risk_5_9_0, person_5_9_0)]

dictionary_observe_5_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8916670292998845, ('false', 'false'): 1.0, ('true', 'true'): 0.1083329707001155}
def f_observe_5_9_0(person_5_9_0, observe_5_9_0):
    return dictionary_observe_5_9_0[(person_5_9_0, observe_5_9_0)]

dictionary_person_6_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.20818139722626772, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5237075735405138, ('false', 'false', 'true', 'false', 'false'): 0.6021192151649681, ('false', 'true', 'false', 'true', 'true'): 0.2089732158290415, ('false', 'false', 'true', 'false', 'true'): 0.39788078483503186, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7910267841709585, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6015170959498032, ('false', 'true', 'true', 'false', 'true'): 0.5232308043448586, ('false', 'true', 'true', 'false', 'false'): 0.47676919565514136, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3984829040501968, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7918186027737323, ('false', 'true', 'true', 'true', 'false'): 0.4762924264594862}
def f_person_6_9_0(person_6_8_0, person_5_8_0, person_12_8_0, risk_6_9_0, person_6_9_0):
    return dictionary_person_6_9_0[(person_6_8_0, person_5_8_0, person_12_8_0, risk_6_9_0, person_6_9_0)]

dictionary_observe_6_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9923450358162338, ('false', 'false'): 1.0, ('true', 'true'): 0.007654964183766211}
def f_observe_6_9_0(person_6_9_0, observe_6_9_0):
    return dictionary_observe_6_9_0[(person_6_9_0, observe_6_9_0)]

dictionary_person_7_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.569254765783185, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.430745234216815, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5686855110174018, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.43131448898259817, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_7_9_0(person_7_8_0, person_2_8_0, risk_7_9_0, person_7_9_0):
    return dictionary_person_7_9_0[(person_7_8_0, person_2_8_0, risk_7_9_0, person_7_9_0)]

dictionary_observe_7_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6055589972454122, ('false', 'false'): 1.0, ('true', 'true'): 0.3944410027545878}
def f_observe_7_9_0(person_7_9_0, observe_7_9_0):
    return dictionary_observe_7_9_0[(person_7_9_0, observe_7_9_0)]

dictionary_person_8_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5577264866358784, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4422735133641216, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5571687601492425, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.44283123985075745, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_8_9_0(person_8_8_0, person_14_8_0, risk_8_9_0, person_8_9_0):
    return dictionary_person_8_9_0[(person_8_8_0, person_14_8_0, risk_8_9_0, person_8_9_0)]

dictionary_observe_8_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9285440009216199, ('false', 'false'): 1.0, ('true', 'true'): 0.07145599907838007}
def f_observe_8_9_0(person_8_9_0, observe_8_9_0):
    return dictionary_observe_8_9_0[(person_8_9_0, observe_8_9_0)]

dictionary_person_9_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_9_9_0(person_9_8_0, risk_9_9_0, person_9_9_0):
    return dictionary_person_9_9_0[(person_9_8_0, risk_9_9_0, person_9_9_0)]

dictionary_observe_9_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4483164207129191, ('false', 'false'): 1.0, ('true', 'true'): 0.5516835792870809}
def f_observe_9_9_0(person_9_9_0, observe_9_9_0):
    return dictionary_observe_9_9_0[(person_9_9_0, observe_9_9_0)]

dictionary_person_10_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.377519350318132, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6664418978875182, ('false', 'false', 'true', 'false', 'false'): 0.5363893548775067, ('false', 'true', 'false', 'true', 'true'): 0.37814183096781384, ('false', 'false', 'true', 'false', 'true'): 0.4636106451224933, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6218581690321862, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5358529655226292, ('false', 'true', 'true', 'false', 'true'): 0.6661080058934116, ('false', 'true', 'true', 'false', 'false'): 0.33389199410658843, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4641470344773708, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.622480649681868, ('false', 'true', 'true', 'true', 'false'): 0.3335581021124818}
def f_person_10_9_0(person_10_8_0, person_4_8_0, person_11_8_0, risk_10_9_0, person_10_9_0):
    return dictionary_person_10_9_0[(person_10_8_0, person_4_8_0, person_11_8_0, risk_10_9_0, person_10_9_0)]

dictionary_observe_10_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9195228283277852, ('false', 'false'): 1.0, ('true', 'true'): 0.0804771716722148}
def f_observe_10_9_0(person_10_9_0, observe_10_9_0):
    return dictionary_observe_10_9_0[(person_10_9_0, observe_10_9_0)]

dictionary_person_11_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_11_9_0(person_11_8_0, risk_11_9_0, person_11_9_0):
    return dictionary_person_11_9_0[(person_11_8_0, risk_11_9_0, person_11_9_0)]

dictionary_observe_11_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8357417926118372, ('false', 'false'): 1.0, ('true', 'true'): 0.16425820738816277}
def f_observe_11_9_0(person_11_9_0, observe_11_9_0):
    return dictionary_observe_11_9_0[(person_11_9_0, observe_11_9_0)]

dictionary_person_12_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_12_9_0(person_12_8_0, risk_12_9_0, person_12_9_0):
    return dictionary_person_12_9_0[(person_12_8_0, risk_12_9_0, person_12_9_0)]

dictionary_observe_12_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7841985061615961, ('false', 'false'): 1.0, ('true', 'true'): 0.21580149383840386}
def f_observe_12_9_0(person_12_9_0, observe_12_9_0):
    return dictionary_observe_12_9_0[(person_12_9_0, observe_12_9_0)]

dictionary_person_13_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3219336654867144, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5476581414596766, ('false', 'false', 'true', 'false', 'false'): 0.6677733875676513, ('false', 'true', 'false', 'true', 'true'): 0.3226117318212277, ('false', 'false', 'true', 'false', 'true'): 0.33222661243234874, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6773882681787723, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6671056141800836, ('false', 'true', 'true', 'false', 'true'): 0.547205346806483, ('false', 'true', 'true', 'false', 'false'): 0.4527946531935169, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.33289438581991637, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6780663345132856, ('false', 'true', 'true', 'true', 'false'): 0.4523418585403234}
def f_person_13_9_0(person_13_8_0, person_1_8_0, person_19_8_0, risk_13_9_0, person_13_9_0):
    return dictionary_person_13_9_0[(person_13_8_0, person_1_8_0, person_19_8_0, risk_13_9_0, person_13_9_0)]

dictionary_observe_13_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4728752941210056, ('false', 'false'): 1.0, ('true', 'true'): 0.5271247058789944}
def f_observe_13_9_0(person_13_9_0, observe_13_9_0):
    return dictionary_observe_13_9_0[(person_13_9_0, observe_13_9_0)]

dictionary_person_14_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7762427604528536, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.22375723954714644, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7754665176924007, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.22453348230759929, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_14_9_0(person_14_8_0, person_13_8_0, risk_14_9_0, person_14_9_0):
    return dictionary_person_14_9_0[(person_14_8_0, person_13_8_0, risk_14_9_0, person_14_9_0)]

dictionary_observe_14_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6367745547067383, ('false', 'false'): 1.0, ('true', 'true'): 0.36322544529326173}
def f_observe_14_9_0(person_14_9_0, observe_14_9_0):
    return dictionary_observe_14_9_0[(person_14_9_0, observe_14_9_0)]

dictionary_person_15_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_15_9_0(person_15_8_0, risk_15_9_0, person_15_9_0):
    return dictionary_person_15_9_0[(person_15_8_0, risk_15_9_0, person_15_9_0)]

dictionary_observe_15_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6666143402533105, ('false', 'false'): 1.0, ('true', 'true'): 0.33338565974668954}
def f_observe_15_9_0(person_15_9_0, observe_15_9_0):
    return dictionary_observe_15_9_0[(person_15_9_0, observe_15_9_0)]

dictionary_person_16_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.537014139584971, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.462985860415029, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5364771254453861, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.46352287455461394, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_16_9_0(person_16_8_0, person_10_8_0, risk_16_9_0, person_16_9_0):
    return dictionary_person_16_9_0[(person_16_8_0, person_10_8_0, risk_16_9_0, person_16_9_0)]

dictionary_observe_16_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6585097977753152, ('false', 'false'): 1.0, ('true', 'true'): 0.34149020222468485}
def f_observe_16_9_0(person_16_9_0, observe_16_9_0):
    return dictionary_observe_16_9_0[(person_16_9_0, observe_16_9_0)]

dictionary_person_17_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_17_9_0(person_17_8_0, risk_17_9_0, person_17_9_0):
    return dictionary_person_17_9_0[(person_17_8_0, risk_17_9_0, person_17_9_0)]

dictionary_observe_17_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8572175333673339, ('false', 'false'): 1.0, ('true', 'true'): 0.14278246663266614}
def f_observe_17_9_0(person_17_9_0, observe_17_9_0):
    return dictionary_observe_17_9_0[(person_17_9_0, observe_17_9_0)]

dictionary_person_18_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6265487209973823, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.37345127900261765, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6259221722763849, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3740778277236151, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_18_9_0(person_18_8_0, person_16_8_0, risk_18_9_0, person_18_9_0):
    return dictionary_person_18_9_0[(person_18_8_0, person_16_8_0, risk_18_9_0, person_18_9_0)]

dictionary_observe_18_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9582932772756836, ('false', 'false'): 1.0, ('true', 'true'): 0.041706722724316414}
def f_observe_18_9_0(person_18_9_0, observe_18_9_0):
    return dictionary_observe_18_9_0[(person_18_9_0, observe_18_9_0)]

dictionary_person_19_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8317327077237194, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.16826729227628057, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8309009750159957, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.1690990249840043, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_19_9_0(person_19_8_0, person_13_8_0, risk_19_9_0, person_19_9_0):
    return dictionary_person_19_9_0[(person_19_8_0, person_13_8_0, risk_19_9_0, person_19_9_0)]

dictionary_observe_19_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.44603646215564474, ('false', 'false'): 1.0, ('true', 'true'): 0.5539635378443553}
def f_observe_19_9_0(person_19_9_0, observe_19_9_0):
    return dictionary_observe_19_9_0[(person_19_9_0, observe_19_9_0)]

dictionary_person_20_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.8312128664711078, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.16878713352889219, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8303816536046367, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.16961834639536333, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_20_9_0(person_20_8_0, person_3_8_0, risk_20_9_0, person_20_9_0):
    return dictionary_person_20_9_0[(person_20_8_0, person_3_8_0, risk_20_9_0, person_20_9_0)]

dictionary_observe_20_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4743690848998712, ('false', 'false'): 1.0, ('true', 'true'): 0.5256309151001288}
def f_observe_20_9_0(person_20_9_0, observe_20_9_0):
    return dictionary_observe_20_9_0[(person_20_9_0, observe_20_9_0)]

dictionary_person_21_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_21_9_0(person_21_8_0, risk_21_9_0, person_21_9_0):
    return dictionary_person_21_9_0[(person_21_8_0, risk_21_9_0, person_21_9_0)]

dictionary_observe_21_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5468194206640051, ('false', 'false'): 1.0, ('true', 'true'): 0.45318057933599487}
def f_observe_21_9_0(person_21_9_0, observe_21_9_0):
    return dictionary_observe_21_9_0[(person_21_9_0, observe_21_9_0)]

dictionary_person_22_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_22_9_0(person_22_8_0, risk_22_9_0, person_22_9_0):
    return dictionary_person_22_9_0[(person_22_8_0, risk_22_9_0, person_22_9_0)]

dictionary_observe_22_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6195547798007379, ('false', 'false'): 1.0, ('true', 'true'): 0.3804452201992621}
def f_observe_22_9_0(person_22_9_0, observe_22_9_0):
    return dictionary_observe_22_9_0[(person_22_9_0, observe_22_9_0)]

dictionary_person_23_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_23_9_0(person_23_8_0, risk_23_9_0, person_23_9_0):
    return dictionary_person_23_9_0[(person_23_8_0, risk_23_9_0, person_23_9_0)]

dictionary_observe_23_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6379306323926284, ('false', 'false'): 1.0, ('true', 'true'): 0.36206936760737163}
def f_observe_23_9_0(person_23_9_0, observe_23_9_0):
    return dictionary_observe_23_9_0[(person_23_9_0, observe_23_9_0)]

dictionary_person_24_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.625640361122809, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.37435963887719104, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6250147207616862, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3749852792383138, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_24_9_0(person_24_8_0, person_30_8_0, risk_24_9_0, person_24_9_0):
    return dictionary_person_24_9_0[(person_24_8_0, person_30_8_0, risk_24_9_0, person_24_9_0)]

dictionary_observe_24_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9222973315851222, ('false', 'false'): 1.0, ('true', 'true'): 0.07770266841487783}
def f_observe_24_9_0(person_24_9_0, observe_24_9_0):
    return dictionary_observe_24_9_0[(person_24_9_0, observe_24_9_0)]

dictionary_person_25_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_25_9_0(person_25_8_0, risk_25_9_0, person_25_9_0):
    return dictionary_person_25_9_0[(person_25_8_0, risk_25_9_0, person_25_9_0)]

dictionary_observe_25_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8428286651134502, ('false', 'false'): 1.0, ('true', 'true'): 0.15717133488654977}
def f_observe_25_9_0(person_25_9_0, observe_25_9_0):
    return dictionary_observe_25_9_0[(person_25_9_0, observe_25_9_0)]

dictionary_person_26_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_26_9_0(person_26_8_0, risk_26_9_0, person_26_9_0):
    return dictionary_person_26_9_0[(person_26_8_0, risk_26_9_0, person_26_9_0)]

dictionary_observe_26_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.46591008314954485, ('false', 'false'): 1.0, ('true', 'true'): 0.5340899168504551}
def f_observe_26_9_0(person_26_9_0, observe_26_9_0):
    return dictionary_observe_26_9_0[(person_26_9_0, observe_26_9_0)]

dictionary_person_27_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_27_9_0(person_27_8_0, risk_27_9_0, person_27_9_0):
    return dictionary_person_27_9_0[(person_27_8_0, risk_27_9_0, person_27_9_0)]

dictionary_observe_27_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9161480014341606, ('false', 'false'): 1.0, ('true', 'true'): 0.08385199856583936}
def f_observe_27_9_0(person_27_9_0, observe_27_9_0):
    return dictionary_observe_27_9_0[(person_27_9_0, observe_27_9_0)]

dictionary_person_28_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_28_9_0(person_28_8_0, risk_28_9_0, person_28_9_0):
    return dictionary_person_28_9_0[(person_28_8_0, risk_28_9_0, person_28_9_0)]

dictionary_observe_28_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4783347039771497, ('false', 'false'): 1.0, ('true', 'true'): 0.5216652960228503}
def f_observe_28_9_0(person_28_9_0, observe_28_9_0):
    return dictionary_observe_28_9_0[(person_28_9_0, observe_28_9_0)]

dictionary_person_29_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5002832527096166, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4997167472903834, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.499782969456907, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5002170305430931, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_29_9_0(person_29_8_0, person_23_8_0, risk_29_9_0, person_29_9_0):
    return dictionary_person_29_9_0[(person_29_8_0, person_23_8_0, risk_29_9_0, person_29_9_0)]

dictionary_observe_29_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9627272674586774, ('false', 'false'): 1.0, ('true', 'true'): 0.03727273254132257}
def f_observe_29_9_0(person_29_9_0, observe_29_9_0):
    return dictionary_observe_29_9_0[(person_29_9_0, observe_29_9_0)]

dictionary_person_30_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_30_9_0(person_30_8_0, risk_30_9_0, person_30_9_0):
    return dictionary_person_30_9_0[(person_30_8_0, risk_30_9_0, person_30_9_0)]

dictionary_observe_30_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5747717580625576, ('false', 'false'): 1.0, ('true', 'true'): 0.42522824193744235}
def f_observe_30_9_0(person_30_9_0, observe_30_9_0):
    return dictionary_observe_30_9_0[(person_30_9_0, observe_30_9_0)]

dictionary_person_31_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.999, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.8991, ('false', 'false', 'true', 'false'): 0.9, ('false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.09999999999999998}
def f_person_31_9_0(person_31_8_0, risk_31_9_0, risk_31_9_1, person_31_9_0):
    return dictionary_person_31_9_0[(person_31_8_0, risk_31_9_0, risk_31_9_1, person_31_9_0)]

dictionary_observe_31_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6669280801044566, ('false', 'false'): 1.0, ('true', 'true'): 0.3330719198955434}
def f_observe_31_9_0(person_31_9_0, observe_31_9_0):
    return dictionary_observe_31_9_0[(person_31_9_0, observe_31_9_0)]

dictionary_person_32_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_32_9_0(person_32_8_0, risk_32_9_0, person_32_9_0):
    return dictionary_person_32_9_0[(person_32_8_0, risk_32_9_0, person_32_9_0)]

dictionary_observe_32_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5055236737990286, ('false', 'false'): 1.0, ('true', 'true'): 0.49447632620097137}
def f_observe_32_9_0(person_32_9_0, observe_32_9_0):
    return dictionary_observe_32_9_0[(person_32_9_0, observe_32_9_0)]

dictionary_person_33_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6574256309389254, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.34257436906107464, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6567682053079864, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3432317946920136, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_33_9_0(person_33_8_0, person_3_8_0, risk_33_9_0, person_33_9_0):
    return dictionary_person_33_9_0[(person_33_8_0, person_3_8_0, risk_33_9_0, person_33_9_0)]

dictionary_observe_33_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.559588118244337, ('false', 'false'): 1.0, ('true', 'true'): 0.44041188175566304}
def f_observe_33_9_0(person_33_9_0, observe_33_9_0):
    return dictionary_observe_33_9_0[(person_33_9_0, observe_33_9_0)]

dictionary_person_34_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5539329632874193, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.44606703671258074, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5533790303241318, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4466209696758682, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_34_9_0(person_34_8_0, person_2_8_0, risk_34_9_0, person_34_9_0):
    return dictionary_person_34_9_0[(person_34_8_0, person_2_8_0, risk_34_9_0, person_34_9_0)]

dictionary_observe_34_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8113939053974999, ('false', 'false'): 1.0, ('true', 'true'): 0.1886060946025001}
def f_observe_34_9_0(person_34_9_0, observe_34_9_0):
    return dictionary_observe_34_9_0[(person_34_9_0, observe_34_9_0)]

dictionary_person_35_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5409761276755619, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4590238723244381, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5404351515478863, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.45956484845211365, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_35_9_0(person_35_8_0, person_33_8_0, risk_35_9_0, person_35_9_0):
    return dictionary_person_35_9_0[(person_35_8_0, person_33_8_0, risk_35_9_0, person_35_9_0)]

dictionary_observe_35_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5999522307118158, ('false', 'false'): 1.0, ('true', 'true'): 0.4000477692881842}
def f_observe_35_9_0(person_35_9_0, observe_35_9_0):
    return dictionary_observe_35_9_0[(person_35_9_0, observe_35_9_0)]

dictionary_person_0_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6337687865117407, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.36623121348825927, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.633135017725229, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.36686498227477105, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_0_10_0(person_0_9_0, person_30_9_0, risk_0_10_0, person_0_10_0):
    return dictionary_person_0_10_0[(person_0_9_0, person_30_9_0, risk_0_10_0, person_0_10_0)]

dictionary_observe_0_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4824173068118289, ('false', 'false'): 1.0, ('true', 'true'): 0.5175826931881711}
def f_observe_0_10_0(person_0_10_0, observe_0_10_0):
    return dictionary_observe_0_10_0[(person_0_10_0, observe_0_10_0)]

dictionary_person_1_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_1_10_0(person_1_9_0, risk_1_10_0, person_1_10_0):
    return dictionary_person_1_10_0[(person_1_9_0, risk_1_10_0, person_1_10_0)]

dictionary_observe_1_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9342279555453734, ('false', 'false'): 1.0, ('true', 'true'): 0.06577204445462659}
def f_observe_1_10_0(person_1_10_0, observe_1_10_0):
    return dictionary_observe_1_10_0[(person_1_10_0, observe_1_10_0)]

dictionary_person_2_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_2_10_0(person_2_9_0, risk_2_10_0, person_2_10_0):
    return dictionary_person_2_10_0[(person_2_9_0, risk_2_10_0, person_2_10_0)]

dictionary_observe_2_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.746869931685334, ('false', 'false'): 1.0, ('true', 'true'): 0.253130068314666}
def f_observe_2_10_0(person_2_10_0, observe_2_10_0):
    return dictionary_observe_2_10_0[(person_2_10_0, observe_2_10_0)]

dictionary_person_3_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_3_10_0(person_3_9_0, risk_3_10_0, person_3_10_0):
    return dictionary_person_3_10_0[(person_3_9_0, risk_3_10_0, person_3_10_0)]

dictionary_observe_3_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5018158692807352, ('false', 'false'): 1.0, ('true', 'true'): 0.4981841307192648}
def f_observe_3_10_0(person_3_10_0, observe_3_10_0):
    return dictionary_observe_3_10_0[(person_3_10_0, observe_3_10_0)]

dictionary_person_4_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6297830151937927, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.37021698480620735, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6291532321785989, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.37084676782140114, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_4_10_0(person_4_9_0, person_34_9_0, risk_4_10_0, person_4_10_0):
    return dictionary_person_4_10_0[(person_4_9_0, person_34_9_0, risk_4_10_0, person_4_10_0)]

dictionary_observe_4_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4952184011709374, ('false', 'false'): 1.0, ('true', 'true'): 0.5047815988290626}
def f_observe_4_10_0(person_4_10_0, observe_4_10_0):
    return dictionary_observe_4_10_0[(person_4_10_0, observe_4_10_0)]

dictionary_person_5_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6369448674239664, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3630551325760336, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6363079225565424, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.36369207744345755, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_5_10_0(person_5_9_0, person_12_9_0, risk_5_10_0, person_5_10_0):
    return dictionary_person_5_10_0[(person_5_9_0, person_12_9_0, risk_5_10_0, person_5_10_0)]

dictionary_observe_5_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9915708569631139, ('false', 'false'): 1.0, ('true', 'true'): 0.008429143036886133}
def f_observe_5_10_0(person_5_10_0, observe_5_10_0):
    return dictionary_observe_5_10_0[(person_5_10_0, observe_5_10_0)]

dictionary_person_6_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.12015472252178959, ('false', 'true', 'false', 'false', 'false', 'true'): 0.3309935690821115, ('false', 'true', 'true', 'false', 'true', 'true'): 0.7809389309979046, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.21906106900209543, ('false', 'true', 'false', 'false', 'false', 'false'): 0.6690064309178885, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.6683374244869705, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.6722298333506445, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.8798452774782104, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.8797250024806911, ('false', 'false', 'true', 'false', 'false', 'false'): 0.32777016664935554, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.3669491911018784, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.36658224191077654, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.6330508088981216, ('false', 'false', 'false', 'true', 'false', 'true'): 0.4515012499978248, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.33166257551302947, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.1202749975193089, ('false', 'false', 'true', 'false', 'true', 'false'): 0.3274423964827062, ('false', 'true', 'true', 'false', 'false', 'false'): 0.21928034935144688, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.8202184733048239, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.6334177580892235, ('false', 'false', 'false', 'true', 'true', 'false'): 0.547950251252173, ('false', 'false', 'false', 'true', 'false', 'false'): 0.5484987500021752, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.17978152669517616, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.820398254831519, ('false', 'false', 'true', 'false', 'true', 'true'): 0.6725576035172938, ('false', 'false', 'false', 'true', 'true', 'true'): 0.452049748747827, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.7807196506485531, ('false', 'false', 'true', 'true', 'true', 'false'): 0.179601745168481}
def f_person_6_10_0(person_6_9_0, person_12_9_0, person_5_9_0, person_0_9_0, risk_6_10_0, person_6_10_0):
    return dictionary_person_6_10_0[(person_6_9_0, person_12_9_0, person_5_9_0, person_0_9_0, risk_6_10_0, person_6_10_0)]

dictionary_observe_6_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9916875244918073, ('false', 'false'): 1.0, ('true', 'true'): 0.008312475508192696}
def f_observe_6_10_0(person_6_10_0, observe_6_10_0):
    return dictionary_observe_6_10_0[(person_6_10_0, observe_6_10_0)]

dictionary_person_7_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_7_10_0(person_7_9_0, risk_7_10_0, person_7_10_0):
    return dictionary_person_7_10_0[(person_7_9_0, risk_7_10_0, person_7_10_0)]

dictionary_observe_7_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6183905641673693, ('false', 'false'): 1.0, ('true', 'true'): 0.38160943583263074}
def f_observe_7_10_0(person_7_10_0, observe_7_10_0):
    return dictionary_observe_7_10_0[(person_7_10_0, observe_7_10_0)]

dictionary_person_8_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5030789608730479, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.49692103912695207, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5025758819121748, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.49742411808782516, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_8_10_0(person_8_9_0, person_7_9_0, risk_8_10_0, person_8_10_0):
    return dictionary_person_8_10_0[(person_8_9_0, person_7_9_0, risk_8_10_0, person_8_10_0)]

dictionary_observe_8_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8145024247998052, ('false', 'false'): 1.0, ('true', 'true'): 0.18549757520019483}
def f_observe_8_10_0(person_8_10_0, observe_8_10_0):
    return dictionary_observe_8_10_0[(person_8_10_0, observe_8_10_0)]

dictionary_person_9_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_9_10_0(person_9_9_0, risk_9_10_0, person_9_10_0):
    return dictionary_person_9_10_0[(person_9_9_0, risk_9_10_0, person_9_10_0)]

dictionary_observe_9_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.807702622155033, ('false', 'false'): 1.0, ('true', 'true'): 0.19229737784496703}
def f_observe_9_10_0(person_9_10_0, observe_9_10_0):
    return dictionary_observe_9_10_0[(person_9_10_0, observe_9_10_0)]

dictionary_person_10_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7708370369814257, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2291629630185743, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7700661999444443, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.22993380005555575, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_10_10_0(person_10_9_0, person_16_9_0, risk_10_10_0, person_10_10_0):
    return dictionary_person_10_10_0[(person_10_9_0, person_16_9_0, risk_10_10_0, person_10_10_0)]

dictionary_observe_10_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7255195124149459, ('false', 'false'): 1.0, ('true', 'true'): 0.27448048758505406}
def f_observe_10_10_0(person_10_10_0, observe_10_10_0):
    return dictionary_observe_10_10_0[(person_10_10_0, observe_10_10_0)]

dictionary_person_11_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.3741130325678565, ('false', 'true', 'false', 'false', 'false', 'true'): 0.21355666144376173, ('false', 'true', 'true', 'false', 'true', 'true'): 0.6255124799120555, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.37448752008794445, ('false', 'true', 'false', 'false', 'false', 'false'): 0.7864433385562383, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.7077990047006144, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.09999999999999998, ('false', 'false', 'false', 'false', 'true', 'false'): 0.9, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.47091262123723165, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.6258869674321434, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.5843188527023817, ('false', 'false', 'true', 'false', 'false', 'false'): 0.5290873787627683, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.785656895217682, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.7070912056959138, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.214343104782318, ('false', 'false', 'false', 'true', 'false', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.2922009952993856, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.41568114729761835, ('false', 'false', 'true', 'false', 'true', 'false'): 0.47617864088649153, ('false', 'true', 'true', 'false', 'false', 'false'): 0.4160972445421605, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.47144170861599444, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.29290879430408623, ('false', 'false', 'false', 'true', 'true', 'false'): 0.8991, ('false', 'false', 'false', 'true', 'false', 'false'): 0.999, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.5285582913840056, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.524297537754395, ('false', 'false', 'true', 'false', 'true', 'true'): 0.5238213591135085, ('false', 'false', 'false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.5839027554578395, ('false', 'false', 'true', 'true', 'true', 'false'): 0.47570246224560503}
def f_person_11_10_0(person_11_9_0, person_12_9_0, person_16_9_0, risk_11_10_0, risk_11_10_1, person_11_10_0):
    return dictionary_person_11_10_0[(person_11_9_0, person_12_9_0, person_16_9_0, risk_11_10_0, risk_11_10_1, person_11_10_0)]

dictionary_observe_11_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.44118811050847473, ('false', 'false'): 1.0, ('true', 'true'): 0.5588118894915253}
def f_observe_11_10_0(person_11_10_0, observe_11_10_0):
    return dictionary_observe_11_10_0[(person_11_10_0, observe_11_10_0)]

dictionary_person_12_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_12_10_0(person_12_9_0, risk_12_10_0, person_12_10_0):
    return dictionary_person_12_10_0[(person_12_9_0, risk_12_10_0, person_12_10_0)]

dictionary_observe_12_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7973159812671906, ('false', 'false'): 1.0, ('true', 'true'): 0.2026840187328094}
def f_observe_12_10_0(person_12_10_0, observe_12_10_0):
    return dictionary_observe_12_10_0[(person_12_10_0, observe_12_10_0)]

dictionary_person_13_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6786738085070138, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.32132619149298625, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6779951346985067, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3220048653014933, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_13_10_0(person_13_9_0, person_12_9_0, risk_13_10_0, person_13_10_0):
    return dictionary_person_13_10_0[(person_13_9_0, person_12_9_0, risk_13_10_0, person_13_10_0)]

dictionary_observe_13_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9892605370777348, ('false', 'false'): 1.0, ('true', 'true'): 0.010739462922265242}
def f_observe_13_10_0(person_13_10_0, observe_13_10_0):
    return dictionary_observe_13_10_0[(person_13_10_0, observe_13_10_0)]

dictionary_person_14_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_14_10_0(person_14_9_0, risk_14_10_0, person_14_10_0):
    return dictionary_person_14_10_0[(person_14_9_0, risk_14_10_0, person_14_10_0)]

dictionary_observe_14_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6938315379232631, ('false', 'false'): 1.0, ('true', 'true'): 0.30616846207673687}
def f_observe_14_10_0(person_14_10_0, observe_14_10_0):
    return dictionary_observe_14_10_0[(person_14_10_0, observe_14_10_0)]

dictionary_person_15_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.37294846105585777, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6563308632980556, ('false', 'false', 'true', 'false', 'false'): 0.5486202145856481, ('false', 'true', 'false', 'true', 'true'): 0.37357551259480193, ('false', 'false', 'true', 'false', 'true'): 0.45137978541435186, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6264244874051981, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5480715943710625, ('false', 'true', 'true', 'false', 'true'): 0.6559868501482038, ('false', 'true', 'true', 'false', 'false'): 0.3440131498517962, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.45192840562893755, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6270515389441422, ('false', 'true', 'true', 'true', 'false'): 0.34366913670194443}
def f_person_15_10_0(person_15_9_0, person_3_9_0, person_9_9_0, risk_15_10_0, person_15_10_0):
    return dictionary_person_15_10_0[(person_15_9_0, person_3_9_0, person_9_9_0, risk_15_10_0, person_15_10_0)]

dictionary_observe_15_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5013938177525409, ('false', 'false'): 1.0, ('true', 'true'): 0.4986061822474591}
def f_observe_15_10_0(person_15_10_0, observe_15_10_0):
    return dictionary_observe_15_10_0[(person_15_10_0, observe_15_10_0)]

dictionary_person_16_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5660424456891143, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4339575543108857, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5654764032434252, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4345235967565748, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_16_10_0(person_16_9_0, person_15_9_0, risk_16_10_0, person_16_10_0):
    return dictionary_person_16_10_0[(person_16_9_0, person_15_9_0, risk_16_10_0, person_16_10_0)]

dictionary_observe_16_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9506561821047217, ('false', 'false'): 1.0, ('true', 'true'): 0.04934381789527831}
def f_observe_16_10_0(person_16_10_0, observe_16_10_0):
    return dictionary_observe_16_10_0[(person_16_10_0, observe_16_10_0)]

dictionary_person_17_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.7001932110822182, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7304437160840224, ('false', 'false', 'true', 'false', 'false'): 0.999, ('false', 'true', 'false', 'true', 'true'): 0.7301738899739965, ('false', 'false', 'true', 'false', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.9, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.2698261100260036, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8991, ('false', 'true', 'true', 'false', 'true'): 0.7004930178711359, ('false', 'true', 'true', 'false', 'false'): 0.299506982128864, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.09999999999999998, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.2998067889177818, ('false', 'true', 'true', 'true', 'false'): 0.26955628391597763}
def f_person_17_10_0(person_17_9_0, person_10_9_0, risk_17_10_0, risk_17_10_1, person_17_10_0):
    return dictionary_person_17_10_0[(person_17_9_0, person_10_9_0, risk_17_10_0, risk_17_10_1, person_17_10_0)]

dictionary_observe_17_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7753931878420313, ('false', 'false'): 1.0, ('true', 'true'): 0.22460681215796874}
def f_observe_17_10_0(person_17_10_0, observe_17_10_0):
    return dictionary_observe_17_10_0[(person_17_10_0, observe_17_10_0)]

dictionary_person_18_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.47470452654763773, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5252954734523623, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4742298220210901, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5257701779789099, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_18_10_0(person_18_9_0, person_17_9_0, risk_18_10_0, person_18_10_0):
    return dictionary_person_18_10_0[(person_18_9_0, person_17_9_0, risk_18_10_0, person_18_10_0)]

dictionary_observe_18_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8510576899654504, ('false', 'false'): 1.0, ('true', 'true'): 0.1489423100345496}
def f_observe_18_10_0(person_18_10_0, observe_18_10_0):
    return dictionary_observe_18_10_0[(person_18_10_0, observe_18_10_0)]

dictionary_person_19_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_19_10_0(person_19_9_0, risk_19_10_0, person_19_10_0):
    return dictionary_person_19_10_0[(person_19_9_0, risk_19_10_0, person_19_10_0)]

dictionary_observe_19_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5767027197996806, ('false', 'false'): 1.0, ('true', 'true'): 0.4232972802003194}
def f_observe_19_10_0(person_19_10_0, observe_19_10_0):
    return dictionary_observe_19_10_0[(person_19_10_0, observe_19_10_0)]

dictionary_person_20_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3728004098220694, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6161732348599704, ('false', 'false', 'true', 'false', 'false'): 0.6125816759656184, ('false', 'true', 'false', 'true', 'true'): 0.3734276094122474, ('false', 'false', 'true', 'false', 'true'): 0.3874183240343816, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6265723905877526, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6119690942896527, ('false', 'true', 'true', 'false', 'true'): 0.6157890238838543, ('false', 'true', 'true', 'false', 'false'): 0.38421097611614574, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.38803090571034726, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6271995901779306, ('false', 'true', 'true', 'true', 'false'): 0.3838267651400296}
def f_person_20_10_0(person_20_9_0, person_26_9_0, person_21_9_0, risk_20_10_0, person_20_10_0):
    return dictionary_person_20_10_0[(person_20_9_0, person_26_9_0, person_21_9_0, risk_20_10_0, person_20_10_0)]

dictionary_observe_20_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6438425519795729, ('false', 'false'): 1.0, ('true', 'true'): 0.35615744802042715}
def f_observe_20_10_0(person_20_10_0, observe_20_10_0):
    return dictionary_observe_20_10_0[(person_20_10_0, observe_20_10_0)]

dictionary_person_21_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_21_10_0(person_21_9_0, risk_21_10_0, person_21_10_0):
    return dictionary_person_21_10_0[(person_21_9_0, risk_21_10_0, person_21_10_0)]

dictionary_observe_21_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.728843204732366, ('false', 'false'): 1.0, ('true', 'true'): 0.27115679526763403}
def f_observe_21_10_0(person_21_10_0, observe_21_10_0):
    return dictionary_observe_21_10_0[(person_21_10_0, observe_21_10_0)]

dictionary_person_22_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5605092309740567, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4394907690259433, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5599487217430826, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.44005127825691737, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_22_10_0(person_22_9_0, person_21_9_0, risk_22_10_0, person_22_10_0):
    return dictionary_person_22_10_0[(person_22_9_0, person_21_9_0, risk_22_10_0, person_22_10_0)]

dictionary_observe_22_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9991442625771161, ('false', 'false'): 1.0, ('true', 'true'): 0.0008557374228839176}
def f_observe_22_10_0(person_22_10_0, observe_22_10_0):
    return dictionary_observe_22_10_0[(person_22_10_0, observe_22_10_0)]

dictionary_person_23_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.7422784324580192, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.847191188216471, ('false', 'false', 'true', 'false', 'false'): 0.5935156107265636, ('false', 'true', 'false', 'true', 'true'): 0.7425361540255612, ('false', 'false', 'true', 'false', 'true'): 0.40648438927343644, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.25746384597443883, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.592922095115837, ('false', 'true', 'true', 'false', 'true'): 0.8470382264429139, ('false', 'true', 'true', 'false', 'false'): 0.15296177355708607, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.40707790488416296, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.25772156754198083, ('false', 'true', 'true', 'true', 'false'): 0.15280881178352898}
def f_person_23_10_0(person_23_9_0, person_22_9_0, person_17_9_0, risk_23_10_0, person_23_10_0):
    return dictionary_person_23_10_0[(person_23_9_0, person_22_9_0, person_17_9_0, risk_23_10_0, person_23_10_0)]

dictionary_observe_23_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8460741663083854, ('false', 'false'): 1.0, ('true', 'true'): 0.1539258336916146}
def f_observe_23_10_0(person_23_10_0, observe_23_10_0):
    return dictionary_observe_23_10_0[(person_23_10_0, observe_23_10_0)]

dictionary_person_24_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.15810902274511032, ('false', 'true', 'false', 'false', 'false', 'true'): 0.46999445872835866, ('false', 'true', 'true', 'false', 'true', 'true'): 0.59228810885149, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.40771189114851003, ('false', 'true', 'false', 'false', 'false', 'false'): 0.5300055412716413, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.5294755357303697, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.22997029393227075, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.8418909772548897, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.8417327099648545, ('false', 'false', 'true', 'false', 'false', 'false'): 0.7700297060677292, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.20553400575071426, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.20532847174496355, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.7944659942492858, ('false', 'false', 'false', 'true', 'false', 'true'): 0.6122040436453232, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.47052446426963035, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.15826729003514547, ('false', 'false', 'true', 'false', 'true', 'false'): 0.7692596763616615, ('false', 'true', 'true', 'false', 'false', 'false'): 0.4081200111596697, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.7013855937139543, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.7946715282550365, ('false', 'false', 'false', 'true', 'true', 'false'): 0.3874081603983221, ('false', 'false', 'false', 'true', 'false', 'false'): 0.3877959563546768, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.29861440628604574, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.7016842081202403, ('false', 'false', 'true', 'false', 'true', 'true'): 0.23074032363833852, ('false', 'false', 'false', 'true', 'true', 'true'): 0.6125918396016778, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.5918799888403303, ('false', 'false', 'true', 'true', 'true', 'false'): 0.2983157918797597}
def f_person_24_10_0(person_24_9_0, person_30_9_0, person_18_9_0, person_23_9_0, risk_24_10_0, person_24_10_0):
    return dictionary_person_24_10_0[(person_24_9_0, person_30_9_0, person_18_9_0, person_23_9_0, risk_24_10_0, person_24_10_0)]

dictionary_observe_24_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5482325300941429, ('false', 'false'): 1.0, ('true', 'true'): 0.45176746990585714}
def f_observe_24_10_0(person_24_10_0, observe_24_10_0):
    return dictionary_observe_24_10_0[(person_24_10_0, observe_24_10_0)]

dictionary_person_25_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_25_10_0(person_25_9_0, risk_25_10_0, person_25_10_0):
    return dictionary_person_25_10_0[(person_25_9_0, risk_25_10_0, person_25_10_0)]

dictionary_observe_25_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6293737600330168, ('false', 'false'): 1.0, ('true', 'true'): 0.3706262399669832}
def f_observe_25_10_0(person_25_10_0, observe_25_10_0):
    return dictionary_observe_25_10_0[(person_25_10_0, observe_25_10_0)]

dictionary_person_26_10_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.7193344634119201, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.10089999999999999, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.4475877892800839, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.2532694546187244, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.4971709896479245, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.6727302210642123, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.5870840126264674, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.31153874561276873, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.4125030713861591, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.5639606430979583, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.7474780234046803, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.42154818678089423, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.5033261813417234, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.3272697789357877, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.3118505962089777, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.2095815292061453, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.7467305453812756, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.5518597985091962, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.999, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.8991, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.6884612543872313, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.578029843062168, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.7668985327481422, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.37939336810280483, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.6283756113638206, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.7196151289485082, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.0010000000000000009, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.37162438863617936, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.41291598737353263, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.4219701569378321, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.4966738186582766, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.5080726514396021, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.3797731412440489, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.09999999999999998, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.23310146725185776, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.587496928613841, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.2328683657846059, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.5524122107199161, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.2525219765953197, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.43547483173377544, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.6881494037910223, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.7671316342153941, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.7904184707938546, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.9, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.6202268587559512, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.4919273485603979, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.4924354212118375, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.6287472357524568, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.5028290103520755, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.5784518132191058, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.7902086794733281, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.4481402014908038, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.5075645787881625, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.28038487105149185, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.3712527642475432, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.32794250915685197, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.672057490843148, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.43603935690204165, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.6206066318971952, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.209791320526672, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.28066553658807997, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.5645251682662246}
def f_person_26_10_0(person_26_9_0, person_25_9_0, person_27_9_0, person_31_9_0, risk_26_10_0, risk_26_10_1, person_26_10_0):
    return dictionary_person_26_10_0[(person_26_9_0, person_25_9_0, person_27_9_0, person_31_9_0, risk_26_10_0, risk_26_10_1, person_26_10_0)]

dictionary_observe_26_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9034372281787566, ('false', 'false'): 1.0, ('true', 'true'): 0.0965627718212434}
def f_observe_26_10_0(person_26_10_0, observe_26_10_0):
    return dictionary_observe_26_10_0[(person_26_10_0, observe_26_10_0)]

dictionary_person_27_10_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.09747179936810647, ('false', 'true', 'false', 'false', 'false', 'true'): 0.6467427469827339, ('false', 'true', 'true', 'false', 'true', 'true'): 0.842254644404341, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.15774535559565908, ('false', 'true', 'false', 'false', 'false', 'false'): 0.35325725301726607, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.3529039957642488, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.5530077372628049, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.9025282006318935, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.9024306312631567, ('false', 'false', 'true', 'false', 'false', 'false'): 0.44699226273719506, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.21827977097269874, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.21806149120172605, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.7817202290273013, ('false', 'false', 'false', 'true', 'false', 'true'): 0.3820940147489911, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.6470960042357512, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.09756936873684331, ('false', 'false', 'true', 'false', 'true', 'false'): 0.44654527047445786, ('false', 'true', 'true', 'false', 'false', 'false'): 0.1579032588545136, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.7238008054937957, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.781938508798274, ('false', 'false', 'false', 'true', 'true', 'false'): 0.6172880792657579, ('false', 'false', 'false', 'true', 'false', 'false'): 0.6179059852510089, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.27619919450620434, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.7240770046883018, ('false', 'false', 'true', 'false', 'true', 'true'): 0.5534547295255421, ('false', 'false', 'false', 'true', 'true', 'true'): 0.3827119207342421, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.8420967411454864, ('false', 'false', 'true', 'true', 'true', 'false'): 0.2759229953116981}
def f_person_27_10_0(person_27_9_0, person_28_9_0, person_1_9_0, person_25_9_0, risk_27_10_0, person_27_10_0):
    return dictionary_person_27_10_0[(person_27_9_0, person_28_9_0, person_1_9_0, person_25_9_0, risk_27_10_0, person_27_10_0)]

dictionary_observe_27_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7968302326291135, ('false', 'false'): 1.0, ('true', 'true'): 0.20316976737088654}
def f_observe_27_10_0(person_27_10_0, observe_27_10_0):
    return dictionary_observe_27_10_0[(person_27_10_0, observe_27_10_0)]

dictionary_person_28_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7687528215219074, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.23124717847809262, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7679840687003855, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2320159312996145, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_28_10_0(person_28_9_0, person_34_9_0, risk_28_10_0, person_28_10_0):
    return dictionary_person_28_10_0[(person_28_9_0, person_34_9_0, risk_28_10_0, person_28_10_0)]

dictionary_observe_28_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.504280876266771, ('false', 'false'): 1.0, ('true', 'true'): 0.495719123733229}
def f_observe_28_10_0(person_28_10_0, observe_28_10_0):
    return dictionary_observe_28_10_0[(person_28_10_0, observe_28_10_0)]

dictionary_person_29_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_29_10_0(person_29_9_0, risk_29_10_0, person_29_10_0):
    return dictionary_person_29_10_0[(person_29_9_0, risk_29_10_0, person_29_10_0)]

dictionary_observe_29_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6695388598942162, ('false', 'false'): 1.0, ('true', 'true'): 0.33046114010578376}
def f_observe_29_10_0(person_29_10_0, observe_29_10_0):
    return dictionary_observe_29_10_0[(person_29_10_0, observe_29_10_0)]

dictionary_person_30_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_30_10_0(person_30_9_0, risk_30_10_0, person_30_10_0):
    return dictionary_person_30_10_0[(person_30_9_0, risk_30_10_0, person_30_10_0)]

dictionary_observe_30_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7859133763911281, ('false', 'false'): 1.0, ('true', 'true'): 0.21408662360887187}
def f_observe_30_10_0(person_30_10_0, observe_30_10_0):
    return dictionary_observe_30_10_0[(person_30_10_0, observe_30_10_0)]

dictionary_person_31_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7127856059512219, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.28721439404877813, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7120728203452706, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.28792717965472936, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_31_10_0(person_31_9_0, person_32_9_0, risk_31_10_0, person_31_10_0):
    return dictionary_person_31_10_0[(person_31_9_0, person_32_9_0, risk_31_10_0, person_31_10_0)]

dictionary_observe_31_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9840978723687865, ('false', 'false'): 1.0, ('true', 'true'): 0.01590212763121346}
def f_observe_31_10_0(person_31_10_0, observe_31_10_0):
    return dictionary_observe_31_10_0[(person_31_10_0, observe_31_10_0)]

dictionary_person_32_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6437733226707276, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3562266773292724, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6431295493480569, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3568704506519431, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_32_10_0(person_32_9_0, person_2_9_0, risk_32_10_0, person_32_10_0):
    return dictionary_person_32_10_0[(person_32_9_0, person_2_9_0, risk_32_10_0, person_32_10_0)]

dictionary_observe_32_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.915942691120848, ('false', 'false'): 1.0, ('true', 'true'): 0.08405730887915197}
def f_observe_32_10_0(person_32_10_0, observe_32_10_0):
    return dictionary_observe_32_10_0[(person_32_10_0, observe_32_10_0)]

dictionary_person_33_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4383307610692294, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5616692389307706, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.43789243030816016, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5621075696918398, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_33_10_0(person_33_9_0, person_27_9_0, risk_33_10_0, person_33_10_0):
    return dictionary_person_33_10_0[(person_33_9_0, person_27_9_0, risk_33_10_0, person_33_10_0)]

dictionary_observe_33_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8527973631829622, ('false', 'false'): 1.0, ('true', 'true'): 0.14720263681703782}
def f_observe_33_10_0(person_33_10_0, observe_33_10_0):
    return dictionary_observe_33_10_0[(person_33_10_0, observe_33_10_0)]

dictionary_person_34_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_34_10_0(person_34_9_0, risk_34_10_0, person_34_10_0):
    return dictionary_person_34_10_0[(person_34_9_0, risk_34_10_0, person_34_10_0)]

dictionary_observe_34_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6957553195336958, ('false', 'false'): 1.0, ('true', 'true'): 0.30424468046630415}
def f_observe_34_10_0(person_34_10_0, observe_34_10_0):
    return dictionary_observe_34_10_0[(person_34_10_0, observe_34_10_0)]

dictionary_person_35_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4327942598380976, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5672057401619024, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4323614655782595, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5676385344217405, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_35_10_0(person_35_9_0, person_34_9_0, risk_35_10_0, person_35_10_0):
    return dictionary_person_35_10_0[(person_35_9_0, person_34_9_0, risk_35_10_0, person_35_10_0)]

dictionary_observe_35_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7425947634123655, ('false', 'false'): 1.0, ('true', 'true'): 0.2574052365876345}
def f_observe_35_10_0(person_35_10_0, observe_35_10_0):
    return dictionary_observe_35_10_0[(person_35_10_0, observe_35_10_0)]

functions = [f_person_0_7_0, f_person_1_7_0, f_person_2_7_0, f_person_3_7_0, f_person_4_7_0, f_person_5_7_0, f_person_6_7_0, f_person_7_7_0, f_person_8_7_0, f_person_9_7_0, f_person_10_7_0, f_person_11_7_0, f_person_12_7_0, f_person_13_7_0, f_person_14_7_0, f_person_15_7_0, f_person_16_7_0, f_person_17_7_0, f_person_18_7_0, f_person_19_7_0, f_person_20_7_0, f_person_21_7_0, f_person_22_7_0, f_person_23_7_0, f_person_24_7_0, f_person_25_7_0, f_person_26_7_0, f_person_27_7_0, f_person_28_7_0, f_person_29_7_0, f_person_30_7_0, f_person_31_7_0, f_person_32_7_0, f_person_33_7_0, f_person_34_7_0, f_person_35_7_0, f_risk_0_8_0, f_risk_1_8_0, f_risk_2_8_0, f_risk_2_8_1, f_risk_3_8_0, f_risk_4_8_0, f_risk_5_8_0, f_risk_6_8_0, f_risk_7_8_0, f_risk_8_8_0, f_risk_9_8_0, f_risk_10_8_0, f_risk_11_8_0, f_risk_12_8_0, f_risk_13_8_0, f_risk_14_8_0, f_risk_15_8_0, f_risk_16_8_0, f_risk_17_8_0, f_risk_18_8_0, f_risk_19_8_0, f_risk_20_8_0, f_risk_21_8_0, f_risk_22_8_0, f_risk_23_8_0, f_risk_24_8_0, f_risk_25_8_0, f_risk_26_8_0, f_risk_27_8_0, f_risk_28_8_0, f_risk_29_8_0, f_risk_30_8_0, f_risk_31_8_0, f_risk_32_8_0, f_risk_33_8_0, f_risk_34_8_0, f_risk_35_8_0, f_risk_0_9_0, f_risk_1_9_0, f_risk_2_9_0, f_risk_3_9_0, f_risk_4_9_0, f_risk_5_9_0, f_risk_6_9_0, f_risk_7_9_0, f_risk_8_9_0, f_risk_9_9_0, f_risk_10_9_0, f_risk_11_9_0, f_risk_12_9_0, f_risk_13_9_0, f_risk_14_9_0, f_risk_15_9_0, f_risk_16_9_0, f_risk_17_9_0, f_risk_18_9_0, f_risk_19_9_0, f_risk_20_9_0, f_risk_21_9_0, f_risk_22_9_0, f_risk_23_9_0, f_risk_24_9_0, f_risk_25_9_0, f_risk_26_9_0, f_risk_27_9_0, f_risk_28_9_0, f_risk_29_9_0, f_risk_30_9_0, f_risk_31_9_0, f_risk_31_9_1, f_risk_32_9_0, f_risk_33_9_0, f_risk_34_9_0, f_risk_35_9_0, f_risk_0_10_0, f_risk_1_10_0, f_risk_2_10_0, f_risk_3_10_0, f_risk_4_10_0, f_risk_5_10_0, f_risk_6_10_0, f_risk_7_10_0, f_risk_8_10_0, f_risk_9_10_0, f_risk_10_10_0, f_risk_11_10_0, f_risk_11_10_1, f_risk_12_10_0, f_risk_13_10_0, f_risk_14_10_0, f_risk_15_10_0, f_risk_16_10_0, f_risk_17_10_0, f_risk_17_10_1, f_risk_18_10_0, f_risk_19_10_0, f_risk_20_10_0, f_risk_21_10_0, f_risk_22_10_0, f_risk_23_10_0, f_risk_24_10_0, f_risk_25_10_0, f_risk_26_10_0, f_risk_26_10_1, f_risk_27_10_0, f_risk_28_10_0, f_risk_29_10_0, f_risk_30_10_0, f_risk_31_10_0, f_risk_32_10_0, f_risk_33_10_0, f_risk_34_10_0, f_risk_35_10_0, f_observe_0_7_0, f_observe_1_7_0, f_observe_2_7_0, f_observe_3_7_0, f_observe_4_7_0, f_observe_5_7_0, f_observe_6_7_0, f_observe_7_7_0, f_observe_8_7_0, f_observe_9_7_0, f_observe_10_7_0, f_observe_11_7_0, f_observe_12_7_0, f_observe_13_7_0, f_observe_14_7_0, f_observe_15_7_0, f_observe_16_7_0, f_observe_17_7_0, f_observe_18_7_0, f_observe_19_7_0, f_observe_20_7_0, f_observe_21_7_0, f_observe_22_7_0, f_observe_23_7_0, f_observe_24_7_0, f_observe_25_7_0, f_observe_26_7_0, f_observe_27_7_0, f_observe_28_7_0, f_observe_29_7_0, f_observe_30_7_0, f_observe_31_7_0, f_observe_32_7_0, f_observe_33_7_0, f_observe_34_7_0, f_observe_35_7_0, f_person_0_8_0, f_observe_0_8_0, f_person_1_8_0, f_observe_1_8_0, f_person_2_8_0, f_observe_2_8_0, f_person_3_8_0, f_observe_3_8_0, f_person_4_8_0, f_observe_4_8_0, f_person_5_8_0, f_observe_5_8_0, f_person_6_8_0, f_observe_6_8_0, f_person_7_8_0, f_observe_7_8_0, f_person_8_8_0, f_observe_8_8_0, f_person_9_8_0, f_observe_9_8_0, f_person_10_8_0, f_observe_10_8_0, f_person_11_8_0, f_observe_11_8_0, f_person_12_8_0, f_observe_12_8_0, f_person_13_8_0, f_observe_13_8_0, f_person_14_8_0, f_observe_14_8_0, f_person_15_8_0, f_observe_15_8_0, f_person_16_8_0, f_observe_16_8_0, f_person_17_8_0, f_observe_17_8_0, f_person_18_8_0, f_observe_18_8_0, f_person_19_8_0, f_observe_19_8_0, f_person_20_8_0, f_observe_20_8_0, f_person_21_8_0, f_observe_21_8_0, f_person_22_8_0, f_observe_22_8_0, f_person_23_8_0, f_observe_23_8_0, f_person_24_8_0, f_observe_24_8_0, f_person_25_8_0, f_observe_25_8_0, f_person_26_8_0, f_observe_26_8_0, f_person_27_8_0, f_observe_27_8_0, f_person_28_8_0, f_observe_28_8_0, f_person_29_8_0, f_observe_29_8_0, f_person_30_8_0, f_observe_30_8_0, f_person_31_8_0, f_observe_31_8_0, f_person_32_8_0, f_observe_32_8_0, f_person_33_8_0, f_observe_33_8_0, f_person_34_8_0, f_observe_34_8_0, f_person_35_8_0, f_observe_35_8_0, f_person_0_9_0, f_observe_0_9_0, f_person_1_9_0, f_observe_1_9_0, f_person_2_9_0, f_observe_2_9_0, f_person_3_9_0, f_observe_3_9_0, f_person_4_9_0, f_observe_4_9_0, f_person_5_9_0, f_observe_5_9_0, f_person_6_9_0, f_observe_6_9_0, f_person_7_9_0, f_observe_7_9_0, f_person_8_9_0, f_observe_8_9_0, f_person_9_9_0, f_observe_9_9_0, f_person_10_9_0, f_observe_10_9_0, f_person_11_9_0, f_observe_11_9_0, f_person_12_9_0, f_observe_12_9_0, f_person_13_9_0, f_observe_13_9_0, f_person_14_9_0, f_observe_14_9_0, f_person_15_9_0, f_observe_15_9_0, f_person_16_9_0, f_observe_16_9_0, f_person_17_9_0, f_observe_17_9_0, f_person_18_9_0, f_observe_18_9_0, f_person_19_9_0, f_observe_19_9_0, f_person_20_9_0, f_observe_20_9_0, f_person_21_9_0, f_observe_21_9_0, f_person_22_9_0, f_observe_22_9_0, f_person_23_9_0, f_observe_23_9_0, f_person_24_9_0, f_observe_24_9_0, f_person_25_9_0, f_observe_25_9_0, f_person_26_9_0, f_observe_26_9_0, f_person_27_9_0, f_observe_27_9_0, f_person_28_9_0, f_observe_28_9_0, f_person_29_9_0, f_observe_29_9_0, f_person_30_9_0, f_observe_30_9_0, f_person_31_9_0, f_observe_31_9_0, f_person_32_9_0, f_observe_32_9_0, f_person_33_9_0, f_observe_33_9_0, f_person_34_9_0, f_observe_34_9_0, f_person_35_9_0, f_observe_35_9_0, f_person_0_10_0, f_observe_0_10_0, f_person_1_10_0, f_observe_1_10_0, f_person_2_10_0, f_observe_2_10_0, f_person_3_10_0, f_observe_3_10_0, f_person_4_10_0, f_observe_4_10_0, f_person_5_10_0, f_observe_5_10_0, f_person_6_10_0, f_observe_6_10_0, f_person_7_10_0, f_observe_7_10_0, f_person_8_10_0, f_observe_8_10_0, f_person_9_10_0, f_observe_9_10_0, f_person_10_10_0, f_observe_10_10_0, f_person_11_10_0, f_observe_11_10_0, f_person_12_10_0, f_observe_12_10_0, f_person_13_10_0, f_observe_13_10_0, f_person_14_10_0, f_observe_14_10_0, f_person_15_10_0, f_observe_15_10_0, f_person_16_10_0, f_observe_16_10_0, f_person_17_10_0, f_observe_17_10_0, f_person_18_10_0, f_observe_18_10_0, f_person_19_10_0, f_observe_19_10_0, f_person_20_10_0, f_observe_20_10_0, f_person_21_10_0, f_observe_21_10_0, f_person_22_10_0, f_observe_22_10_0, f_person_23_10_0, f_observe_23_10_0, f_person_24_10_0, f_observe_24_10_0, f_person_25_10_0, f_observe_25_10_0, f_person_26_10_0, f_observe_26_10_0, f_person_27_10_0, f_observe_27_10_0, f_person_28_10_0, f_observe_28_10_0, f_person_29_10_0, f_observe_29_10_0, f_person_30_10_0, f_observe_30_10_0, f_person_31_10_0, f_observe_31_10_0, f_person_32_10_0, f_observe_32_10_0, f_person_33_10_0, f_observe_33_10_0, f_person_34_10_0, f_observe_34_10_0, f_person_35_10_0, f_observe_35_10_0]
domains_dict = {'person_33_7_0': ['false', 'true'], 'person_4_7_0': ['false', 'true'], 'risk_13_8_0': ['false', 'true'], 'risk_6_8_0': ['false', 'true'], 'person_31_7_0': ['false', 'true'], 'risk_2_9_0': ['false', 'true'], 'person_17_8_0': ['false', 'true'], 'risk_10_9_0': ['false', 'true'], 'observe_23_9_0': ['false', 'true'], 'risk_13_10_0': ['false', 'true'], 'observe_0_10_0': ['false', 'true'], 'person_4_9_0': ['false', 'true'], 'observe_3_10_0': ['false', 'true'], 'person_34_8_0': ['false', 'true'], 'person_31_9_0': ['false', 'true'], 'person_29_10_0': ['false', 'true'], 'person_17_10_0': ['false', 'true'], 'risk_5_10_0': ['false', 'true'], 'risk_23_9_0': ['false', 'true'], 'person_33_10_0': ['false', 'true'], 'person_32_8_0': ['false', 'true'], 'risk_31_10_0': ['false', 'true'], 'person_0_8_0': ['false', 'true'], 'person_9_10_0': ['false', 'true'], 'observe_21_10_0': ['false', 'true'], 'person_27_7_0': ['false', 'true'], 'risk_12_10_0': ['false', 'true'], 'risk_27_10_0': ['false', 'true'], 'risk_26_8_0': ['false', 'true'], 'observe_30_8_0': ['false', 'true'], 'risk_21_9_0': ['false', 'true'], 'person_25_7_0': ['false', 'true'], 'person_2_8_0': ['false', 'true'], 'observe_4_10_0': ['false', 'true'], 'person_31_10_0': ['false', 'true'], 'person_5_10_0': ['false', 'true'], 'person_18_10_0': ['false', 'true'], 'observe_7_8_0': ['false', 'true'], 'person_25_9_0': ['false', 'true'], 'person_29_9_0': ['false', 'true'], 'person_16_9_0': ['false', 'true'], 'observe_15_8_0': ['false', 'true'], 'risk_28_9_0': ['false', 'true'], 'observe_35_9_0': ['false', 'true'], 'observe_35_7_0': ['false', 'true'], 'risk_0_9_0': ['false', 'true'], 'observe_25_8_0': ['false', 'true'], 'person_7_9_0': ['false', 'true'], 'person_27_8_0': ['false', 'true'], 'person_10_8_0': ['false', 'true'], 'risk_18_9_0': ['false', 'true'], 'person_29_7_0': ['false', 'true'], 'person_1_10_0': ['false', 'true'], 'observe_18_8_0': ['false', 'true'], 'person_26_9_0': ['false', 'true'], 'risk_34_8_0': ['false', 'true'], 'risk_29_8_0': ['false', 'true'], 'risk_24_9_0': ['false', 'true'], 'person_22_10_0': ['false', 'true'], 'observe_25_7_0': ['false', 'true'], 'person_24_9_0': ['false', 'true'], 'observe_1_8_0': ['false', 'true'], 'person_21_8_0': ['false', 'true'], 'risk_11_9_0': ['false', 'true'], 'observe_21_8_0': ['false', 'true'], 'observe_23_10_0': ['false', 'true'], 'observe_27_7_0': ['false', 'true'], 'person_15_8_0': ['false', 'true'], 'risk_8_8_0': ['false', 'true'], 'person_25_10_0': ['false', 'true'], 'risk_34_10_0': ['false', 'true'], 'observe_13_10_0': ['false', 'true'], 'observe_1_10_0': ['false', 'true'], 'person_7_10_0': ['false', 'true'], 'observe_17_9_0': ['false', 'true'], 'person_24_7_0': ['false', 'true'], 'observe_35_10_0': ['false', 'true'], 'person_7_7_0': ['false', 'true'], 'person_11_9_0': ['false', 'true'], 'risk_1_10_0': ['false', 'true'], 'observe_23_8_0': ['false', 'true'], 'observe_18_7_0': ['false', 'true'], 'person_17_9_0': ['false', 'true'], 'observe_27_9_0': ['false', 'true'], 'risk_2_8_0': ['false', 'true'], 'risk_2_8_1': ['false', 'true'], 'risk_3_9_0': ['false', 'true'], 'person_14_10_0': ['false', 'true'], 'person_34_9_0': ['false', 'true'], 'risk_23_8_0': ['false', 'true'], 'person_12_10_0': ['false', 'true'], 'person_11_7_0': ['false', 'true'], 'observe_7_10_0': ['false', 'true'], 'risk_13_9_0': ['false', 'true'], 'observe_32_10_0': ['false', 'true'], 'person_32_7_0': ['false', 'true'], 'person_3_10_0': ['false', 'true'], 'person_0_9_0': ['false', 'true'], 'person_32_9_0': ['false', 'true'], 'person_14_8_0': ['false', 'true'], 'person_0_7_0': ['false', 'true'], 'observe_23_7_0': ['false', 'true'], 'observe_5_10_0': ['false', 'true'], 'observe_33_10_0': ['false', 'true'], 'risk_21_8_0': ['false', 'true'], 'risk_7_10_0': ['false', 'true'], 'observe_9_8_0': ['false', 'true'], 'person_3_8_0': ['false', 'true'], 'person_8_9_0': ['false', 'true'], 'observe_32_7_0': ['false', 'true'], 'observe_32_9_0': ['false', 'true'], 'risk_22_9_0': ['false', 'true'], 'person_6_7_0': ['false', 'true'], 'risk_28_8_0': ['false', 'true'], 'person_11_10_0': ['false', 'true'], 'observe_25_9_0': ['false', 'true'], 'person_7_8_0': ['false', 'true'], 'risk_14_10_0': ['false', 'true'], 'person_20_8_0': ['false', 'true'], 'person_3_7_0': ['false', 'true'], 'risk_18_8_0': ['false', 'true'], 'risk_30_10_0': ['false', 'true'], 'person_14_7_0': ['false', 'true'], 'person_1_7_0': ['false', 'true'], 'observe_1_7_0': ['false', 'true'], 'observe_34_10_0': ['false', 'true'], 'observe_16_9_0': ['false', 'true'], 'observe_11_9_0': ['false', 'true'], 'risk_34_9_0': ['false', 'true'], 'risk_29_9_0': ['false', 'true'], 'observe_16_7_0': ['false', 'true'], 'person_19_9_0': ['false', 'true'], 'person_20_7_0': ['false', 'true'], 'observe_0_8_0': ['false', 'true'], 'person_5_8_0': ['false', 'true'], 'person_24_8_0': ['false', 'true'], 'risk_8_9_0': ['false', 'true'], 'person_22_7_0': ['false', 'true'], 'risk_11_8_0': ['false', 'true'], 'person_1_9_0': ['false', 'true'], 'risk_10_10_0': ['false', 'true'], 'observe_34_9_0': ['false', 'true'], 'observe_13_8_0': ['false', 'true'], 'risk_31_8_0': ['false', 'true'], 'person_6_9_0': ['false', 'true'], 'risk_2_10_0': ['false', 'true'], 'observe_2_8_0': ['false', 'true'], 'risk_19_8_0': ['false', 'true'], 'person_26_8_0': ['false', 'true'], 'person_11_8_0': ['false', 'true'], 'person_22_9_0': ['false', 'true'], 'observe_27_8_0': ['false', 'true'], 'risk_32_10_0': ['false', 'true'], 'risk_3_8_0': ['false', 'true'], 'observe_26_9_0': ['false', 'true'], 'risk_3_10_0': ['false', 'true'], 'observe_34_7_0': ['false', 'true'], 'observe_25_10_0': ['false', 'true'], 'person_27_10_0': ['false', 'true'], 'observe_26_7_0': ['false', 'true'], 'risk_8_10_0': ['false', 'true'], 'observe_1_9_0': ['false', 'true'], 'observe_29_10_0': ['false', 'true'], 'risk_17_8_0': ['false', 'true'], 'person_32_10_0': ['false', 'true'], 'observe_28_9_0': ['false', 'true'], 'person_5_7_0': ['false', 'true'], 'risk_25_8_0': ['false', 'true'], 'risk_33_9_0': ['false', 'true'], 'risk_23_10_0': ['false', 'true'], 'person_8_7_0': ['false', 'true'], 'person_26_7_0': ['false', 'true'], 'person_14_9_0': ['false', 'true'], 'observe_34_8_0': ['false', 'true'], 'observe_2_7_0': ['false', 'true'], 'person_6_10_0': ['false', 'true'], 'observe_9_9_0': ['false', 'true'], 'risk_22_10_0': ['false', 'true'], 'person_3_9_0': ['false', 'true'], 'person_8_8_0': ['false', 'true'], 'observe_32_8_0': ['false', 'true'], 'observe_33_9_0': ['false', 'true'], 'risk_22_8_0': ['false', 'true'], 'person_20_9_0': ['false', 'true'], 'person_6_8_0': ['false', 'true'], 'observe_10_7_0': ['false', 'true'], 'observe_4_9_0': ['false', 'true'], 'risk_4_10_0': ['false', 'true'], 'risk_20_9_0': ['false', 'true'], 'person_23_10_0': ['false', 'true'], 'observe_11_8_0': ['false', 'true'], 'observe_33_7_0': ['false', 'true'], 'observe_9_7_0': ['false', 'true'], 'observe_16_8_0': ['false', 'true'], 'person_28_10_0': ['false', 'true'], 'observe_31_7_0': ['false', 'true'], 'person_19_8_0': ['false', 'true'], 'risk_5_8_0': ['false', 'true'], 'observe_0_9_0': ['false', 'true'], 'person_28_8_0': ['false', 'true'], 'person_1_8_0': ['false', 'true'], 'risk_9_8_0': ['false', 'true'], 'observe_30_10_0': ['false', 'true'], 'person_12_8_0': ['false', 'true'], 'risk_31_9_0': ['false', 'true'], 'risk_31_9_1': ['false', 'true'], 'observe_13_9_0': ['false', 'true'], 'risk_27_8_0': ['false', 'true'], 'observe_31_8_0': ['false', 'true'], 'observe_17_10_0': ['false', 'true'], 'person_19_7_0': ['false', 'true'], 'risk_19_9_0': ['false', 'true'], 'observe_13_7_0': ['false', 'true'], 'observe_9_10_0': ['false', 'true'], 'observe_2_10_0': ['false', 'true'], 'observe_2_9_0': ['false', 'true'], 'risk_7_9_0': ['false', 'true'], 'observe_6_8_0': ['false', 'true'], 'observe_26_8_0': ['false', 'true'], 'person_22_8_0': ['false', 'true'], 'risk_30_8_0': ['false', 'true'], 'person_23_9_0': ['false', 'true'], 'observe_11_7_0': ['false', 'true'], 'observe_15_10_0': ['false', 'true'], 'observe_10_8_0': ['false', 'true'], 'observe_8_7_0': ['false', 'true'], 'person_23_7_0': ['false', 'true'], 'risk_16_8_0': ['false', 'true'], 'observe_8_9_0': ['false', 'true'], 'observe_0_7_0': ['false', 'true'], 'risk_6_10_0': ['false', 'true'], 'risk_1_9_0': ['false', 'true'], 'observe_28_8_0': ['false', 'true'], 'observe_20_10_0': ['false', 'true'], 'observe_6_10_0': ['false', 'true'], 'risk_20_10_0': ['false', 'true'], 'risk_33_8_0': ['false', 'true'], 'risk_14_8_0': ['false', 'true'], 'person_18_8_0': ['false', 'true'], 'person_24_10_0': ['false', 'true'], 'risk_24_10_0': ['false', 'true'], 'observe_12_10_0': ['false', 'true'], 'risk_30_9_0': ['false', 'true'], 'risk_17_9_0': ['false', 'true'], 'observe_3_7_0': ['false', 'true'], 'risk_25_9_0': ['false', 'true'], 'person_9_8_0': ['false', 'true'], 'person_35_8_0': ['false', 'true'], 'observe_28_7_0': ['false', 'true'], 'person_30_8_0': ['false', 'true'], 'observe_33_8_0': ['false', 'true'], 'person_35_10_0': ['false', 'true'], 'risk_35_10_0': ['false', 'true'], 'person_17_7_0': ['false', 'true'], 'observe_3_9_0': ['false', 'true'], 'observe_4_8_0': ['false', 'true'], 'person_33_9_0': ['false', 'true'], 'person_4_10_0': ['false', 'true'], 'observe_18_9_0': ['false', 'true'], 'observe_19_9_0': ['false', 'true'], 'person_12_7_0': ['false', 'true'], 'risk_16_9_0': ['false', 'true'], 'person_28_9_0': ['false', 'true'], 'observe_14_7_0': ['false', 'true'], 'observe_4_7_0': ['false', 'true'], 'observe_20_8_0': ['false', 'true'], 'person_26_10_0': ['false', 'true'], 'risk_5_9_0': ['false', 'true'], 'observe_6_7_0': ['false', 'true'], 'observe_14_9_0': ['false', 'true'], 'person_35_7_0': ['false', 'true'], 'risk_9_9_0': ['false', 'true'], 'person_12_9_0': ['false', 'true'], 'person_8_10_0': ['false', 'true'], 'risk_27_9_0': ['false', 'true'], 'observe_31_9_0': ['false', 'true'], 'observe_5_8_0': ['false', 'true'], 'person_20_10_0': ['false', 'true'], 'risk_7_8_0': ['false', 'true'], 'observe_24_10_0': ['false', 'true'], 'risk_12_9_0': ['false', 'true'], 'observe_22_9_0': ['false', 'true'], 'observe_29_8_0': ['false', 'true'], 'person_23_8_0': ['false', 'true'], 'observe_6_9_0': ['false', 'true'], 'person_16_10_0': ['false', 'true'], 'observe_10_9_0': ['false', 'true'], 'observe_19_10_0': ['false', 'true'], 'risk_35_8_0': ['false', 'true'], 'risk_16_10_0': ['false', 'true'], 'person_28_7_0': ['false', 'true'], 'risk_28_10_0': ['false', 'true'], 'observe_31_10_0': ['false', 'true'], 'observe_24_7_0': ['false', 'true'], 'risk_4_9_0': ['false', 'true'], 'risk_15_10_0': ['false', 'true'], 'risk_1_8_0': ['false', 'true'], 'observe_24_9_0': ['false', 'true'], 'person_13_9_0': ['false', 'true'], 'observe_12_9_0': ['false', 'true'], 'observe_18_10_0': ['false', 'true'], 'person_13_7_0': ['false', 'true'], 'risk_32_8_0': ['false', 'true'], 'risk_6_9_0': ['false', 'true'], 'person_18_7_0': ['false', 'true'], 'risk_14_9_0': ['false', 'true'], 'observe_19_7_0': ['false', 'true'], 'person_13_10_0': ['false', 'true'], 'person_18_9_0': ['false', 'true'], 'risk_10_8_0': ['false', 'true'], 'observe_12_7_0': ['false', 'true'], 'risk_0_10_0': ['false', 'true'], 'observe_22_10_0': ['false', 'true'], 'risk_19_10_0': ['false', 'true'], 'observe_8_8_0': ['false', 'true'], 'person_35_9_0': ['false', 'true'], 'risk_26_10_1': ['false', 'true'], 'risk_26_10_0': ['false', 'true'], 'observe_10_10_0': ['false', 'true'], 'person_9_9_0': ['false', 'true'], 'person_31_8_0': ['false', 'true'], 'observe_16_10_0': ['false', 'true'], 'person_9_7_0': ['false', 'true'], 'person_30_9_0': ['false', 'true'], 'risk_33_10_0': ['false', 'true'], 'person_19_10_0': ['false', 'true'], 'person_30_7_0': ['false', 'true'], 'person_34_10_0': ['false', 'true'], 'person_15_10_0': ['false', 'true'], 'observe_28_10_0': ['false', 'true'], 'person_4_8_0': ['false', 'true'], 'observe_22_7_0': ['false', 'true'], 'observe_19_8_0': ['false', 'true'], 'observe_12_8_0': ['false', 'true'], 'risk_26_9_0': ['false', 'true'], 'observe_30_9_0': ['false', 'true'], 'observe_30_7_0': ['false', 'true'], 'observe_20_7_0': ['false', 'true'], 'person_0_10_0': ['false', 'true'], 'observe_3_8_0': ['false', 'true'], 'person_21_10_0': ['false', 'true'], 'observe_7_9_0': ['false', 'true'], 'person_25_8_0': ['false', 'true'], 'person_29_8_0': ['false', 'true'], 'risk_9_10_0': ['false', 'true'], 'observe_20_9_0': ['false', 'true'], 'person_16_8_0': ['false', 'true'], 'observe_7_7_0': ['false', 'true'], 'person_2_10_0': ['false', 'true'], 'observe_14_8_0': ['false', 'true'], 'observe_35_8_0': ['false', 'true'], 'observe_15_9_0': ['false', 'true'], 'risk_17_10_1': ['false', 'true'], 'risk_17_10_0': ['false', 'true'], 'observe_29_7_0': ['false', 'true'], 'risk_15_9_0': ['false', 'true'], 'observe_27_10_0': ['false', 'true'], 'risk_32_9_0': ['false', 'true'], 'risk_12_8_0': ['false', 'true'], 'risk_15_8_0': ['false', 'true'], 'observe_22_8_0': ['false', 'true'], 'risk_0_8_0': ['false', 'true'], 'observe_29_9_0': ['false', 'true'], 'observe_11_10_0': ['false', 'true'], 'person_10_10_0': ['false', 'true'], 'person_27_9_0': ['false', 'true'], 'person_10_9_0': ['false', 'true'], 'risk_35_9_0': ['false', 'true'], 'observe_14_10_0': ['false', 'true'], 'observe_26_10_0': ['false', 'true'], 'observe_15_7_0': ['false', 'true'], 'person_2_7_0': ['false', 'true'], 'person_15_7_0': ['false', 'true'], 'risk_29_10_0': ['false', 'true'], 'person_2_9_0': ['false', 'true'], 'observe_17_7_0': ['false', 'true'], 'risk_24_8_0': ['false', 'true'], 'person_21_7_0': ['false', 'true'], 'risk_25_10_0': ['false', 'true'], 'observe_21_9_0': ['false', 'true'], 'observe_8_10_0': ['false', 'true'], 'person_33_8_0': ['false', 'true'], 'risk_4_8_0': ['false', 'true'], 'observe_24_8_0': ['false', 'true'], 'person_15_9_0': ['false', 'true'], 'risk_21_10_0': ['false', 'true'], 'person_21_9_0': ['false', 'true'], 'person_5_9_0': ['false', 'true'], 'person_10_7_0': ['false', 'true'], 'person_34_7_0': ['false', 'true'], 'person_13_8_0': ['false', 'true'], 'person_30_10_0': ['false', 'true'], 'observe_5_7_0': ['false', 'true'], 'observe_17_8_0': ['false', 'true'], 'person_16_7_0': ['false', 'true'], 'risk_20_8_0': ['false', 'true'], 'observe_5_9_0': ['false', 'true'], 'risk_18_10_0': ['false', 'true'], 'observe_21_7_0': ['false', 'true'], 'risk_11_10_1': ['false', 'true'], 'risk_11_10_0': ['false', 'true']}

def create_graph():
    g = build_graph(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/d4_addtional/d4_new30/infection0'
    return g

def create_bbn():
    g = build_bbn(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/d4_addtional/d4_new30/infection0'
    return g

