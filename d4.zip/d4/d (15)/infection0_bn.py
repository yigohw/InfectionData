from bayesian.factor_graph import *
from bayesian.bbn import *

dictionary_person_0_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_0_7_0(person_0_7_0):
    return dictionary_person_0_7_0[person_0_7_0]

dictionary_person_1_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_1_7_0(person_1_7_0):
    return dictionary_person_1_7_0[person_1_7_0]

dictionary_person_2_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_2_7_0(person_2_7_0):
    return dictionary_person_2_7_0[person_2_7_0]

dictionary_person_3_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_3_7_0(person_3_7_0):
    return dictionary_person_3_7_0[person_3_7_0]

dictionary_person_4_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_4_7_0(person_4_7_0):
    return dictionary_person_4_7_0[person_4_7_0]

dictionary_person_5_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_5_7_0(person_5_7_0):
    return dictionary_person_5_7_0[person_5_7_0]

dictionary_person_6_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_6_7_0(person_6_7_0):
    return dictionary_person_6_7_0[person_6_7_0]

dictionary_person_7_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_7_7_0(person_7_7_0):
    return dictionary_person_7_7_0[person_7_7_0]

dictionary_person_8_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_8_7_0(person_8_7_0):
    return dictionary_person_8_7_0[person_8_7_0]

dictionary_person_9_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_9_7_0(person_9_7_0):
    return dictionary_person_9_7_0[person_9_7_0]

dictionary_person_10_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_10_7_0(person_10_7_0):
    return dictionary_person_10_7_0[person_10_7_0]

dictionary_person_11_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_11_7_0(person_11_7_0):
    return dictionary_person_11_7_0[person_11_7_0]

dictionary_person_12_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_12_7_0(person_12_7_0):
    return dictionary_person_12_7_0[person_12_7_0]

dictionary_person_13_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_13_7_0(person_13_7_0):
    return dictionary_person_13_7_0[person_13_7_0]

dictionary_person_14_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_14_7_0(person_14_7_0):
    return dictionary_person_14_7_0[person_14_7_0]

dictionary_person_15_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_15_7_0(person_15_7_0):
    return dictionary_person_15_7_0[person_15_7_0]

dictionary_person_16_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_16_7_0(person_16_7_0):
    return dictionary_person_16_7_0[person_16_7_0]

dictionary_person_17_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_17_7_0(person_17_7_0):
    return dictionary_person_17_7_0[person_17_7_0]

dictionary_person_18_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_18_7_0(person_18_7_0):
    return dictionary_person_18_7_0[person_18_7_0]

dictionary_person_19_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_19_7_0(person_19_7_0):
    return dictionary_person_19_7_0[person_19_7_0]

dictionary_person_20_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_20_7_0(person_20_7_0):
    return dictionary_person_20_7_0[person_20_7_0]

dictionary_person_21_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_21_7_0(person_21_7_0):
    return dictionary_person_21_7_0[person_21_7_0]

dictionary_person_22_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_22_7_0(person_22_7_0):
    return dictionary_person_22_7_0[person_22_7_0]

dictionary_person_23_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_23_7_0(person_23_7_0):
    return dictionary_person_23_7_0[person_23_7_0]

dictionary_person_24_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_24_7_0(person_24_7_0):
    return dictionary_person_24_7_0[person_24_7_0]

dictionary_person_25_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_25_7_0(person_25_7_0):
    return dictionary_person_25_7_0[person_25_7_0]

dictionary_person_26_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_26_7_0(person_26_7_0):
    return dictionary_person_26_7_0[person_26_7_0]

dictionary_person_27_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_27_7_0(person_27_7_0):
    return dictionary_person_27_7_0[person_27_7_0]

dictionary_person_28_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_28_7_0(person_28_7_0):
    return dictionary_person_28_7_0[person_28_7_0]

dictionary_person_29_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_29_7_0(person_29_7_0):
    return dictionary_person_29_7_0[person_29_7_0]

dictionary_person_30_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_30_7_0(person_30_7_0):
    return dictionary_person_30_7_0[person_30_7_0]

dictionary_person_31_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_31_7_0(person_31_7_0):
    return dictionary_person_31_7_0[person_31_7_0]

dictionary_person_32_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_32_7_0(person_32_7_0):
    return dictionary_person_32_7_0[person_32_7_0]

dictionary_person_33_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_33_7_0(person_33_7_0):
    return dictionary_person_33_7_0[person_33_7_0]

dictionary_person_34_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_34_7_0(person_34_7_0):
    return dictionary_person_34_7_0[person_34_7_0]

dictionary_person_35_7_0 = {'true': 0.1, 'false': 0.9}

def f_person_35_7_0(person_35_7_0):
    return dictionary_person_35_7_0[person_35_7_0]

dictionary_risk_0_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_8_0(risk_0_8_0):
    return dictionary_risk_0_8_0[risk_0_8_0]

dictionary_risk_1_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_8_0(risk_1_8_0):
    return dictionary_risk_1_8_0[risk_1_8_0]

dictionary_risk_2_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_8_0(risk_2_8_0):
    return dictionary_risk_2_8_0[risk_2_8_0]

dictionary_risk_3_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_8_0(risk_3_8_0):
    return dictionary_risk_3_8_0[risk_3_8_0]

dictionary_risk_4_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_8_0(risk_4_8_0):
    return dictionary_risk_4_8_0[risk_4_8_0]

dictionary_risk_5_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_8_0(risk_5_8_0):
    return dictionary_risk_5_8_0[risk_5_8_0]

dictionary_risk_6_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_8_0(risk_6_8_0):
    return dictionary_risk_6_8_0[risk_6_8_0]

dictionary_risk_7_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_8_0(risk_7_8_0):
    return dictionary_risk_7_8_0[risk_7_8_0]

dictionary_risk_8_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_8_0(risk_8_8_0):
    return dictionary_risk_8_8_0[risk_8_8_0]

dictionary_risk_9_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_8_0(risk_9_8_0):
    return dictionary_risk_9_8_0[risk_9_8_0]

dictionary_risk_10_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_8_0(risk_10_8_0):
    return dictionary_risk_10_8_0[risk_10_8_0]

dictionary_risk_11_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_8_0(risk_11_8_0):
    return dictionary_risk_11_8_0[risk_11_8_0]

dictionary_risk_12_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_8_0(risk_12_8_0):
    return dictionary_risk_12_8_0[risk_12_8_0]

dictionary_risk_13_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_8_0(risk_13_8_0):
    return dictionary_risk_13_8_0[risk_13_8_0]

dictionary_risk_14_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_8_0(risk_14_8_0):
    return dictionary_risk_14_8_0[risk_14_8_0]

dictionary_risk_15_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_8_0(risk_15_8_0):
    return dictionary_risk_15_8_0[risk_15_8_0]

dictionary_risk_16_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_8_0(risk_16_8_0):
    return dictionary_risk_16_8_0[risk_16_8_0]

dictionary_risk_17_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_8_0(risk_17_8_0):
    return dictionary_risk_17_8_0[risk_17_8_0]

dictionary_risk_18_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_8_0(risk_18_8_0):
    return dictionary_risk_18_8_0[risk_18_8_0]

dictionary_risk_19_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_8_0(risk_19_8_0):
    return dictionary_risk_19_8_0[risk_19_8_0]

dictionary_risk_20_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_8_0(risk_20_8_0):
    return dictionary_risk_20_8_0[risk_20_8_0]

dictionary_risk_21_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_8_0(risk_21_8_0):
    return dictionary_risk_21_8_0[risk_21_8_0]

dictionary_risk_22_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_8_0(risk_22_8_0):
    return dictionary_risk_22_8_0[risk_22_8_0]

dictionary_risk_23_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_8_0(risk_23_8_0):
    return dictionary_risk_23_8_0[risk_23_8_0]

dictionary_risk_24_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_8_0(risk_24_8_0):
    return dictionary_risk_24_8_0[risk_24_8_0]

dictionary_risk_25_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_8_0(risk_25_8_0):
    return dictionary_risk_25_8_0[risk_25_8_0]

dictionary_risk_26_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_8_0(risk_26_8_0):
    return dictionary_risk_26_8_0[risk_26_8_0]

dictionary_risk_27_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_8_0(risk_27_8_0):
    return dictionary_risk_27_8_0[risk_27_8_0]

dictionary_risk_28_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_8_0(risk_28_8_0):
    return dictionary_risk_28_8_0[risk_28_8_0]

dictionary_risk_29_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_8_0(risk_29_8_0):
    return dictionary_risk_29_8_0[risk_29_8_0]

dictionary_risk_30_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_8_0(risk_30_8_0):
    return dictionary_risk_30_8_0[risk_30_8_0]

dictionary_risk_31_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_8_0(risk_31_8_0):
    return dictionary_risk_31_8_0[risk_31_8_0]

dictionary_risk_32_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_8_0(risk_32_8_0):
    return dictionary_risk_32_8_0[risk_32_8_0]

dictionary_risk_33_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_8_0(risk_33_8_0):
    return dictionary_risk_33_8_0[risk_33_8_0]

dictionary_risk_34_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_8_0(risk_34_8_0):
    return dictionary_risk_34_8_0[risk_34_8_0]

dictionary_risk_35_8_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_8_0(risk_35_8_0):
    return dictionary_risk_35_8_0[risk_35_8_0]

dictionary_risk_0_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_9_0(risk_0_9_0):
    return dictionary_risk_0_9_0[risk_0_9_0]

dictionary_risk_1_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_9_0(risk_1_9_0):
    return dictionary_risk_1_9_0[risk_1_9_0]

dictionary_risk_2_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_9_0(risk_2_9_0):
    return dictionary_risk_2_9_0[risk_2_9_0]

dictionary_risk_3_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_9_0(risk_3_9_0):
    return dictionary_risk_3_9_0[risk_3_9_0]

dictionary_risk_4_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_9_0(risk_4_9_0):
    return dictionary_risk_4_9_0[risk_4_9_0]

dictionary_risk_5_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_9_0(risk_5_9_0):
    return dictionary_risk_5_9_0[risk_5_9_0]

dictionary_risk_6_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_9_0(risk_6_9_0):
    return dictionary_risk_6_9_0[risk_6_9_0]

dictionary_risk_7_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_9_0(risk_7_9_0):
    return dictionary_risk_7_9_0[risk_7_9_0]

dictionary_risk_8_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_9_0(risk_8_9_0):
    return dictionary_risk_8_9_0[risk_8_9_0]

dictionary_risk_9_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_9_0(risk_9_9_0):
    return dictionary_risk_9_9_0[risk_9_9_0]

dictionary_risk_10_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_9_0(risk_10_9_0):
    return dictionary_risk_10_9_0[risk_10_9_0]

dictionary_risk_11_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_9_0(risk_11_9_0):
    return dictionary_risk_11_9_0[risk_11_9_0]

dictionary_risk_12_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_9_0(risk_12_9_0):
    return dictionary_risk_12_9_0[risk_12_9_0]

dictionary_risk_13_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_9_0(risk_13_9_0):
    return dictionary_risk_13_9_0[risk_13_9_0]

dictionary_risk_14_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_9_0(risk_14_9_0):
    return dictionary_risk_14_9_0[risk_14_9_0]

dictionary_risk_15_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_9_0(risk_15_9_0):
    return dictionary_risk_15_9_0[risk_15_9_0]

dictionary_risk_16_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_9_0(risk_16_9_0):
    return dictionary_risk_16_9_0[risk_16_9_0]

dictionary_risk_17_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_9_0(risk_17_9_0):
    return dictionary_risk_17_9_0[risk_17_9_0]

dictionary_risk_18_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_9_0(risk_18_9_0):
    return dictionary_risk_18_9_0[risk_18_9_0]

dictionary_risk_19_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_9_0(risk_19_9_0):
    return dictionary_risk_19_9_0[risk_19_9_0]

dictionary_risk_20_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_9_0(risk_20_9_0):
    return dictionary_risk_20_9_0[risk_20_9_0]

dictionary_risk_21_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_9_0(risk_21_9_0):
    return dictionary_risk_21_9_0[risk_21_9_0]

dictionary_risk_22_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_9_0(risk_22_9_0):
    return dictionary_risk_22_9_0[risk_22_9_0]

dictionary_risk_23_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_9_0(risk_23_9_0):
    return dictionary_risk_23_9_0[risk_23_9_0]

dictionary_risk_24_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_9_0(risk_24_9_0):
    return dictionary_risk_24_9_0[risk_24_9_0]

dictionary_risk_25_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_9_0(risk_25_9_0):
    return dictionary_risk_25_9_0[risk_25_9_0]

dictionary_risk_26_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_9_0(risk_26_9_0):
    return dictionary_risk_26_9_0[risk_26_9_0]

dictionary_risk_27_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_9_0(risk_27_9_0):
    return dictionary_risk_27_9_0[risk_27_9_0]

dictionary_risk_28_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_9_0(risk_28_9_0):
    return dictionary_risk_28_9_0[risk_28_9_0]

dictionary_risk_29_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_9_0(risk_29_9_0):
    return dictionary_risk_29_9_0[risk_29_9_0]

dictionary_risk_30_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_9_0(risk_30_9_0):
    return dictionary_risk_30_9_0[risk_30_9_0]

dictionary_risk_31_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_9_0(risk_31_9_0):
    return dictionary_risk_31_9_0[risk_31_9_0]

dictionary_risk_32_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_9_0(risk_32_9_0):
    return dictionary_risk_32_9_0[risk_32_9_0]

dictionary_risk_33_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_9_0(risk_33_9_0):
    return dictionary_risk_33_9_0[risk_33_9_0]

dictionary_risk_34_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_9_0(risk_34_9_0):
    return dictionary_risk_34_9_0[risk_34_9_0]

dictionary_risk_35_9_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_9_0(risk_35_9_0):
    return dictionary_risk_35_9_0[risk_35_9_0]

dictionary_risk_0_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_0_10_0(risk_0_10_0):
    return dictionary_risk_0_10_0[risk_0_10_0]

dictionary_risk_1_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_1_10_0(risk_1_10_0):
    return dictionary_risk_1_10_0[risk_1_10_0]

dictionary_risk_2_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_2_10_0(risk_2_10_0):
    return dictionary_risk_2_10_0[risk_2_10_0]

dictionary_risk_3_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_3_10_0(risk_3_10_0):
    return dictionary_risk_3_10_0[risk_3_10_0]

dictionary_risk_4_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_4_10_0(risk_4_10_0):
    return dictionary_risk_4_10_0[risk_4_10_0]

dictionary_risk_5_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_5_10_0(risk_5_10_0):
    return dictionary_risk_5_10_0[risk_5_10_0]

dictionary_risk_6_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_6_10_0(risk_6_10_0):
    return dictionary_risk_6_10_0[risk_6_10_0]

dictionary_risk_7_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_7_10_0(risk_7_10_0):
    return dictionary_risk_7_10_0[risk_7_10_0]

dictionary_risk_8_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_8_10_0(risk_8_10_0):
    return dictionary_risk_8_10_0[risk_8_10_0]

dictionary_risk_9_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_9_10_0(risk_9_10_0):
    return dictionary_risk_9_10_0[risk_9_10_0]

dictionary_risk_10_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_10_10_0(risk_10_10_0):
    return dictionary_risk_10_10_0[risk_10_10_0]

dictionary_risk_11_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_11_10_0(risk_11_10_0):
    return dictionary_risk_11_10_0[risk_11_10_0]

dictionary_risk_12_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_12_10_0(risk_12_10_0):
    return dictionary_risk_12_10_0[risk_12_10_0]

dictionary_risk_13_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_13_10_0(risk_13_10_0):
    return dictionary_risk_13_10_0[risk_13_10_0]

dictionary_risk_14_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_14_10_0(risk_14_10_0):
    return dictionary_risk_14_10_0[risk_14_10_0]

dictionary_risk_15_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_15_10_0(risk_15_10_0):
    return dictionary_risk_15_10_0[risk_15_10_0]

dictionary_risk_16_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_16_10_0(risk_16_10_0):
    return dictionary_risk_16_10_0[risk_16_10_0]

dictionary_risk_17_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_17_10_0(risk_17_10_0):
    return dictionary_risk_17_10_0[risk_17_10_0]

dictionary_risk_18_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_18_10_0(risk_18_10_0):
    return dictionary_risk_18_10_0[risk_18_10_0]

dictionary_risk_19_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_19_10_0(risk_19_10_0):
    return dictionary_risk_19_10_0[risk_19_10_0]

dictionary_risk_20_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_20_10_0(risk_20_10_0):
    return dictionary_risk_20_10_0[risk_20_10_0]

dictionary_risk_21_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_21_10_0(risk_21_10_0):
    return dictionary_risk_21_10_0[risk_21_10_0]

dictionary_risk_22_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_22_10_0(risk_22_10_0):
    return dictionary_risk_22_10_0[risk_22_10_0]

dictionary_risk_23_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_23_10_0(risk_23_10_0):
    return dictionary_risk_23_10_0[risk_23_10_0]

dictionary_risk_24_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_24_10_0(risk_24_10_0):
    return dictionary_risk_24_10_0[risk_24_10_0]

dictionary_risk_25_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_25_10_0(risk_25_10_0):
    return dictionary_risk_25_10_0[risk_25_10_0]

dictionary_risk_26_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_26_10_0(risk_26_10_0):
    return dictionary_risk_26_10_0[risk_26_10_0]

dictionary_risk_27_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_27_10_0(risk_27_10_0):
    return dictionary_risk_27_10_0[risk_27_10_0]

dictionary_risk_28_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_28_10_0(risk_28_10_0):
    return dictionary_risk_28_10_0[risk_28_10_0]

dictionary_risk_29_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_29_10_0(risk_29_10_0):
    return dictionary_risk_29_10_0[risk_29_10_0]

dictionary_risk_30_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_30_10_0(risk_30_10_0):
    return dictionary_risk_30_10_0[risk_30_10_0]

dictionary_risk_31_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_31_10_0(risk_31_10_0):
    return dictionary_risk_31_10_0[risk_31_10_0]

dictionary_risk_32_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_32_10_0(risk_32_10_0):
    return dictionary_risk_32_10_0[risk_32_10_0]

dictionary_risk_33_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_33_10_0(risk_33_10_0):
    return dictionary_risk_33_10_0[risk_33_10_0]

dictionary_risk_34_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_34_10_0(risk_34_10_0):
    return dictionary_risk_34_10_0[risk_34_10_0]

dictionary_risk_35_10_0 = {'true': 1.0, 'false': 0.0}

def f_risk_35_10_0(risk_35_10_0):
    return dictionary_risk_35_10_0[risk_35_10_0]

dictionary_observe_0_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9624969965305669, ('false', 'false'): 1.0, ('true', 'true'): 0.03750300346943314}
def f_observe_0_7_0(person_0_7_0, observe_0_7_0):
    return dictionary_observe_0_7_0[(person_0_7_0, observe_0_7_0)]

dictionary_observe_1_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7812909420368731, ('false', 'false'): 1.0, ('true', 'true'): 0.2187090579631269}
def f_observe_1_7_0(person_1_7_0, observe_1_7_0):
    return dictionary_observe_1_7_0[(person_1_7_0, observe_1_7_0)]

dictionary_observe_2_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5340080964013414, ('false', 'false'): 1.0, ('true', 'true'): 0.4659919035986586}
def f_observe_2_7_0(person_2_7_0, observe_2_7_0):
    return dictionary_observe_2_7_0[(person_2_7_0, observe_2_7_0)]

dictionary_observe_3_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5113155932287816, ('false', 'false'): 1.0, ('true', 'true'): 0.4886844067712184}
def f_observe_3_7_0(person_3_7_0, observe_3_7_0):
    return dictionary_observe_3_7_0[(person_3_7_0, observe_3_7_0)]

dictionary_observe_4_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5153957998487635, ('false', 'false'): 1.0, ('true', 'true'): 0.4846042001512365}
def f_observe_4_7_0(person_4_7_0, observe_4_7_0):
    return dictionary_observe_4_7_0[(person_4_7_0, observe_4_7_0)]

dictionary_observe_5_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5410328685875689, ('false', 'false'): 1.0, ('true', 'true'): 0.45896713141243106}
def f_observe_5_7_0(person_5_7_0, observe_5_7_0):
    return dictionary_observe_5_7_0[(person_5_7_0, observe_5_7_0)]

dictionary_observe_6_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7795895492256983, ('false', 'false'): 1.0, ('true', 'true'): 0.22041045077430166}
def f_observe_6_7_0(person_6_7_0, observe_6_7_0):
    return dictionary_observe_6_7_0[(person_6_7_0, observe_6_7_0)]

dictionary_observe_7_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6918887689168111, ('false', 'false'): 1.0, ('true', 'true'): 0.30811123108318894}
def f_observe_7_7_0(person_7_7_0, observe_7_7_0):
    return dictionary_observe_7_7_0[(person_7_7_0, observe_7_7_0)]

dictionary_observe_8_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5387876307195124, ('false', 'false'): 1.0, ('true', 'true'): 0.4612123692804876}
def f_observe_8_7_0(person_8_7_0, observe_8_7_0):
    return dictionary_observe_8_7_0[(person_8_7_0, observe_8_7_0)]

dictionary_observe_9_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.41975530095335345, ('false', 'false'): 1.0, ('true', 'true'): 0.5802446990466466}
def f_observe_9_7_0(person_9_7_0, observe_9_7_0):
    return dictionary_observe_9_7_0[(person_9_7_0, observe_9_7_0)]

dictionary_observe_10_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.950039416670954, ('false', 'false'): 1.0, ('true', 'true'): 0.04996058332904596}
def f_observe_10_7_0(person_10_7_0, observe_10_7_0):
    return dictionary_observe_10_7_0[(person_10_7_0, observe_10_7_0)]

dictionary_observe_11_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8060290864124702, ('false', 'false'): 1.0, ('true', 'true'): 0.19397091358752983}
def f_observe_11_7_0(person_11_7_0, observe_11_7_0):
    return dictionary_observe_11_7_0[(person_11_7_0, observe_11_7_0)]

dictionary_observe_12_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8861962711359868, ('false', 'false'): 1.0, ('true', 'true'): 0.11380372886401324}
def f_observe_12_7_0(person_12_7_0, observe_12_7_0):
    return dictionary_observe_12_7_0[(person_12_7_0, observe_12_7_0)]

dictionary_observe_13_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9715204237281758, ('false', 'false'): 1.0, ('true', 'true'): 0.02847957627182418}
def f_observe_13_7_0(person_13_7_0, observe_13_7_0):
    return dictionary_observe_13_7_0[(person_13_7_0, observe_13_7_0)]

dictionary_observe_14_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7245748523807862, ('false', 'false'): 1.0, ('true', 'true'): 0.2754251476192138}
def f_observe_14_7_0(person_14_7_0, observe_14_7_0):
    return dictionary_observe_14_7_0[(person_14_7_0, observe_14_7_0)]

dictionary_observe_15_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8404767921063474, ('false', 'false'): 1.0, ('true', 'true'): 0.1595232078936526}
def f_observe_15_7_0(person_15_7_0, observe_15_7_0):
    return dictionary_observe_15_7_0[(person_15_7_0, observe_15_7_0)]

dictionary_observe_16_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9556765214132045, ('false', 'false'): 1.0, ('true', 'true'): 0.04432347858679553}
def f_observe_16_7_0(person_16_7_0, observe_16_7_0):
    return dictionary_observe_16_7_0[(person_16_7_0, observe_16_7_0)]

dictionary_observe_17_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7320841907168086, ('false', 'false'): 1.0, ('true', 'true'): 0.26791580928319136}
def f_observe_17_7_0(person_17_7_0, observe_17_7_0):
    return dictionary_observe_17_7_0[(person_17_7_0, observe_17_7_0)]

dictionary_observe_18_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5643067109403129, ('false', 'false'): 1.0, ('true', 'true'): 0.43569328905968707}
def f_observe_18_7_0(person_18_7_0, observe_18_7_0):
    return dictionary_observe_18_7_0[(person_18_7_0, observe_18_7_0)]

dictionary_observe_19_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.40679035181586376, ('false', 'false'): 1.0, ('true', 'true'): 0.5932096481841362}
def f_observe_19_7_0(person_19_7_0, observe_19_7_0):
    return dictionary_observe_19_7_0[(person_19_7_0, observe_19_7_0)]

dictionary_observe_20_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8854379504442828, ('false', 'false'): 1.0, ('true', 'true'): 0.11456204955571725}
def f_observe_20_7_0(person_20_7_0, observe_20_7_0):
    return dictionary_observe_20_7_0[(person_20_7_0, observe_20_7_0)]

dictionary_observe_21_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.944793538020166, ('false', 'false'): 1.0, ('true', 'true'): 0.05520646197983403}
def f_observe_21_7_0(person_21_7_0, observe_21_7_0):
    return dictionary_observe_21_7_0[(person_21_7_0, observe_21_7_0)]

dictionary_observe_22_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9871602006005423, ('false', 'false'): 1.0, ('true', 'true'): 0.012839799399457674}
def f_observe_22_7_0(person_22_7_0, observe_22_7_0):
    return dictionary_observe_22_7_0[(person_22_7_0, observe_22_7_0)]

dictionary_observe_23_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9840404841961359, ('false', 'false'): 1.0, ('true', 'true'): 0.01595951580386412}
def f_observe_23_7_0(person_23_7_0, observe_23_7_0):
    return dictionary_observe_23_7_0[(person_23_7_0, observe_23_7_0)]

dictionary_observe_24_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7830624564810178, ('false', 'false'): 1.0, ('true', 'true'): 0.2169375435189822}
def f_observe_24_7_0(person_24_7_0, observe_24_7_0):
    return dictionary_observe_24_7_0[(person_24_7_0, observe_24_7_0)]

dictionary_observe_25_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5950774400549727, ('false', 'false'): 1.0, ('true', 'true'): 0.40492255994502735}
def f_observe_25_7_0(person_25_7_0, observe_25_7_0):
    return dictionary_observe_25_7_0[(person_25_7_0, observe_25_7_0)]

dictionary_observe_26_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6263892235925684, ('false', 'false'): 1.0, ('true', 'true'): 0.37361077640743157}
def f_observe_26_7_0(person_26_7_0, observe_26_7_0):
    return dictionary_observe_26_7_0[(person_26_7_0, observe_26_7_0)]

dictionary_observe_27_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4200980214389698, ('false', 'false'): 1.0, ('true', 'true'): 0.5799019785610302}
def f_observe_27_7_0(person_27_7_0, observe_27_7_0):
    return dictionary_observe_27_7_0[(person_27_7_0, observe_27_7_0)]

dictionary_observe_28_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6883155713835656, ('false', 'false'): 1.0, ('true', 'true'): 0.3116844286164344}
def f_observe_28_7_0(person_28_7_0, observe_28_7_0):
    return dictionary_observe_28_7_0[(person_28_7_0, observe_28_7_0)]

dictionary_observe_29_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.653531517935142, ('false', 'false'): 1.0, ('true', 'true'): 0.34646848206485803}
def f_observe_29_7_0(person_29_7_0, observe_29_7_0):
    return dictionary_observe_29_7_0[(person_29_7_0, observe_29_7_0)]

dictionary_observe_30_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5726846409599755, ('false', 'false'): 1.0, ('true', 'true'): 0.4273153590400245}
def f_observe_30_7_0(person_30_7_0, observe_30_7_0):
    return dictionary_observe_30_7_0[(person_30_7_0, observe_30_7_0)]

dictionary_observe_31_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.991515521264066, ('false', 'false'): 1.0, ('true', 'true'): 0.008484478735934053}
def f_observe_31_7_0(person_31_7_0, observe_31_7_0):
    return dictionary_observe_31_7_0[(person_31_7_0, observe_31_7_0)]

dictionary_observe_32_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9695513876398181, ('false', 'false'): 1.0, ('true', 'true'): 0.030448612360181926}
def f_observe_32_7_0(person_32_7_0, observe_32_7_0):
    return dictionary_observe_32_7_0[(person_32_7_0, observe_32_7_0)]

dictionary_observe_33_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4275965801944722, ('false', 'false'): 1.0, ('true', 'true'): 0.5724034198055278}
def f_observe_33_7_0(person_33_7_0, observe_33_7_0):
    return dictionary_observe_33_7_0[(person_33_7_0, observe_33_7_0)]

dictionary_observe_34_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8998760640484478, ('false', 'false'): 1.0, ('true', 'true'): 0.10012393595155222}
def f_observe_34_7_0(person_34_7_0, observe_34_7_0):
    return dictionary_observe_34_7_0[(person_34_7_0, observe_34_7_0)]

dictionary_observe_35_7_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7220025810286008, ('false', 'false'): 1.0, ('true', 'true'): 0.2779974189713992}
def f_observe_35_7_0(person_35_7_0, observe_35_7_0):
    return dictionary_observe_35_7_0[(person_35_7_0, observe_35_7_0)]

dictionary_person_0_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6397279418651578, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3602720581348422, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6390882139232926, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3609117860767074, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_0_8_0(person_0_7_0, person_6_7_0, risk_0_8_0, person_0_8_0):
    return dictionary_person_0_8_0[(person_0_7_0, person_6_7_0, risk_0_8_0, person_0_8_0)]

dictionary_observe_0_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9541682908214391, ('false', 'false'): 1.0, ('true', 'true'): 0.04583170917856094}
def f_observe_0_8_0(person_0_8_0, observe_0_8_0):
    return dictionary_observe_0_8_0[(person_0_8_0, observe_0_8_0)]

dictionary_person_1_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.40340301117251487, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7551666457642521, ('false', 'false', 'true', 'false', 'false'): 0.4107939484409372, ('false', 'true', 'false', 'true', 'true'): 0.4039996081613424, ('false', 'false', 'true', 'false', 'true'): 0.5892060515590628, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5960003918386576, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.41038315449249624, ('false', 'true', 'true', 'false', 'true'): 0.7549215673315837, ('false', 'true', 'true', 'false', 'false'): 0.2450784326684163, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5896168455075037, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5965969888274851, ('false', 'true', 'true', 'true', 'false'): 0.2448333542357479}
def f_person_1_8_0(person_1_7_0, person_7_7_0, person_2_7_0, risk_1_8_0, person_1_8_0):
    return dictionary_person_1_8_0[(person_1_7_0, person_7_7_0, person_2_7_0, risk_1_8_0, person_1_8_0)]

dictionary_observe_1_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7922018345274866, ('false', 'false'): 1.0, ('true', 'true'): 0.2077981654725134}
def f_observe_1_8_0(person_1_8_0, observe_1_8_0):
    return dictionary_observe_1_8_0[(person_1_8_0, observe_1_8_0)]

dictionary_person_2_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.2739104748752653, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6654910203885485, ('false', 'false', 'true', 'false', 'false'): 0.46116052063602453, ('false', 'true', 'false', 'true', 'true'): 0.2746365644003901, ('false', 'false', 'true', 'false', 'true'): 0.5388394793639755, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7253634355996099, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.4606993601153885, ('false', 'true', 'true', 'false', 'true'): 0.6651561765651135, ('false', 'true', 'true', 'false', 'false'): 0.33484382343488645, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5393006398846115, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7260895251247347, ('false', 'true', 'true', 'true', 'false'): 0.33450897961145154}
def f_person_2_8_0(person_2_7_0, person_32_7_0, person_3_7_0, risk_2_8_0, person_2_8_0):
    return dictionary_person_2_8_0[(person_2_7_0, person_32_7_0, person_3_7_0, risk_2_8_0, person_2_8_0)]

dictionary_observe_2_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5621551996539178, ('false', 'false'): 1.0, ('true', 'true'): 0.4378448003460822}
def f_observe_2_8_0(person_2_8_0, observe_2_8_0):
    return dictionary_observe_2_8_0[(person_2_8_0, observe_2_8_0)]

dictionary_person_3_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_3_8_0(person_3_7_0, risk_3_8_0, person_3_8_0):
    return dictionary_person_3_8_0[(person_3_7_0, risk_3_8_0, person_3_8_0)]

dictionary_observe_3_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6496698726490389, ('false', 'false'): 1.0, ('true', 'true'): 0.35033012735096114}
def f_observe_3_8_0(person_3_8_0, observe_3_8_0):
    return dictionary_observe_3_8_0[(person_3_8_0, observe_3_8_0)]

dictionary_person_4_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5819831060930023, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4180168939069977, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5814011229869093, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.41859887701309073, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_4_8_0(person_4_7_0, person_10_7_0, risk_4_8_0, person_4_8_0):
    return dictionary_person_4_8_0[(person_4_7_0, person_10_7_0, risk_4_8_0, person_4_8_0)]

dictionary_observe_4_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6570636062674474, ('false', 'false'): 1.0, ('true', 'true'): 0.3429363937325526}
def f_observe_4_8_0(person_4_8_0, observe_4_8_0):
    return dictionary_observe_4_8_0[(person_4_8_0, observe_4_8_0)]

dictionary_person_5_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_5_8_0(person_5_7_0, risk_5_8_0, person_5_8_0):
    return dictionary_person_5_8_0[(person_5_7_0, risk_5_8_0, person_5_8_0)]

dictionary_observe_5_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8952660451495006, ('false', 'false'): 1.0, ('true', 'true'): 0.10473395485049941}
def f_observe_5_8_0(person_5_8_0, observe_5_8_0):
    return dictionary_observe_5_8_0[(person_5_8_0, observe_5_8_0)]

dictionary_person_6_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.5347951340358252, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.8638661607013565, ('false', 'false', 'true', 'false', 'false'): 0.29292494420844184, ('false', 'true', 'false', 'true', 'true'): 0.5352603389017894, ('false', 'false', 'true', 'false', 'true'): 0.7070750557915582, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.4647396610982106, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.2926320192642334, ('false', 'true', 'true', 'false', 'true'): 0.8637298905919484, ('false', 'true', 'true', 'false', 'false'): 0.13627010940805157, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.7073679807357667, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.46520486596417476, ('false', 'true', 'true', 'true', 'false'): 0.1361338392986435}
def f_person_6_8_0(person_6_7_0, person_0_7_0, person_12_7_0, risk_6_8_0, person_6_8_0):
    return dictionary_person_6_8_0[(person_6_7_0, person_0_7_0, person_12_7_0, risk_6_8_0, person_6_8_0)]

dictionary_observe_6_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7786037698107873, ('false', 'false'): 1.0, ('true', 'true'): 0.22139623018921273}
def f_observe_6_8_0(person_6_8_0, observe_6_8_0):
    return dictionary_observe_6_8_0[(person_6_8_0, observe_6_8_0)]

dictionary_person_7_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_7_8_0(person_7_7_0, risk_7_8_0, person_7_8_0):
    return dictionary_person_7_8_0[(person_7_7_0, risk_7_8_0, person_7_8_0)]

dictionary_observe_7_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6826093067310408, ('false', 'false'): 1.0, ('true', 'true'): 0.3173906932689592}
def f_observe_7_8_0(person_7_8_0, observe_7_8_0):
    return dictionary_observe_7_8_0[(person_7_8_0, observe_7_8_0)]

dictionary_person_8_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5457501707377601, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4542498292622399, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5452044205670223, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.45479557943297766, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_8_8_0(person_8_7_0, person_32_7_0, risk_8_8_0, person_8_8_0):
    return dictionary_person_8_8_0[(person_8_7_0, person_32_7_0, risk_8_8_0, person_8_8_0)]

dictionary_observe_8_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6959270216027775, ('false', 'false'): 1.0, ('true', 'true'): 0.30407297839722247}
def f_observe_8_8_0(person_8_8_0, observe_8_8_0):
    return dictionary_observe_8_8_0[(person_8_8_0, observe_8_8_0)]

dictionary_person_9_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4073729348437234, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5926270651562766, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.40696556190887967, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5930344380911203, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_9_8_0(person_9_7_0, person_3_7_0, risk_9_8_0, person_9_8_0):
    return dictionary_person_9_8_0[(person_9_7_0, person_3_7_0, risk_9_8_0, person_9_8_0)]

dictionary_observe_9_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8870375300197664, ('false', 'false'): 1.0, ('true', 'true'): 0.11296246998023363}
def f_observe_9_8_0(person_9_8_0, observe_9_8_0):
    return dictionary_observe_9_8_0[(person_9_8_0, observe_9_8_0)]

dictionary_person_10_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4383593735307325, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5616406264692675, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4379210141572018, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5620789858427981, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_10_8_0(person_10_7_0, person_9_7_0, risk_10_8_0, person_10_8_0):
    return dictionary_person_10_8_0[(person_10_7_0, person_9_7_0, risk_10_8_0, person_10_8_0)]

dictionary_observe_10_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6149201358415823, ('false', 'false'): 1.0, ('true', 'true'): 0.38507986415841766}
def f_observe_10_8_0(person_10_8_0, observe_10_8_0):
    return dictionary_observe_10_8_0[(person_10_8_0, observe_10_8_0)]

dictionary_person_11_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_11_8_0(person_11_7_0, risk_11_8_0, person_11_8_0):
    return dictionary_person_11_8_0[(person_11_7_0, risk_11_8_0, person_11_8_0)]

dictionary_observe_11_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8399220683964372, ('false', 'false'): 1.0, ('true', 'true'): 0.16007793160356276}
def f_observe_11_8_0(person_11_8_0, observe_11_8_0):
    return dictionary_observe_11_8_0[(person_11_8_0, observe_11_8_0)]

dictionary_person_12_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_12_8_0(person_12_7_0, risk_12_8_0, person_12_8_0):
    return dictionary_person_12_8_0[(person_12_7_0, risk_12_8_0, person_12_8_0)]

dictionary_observe_12_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9370009225654334, ('false', 'false'): 1.0, ('true', 'true'): 0.06299907743456656}
def f_observe_12_8_0(person_12_8_0, observe_12_8_0):
    return dictionary_observe_12_8_0[(person_12_8_0, observe_12_8_0)]

dictionary_person_13_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5604109596347708, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.43958904036522917, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5598505486751361, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.44014945132486394, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_13_8_0(person_13_7_0, person_19_7_0, risk_13_8_0, person_13_8_0):
    return dictionary_person_13_8_0[(person_13_7_0, person_19_7_0, risk_13_8_0, person_13_8_0)]

dictionary_observe_13_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5781555805909937, ('false', 'false'): 1.0, ('true', 'true'): 0.4218444194090063}
def f_observe_13_8_0(person_13_8_0, observe_13_8_0):
    return dictionary_observe_13_8_0[(person_13_8_0, observe_13_8_0)]

dictionary_person_14_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.20016832936873197, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5426970017978973, ('false', 'false', 'true', 'false', 'false'): 0.5723213718203677, ('false', 'true', 'false', 'true', 'true'): 0.2009681610393632, ('false', 'false', 'true', 'false', 'true'): 0.4276786281796323, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7990318389606368, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5717490504485473, ('false', 'true', 'true', 'false', 'true'): 0.5422392410389362, ('false', 'true', 'true', 'false', 'false'): 0.45776075896106383, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4282509495514527, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.799831670631268, ('false', 'true', 'true', 'true', 'false'): 0.45730299820210274}
def f_person_14_8_0(person_14_7_0, person_17_7_0, person_26_7_0, risk_14_8_0, person_14_8_0):
    return dictionary_person_14_8_0[(person_14_7_0, person_17_7_0, person_26_7_0, risk_14_8_0, person_14_8_0)]

dictionary_observe_14_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6342593213787922, ('false', 'false'): 1.0, ('true', 'true'): 0.36574067862120785}
def f_observe_14_8_0(person_14_8_0, observe_14_8_0):
    return dictionary_observe_14_8_0[(person_14_8_0, observe_14_8_0)]

dictionary_person_15_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.39437050914112803, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5756293311828924, ('false', 'false', 'true', 'false', 'false'): 0.7014114581490514, ('false', 'true', 'false', 'true', 'true'): 0.3949761386319869, ('false', 'false', 'true', 'false', 'true'): 0.29858854185094863, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6050238613680131, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7007100466909023, ('false', 'true', 'true', 'false', 'true'): 0.5752045357186111, ('false', 'true', 'true', 'false', 'false'): 0.424795464281389, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.2992899533090977, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.605629490858872, ('false', 'true', 'true', 'true', 'false'): 0.4243706688171076}
def f_person_15_8_0(person_15_7_0, person_21_7_0, person_16_7_0, risk_15_8_0, person_15_8_0):
    return dictionary_person_15_8_0[(person_15_7_0, person_21_7_0, person_16_7_0, risk_15_8_0, person_15_8_0)]

dictionary_observe_15_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5486570345741856, ('false', 'false'): 1.0, ('true', 'true'): 0.4513429654258144}
def f_observe_15_8_0(person_15_8_0, observe_15_8_0):
    return dictionary_observe_15_8_0[(person_15_8_0, observe_15_8_0)]

dictionary_person_16_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.2316888024037398, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.34954713023562234, ('false', 'false', 'true', 'false', 'false'): 0.8474482420341665, ('false', 'true', 'false', 'true', 'true'): 0.23245711360133603, ('false', 'false', 'true', 'false', 'true'): 0.15255175796583353, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.767542886398664, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.8466007937921323, ('false', 'true', 'true', 'false', 'true'): 0.3488960262618842, ('false', 'true', 'true', 'false', 'false'): 0.6511039737381158, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.15339920620786773, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7683111975962602, ('false', 'true', 'true', 'true', 'false'): 0.6504528697643777}
def f_person_16_8_0(person_16_7_0, person_18_7_0, person_10_7_0, risk_16_8_0, person_16_8_0):
    return dictionary_person_16_8_0[(person_16_7_0, person_18_7_0, person_10_7_0, risk_16_8_0, person_16_8_0)]

dictionary_observe_16_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6557872216908125, ('false', 'false'): 1.0, ('true', 'true'): 0.3442127783091875}
def f_observe_16_8_0(person_16_8_0, observe_16_8_0):
    return dictionary_observe_16_8_0[(person_16_8_0, observe_16_8_0)]

dictionary_person_17_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.40201390841615037, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5979860915838496, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4016118945077342, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5983881054922657, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_17_8_0(person_17_7_0, person_23_7_0, risk_17_8_0, person_17_8_0):
    return dictionary_person_17_8_0[(person_17_7_0, person_23_7_0, risk_17_8_0, person_17_8_0)]

dictionary_observe_17_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.45773748864968344, ('false', 'false'): 1.0, ('true', 'true'): 0.5422625113503166}
def f_observe_17_8_0(person_17_8_0, observe_17_8_0):
    return dictionary_observe_17_8_0[(person_17_8_0, observe_17_8_0)]

dictionary_person_18_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.48791557100738925, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5120844289926108, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.48742765543638183, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5125723445636181, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_18_8_0(person_18_7_0, person_24_7_0, risk_18_8_0, person_18_8_0):
    return dictionary_person_18_8_0[(person_18_7_0, person_24_7_0, risk_18_8_0, person_18_8_0)]

dictionary_observe_18_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9300411404585283, ('false', 'false'): 1.0, ('true', 'true'): 0.06995885954147174}
def f_observe_18_8_0(person_18_8_0, observe_18_8_0):
    return dictionary_observe_18_8_0[(person_18_8_0, observe_18_8_0)]

dictionary_person_19_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.43843011047178426, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6582086642406607, ('false', 'false', 'true', 'false', 'false'): 0.6092446828230051, ('false', 'true', 'false', 'true', 'true'): 0.43899168036131253, ('false', 'false', 'true', 'false', 'true'): 0.39075531717699485, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5610083196386875, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6086354381401822, ('false', 'true', 'true', 'false', 'true'): 0.6578665307714322, ('false', 'true', 'true', 'false', 'false'): 0.34213346922856785, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3913645618598178, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5615698895282157, ('false', 'true', 'true', 'true', 'false'): 0.3417913357593393}
def f_person_19_8_0(person_19_7_0, person_13_7_0, person_20_7_0, risk_19_8_0, person_19_8_0):
    return dictionary_person_19_8_0[(person_19_7_0, person_13_7_0, person_20_7_0, risk_19_8_0, person_19_8_0)]

dictionary_observe_19_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9051705181061327, ('false', 'false'): 1.0, ('true', 'true'): 0.0948294818938673}
def f_observe_19_8_0(person_19_8_0, observe_19_8_0):
    return dictionary_observe_19_8_0[(person_19_8_0, observe_19_8_0)]

dictionary_person_20_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.38551968321989816, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6716091493701317, ('false', 'false', 'true', 'false', 'false'): 0.5349554106510203, ('false', 'true', 'false', 'true', 'true'): 0.3861341635366783, ('false', 'false', 'true', 'false', 'true'): 0.46504458934897974, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6138658364633217, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5344204552403692, ('false', 'true', 'true', 'false', 'true'): 0.6712804297999315, ('false', 'true', 'true', 'false', 'false'): 0.3287195702000684, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4655795447596308, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6144803167801018, ('false', 'true', 'true', 'true', 'false'): 0.32839085062986834}
def f_person_20_8_0(person_20_7_0, person_14_7_0, person_26_7_0, risk_20_8_0, person_20_8_0):
    return dictionary_person_20_8_0[(person_20_7_0, person_14_7_0, person_26_7_0, risk_20_8_0, person_20_8_0)]

dictionary_observe_20_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6780813363391665, ('false', 'false'): 1.0, ('true', 'true'): 0.32191866366083355}
def f_observe_20_8_0(person_20_8_0, observe_20_8_0):
    return dictionary_observe_20_8_0[(person_20_8_0, observe_20_8_0)]

dictionary_person_21_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_21_8_0(person_21_7_0, risk_21_8_0, person_21_8_0):
    return dictionary_person_21_8_0[(person_21_7_0, risk_21_8_0, person_21_8_0)]

dictionary_observe_21_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7928108987435745, ('false', 'false'): 1.0, ('true', 'true'): 0.20718910125642553}
def f_observe_21_8_0(person_21_8_0, observe_21_8_0):
    return dictionary_observe_21_8_0[(person_21_8_0, observe_21_8_0)]

dictionary_person_22_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_22_8_0(person_22_7_0, risk_22_8_0, person_22_8_0):
    return dictionary_person_22_8_0[(person_22_7_0, risk_22_8_0, person_22_8_0)]

dictionary_observe_22_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5025310486795217, ('false', 'false'): 1.0, ('true', 'true'): 0.4974689513204783}
def f_observe_22_8_0(person_22_8_0, observe_22_8_0):
    return dictionary_observe_22_8_0[(person_22_8_0, observe_22_8_0)]

dictionary_person_23_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6011197076773819, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3988802923226181, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6005185879697045, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3994814120302955, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_23_8_0(person_23_7_0, person_22_7_0, risk_23_8_0, person_23_8_0):
    return dictionary_person_23_8_0[(person_23_7_0, person_22_7_0, risk_23_8_0, person_23_8_0)]

dictionary_observe_23_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.44760552739240245, ('false', 'false'): 1.0, ('true', 'true'): 0.5523944726075976}
def f_observe_23_8_0(person_23_8_0, observe_23_8_0):
    return dictionary_observe_23_8_0[(person_23_8_0, observe_23_8_0)]

dictionary_person_24_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6121652009636697, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.38783479903633034, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.611553035762706, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.38844696423729397, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_24_8_0(person_24_7_0, person_23_7_0, risk_24_8_0, person_24_8_0):
    return dictionary_person_24_8_0[(person_24_7_0, person_23_7_0, risk_24_8_0, person_24_8_0)]

dictionary_observe_24_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6670998559891921, ('false', 'false'): 1.0, ('true', 'true'): 0.3329001440108079}
def f_observe_24_8_0(person_24_8_0, observe_24_8_0):
    return dictionary_observe_24_8_0[(person_24_8_0, observe_24_8_0)]

dictionary_person_25_8_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.19816257736823603, ('false', 'true', 'false', 'false', 'false', 'true'): 0.4338091222874767, ('false', 'true', 'true', 'false', 'true', 'true'): 0.6200894603798798, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.3799105396201202, ('false', 'true', 'false', 'false', 'false', 'false'): 0.5661908777125233, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.5656246868348108, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.3283345857019284, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.8018374226317639, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.8016390616934574, ('false', 'false', 'true', 'false', 'false', 'false'): 0.6716654142980716, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.2953270096746622, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.2950316826649875, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.7046729903253378, ('false', 'false', 'false', 'true', 'false', 'true'): 0.4783967363306567, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.4343753131651892, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.19836093830654258, ('false', 'false', 'true', 'false', 'true', 'false'): 0.6709937488837735, ('false', 'true', 'true', 'false', 'false', 'false'): 0.38029083045057077, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.6496571278083043, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.7049683173350125, ('false', 'false', 'false', 'true', 'true', 'false'): 0.5210816604056739, ('false', 'false', 'false', 'true', 'false', 'false'): 0.5216032636693433, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.35034287219169574, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.6500074706804959, ('false', 'false', 'true', 'false', 'true', 'true'): 0.3290062511162265, ('false', 'false', 'false', 'true', 'true', 'true'): 0.47891833959432606, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.6197091695494292, ('false', 'false', 'true', 'true', 'true', 'false'): 0.34999252931950403}
def f_person_25_8_0(person_25_7_0, person_31_7_0, person_26_7_0, person_24_7_0, risk_25_8_0, person_25_8_0):
    return dictionary_person_25_8_0[(person_25_7_0, person_31_7_0, person_26_7_0, person_24_7_0, risk_25_8_0, person_25_8_0)]

dictionary_observe_25_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7488399806329082, ('false', 'false'): 1.0, ('true', 'true'): 0.25116001936709176}
def f_observe_25_8_0(person_25_8_0, observe_25_8_0):
    return dictionary_observe_25_8_0[(person_25_8_0, observe_25_8_0)]

dictionary_person_26_8_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.3557328512175885, ('false', 'true', 'false', 'false', 'false', 'true'): 0.42783870191237794, ('false', 'true', 'true', 'false', 'true', 'true'): 0.4641746297066591, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.5358253702933409, ('false', 'true', 'false', 'false', 'false', 'false'): 0.5721612980876221, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.5715891367895345, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.06256901014086669, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.6442671487824114, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.6439110598422537, ('false', 'false', 'true', 'false', 'false', 'false'): 0.9374309898591333, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.3798561643575015, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.37947630819314404, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.6201438356424984, ('false', 'false', 'false', 'true', 'false', 'true'): 0.3361030086670953, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.4284108632104655, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.3560889401577463, ('false', 'false', 'true', 'false', 'true', 'false'): 0.9364935588692742, ('false', 'true', 'true', 'false', 'false', 'false'): 0.5363617320253662, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.37764238625029467, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.620523691806856, ('false', 'false', 'false', 'true', 'true', 'false'): 0.6632330943415717, ('false', 'false', 'false', 'true', 'false', 'false'): 0.6638969913329047, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.6223576137497053, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.3782647438640444, ('false', 'false', 'true', 'false', 'true', 'true'): 0.06350644113072579, ('false', 'false', 'false', 'true', 'true', 'true'): 0.33676690565842826, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.4636382679746338, ('false', 'false', 'true', 'true', 'true', 'false'): 0.6217352561359556}
def f_person_26_8_0(person_26_7_0, person_27_7_0, person_25_7_0, person_20_7_0, risk_26_8_0, person_26_8_0):
    return dictionary_person_26_8_0[(person_26_7_0, person_27_7_0, person_25_7_0, person_20_7_0, risk_26_8_0, person_26_8_0)]

dictionary_observe_26_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9315146411599367, ('false', 'false'): 1.0, ('true', 'true'): 0.06848535884006335}
def f_observe_26_8_0(person_26_8_0, observe_26_8_0):
    return dictionary_observe_26_8_0[(person_26_8_0, observe_26_8_0)]

dictionary_person_27_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5709526024117695, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4290473975882305, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5703816498093577, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4296183501906423, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_27_8_0(person_27_7_0, person_28_7_0, risk_27_8_0, person_27_8_0):
    return dictionary_person_27_8_0[(person_27_7_0, person_28_7_0, risk_27_8_0, person_27_8_0)]

dictionary_observe_27_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6994648393550782, ('false', 'false'): 1.0, ('true', 'true'): 0.3005351606449218}
def f_observe_27_8_0(person_27_8_0, observe_27_8_0):
    return dictionary_observe_27_8_0[(person_27_8_0, observe_27_8_0)]

dictionary_person_28_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_28_8_0(person_28_7_0, risk_28_8_0, person_28_8_0):
    return dictionary_person_28_8_0[(person_28_7_0, risk_28_8_0, person_28_8_0)]

dictionary_observe_28_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8567020105564553, ('false', 'false'): 1.0, ('true', 'true'): 0.14329798944354466}
def f_observe_28_8_0(person_28_8_0, observe_28_8_0):
    return dictionary_observe_28_8_0[(person_28_8_0, observe_28_8_0)]

dictionary_person_29_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7700120933293803, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.22998790667061975, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7692420812360509, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.23075791876394913, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_29_8_0(person_29_7_0, person_28_7_0, risk_29_8_0, person_29_8_0):
    return dictionary_person_29_8_0[(person_29_7_0, person_28_7_0, risk_29_8_0, person_29_8_0)]

dictionary_observe_29_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8313452563626192, ('false', 'false'): 1.0, ('true', 'true'): 0.16865474363738076}
def f_observe_29_8_0(person_29_8_0, observe_29_8_0):
    return dictionary_observe_29_8_0[(person_29_8_0, observe_29_8_0)]

dictionary_person_30_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_30_8_0(person_30_7_0, risk_30_8_0, person_30_8_0):
    return dictionary_person_30_8_0[(person_30_7_0, risk_30_8_0, person_30_8_0)]

dictionary_observe_30_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8450660342204651, ('false', 'false'): 1.0, ('true', 'true'): 0.1549339657795349}
def f_observe_30_8_0(person_30_8_0, observe_30_8_0):
    return dictionary_observe_30_8_0[(person_30_8_0, observe_30_8_0)]

dictionary_person_31_8_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6586421174941475, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.34135788250585253, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6579834753766534, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.34201652462334664, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_31_8_0(person_31_7_0, person_30_7_0, risk_31_8_0, person_31_8_0):
    return dictionary_person_31_8_0[(person_31_7_0, person_30_7_0, risk_31_8_0, person_31_8_0)]

dictionary_observe_31_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7842776577324109, ('false', 'false'): 1.0, ('true', 'true'): 0.21572234226758913}
def f_observe_31_8_0(person_31_8_0, observe_31_8_0):
    return dictionary_observe_31_8_0[(person_31_8_0, observe_31_8_0)]

dictionary_person_32_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_32_8_0(person_32_7_0, risk_32_8_0, person_32_8_0):
    return dictionary_person_32_8_0[(person_32_7_0, risk_32_8_0, person_32_8_0)]

dictionary_observe_32_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7307048190372458, ('false', 'false'): 1.0, ('true', 'true'): 0.2692951809627542}
def f_observe_32_8_0(person_32_8_0, observe_32_8_0):
    return dictionary_observe_32_8_0[(person_32_8_0, observe_32_8_0)]

dictionary_person_33_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_33_8_0(person_33_7_0, risk_33_8_0, person_33_8_0):
    return dictionary_person_33_8_0[(person_33_7_0, risk_33_8_0, person_33_8_0)]

dictionary_observe_33_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5486172562990383, ('false', 'false'): 1.0, ('true', 'true'): 0.45138274370096165}
def f_observe_33_8_0(person_33_8_0, observe_33_8_0):
    return dictionary_observe_33_8_0[(person_33_8_0, observe_33_8_0)]

dictionary_person_34_8_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3850382910256607, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.62448845626101, ('false', 'false', 'true', 'false', 'false'): 0.6112371318160315, ('false', 'true', 'false', 'true', 'true'): 0.385653252734635, ('false', 'false', 'true', 'false', 'true'): 0.38876286818396855, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.614346747265365, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6106258946842155, ('false', 'true', 'true', 'false', 'true'): 0.6241125688298398, ('false', 'true', 'true', 'false', 'false'): 0.3758874311701602, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.38937410531578454, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6149617089743393, ('false', 'true', 'true', 'true', 'false'): 0.37551154373899004}
def f_person_34_8_0(person_34_7_0, person_28_7_0, person_31_7_0, risk_34_8_0, person_34_8_0):
    return dictionary_person_34_8_0[(person_34_7_0, person_28_7_0, person_31_7_0, risk_34_8_0, person_34_8_0)]

dictionary_observe_34_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6844098759838437, ('false', 'false'): 1.0, ('true', 'true'): 0.31559012401615627}
def f_observe_34_8_0(person_34_8_0, observe_34_8_0):
    return dictionary_observe_34_8_0[(person_34_8_0, observe_34_8_0)]

dictionary_person_35_8_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_35_8_0(person_35_7_0, risk_35_8_0, person_35_8_0):
    return dictionary_person_35_8_0[(person_35_7_0, risk_35_8_0, person_35_8_0)]

dictionary_observe_35_8_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6113601562168955, ('false', 'false'): 1.0, ('true', 'true'): 0.38863984378310445}
def f_observe_35_8_0(person_35_8_0, observe_35_8_0):
    return dictionary_observe_35_8_0[(person_35_8_0, observe_35_8_0)]

dictionary_person_0_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.3537864481303383, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5677711955952973, ('false', 'false', 'true', 'false', 'false'): 0.6695332597386305, ('false', 'true', 'false', 'true', 'true'): 0.354432661682208, ('false', 'false', 'true', 'false', 'true'): 0.33046674026136946, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.645567338317792, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6688637264788919, ('false', 'true', 'true', 'false', 'true'): 0.5673385341294268, ('false', 'true', 'true', 'false', 'false'): 0.4326614658705732, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3311362735211081, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6462135518696617, ('false', 'true', 'true', 'true', 'false'): 0.4322288044047026}
def f_person_0_9_0(person_0_8_0, person_35_8_0, person_30_8_0, risk_0_9_0, person_0_9_0):
    return dictionary_person_0_9_0[(person_0_8_0, person_35_8_0, person_30_8_0, risk_0_9_0, person_0_9_0)]

dictionary_observe_0_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6418162767424358, ('false', 'false'): 1.0, ('true', 'true'): 0.3581837232575642}
def f_observe_0_9_0(person_0_9_0, observe_0_9_0):
    return dictionary_observe_0_9_0[(person_0_9_0, observe_0_9_0)]

dictionary_person_1_9_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.6024693487263757, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.19020437963203585, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.31149386189112893, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.674920736284139, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.6878176319707622, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.40063124831457475, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.7238868132304264, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.3225633845691591, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.22381906844028268, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.46849747114114076, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.40103228059516993, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.1878826093048015, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.4424507447629755, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.5993687516854252, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.39792857985347774, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.12922897142051645, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.325079263715861, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.5581073625996241, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.8106062265945587, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.8097956203679642, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.6774366154308409, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.7682196322447263, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.8404177941073626, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.1876947266954967, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.724162926417196, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.67775917881541, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.18939377340544128, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.275837073582804, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.2761131867695736, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.23178036775527364, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.5575492552370245, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.5773814193807, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.23154858738751835, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.15958220589263736, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.7761809315597173, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.12935832975026673, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.6885061381088711, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.5989677194048301, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.42204062124054054, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.6020714201465223, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.8706416702497333, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.8707710285794835, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.7684514126124816, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.4226185806193, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.5319710263300004, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.7764047506281576, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.3121823680292378, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.8121173906951985, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.8405773763132552, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.4418926374003759, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.4680289736699996, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.32224082118458997, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.2235952493718424, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.6752458155478549, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.3247541844521451, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.5315025288588593, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.8123052733045033, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.15942262368674473, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.39753065127362425, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.5779593787594595}
def f_person_1_9_0(person_1_8_0, person_7_8_0, person_0_8_0, person_31_8_0, person_2_8_0, risk_1_9_0, person_1_9_0):
    return dictionary_person_1_9_0[(person_1_8_0, person_7_8_0, person_0_8_0, person_31_8_0, person_2_8_0, risk_1_9_0, person_1_9_0)]

dictionary_observe_1_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5742830397352168, ('false', 'false'): 1.0, ('true', 'true'): 0.42571696026478323}
def f_observe_1_9_0(person_1_9_0, observe_1_9_0):
    return dictionary_observe_1_9_0[(person_1_9_0, observe_1_9_0)]

dictionary_person_2_9_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.3460211176986091, ('false', 'true', 'false', 'false', 'false', 'true'): 0.3463146870428885, ('false', 'true', 'true', 'false', 'true', 'true'): 0.48766174890590575, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.5123382510940943, ('false', 'true', 'false', 'false', 'false', 'false'): 0.6536853129571115, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.6530316276441545, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.21544649691412154, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.6539788823013909, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.6536325148162071, ('false', 'false', 'true', 'false', 'false', 'false'): 0.7845535030858785, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.4414835748249523, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.4410420912501274, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.5585164251750476, ('false', 'false', 'false', 'true', 'false', 'true'): 0.3246236896041166, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.34696837235584554, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.3463674851837929, ('false', 'false', 'true', 'false', 'true', 'false'): 0.7837689495827925, ('false', 'true', 'true', 'false', 'false', 'false'): 0.5128511021962906, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.4701311497776941, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.5589579087498726, ('false', 'false', 'false', 'true', 'true', 'false'): 0.6747009340854875, ('false', 'false', 'false', 'true', 'false', 'false'): 0.6753763103958834, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.5298688502223059, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.4706610186279164, ('false', 'false', 'true', 'false', 'true', 'true'): 0.21623105041720747, ('false', 'false', 'false', 'true', 'true', 'true'): 0.3252990659145125, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.4871488978037094, ('false', 'false', 'true', 'true', 'true', 'false'): 0.5293389813720836}
def f_person_2_9_0(person_2_8_0, person_32_8_0, person_8_8_0, person_33_8_0, risk_2_9_0, person_2_9_0):
    return dictionary_person_2_9_0[(person_2_8_0, person_32_8_0, person_8_8_0, person_33_8_0, risk_2_9_0, person_2_9_0)]

dictionary_observe_2_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8743935434744513, ('false', 'false'): 1.0, ('true', 'true'): 0.1256064565255487}
def f_observe_2_9_0(person_2_9_0, observe_2_9_0):
    return dictionary_observe_2_9_0[(person_2_9_0, observe_2_9_0)]

dictionary_person_3_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5540269388060566, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4459730611939434, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5534729118672506, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.44652708813274944, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_3_9_0(person_3_8_0, person_9_8_0, risk_3_9_0, person_3_9_0):
    return dictionary_person_3_9_0[(person_3_8_0, person_9_8_0, risk_3_9_0, person_3_9_0)]

dictionary_observe_3_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7794114324175754, ('false', 'false'): 1.0, ('true', 'true'): 0.22058856758242462}
def f_observe_3_9_0(person_3_9_0, observe_3_9_0):
    return dictionary_observe_3_9_0[(person_3_9_0, observe_3_9_0)]

dictionary_person_4_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.4242051489815579, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5753015579892076, ('false', 'false', 'true', 'false', 'false'): 0.7383247085735969, ('false', 'true', 'false', 'true', 'true'): 0.42478094383257636, ('false', 'false', 'true', 'false', 'true'): 0.2616752914264031, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5752190561674236, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.7375863838650233, ('false', 'true', 'true', 'false', 'true'): 0.5748764344236311, ('false', 'true', 'true', 'false', 'false'): 0.4251235655763689, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.2624136161349767, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5757948510184421, ('false', 'true', 'true', 'true', 'false'): 0.4246984420107925}
def f_person_4_9_0(person_4_8_0, person_10_8_0, person_34_8_0, risk_4_9_0, person_4_9_0):
    return dictionary_person_4_9_0[(person_4_8_0, person_10_8_0, person_34_8_0, risk_4_9_0, person_4_9_0)]

dictionary_observe_4_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8312565690206184, ('false', 'false'): 1.0, ('true', 'true'): 0.1687434309793816}
def f_observe_4_9_0(person_4_9_0, observe_4_9_0):
    return dictionary_observe_4_9_0[(person_4_9_0, observe_4_9_0)]

dictionary_person_5_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_5_9_0(person_5_8_0, risk_5_9_0, person_5_9_0):
    return dictionary_person_5_9_0[(person_5_8_0, risk_5_9_0, person_5_9_0)]

dictionary_observe_5_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5060889929367094, ('false', 'false'): 1.0, ('true', 'true'): 0.4939110070632906}
def f_observe_5_9_0(person_5_9_0, observe_5_9_0):
    return dictionary_observe_5_9_0[(person_5_9_0, observe_5_9_0)]

dictionary_person_6_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5320214429165415, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4679785570834585, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.531489421473625, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.468510578526375, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_6_9_0(person_6_8_0, person_12_8_0, risk_6_9_0, person_6_9_0):
    return dictionary_person_6_9_0[(person_6_8_0, person_12_8_0, risk_6_9_0, person_6_9_0)]

dictionary_observe_6_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8990601098051993, ('false', 'false'): 1.0, ('true', 'true'): 0.10093989019480065}
def f_observe_6_9_0(person_6_9_0, observe_6_9_0):
    return dictionary_observe_6_9_0[(person_6_9_0, observe_6_9_0)]

dictionary_person_7_9_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.5801193620575948, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.740422221163029, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.4199362175488147, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.799817738728704, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.579483718668734, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.7696425242026926, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.5531113576333415, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.10920999415204986, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.11611847965265935, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.18827238909928035, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.7704129371398325, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.14504748426830993, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.8494283317675494, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.23035747579730737, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.4203009388812864, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.08405265556734495, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.20018226127129596, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.1507223906230737, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.2598376164534244, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.259577778836971, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.8907900058479501, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.4417764207966034, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.6761947191938389, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.14490243678404163, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.5535582462757082, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.8908992158421022, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.7401623835465756, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.44644175372429185, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.4468886423666585, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.5582235792033966, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.1505716682324506, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.7238525325061813, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.5576653556241932, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.32380528080616106, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.8838815203473407, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.08413679235970466, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.5800637824511853, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.2295870628601675, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.27542289038420287, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.5796990611187136, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.9158632076402954, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.915947344432655, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.44233464437580683, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.2761474674938187, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.8119158832898189, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.8839976388269933, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.42051628133126595, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.8549525157316901, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.6765185244746451, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.8492776093769263, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.18808411671018108, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.10910078415789781, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.11600236117300669, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.8000179209899754, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.19998207901002465, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.8117276109007197, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.8550975632159583, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.3234814755253549, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.4198806379424051, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.7245771096157971}
def f_person_7_9_0(person_7_8_0, person_6_8_0, person_5_8_0, person_1_8_0, person_13_8_0, risk_7_9_0, person_7_9_0):
    return dictionary_person_7_9_0[(person_7_8_0, person_6_8_0, person_5_8_0, person_1_8_0, person_13_8_0, risk_7_9_0, person_7_9_0)]

dictionary_observe_7_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7427162015262927, ('false', 'false'): 1.0, ('true', 'true'): 0.2572837984737073}
def f_observe_7_9_0(person_7_9_0, observe_7_9_0):
    return dictionary_observe_7_9_0[(person_7_9_0, observe_7_9_0)]

dictionary_person_8_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.819047579364063, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.18095242063593697, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.818228531784699, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.181771468215301, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_8_9_0(person_8_8_0, person_9_8_0, risk_8_9_0, person_8_9_0):
    return dictionary_person_8_9_0[(person_8_8_0, person_9_8_0, risk_8_9_0, person_8_9_0)]

dictionary_observe_8_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6068752897647541, ('false', 'false'): 1.0, ('true', 'true'): 0.39312471023524587}
def f_observe_8_9_0(person_8_9_0, observe_8_9_0):
    return dictionary_observe_8_9_0[(person_8_9_0, observe_8_9_0)]

dictionary_person_9_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7500928211269109, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.2499071788730891, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.749342728305784, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.25065727169421603, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_9_9_0(person_9_8_0, person_3_8_0, risk_9_9_0, person_9_9_0):
    return dictionary_person_9_9_0[(person_9_8_0, person_3_8_0, risk_9_9_0, person_9_9_0)]

dictionary_observe_9_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7658842809684439, ('false', 'false'): 1.0, ('true', 'true'): 0.23411571903155615}
def f_observe_9_9_0(person_9_9_0, observe_9_9_0):
    return dictionary_observe_9_9_0[(person_9_9_0, observe_9_9_0)]

dictionary_person_10_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5536839597839911, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4463160402160089, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5531302758242072, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.44686972417579285, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_10_9_0(person_10_8_0, person_16_8_0, risk_10_9_0, person_10_9_0):
    return dictionary_person_10_9_0[(person_10_8_0, person_16_8_0, risk_10_9_0, person_10_9_0)]

dictionary_observe_10_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9259994694660985, ('false', 'false'): 1.0, ('true', 'true'): 0.07400053053390154}
def f_observe_10_9_0(person_10_9_0, observe_10_9_0):
    return dictionary_observe_10_9_0[(person_10_9_0, observe_10_9_0)]

dictionary_person_11_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4418917376296949, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5581082623703051, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4414498458920652, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5585501541079347, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_11_9_0(person_11_8_0, person_10_8_0, risk_11_9_0, person_11_9_0):
    return dictionary_person_11_9_0[(person_11_8_0, person_10_8_0, risk_11_9_0, person_11_9_0)]

dictionary_observe_11_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7812189990356642, ('false', 'false'): 1.0, ('true', 'true'): 0.21878100096433584}
def f_observe_11_9_0(person_11_9_0, observe_11_9_0):
    return dictionary_observe_11_9_0[(person_11_9_0, observe_11_9_0)]

dictionary_person_12_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.42013399985825894, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7325409367668236, ('false', 'false', 'true', 'false', 'false'): 0.46170458339988396, ('false', 'true', 'false', 'true', 'true'): 0.42071386585840065, ('false', 'false', 'true', 'false', 'true'): 0.538295416600116, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5792861341415994, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.46124287881648407, ('false', 'true', 'true', 'false', 'true'): 0.7322732099768003, ('false', 'true', 'true', 'false', 'false'): 0.2677267900231996, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5387571211835159, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5798660001417411, ('false', 'true', 'true', 'true', 'false'): 0.2674590632331764}
def f_person_12_9_0(person_12_8_0, person_13_8_0, person_10_8_0, risk_12_9_0, person_12_9_0):
    return dictionary_person_12_9_0[(person_12_8_0, person_13_8_0, person_10_8_0, risk_12_9_0, person_12_9_0)]

dictionary_observe_12_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.610232383094298, ('false', 'false'): 1.0, ('true', 'true'): 0.38976761690570205}
def f_observe_12_9_0(person_12_9_0, observe_12_9_0):
    return dictionary_observe_12_9_0[(person_12_9_0, observe_12_9_0)]

dictionary_person_13_9_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.4138190377832311, ('false', 'true', 'false', 'false', 'false', 'true'): 0.09171836880465456, ('false', 'true', 'true', 'false', 'true', 'true'): 0.45260679064055676, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.5473932093594432, ('false', 'true', 'false', 'false', 'false', 'false'): 0.9082816311953454, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.9073733495641501, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.39672769800614116, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.5861809622167689, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.5857667289457147, ('false', 'false', 'true', 'false', 'false', 'false'): 0.6032723019938588, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.6866439411940748, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.6859572972528807, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.3133560588059252, ('false', 'false', 'false', 'true', 'false', 'true'): 0.24401868582279262, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.09262665043584994, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.41423327105428537, ('false', 'false', 'true', 'false', 'true', 'false'): 0.602669029691865, ('false', 'true', 'true', 'false', 'false', 'false'): 0.5479411505099532, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.5439374123319735, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.3140427027471193, ('false', 'false', 'false', 'true', 'true', 'false'): 0.7552253328630302, ('false', 'false', 'false', 'true', 'false', 'false'): 0.7559813141772074, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.45606258766802654, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.5443934749196415, ('false', 'false', 'true', 'false', 'true', 'true'): 0.397330970308135, ('false', 'false', 'false', 'true', 'true', 'true'): 0.24477466713696983, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.4520588494900468, ('false', 'false', 'true', 'true', 'true', 'false'): 0.45560652508035854}
def f_person_13_9_0(person_13_8_0, person_12_8_0, person_19_8_0, person_14_8_0, risk_13_9_0, person_13_9_0):
    return dictionary_person_13_9_0[(person_13_8_0, person_12_8_0, person_19_8_0, person_14_8_0, risk_13_9_0, person_13_9_0)]

dictionary_observe_13_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6402375761715564, ('false', 'false'): 1.0, ('true', 'true'): 0.3597624238284436}
def f_observe_13_9_0(person_13_9_0, observe_13_9_0):
    return dictionary_observe_13_9_0[(person_13_9_0, observe_13_9_0)]

dictionary_person_14_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.6876985953884158, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7966985292372288, ('false', 'false', 'true', 'false', 'false'): 0.6516300366679846, ('false', 'true', 'false', 'true', 'true'): 0.6880108967930274, ('false', 'false', 'true', 'false', 'true'): 0.3483699633320154, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.3119891032069726, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6509784066313166, ('false', 'true', 'true', 'false', 'true'): 0.7964950242614903, ('false', 'true', 'true', 'false', 'false'): 0.20350497573850967, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.34902159336868344, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.3123014046115842, ('false', 'true', 'true', 'true', 'false'): 0.20330147076277116}
def f_person_14_9_0(person_14_8_0, person_20_8_0, person_15_8_0, risk_14_9_0, person_14_9_0):
    return dictionary_person_14_9_0[(person_14_8_0, person_20_8_0, person_15_8_0, risk_14_9_0, person_14_9_0)]

dictionary_observe_14_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8852123594229536, ('false', 'false'): 1.0, ('true', 'true'): 0.11478764057704638}
def f_observe_14_9_0(person_14_9_0, observe_14_9_0):
    return dictionary_observe_14_9_0[(person_14_9_0, observe_14_9_0)]

dictionary_person_15_9_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.6983483636779295, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.415819594933847, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.52849610810906, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.7031933329359901, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.47103238799904906, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.5070580046295897, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.7606808582609551, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.1765719424083693, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.1399454986598592, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.3744867125067354, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.5075655701997895, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.1900765617657258, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.7245566654448831, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.4929419953704103, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.3019535899119824, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.08953221679115857, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.29680666706401, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.2757190536087257, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.5847651702363894, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.584180405066153, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.8234280575916307, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.6749523202811687, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.8467387539624512, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.18988648520396006, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.7609201774026941, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.8236046295340391, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.4152348297636106, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.23907982259730584, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.2393191417390449, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.32504767971883136, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.27544333455511694, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.639764891679501, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.32472263203911256, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.15326124603754876, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.8600545013401408, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.08962183862978836, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.47150389189094, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.49243442980021046, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.3595947030235225, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.6980464100880176, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.9103781613702117, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.9104677832088415, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.6752773679608874, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.360235108320499, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.6258877742057714, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.8601944468388006, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.528967612000951, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.8099234382342742, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.8468920152084888, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.7242809463912743, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.37411222579422865, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.17639537046596093, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.13980555316119933, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.703490139603054, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.296509860396946, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.6255132874932646, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.8101135147960399, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.15310798479151122, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.3016516363220704, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.6404052969764775}
def f_person_15_9_0(person_15_8_0, person_9_8_0, person_21_8_0, person_22_8_0, person_14_8_0, risk_15_9_0, person_15_9_0):
    return dictionary_person_15_9_0[(person_15_8_0, person_9_8_0, person_21_8_0, person_22_8_0, person_14_8_0, risk_15_9_0, person_15_9_0)]

dictionary_observe_15_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.616812654220972, ('false', 'false'): 1.0, ('true', 'true'): 0.383187345779028}
def f_observe_15_9_0(person_15_9_0, observe_15_9_0):
    return dictionary_observe_15_9_0[(person_15_9_0, observe_15_9_0)]

dictionary_person_16_9_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.2545958305573289, ('false', 'true', 'false', 'false', 'false', 'true'): 0.326407647670075, ('false', 'true', 'true', 'false', 'true', 'true'): 0.547126114972096, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.45287388502790404, ('false', 'true', 'false', 'false', 'false', 'false'): 0.673592352329925, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.6729187599775951, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.3270006545173707, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.7454041694426712, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.7451493187614325, ('false', 'false', 'true', 'false', 'false', 'false'): 0.6729993454826293, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.37867894367089744, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.37830026472722655, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.6213210563291025, ('false', 'false', 'false', 'true', 'false', 'true'): 0.4378217888592939, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.3270812400224049, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.25485068123856747, ('false', 'false', 'true', 'false', 'true', 'false'): 0.6723263461371467, ('false', 'true', 'true', 'false', 'false', 'false'): 0.45332721224014416, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.6216544318577094, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.6216997352727734, ('false', 'false', 'false', 'true', 'true', 'false'): 0.5616160329295654, ('false', 'false', 'false', 'true', 'false', 'false'): 0.5621782111407061, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.3783455681422906, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.6220327774258517, ('false', 'false', 'true', 'false', 'true', 'true'): 0.3276736538628533, ('false', 'false', 'false', 'true', 'true', 'true'): 0.4383839670704346, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.5466727877598558, ('false', 'false', 'true', 'true', 'true', 'false'): 0.3779672225741483}
def f_person_16_9_0(person_16_8_0, person_15_8_0, person_22_8_0, person_17_8_0, risk_16_9_0, person_16_9_0):
    return dictionary_person_16_9_0[(person_16_8_0, person_15_8_0, person_22_8_0, person_17_8_0, risk_16_9_0, person_16_9_0)]

dictionary_observe_16_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5454062841816796, ('false', 'false'): 1.0, ('true', 'true'): 0.4545937158183204}
def f_observe_16_9_0(person_16_9_0, observe_16_9_0):
    return dictionary_observe_16_9_0[(person_16_9_0, observe_16_9_0)]

dictionary_person_17_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.36761970954202394, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6050179925222254, ('false', 'false', 'true', 'false', 'false'): 0.625220916635939, ('false', 'true', 'false', 'true', 'true'): 0.3682520898324819, ('false', 'false', 'true', 'false', 'true'): 0.37477908336406096, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6317479101675181, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6245956957193031, ('false', 'true', 'true', 'false', 'true'): 0.6046226151373628, ('false', 'true', 'true', 'false', 'false'): 0.3953773848626372, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.37540430428069693, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6323802904579761, ('false', 'true', 'true', 'true', 'false'): 0.39498200747777457}
def f_person_17_9_0(person_17_8_0, person_16_8_0, person_10_8_0, risk_17_9_0, person_17_9_0):
    return dictionary_person_17_9_0[(person_17_8_0, person_16_8_0, person_10_8_0, risk_17_9_0, person_17_9_0)]

dictionary_observe_17_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7768367567543005, ('false', 'false'): 1.0, ('true', 'true'): 0.22316324324569947}
def f_observe_17_9_0(person_17_9_0, observe_17_9_0):
    return dictionary_observe_17_9_0[(person_17_9_0, observe_17_9_0)]

dictionary_person_18_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_18_9_0(person_18_8_0, risk_18_9_0, person_18_9_0):
    return dictionary_person_18_9_0[(person_18_8_0, risk_18_9_0, person_18_9_0)]

dictionary_observe_18_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8673472406324346, ('false', 'false'): 1.0, ('true', 'true'): 0.13265275936756538}
def f_observe_18_9_0(person_18_9_0, observe_18_9_0):
    return dictionary_observe_18_9_0[(person_18_9_0, observe_18_9_0)]

dictionary_person_19_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5898940624108486, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.41010593758915137, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5893041683484378, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4106958316515622, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_19_9_0(person_19_8_0, person_20_8_0, risk_19_9_0, person_19_9_0):
    return dictionary_person_19_9_0[(person_19_8_0, person_20_8_0, risk_19_9_0, person_19_9_0)]

dictionary_observe_19_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.42468143372501443, ('false', 'false'): 1.0, ('true', 'true'): 0.5753185662749856}
def f_observe_19_9_0(person_19_9_0, observe_19_9_0):
    return dictionary_observe_19_9_0[(person_19_9_0, observe_19_9_0)]

dictionary_person_20_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.2542378514059225, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5795934366734847, ('false', 'false', 'true', 'false', 'false'): 0.5642917001225967, ('false', 'true', 'false', 'true', 'true'): 0.2549836135545166, ('false', 'false', 'true', 'false', 'true'): 0.43570829987740334, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.7450163864454834, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.563727408422474, ('false', 'true', 'true', 'false', 'true'): 0.5791726092827674, ('false', 'true', 'true', 'false', 'false'): 0.4208273907172326, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.43627259157752596, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.7457621485940775, ('false', 'true', 'true', 'true', 'false'): 0.4204065633265153}
def f_person_20_9_0(person_20_8_0, person_26_8_0, person_14_8_0, risk_20_9_0, person_20_9_0):
    return dictionary_person_20_9_0[(person_20_8_0, person_26_8_0, person_14_8_0, risk_20_9_0, person_20_9_0)]

dictionary_observe_20_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8977133382481097, ('false', 'false'): 1.0, ('true', 'true'): 0.10228666175189027}
def f_observe_20_9_0(person_20_9_0, observe_20_9_0):
    return dictionary_observe_20_9_0[(person_20_9_0, observe_20_9_0)]

dictionary_person_21_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_21_9_0(person_21_8_0, risk_21_9_0, person_21_9_0):
    return dictionary_person_21_9_0[(person_21_8_0, risk_21_9_0, person_21_9_0)]

dictionary_observe_21_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.46004433772089937, ('false', 'false'): 1.0, ('true', 'true'): 0.5399556622791006}
def f_observe_21_9_0(person_21_9_0, observe_21_9_0):
    return dictionary_observe_21_9_0[(person_21_9_0, observe_21_9_0)]

dictionary_person_22_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5927371884093037, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4072628115906963, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5921444512208943, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4078555487791057, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_22_9_0(person_22_8_0, person_21_8_0, risk_22_9_0, person_22_9_0):
    return dictionary_person_22_9_0[(person_22_8_0, person_21_8_0, risk_22_9_0, person_22_9_0)]

dictionary_observe_22_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4248416707753855, ('false', 'false'): 1.0, ('true', 'true'): 0.5751583292246145}
def f_observe_22_9_0(person_22_9_0, observe_22_9_0):
    return dictionary_observe_22_9_0[(person_22_9_0, observe_22_9_0)]

dictionary_person_23_9_0 = {('true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false'): 0.15765923227281306, ('false', 'true', 'false', 'false', 'false', 'true'): 0.5286336553273506, ('false', 'true', 'true', 'false', 'true', 'true'): 0.7233214240033735, ('true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false'): 0.2766785759966265, ('false', 'true', 'false', 'false', 'false', 'false'): 0.4713663446726494, ('false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false'): 0.4708949783279767, ('true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true'): 0.4124410139623089, ('true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true'): 0.8423407677271869, ('true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true'): 0.8421829506778649, ('false', 'false', 'true', 'false', 'false', 'false'): 0.5875589860376911, ('true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false'): 0.26859779711038484, ('false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'false', 'true', 'true', 'false'): 0.2683291993132745, ('true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true'): 0.7314022028896152, ('false', 'false', 'false', 'true', 'false', 'true'): 0.43017188192144173, ('true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false', 'true', 'true'): 0.5291050216720232, ('true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'false'): 0.1578170493221352, ('false', 'false', 'true', 'false', 'true', 'false'): 0.5869714270516534, ('false', 'true', 'true', 'false', 'false', 'false'): 0.27695553152815466, ('true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true'): 0.6651923687259966, ('true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'true', 'true'): 0.7316708006867255, ('false', 'false', 'false', 'true', 'true', 'false'): 0.5692582899604797, ('false', 'false', 'false', 'true', 'false', 'false'): 0.5698281180785583, ('true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false'): 0.3348076312740034, ('true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true'): 0.6655271763572705, ('false', 'false', 'true', 'false', 'true', 'true'): 0.4130285729483466, ('false', 'false', 'false', 'true', 'true', 'true'): 0.43074171003952033, ('true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'true'): 0.7230444684718453, ('false', 'false', 'true', 'true', 'true', 'false'): 0.3344728236427294}
def f_person_23_9_0(person_23_8_0, person_29_8_0, person_11_8_0, person_22_8_0, risk_23_9_0, person_23_9_0):
    return dictionary_person_23_9_0[(person_23_8_0, person_29_8_0, person_11_8_0, person_22_8_0, risk_23_9_0, person_23_9_0)]

dictionary_observe_23_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8287784111370362, ('false', 'false'): 1.0, ('true', 'true'): 0.1712215888629638}
def f_observe_23_9_0(person_23_9_0, observe_23_9_0):
    return dictionary_observe_23_9_0[(person_23_9_0, observe_23_9_0)]

dictionary_person_24_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.6574718318023032, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.829524451943507, ('false', 'false', 'true', 'false', 'false'): 0.4981960904081092, ('false', 'true', 'false', 'true', 'true'): 0.6578143599705009, ('false', 'false', 'true', 'false', 'true'): 0.5018039095918908, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.34218564002949914, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.49769789431770106, ('false', 'true', 'true', 'false', 'true'): 0.8293538057492562, ('false', 'true', 'true', 'false', 'false'): 0.1706461942507438, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.5023021056822989, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.3425281681976968, ('false', 'true', 'true', 'true', 'false'): 0.17047554805649304}
def f_person_24_9_0(person_24_8_0, person_32_8_0, person_23_8_0, risk_24_9_0, person_24_9_0):
    return dictionary_person_24_9_0[(person_24_8_0, person_32_8_0, person_23_8_0, risk_24_9_0, person_24_9_0)]

dictionary_observe_24_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.492271061096754, ('false', 'false'): 1.0, ('true', 'true'): 0.507728938903246}
def f_observe_24_9_0(person_24_9_0, observe_24_9_0):
    return dictionary_observe_24_9_0[(person_24_9_0, observe_24_9_0)]

dictionary_person_25_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.47708781778204323, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6750010654823861, ('false', 'false', 'true', 'false', 'false'): 0.6221393760545262, ('false', 'true', 'false', 'true', 'true'): 0.47761072996426124, ('false', 'false', 'true', 'false', 'true'): 0.3778606239454738, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5223892700357388, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6215172366784717, ('false', 'true', 'true', 'false', 'true'): 0.6746757412236097, ('false', 'true', 'true', 'false', 'false'): 0.3253242587763903, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3784827633215283, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5229121822179568, ('false', 'true', 'true', 'true', 'false'): 0.3249989345176139}
def f_person_25_9_0(person_25_8_0, person_31_8_0, person_30_8_0, risk_25_9_0, person_25_9_0):
    return dictionary_person_25_9_0[(person_25_8_0, person_31_8_0, person_30_8_0, risk_25_9_0, person_25_9_0)]

dictionary_observe_25_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.40129665951873483, ('false', 'false'): 1.0, ('true', 'true'): 0.5987033404812652}
def f_observe_25_9_0(person_25_9_0, observe_25_9_0):
    return dictionary_observe_25_9_0[(person_25_9_0, observe_25_9_0)]

dictionary_person_26_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.31390730305503567, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.5773087431942601, ('false', 'false', 'true', 'false', 'false'): 0.6167014647743109, ('false', 'true', 'false', 'true', 'true'): 0.31459339575198064, ('false', 'false', 'true', 'false', 'true'): 0.38329853522568913, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6854066042480194, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6160847633095365, ('false', 'true', 'true', 'false', 'true'): 0.5768856288230831, ('false', 'true', 'true', 'false', 'false'): 0.42311437117691686, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.38391523669046346, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6860926969449643, ('false', 'true', 'true', 'true', 'false'): 0.42269125680573993}
def f_person_26_9_0(person_26_8_0, person_28_8_0, person_32_8_0, risk_26_9_0, person_26_9_0):
    return dictionary_person_26_9_0[(person_26_8_0, person_28_8_0, person_32_8_0, risk_26_9_0, person_26_9_0)]

dictionary_observe_26_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4629073687708316, ('false', 'false'): 1.0, ('true', 'true'): 0.5370926312291684}
def f_observe_26_9_0(person_26_9_0, observe_26_9_0):
    return dictionary_observe_26_9_0[(person_26_9_0, observe_26_9_0)]

dictionary_person_27_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6334900923569637, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.36650990764303626, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6328566022646068, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3671433977353932, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_27_9_0(person_27_8_0, person_32_8_0, risk_27_9_0, person_27_9_0):
    return dictionary_person_27_9_0[(person_27_8_0, person_32_8_0, risk_27_9_0, person_27_9_0)]

dictionary_observe_27_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7621464177112334, ('false', 'false'): 1.0, ('true', 'true'): 0.23785358228876663}
def f_observe_27_9_0(person_27_9_0, observe_27_9_0):
    return dictionary_observe_27_9_0[(person_27_9_0, observe_27_9_0)]

dictionary_person_28_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6716560384952592, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.32834396150474077, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.670984382456764, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.32901561754323605, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_28_9_0(person_28_8_0, person_22_8_0, risk_28_9_0, person_28_9_0):
    return dictionary_person_28_9_0[(person_28_8_0, person_22_8_0, risk_28_9_0, person_28_9_0)]

dictionary_observe_28_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9924051204838689, ('false', 'false'): 1.0, ('true', 'true'): 0.007594879516131137}
def f_observe_28_9_0(person_28_9_0, observe_28_9_0):
    return dictionary_observe_28_9_0[(person_28_9_0, observe_28_9_0)]

dictionary_person_29_9_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_29_9_0(person_29_8_0, risk_29_9_0, person_29_9_0):
    return dictionary_person_29_9_0[(person_29_8_0, risk_29_9_0, person_29_9_0)]

dictionary_observe_29_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5443467852300397, ('false', 'false'): 1.0, ('true', 'true'): 0.45565321476996035}
def f_observe_29_9_0(person_29_9_0, observe_29_9_0):
    return dictionary_observe_29_9_0[(person_29_9_0, observe_29_9_0)]

dictionary_person_30_9_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.5199816243354789, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.10630817701512518, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.22932773925711647, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.4155141131255815, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.7699015884821406, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.652705423261357, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.49647451036639567, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.4298477628918852, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.4504470598098173, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.5577568893910062, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.6533587820434005, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.36441536192882346, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.31125650237281777, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.34729457673864295, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.48049887453906015, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.28056396601629535, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.5844858868744185, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.68943293055774, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.894586409394269, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.8936918229848748, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.5701522371081148, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.5926437534686317, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.686061840557935, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.36405094656689463, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.4969780358560293, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.5705820848710067, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.10541359060573097, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.5030219641439707, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.5035254896336043, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.4073562465313683, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.6887434976271822, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.6228566929369057, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.40694889028483694, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.31393815944206505, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.5495529401901826, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.2808448108271225, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.7706722607428835, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.3466412179565995, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.3765198268899843, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.5195011254609398, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.7191551891728776, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.7194360339837047, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.5930511097151631, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.3771433070630943, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.44280086749838476, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.5500033872499925, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.23009841151785937, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.6355846380711765, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.686375778717377, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.31056706944226, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.5571991325016152, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.4294179151289933, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.44999661275000746, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.41609859901245594, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.5839014009875441, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.4422431106089938, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.6359490534331054, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.31362422128262296, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.4800183756645211, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.6234801731100157}
def f_person_30_9_0(person_30_8_0, person_32_8_0, person_29_8_0, person_24_8_0, person_0_8_0, risk_30_9_0, person_30_9_0):
    return dictionary_person_30_9_0[(person_30_8_0, person_32_8_0, person_29_8_0, person_24_8_0, person_0_8_0, risk_30_9_0, person_30_9_0)]

dictionary_observe_30_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8203591454142691, ('false', 'false'): 1.0, ('true', 'true'): 0.17964085458573087}
def f_observe_30_9_0(person_30_9_0, observe_30_9_0):
    return dictionary_observe_30_9_0[(person_30_9_0, observe_30_9_0)]

dictionary_person_31_9_0 = {('true', 'false', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false', 'true', 'true'): 0.8403015661600218, ('false', 'false', 'false', 'false', 'true', 'true', 'true'): 0.5450095938576511, ('true', 'true', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'false', 'true'): 0.6769740804742239, ('false', 'true', 'false', 'false', 'true', 'false', 'true'): 0.6885922791818635, ('true', 'true', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'true', 'false', 'true', 'false'): 0.3227028936062503, ('false', 'true', 'false', 'false', 'false', 'true', 'false'): 0.683058835062532, ('true', 'true', 'true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false', 'false', 'true'): 0.7791334251388591, ('false', 'false', 'true', 'true', 'true', 'false', 'false'): 0.07280679605846957, ('false', 'true', 'false', 'true', 'true', 'false', 'false'): 0.10059276536470471, ('true', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'false'): 0.22538995064344955, ('false', 'true', 'false', 'false', 'false', 'false', 'false'): 0.6837425776401721, ('false', 'true', 'true', 'false', 'true', 'false', 'false'): 0.15410870582714334, ('true', 'false', 'false', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true', 'true', 'true'): 0.8530263056804614, ('true', 'false', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'true', 'true'): 0.31694116493746805, ('false', 'false', 'true', 'true', 'false', 'false', 'false'): 0.15985829213211028, ('false', 'true', 'true', 'true', 'true', 'true', 'false'): 0.04973132530033356, ('true', 'true', 'true', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'false', 'false'): 0.3114077208181365, ('false', 'false', 'false', 'true', 'true', 'false', 'false'): 0.14712081513467323, ('true', 'true', 'true', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'true', 'false', 'false'): 0.4554458519943432, ('false', 'false', 'false', 'false', 'true', 'true', 'false'): 0.4549904061423488, ('false', 'false', 'true', 'true', 'true', 'false', 'true'): 0.9271932039415305, ('true', 'false', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false', 'false', 'false', 'true'): 0.6616311134412145, ('true', 'true', 'false', 'true', 'true', 'true', 'true'): 1.0, ('true', 'true', 'false', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'true'): 1.0, ('true', 'false', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'true'): 0.8906980792804353, ('false', 'true', 'true', 'false', 'true', 'true', 'false'): 0.1539545971213162, ('true', 'false', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false', 'false', 'true'): 1.0, ('true', 'true', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'true', 'true'): 0.7793542917137202, ('true', 'false', 'false', 'false', 'false', 'true', 'false'): 0.0, ('true', 'true', 'false', 'false', 'true', 'true', 'false'): 0.0, ('false', 'false', 'true', 'true', 'true', 'true', 'true'): 0.9272660107375889, ('false', 'false', 'false', 'false', 'true', 'false', 'true'): 0.5445541480056568, ('false', 'true', 'false', 'true', 'false', 'true', 'false'): 0.2206457082862798, ('true', 'false', 'false', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'false', 'false', 'false'): 0.22086657486114095, ('false', 'false', 'false', 'false', 'false', 'false', 'false'): 1.0, ('false', 'true', 'true', 'false', 'false', 'false', 'false'): 0.33836888655878555, ('false', 'false', 'false', 'true', 'true', 'true', 'false'): 0.14697369431953855, ('true', 'true', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'false', 'true', 'false'): 0.4943827234496423, ('false', 'true', 'true', 'false', 'false', 'true', 'false'): 0.33803051767222675, ('false', 'false', 'false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'false', 'false', 'false'): 0.10930192071956472, ('false', 'true', 'false', 'true', 'true', 'false', 'true'): 0.8994072346352953, ('true', 'false', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'false', 'false'): 0.04978110640674031, ('true', 'false', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false', 'false', 'false'): 0.3230259195257761, ('true', 'false', 'false', 'false', 'true', 'true', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'false'): 0.0, ('true', 'false', 'false', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'true', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false', 'false', 'true'): 0.3162574223598279, ('false', 'false', 'true', 'false', 'false', 'false', 'true'): 0.505122398949307, ('true', 'true', 'true', 'false', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'false', 'false', 'true'): 0.8401417078678897, ('false', 'true', 'true', 'true', 'true', 'false', 'true'): 0.9502188935932597, ('true', 'true', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'false', 'true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'true', 'true', 'true', 'true', 'true', 'true'): 0.9502686746996665, ('true', 'true', 'false', 'true', 'false', 'true', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true', 'true', 'true'): 1.0, ('true', 'false', 'false', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'true', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'false', 'false', 'true', 'true', 'true'): 1.0, ('false', 'true', 'true', 'false', 'false', 'true', 'true'): 0.6619694823277733, ('true', 'true', 'false', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'true', 'true'): 0.5056172765503577, ('false', 'false', 'true', 'false', 'true', 'true', 'true'): 0.7748354393071939, ('true', 'true', 'false', 'false', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'true', 'true', 'true', 'true'): 0.89950782740066, ('false', 'false', 'false', 'true', 'false', 'true', 'true'): 0.6772971063937496, ('true', 'true', 'false', 'false', 'true', 'false', 'true'): 1.0, ('false', 'true', 'true', 'false', 'true', 'false', 'true'): 0.8458912941728567, ('true', 'false', 'false', 'false', 'true', 'false', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'true'): 0.8908073812011549, ('false', 'false', 'false', 'true', 'true', 'false', 'true'): 0.8528791848653268, ('true', 'true', 'true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'false', 'true', 'true', 'false'): 0.2251645606928061, ('true', 'false', 'true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true', 'true', 'false'): 0.0727339892624111, ('false', 'true', 'false', 'true', 'true', 'true', 'false'): 0.10049217259934001, ('true', 'false', 'true', 'false', 'true', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'true', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true', 'true', 'true'): 0.6889036869026817, ('false', 'true', 'false', 'false', 'true', 'true', 'false'): 0.3110963130973184, ('true', 'true', 'true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'true', 'false', 'true'): 0.7746100493565504, ('false', 'true', 'true', 'false', 'true', 'true', 'true'): 0.8460454028786838, ('true', 'true', 'false', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'false', 'true', 'false'): 0.10919261879884516, ('false', 'false', 'true', 'true', 'false', 'true', 'false'): 0.15969843383997817, ('true', 'true', 'true', 'true', 'false', 'true', 'true'): 1.0, ('false', 'false', 'true', 'false', 'false', 'false', 'false'): 0.494877601050693}
def f_person_31_9_0(person_31_8_0, person_25_8_0, person_1_8_0, person_29_8_0, person_32_8_0, risk_31_9_0, person_31_9_0):
    return dictionary_person_31_9_0[(person_31_8_0, person_25_8_0, person_1_8_0, person_29_8_0, person_32_8_0, risk_31_9_0, person_31_9_0)]

dictionary_observe_31_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6920829273823557, ('false', 'false'): 1.0, ('true', 'true'): 0.30791707261764434}
def f_observe_31_9_0(person_31_9_0, observe_31_9_0):
    return dictionary_observe_31_9_0[(person_31_9_0, observe_31_9_0)]

dictionary_person_32_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.6268079530205232, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7798865344644116, ('false', 'false', 'true', 'false', 'false'): 0.590403255155757, ('false', 'true', 'false', 'true', 'true'): 0.6271811450675027, ('false', 'false', 'true', 'false', 'true'): 0.409596744844243, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.37281885493249733, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5898128519006012, ('false', 'true', 'true', 'false', 'true'): 0.7796662006650767, ('false', 'true', 'true', 'false', 'false'): 0.2203337993349233, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4101871480993988, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.37319204697947683, ('false', 'true', 'true', 'true', 'false'): 0.2201134655355884}
def f_person_32_9_0(person_32_8_0, person_2_8_0, person_27_8_0, risk_32_9_0, person_32_9_0):
    return dictionary_person_32_9_0[(person_32_8_0, person_2_8_0, person_27_8_0, risk_32_9_0, person_32_9_0)]

dictionary_observe_32_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6379000785610338, ('false', 'false'): 1.0, ('true', 'true'): 0.3620999214389662}
def f_observe_32_9_0(person_32_9_0, observe_32_9_0):
    return dictionary_observe_32_9_0[(person_32_9_0, observe_32_9_0)]

dictionary_person_33_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5048116878420388, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4951883121579612, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5043068761541968, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4956931238458032, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_33_9_0(person_33_8_0, person_28_8_0, risk_33_9_0, person_33_9_0):
    return dictionary_person_33_9_0[(person_33_8_0, person_28_8_0, risk_33_9_0, person_33_9_0)]

dictionary_observe_33_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9853511823040157, ('false', 'false'): 1.0, ('true', 'true'): 0.014648817695984251}
def f_observe_33_9_0(person_33_9_0, observe_33_9_0):
    return dictionary_observe_33_9_0[(person_33_9_0, observe_33_9_0)]

dictionary_person_34_9_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.45310293693858505, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7224259133928532, ('false', 'false', 'true', 'false', 'false'): 0.5080516194223748, ('false', 'true', 'false', 'true', 'true'): 0.4536498340016465, ('false', 'false', 'true', 'false', 'true'): 0.49194838057762524, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5463501659983535, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5075435678029524, ('false', 'true', 'true', 'false', 'true'): 0.7221480614543075, ('false', 'true', 'true', 'false', 'false'): 0.27785193854569246, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4924564321970476, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.546897063061415, ('false', 'true', 'true', 'true', 'false'): 0.2775740866071468}
def f_person_34_9_0(person_34_8_0, person_28_8_0, person_35_8_0, risk_34_9_0, person_34_9_0):
    return dictionary_person_34_9_0[(person_34_8_0, person_28_8_0, person_35_8_0, risk_34_9_0, person_34_9_0)]

dictionary_observe_34_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.44028742744898985, ('false', 'false'): 1.0, ('true', 'true'): 0.5597125725510101}
def f_observe_34_9_0(person_34_9_0, observe_34_9_0):
    return dictionary_observe_34_9_0[(person_34_9_0, observe_34_9_0)]

dictionary_person_35_9_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.7554835471506909, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.24451645284930912, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7547280636035402, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.24527193639645983, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_35_9_0(person_35_8_0, person_34_8_0, risk_35_9_0, person_35_9_0):
    return dictionary_person_35_9_0[(person_35_8_0, person_34_8_0, risk_35_9_0, person_35_9_0)]

dictionary_observe_35_9_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7101485139801864, ('false', 'false'): 1.0, ('true', 'true'): 0.2898514860198136}
def f_observe_35_9_0(person_35_9_0, observe_35_9_0):
    return dictionary_observe_35_9_0[(person_35_9_0, observe_35_9_0)]

dictionary_person_0_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6003731228752764, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.39962687712472356, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5997727497524011, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.40022725024759886, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_0_10_0(person_0_9_0, person_5_9_0, risk_0_10_0, person_0_10_0):
    return dictionary_person_0_10_0[(person_0_9_0, person_5_9_0, risk_0_10_0, person_0_10_0)]

dictionary_observe_0_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7204886778776185, ('false', 'false'): 1.0, ('true', 'true'): 0.2795113221223815}
def f_observe_0_10_0(person_0_10_0, observe_0_10_0):
    return dictionary_observe_0_10_0[(person_0_10_0, observe_0_10_0)]

dictionary_person_1_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_1_10_0(person_1_9_0, risk_1_10_0, person_1_10_0):
    return dictionary_person_1_10_0[(person_1_9_0, risk_1_10_0, person_1_10_0)]

dictionary_observe_1_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5632835150555366, ('false', 'false'): 1.0, ('true', 'true'): 0.43671648494446336}
def f_observe_1_10_0(person_1_10_0, observe_1_10_0):
    return dictionary_observe_1_10_0[(person_1_10_0, observe_1_10_0)]

dictionary_person_2_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.3868476911547626, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.6131523088452374, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.3864608434636078, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.6135391565363921, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_2_10_0(person_2_9_0, person_8_9_0, risk_2_10_0, person_2_10_0):
    return dictionary_person_2_10_0[(person_2_9_0, person_8_9_0, risk_2_10_0, person_2_10_0)]

dictionary_observe_2_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.885134477868204, ('false', 'false'): 1.0, ('true', 'true'): 0.11486552213179602}
def f_observe_2_10_0(person_2_10_0, observe_2_10_0):
    return dictionary_observe_2_10_0[(person_2_10_0, observe_2_10_0)]

dictionary_person_3_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_3_10_0(person_3_9_0, risk_3_10_0, person_3_10_0):
    return dictionary_person_3_10_0[(person_3_9_0, risk_3_10_0, person_3_10_0)]

dictionary_observe_3_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6059881140270743, ('false', 'false'): 1.0, ('true', 'true'): 0.3940118859729257}
def f_observe_3_10_0(person_3_10_0, observe_3_10_0):
    return dictionary_observe_3_10_0[(person_3_10_0, observe_3_10_0)]

dictionary_person_4_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_4_10_0(person_4_9_0, risk_4_10_0, person_4_10_0):
    return dictionary_person_4_10_0[(person_4_9_0, risk_4_10_0, person_4_10_0)]

dictionary_observe_4_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6805013117359093, ('false', 'false'): 1.0, ('true', 'true'): 0.31949868826409067}
def f_observe_4_10_0(person_4_10_0, observe_4_10_0):
    return dictionary_observe_4_10_0[(person_4_10_0, observe_4_10_0)]

dictionary_person_5_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_5_10_0(person_5_9_0, risk_5_10_0, person_5_10_0):
    return dictionary_person_5_10_0[(person_5_9_0, risk_5_10_0, person_5_10_0)]

dictionary_observe_5_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7441993500510988, ('false', 'false'): 1.0, ('true', 'true'): 0.25580064994890117}
def f_observe_5_10_0(person_5_10_0, observe_5_10_0):
    return dictionary_observe_5_10_0[(person_5_10_0, observe_5_10_0)]

dictionary_person_6_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.6623521944073796, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.818130767632596, ('false', 'false', 'true', 'false', 'false'): 0.5391750831358995, ('false', 'true', 'false', 'true', 'true'): 0.6626898422129722, ('false', 'false', 'true', 'false', 'true'): 0.46082491686410054, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.3373101577870278, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.5386359080527635, ('false', 'true', 'true', 'false', 'true'): 0.8179487163489448, ('false', 'true', 'true', 'false', 'false'): 0.18205128365105513, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.4613640919472365, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.3376478055926204, ('false', 'true', 'true', 'true', 'false'): 0.18186923236740407}
def f_person_6_10_0(person_6_9_0, person_12_9_0, person_18_9_0, risk_6_10_0, person_6_10_0):
    return dictionary_person_6_10_0[(person_6_9_0, person_12_9_0, person_18_9_0, risk_6_10_0, person_6_10_0)]

dictionary_observe_6_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6947710757720056, ('false', 'false'): 1.0, ('true', 'true'): 0.3052289242279944}
def f_observe_6_10_0(person_6_10_0, observe_6_10_0):
    return dictionary_observe_6_10_0[(person_6_10_0, observe_6_10_0)]

dictionary_person_7_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_7_10_0(person_7_9_0, risk_7_10_0, person_7_10_0):
    return dictionary_person_7_10_0[(person_7_9_0, risk_7_10_0, person_7_10_0)]

dictionary_observe_7_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4362537091711257, ('false', 'false'): 1.0, ('true', 'true'): 0.5637462908288743}
def f_observe_7_10_0(person_7_10_0, observe_7_10_0):
    return dictionary_observe_7_10_0[(person_7_10_0, observe_7_10_0)]

dictionary_person_8_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_8_10_0(person_8_9_0, risk_8_10_0, person_8_10_0):
    return dictionary_person_8_10_0[(person_8_9_0, risk_8_10_0, person_8_10_0)]

dictionary_observe_8_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9472583888495516, ('false', 'false'): 1.0, ('true', 'true'): 0.0527416111504484}
def f_observe_8_10_0(person_8_10_0, observe_8_10_0):
    return dictionary_observe_8_10_0[(person_8_10_0, observe_8_10_0)]

dictionary_person_9_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.5043569445630496, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.4956430554369504, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.5038525876184865, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.4961474123815135, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_9_10_0(person_9_9_0, person_15_9_0, risk_9_10_0, person_9_10_0):
    return dictionary_person_9_10_0[(person_9_9_0, person_15_9_0, risk_9_10_0, person_9_10_0)]

dictionary_observe_9_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8865361731407123, ('false', 'false'): 1.0, ('true', 'true'): 0.11346382685928769}
def f_observe_9_10_0(person_9_10_0, observe_9_10_0):
    return dictionary_observe_9_10_0[(person_9_10_0, observe_9_10_0)]

dictionary_person_10_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6046323905149045, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.39536760948509553, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6040277581243896, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3959722418756104, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_10_10_0(person_10_9_0, person_16_9_0, risk_10_10_0, person_10_10_0):
    return dictionary_person_10_10_0[(person_10_9_0, person_16_9_0, risk_10_10_0, person_10_10_0)]

dictionary_observe_10_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7200823032242682, ('false', 'false'): 1.0, ('true', 'true'): 0.27991769677573175}
def f_observe_10_10_0(person_10_10_0, observe_10_10_0):
    return dictionary_observe_10_10_0[(person_10_10_0, observe_10_10_0)]

dictionary_person_11_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.3354000589485391, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.6645999410514609, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.3350646588895905, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.6649353411104095, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_11_10_0(person_11_9_0, person_18_9_0, risk_11_10_0, person_11_10_0):
    return dictionary_person_11_10_0[(person_11_9_0, person_18_9_0, risk_11_10_0, person_11_10_0)]

dictionary_observe_11_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6436253084463888, ('false', 'false'): 1.0, ('true', 'true'): 0.35637469155361123}
def f_observe_11_10_0(person_11_10_0, observe_11_10_0):
    return dictionary_observe_11_10_0[(person_11_10_0, observe_11_10_0)]

dictionary_person_12_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.32506946789594227, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.7381334272420426, ('false', 'false', 'true', 'false', 'false'): 0.38837878713568563, ('false', 'true', 'false', 'true', 'true'): 0.32574439842804637, ('false', 'false', 'true', 'false', 'true'): 0.6116212128643144, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.6742556015719536, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.3879904083485499, ('false', 'true', 'true', 'false', 'true'): 0.7378712985405831, ('false', 'true', 'true', 'false', 'false'): 0.26212870145941686, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.6120095916514501, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.6749305321040577, ('false', 'true', 'true', 'true', 'false'): 0.26186657275795744}
def f_person_12_10_0(person_12_9_0, person_17_9_0, person_10_9_0, risk_12_10_0, person_12_10_0):
    return dictionary_person_12_10_0[(person_12_9_0, person_17_9_0, person_10_9_0, risk_12_10_0, person_12_10_0)]

dictionary_observe_12_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5827457545156072, ('false', 'false'): 1.0, ('true', 'true'): 0.4172542454843928}
def f_observe_12_10_0(person_12_10_0, observe_12_10_0):
    return dictionary_observe_12_10_0[(person_12_10_0, observe_12_10_0)]

dictionary_person_13_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_13_10_0(person_13_9_0, risk_13_10_0, person_13_10_0):
    return dictionary_person_13_10_0[(person_13_9_0, risk_13_10_0, person_13_10_0)]

dictionary_observe_13_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4800179675026136, ('false', 'false'): 1.0, ('true', 'true'): 0.5199820324973864}
def f_observe_13_10_0(person_13_10_0, observe_13_10_0):
    return dictionary_observe_13_10_0[(person_13_10_0, observe_13_10_0)]

dictionary_person_14_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_14_10_0(person_14_9_0, risk_14_10_0, person_14_10_0):
    return dictionary_person_14_10_0[(person_14_9_0, risk_14_10_0, person_14_10_0)]

dictionary_observe_14_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7244664638828597, ('false', 'false'): 1.0, ('true', 'true'): 0.27553353611714027}
def f_observe_14_10_0(person_14_10_0, observe_14_10_0):
    return dictionary_observe_14_10_0[(person_14_10_0, observe_14_10_0)]

dictionary_person_15_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_15_10_0(person_15_9_0, risk_15_10_0, person_15_10_0):
    return dictionary_person_15_10_0[(person_15_9_0, risk_15_10_0, person_15_10_0)]

dictionary_observe_15_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9432773116808492, ('false', 'false'): 1.0, ('true', 'true'): 0.05672268831915084}
def f_observe_15_10_0(person_15_10_0, observe_15_10_0):
    return dictionary_observe_15_10_0[(person_15_10_0, observe_15_10_0)]

dictionary_person_16_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4678223058236014, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5321776941763986, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4673544835177778, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5326455164822221, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_16_10_0(person_16_9_0, person_17_9_0, risk_16_10_0, person_16_10_0):
    return dictionary_person_16_10_0[(person_16_9_0, person_17_9_0, risk_16_10_0, person_16_10_0)]

dictionary_observe_16_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6591030076463389, ('false', 'false'): 1.0, ('true', 'true'): 0.3408969923536611}
def f_observe_16_10_0(person_16_10_0, observe_16_10_0):
    return dictionary_observe_16_10_0[(person_16_10_0, observe_16_10_0)]

dictionary_person_17_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_17_10_0(person_17_9_0, risk_17_10_0, person_17_10_0):
    return dictionary_person_17_10_0[(person_17_9_0, risk_17_10_0, person_17_10_0)]

dictionary_observe_17_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.718447930654895, ('false', 'false'): 1.0, ('true', 'true'): 0.281552069345105}
def f_observe_17_10_0(person_17_10_0, observe_17_10_0):
    return dictionary_observe_17_10_0[(person_17_10_0, observe_17_10_0)]

dictionary_person_18_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_18_10_0(person_18_9_0, risk_18_10_0, person_18_10_0):
    return dictionary_person_18_10_0[(person_18_9_0, risk_18_10_0, person_18_10_0)]

dictionary_observe_18_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.717519923830673, ('false', 'false'): 1.0, ('true', 'true'): 0.282480076169327}
def f_observe_18_10_0(person_18_10_0, observe_18_10_0):
    return dictionary_observe_18_10_0[(person_18_10_0, observe_18_10_0)]

dictionary_person_19_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_19_10_0(person_19_9_0, risk_19_10_0, person_19_10_0):
    return dictionary_person_19_10_0[(person_19_9_0, risk_19_10_0, person_19_10_0)]

dictionary_observe_19_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4915818347797991, ('false', 'false'): 1.0, ('true', 'true'): 0.5084181652202009}
def f_observe_19_10_0(person_19_10_0, observe_19_10_0):
    return dictionary_observe_19_10_0[(person_19_10_0, observe_19_10_0)]

dictionary_person_20_10_0 = {('true', 'true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'false', 'false', 'true'): 0.42314846752626245, ('true', 'true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true', 'false'): 0.0, ('false', 'true', 'true', 'true', 'true'): 0.6519111269188123, ('false', 'false', 'true', 'false', 'false'): 0.604032911028875, ('false', 'true', 'false', 'true', 'true'): 0.4237253190587362, ('false', 'false', 'true', 'false', 'true'): 0.395967088971125, ('false', 'false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true', 'false'): 0.999, ('true', 'false', 'true', 'false', 'false'): 0.0, ('true', 'true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'true', 'false'): 0.5762746809412638, ('true', 'false', 'false', 'true', 'true'): 1.0, ('true', 'false', 'false', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true', 'false'): 0.6034288781178462, ('false', 'true', 'true', 'false', 'true'): 0.6515626896084207, ('false', 'true', 'true', 'false', 'false'): 0.3484373103915793, ('false', 'false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false', 'true'): 1.0, ('false', 'false', 'true', 'true', 'true'): 0.3965711218821538, ('true', 'true', 'true', 'true', 'false'): 0.0, ('true', 'false', 'true', 'false', 'true'): 1.0, ('true', 'true', 'true', 'false', 'false'): 0.0, ('true', 'true', 'false', 'true', 'true'): 1.0, ('true', 'false', 'true', 'true', 'true'): 1.0, ('false', 'false', 'false', 'true', 'true'): 0.0010000000000000009, ('true', 'true', 'false', 'true', 'false'): 0.0, ('true', 'false', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'false', 'false'): 0.5768515324737375, ('false', 'true', 'true', 'true', 'false'): 0.34808887308118774}
def f_person_20_10_0(person_20_9_0, person_26_9_0, person_21_9_0, risk_20_10_0, person_20_10_0):
    return dictionary_person_20_10_0[(person_20_9_0, person_26_9_0, person_21_9_0, risk_20_10_0, person_20_10_0)]

dictionary_observe_20_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.49223549488431995, ('false', 'false'): 1.0, ('true', 'true'): 0.50776450511568}
def f_observe_20_10_0(person_20_10_0, observe_20_10_0):
    return dictionary_observe_20_10_0[(person_20_10_0, observe_20_10_0)]

dictionary_person_21_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_21_10_0(person_21_9_0, risk_21_10_0, person_21_10_0):
    return dictionary_person_21_10_0[(person_21_9_0, risk_21_10_0, person_21_10_0)]

dictionary_observe_21_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9542189474649907, ('false', 'false'): 1.0, ('true', 'true'): 0.0457810525350093}
def f_observe_21_10_0(person_21_10_0, observe_21_10_0):
    return dictionary_observe_21_10_0[(person_21_10_0, observe_21_10_0)]

dictionary_person_22_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_22_10_0(person_22_9_0, risk_22_10_0, person_22_10_0):
    return dictionary_person_22_10_0[(person_22_9_0, risk_22_10_0, person_22_10_0)]

dictionary_observe_22_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9491960089971199, ('false', 'false'): 1.0, ('true', 'true'): 0.05080399100288013}
def f_observe_22_10_0(person_22_10_0, observe_22_10_0):
    return dictionary_observe_22_10_0[(person_22_10_0, observe_22_10_0)]

dictionary_person_23_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_23_10_0(person_23_9_0, risk_23_10_0, person_23_10_0):
    return dictionary_person_23_10_0[(person_23_9_0, risk_23_10_0, person_23_10_0)]

dictionary_observe_23_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5386660843653267, ('false', 'false'): 1.0, ('true', 'true'): 0.4613339156346733}
def f_observe_23_10_0(person_23_10_0, observe_23_10_0):
    return dictionary_observe_23_10_0[(person_23_10_0, observe_23_10_0)]

dictionary_person_24_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_24_10_0(person_24_9_0, risk_24_10_0, person_24_10_0):
    return dictionary_person_24_10_0[(person_24_9_0, risk_24_10_0, person_24_10_0)]

dictionary_observe_24_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.8715201884438215, ('false', 'false'): 1.0, ('true', 'true'): 0.1284798115561785}
def f_observe_24_10_0(person_24_10_0, observe_24_10_0):
    return dictionary_observe_24_10_0[(person_24_10_0, observe_24_10_0)]

dictionary_person_25_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.4533533119825278, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.5466466880174722, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.4528999586705453, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.5471000413294547, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_25_10_0(person_25_9_0, person_31_9_0, risk_25_10_0, person_25_10_0):
    return dictionary_person_25_10_0[(person_25_9_0, person_31_9_0, risk_25_10_0, person_25_10_0)]

dictionary_observe_25_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4239178362443212, ('false', 'false'): 1.0, ('true', 'true'): 0.5760821637556788}
def f_observe_25_10_0(person_25_10_0, observe_25_10_0):
    return dictionary_observe_25_10_0[(person_25_10_0, observe_25_10_0)]

dictionary_person_26_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_26_10_0(person_26_9_0, risk_26_10_0, person_26_10_0):
    return dictionary_person_26_10_0[(person_26_9_0, risk_26_10_0, person_26_10_0)]

dictionary_observe_26_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6500576812527188, ('false', 'false'): 1.0, ('true', 'true'): 0.3499423187472812}
def f_observe_26_10_0(person_26_10_0, observe_26_10_0):
    return dictionary_observe_26_10_0[(person_26_10_0, observe_26_10_0)]

dictionary_person_27_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.747895269241517, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.25210473075848305, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.7471473739722754, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.2528526260277246, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_27_10_0(person_27_9_0, person_25_9_0, risk_27_10_0, person_27_10_0):
    return dictionary_person_27_10_0[(person_27_9_0, person_25_9_0, risk_27_10_0, person_27_10_0)]

dictionary_observe_27_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5020634898547476, ('false', 'false'): 1.0, ('true', 'true'): 0.4979365101452524}
def f_observe_27_10_0(person_27_10_0, observe_27_10_0):
    return dictionary_observe_27_10_0[(person_27_10_0, observe_27_10_0)]

dictionary_person_28_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_28_10_0(person_28_9_0, risk_28_10_0, person_28_10_0):
    return dictionary_person_28_10_0[(person_28_9_0, risk_28_10_0, person_28_10_0)]

dictionary_observe_28_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7856051928686251, ('false', 'false'): 1.0, ('true', 'true'): 0.21439480713137493}
def f_observe_28_10_0(person_28_10_0, observe_28_10_0):
    return dictionary_observe_28_10_0[(person_28_10_0, observe_28_10_0)]

dictionary_person_29_10_0 = {('true', 'true', 'true', 'true'): 1.0, ('false', 'true', 'false', 'false'): 0.6040169874627652, ('true', 'false', 'true', 'false'): 0.0, ('false', 'true', 'false', 'true'): 0.3959830125372348, ('true', 'false', 'false', 'true'): 1.0, ('true', 'false', 'true', 'true'): 1.0, ('true', 'true', 'false', 'true'): 1.0, ('false', 'false', 'false', 'true'): 0.0, ('true', 'false', 'false', 'false'): 0.0, ('false', 'true', 'true', 'false'): 0.6034129704753024, ('false', 'false', 'true', 'false'): 0.999, ('false', 'true', 'true', 'true'): 0.3965870295246976, ('true', 'true', 'true', 'false'): 0.0, ('false', 'false', 'false', 'false'): 1.0, ('true', 'true', 'false', 'false'): 0.0, ('false', 'false', 'true', 'true'): 0.0010000000000000009}
def f_person_29_10_0(person_29_9_0, person_23_9_0, risk_29_10_0, person_29_10_0):
    return dictionary_person_29_10_0[(person_29_9_0, person_23_9_0, risk_29_10_0, person_29_10_0)]

dictionary_observe_29_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.7450233813391414, ('false', 'false'): 1.0, ('true', 'true'): 0.25497661866085863}
def f_observe_29_10_0(person_29_10_0, observe_29_10_0):
    return dictionary_observe_29_10_0[(person_29_10_0, observe_29_10_0)]

dictionary_person_30_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_30_10_0(person_30_9_0, risk_30_10_0, person_30_10_0):
    return dictionary_person_30_10_0[(person_30_9_0, risk_30_10_0, person_30_10_0)]

dictionary_observe_30_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6176240334099115, ('false', 'false'): 1.0, ('true', 'true'): 0.38237596659008855}
def f_observe_30_10_0(person_30_10_0, observe_30_10_0):
    return dictionary_observe_30_10_0[(person_30_10_0, observe_30_10_0)]

dictionary_person_31_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_31_10_0(person_31_9_0, risk_31_10_0, person_31_10_0):
    return dictionary_person_31_10_0[(person_31_9_0, risk_31_10_0, person_31_10_0)]

dictionary_observe_31_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9614586153297149, ('false', 'false'): 1.0, ('true', 'true'): 0.03854138467028512}
def f_observe_31_10_0(person_31_10_0, observe_31_10_0):
    return dictionary_observe_31_10_0[(person_31_10_0, observe_31_10_0)]

dictionary_person_32_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_32_10_0(person_32_9_0, risk_32_10_0, person_32_10_0):
    return dictionary_person_32_10_0[(person_32_9_0, risk_32_10_0, person_32_10_0)]

dictionary_observe_32_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.5443030729312383, ('false', 'false'): 1.0, ('true', 'true'): 0.45569692706876175}
def f_observe_32_10_0(person_32_10_0, observe_32_10_0):
    return dictionary_observe_32_10_0[(person_32_10_0, observe_32_10_0)]

dictionary_person_33_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_33_10_0(person_33_9_0, risk_33_10_0, person_33_10_0):
    return dictionary_person_33_10_0[(person_33_9_0, risk_33_10_0, person_33_10_0)]

dictionary_observe_33_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.4836980225774894, ('false', 'false'): 1.0, ('true', 'true'): 0.5163019774225106}
def f_observe_33_10_0(person_33_10_0, observe_33_10_0):
    return dictionary_observe_33_10_0[(person_33_10_0, observe_33_10_0)]

dictionary_person_34_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_34_10_0(person_34_9_0, risk_34_10_0, person_34_10_0):
    return dictionary_person_34_10_0[(person_34_9_0, risk_34_10_0, person_34_10_0)]

dictionary_observe_34_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.9488104109051279, ('false', 'false'): 1.0, ('true', 'true'): 0.051189589094872145}
def f_observe_34_10_0(person_34_10_0, observe_34_10_0):
    return dictionary_observe_34_10_0[(person_34_10_0, observe_34_10_0)]

dictionary_person_35_10_0 = {('true', 'true', 'false'): 0.0, ('false', 'false', 'true'): 0.0, ('true', 'true', 'true'): 1.0, ('false', 'true', 'false'): 0.999, ('false', 'false', 'false'): 1.0, ('true', 'false', 'false'): 0.0, ('false', 'true', 'true'): 0.0010000000000000009, ('true', 'false', 'true'): 1.0}
def f_person_35_10_0(person_35_9_0, risk_35_10_0, person_35_10_0):
    return dictionary_person_35_10_0[(person_35_9_0, risk_35_10_0, person_35_10_0)]

dictionary_observe_35_10_0 = {('false', 'true'): 0.0, ('true', 'false'): 0.6745257126152135, ('false', 'false'): 1.0, ('true', 'true'): 0.32547428738478645}
def f_observe_35_10_0(person_35_10_0, observe_35_10_0):
    return dictionary_observe_35_10_0[(person_35_10_0, observe_35_10_0)]

functions = [f_person_0_7_0, f_person_1_7_0, f_person_2_7_0, f_person_3_7_0, f_person_4_7_0, f_person_5_7_0, f_person_6_7_0, f_person_7_7_0, f_person_8_7_0, f_person_9_7_0, f_person_10_7_0, f_person_11_7_0, f_person_12_7_0, f_person_13_7_0, f_person_14_7_0, f_person_15_7_0, f_person_16_7_0, f_person_17_7_0, f_person_18_7_0, f_person_19_7_0, f_person_20_7_0, f_person_21_7_0, f_person_22_7_0, f_person_23_7_0, f_person_24_7_0, f_person_25_7_0, f_person_26_7_0, f_person_27_7_0, f_person_28_7_0, f_person_29_7_0, f_person_30_7_0, f_person_31_7_0, f_person_32_7_0, f_person_33_7_0, f_person_34_7_0, f_person_35_7_0, f_risk_0_8_0, f_risk_1_8_0, f_risk_2_8_0, f_risk_3_8_0, f_risk_4_8_0, f_risk_5_8_0, f_risk_6_8_0, f_risk_7_8_0, f_risk_8_8_0, f_risk_9_8_0, f_risk_10_8_0, f_risk_11_8_0, f_risk_12_8_0, f_risk_13_8_0, f_risk_14_8_0, f_risk_15_8_0, f_risk_16_8_0, f_risk_17_8_0, f_risk_18_8_0, f_risk_19_8_0, f_risk_20_8_0, f_risk_21_8_0, f_risk_22_8_0, f_risk_23_8_0, f_risk_24_8_0, f_risk_25_8_0, f_risk_26_8_0, f_risk_27_8_0, f_risk_28_8_0, f_risk_29_8_0, f_risk_30_8_0, f_risk_31_8_0, f_risk_32_8_0, f_risk_33_8_0, f_risk_34_8_0, f_risk_35_8_0, f_risk_0_9_0, f_risk_1_9_0, f_risk_2_9_0, f_risk_3_9_0, f_risk_4_9_0, f_risk_5_9_0, f_risk_6_9_0, f_risk_7_9_0, f_risk_8_9_0, f_risk_9_9_0, f_risk_10_9_0, f_risk_11_9_0, f_risk_12_9_0, f_risk_13_9_0, f_risk_14_9_0, f_risk_15_9_0, f_risk_16_9_0, f_risk_17_9_0, f_risk_18_9_0, f_risk_19_9_0, f_risk_20_9_0, f_risk_21_9_0, f_risk_22_9_0, f_risk_23_9_0, f_risk_24_9_0, f_risk_25_9_0, f_risk_26_9_0, f_risk_27_9_0, f_risk_28_9_0, f_risk_29_9_0, f_risk_30_9_0, f_risk_31_9_0, f_risk_32_9_0, f_risk_33_9_0, f_risk_34_9_0, f_risk_35_9_0, f_risk_0_10_0, f_risk_1_10_0, f_risk_2_10_0, f_risk_3_10_0, f_risk_4_10_0, f_risk_5_10_0, f_risk_6_10_0, f_risk_7_10_0, f_risk_8_10_0, f_risk_9_10_0, f_risk_10_10_0, f_risk_11_10_0, f_risk_12_10_0, f_risk_13_10_0, f_risk_14_10_0, f_risk_15_10_0, f_risk_16_10_0, f_risk_17_10_0, f_risk_18_10_0, f_risk_19_10_0, f_risk_20_10_0, f_risk_21_10_0, f_risk_22_10_0, f_risk_23_10_0, f_risk_24_10_0, f_risk_25_10_0, f_risk_26_10_0, f_risk_27_10_0, f_risk_28_10_0, f_risk_29_10_0, f_risk_30_10_0, f_risk_31_10_0, f_risk_32_10_0, f_risk_33_10_0, f_risk_34_10_0, f_risk_35_10_0, f_observe_0_7_0, f_observe_1_7_0, f_observe_2_7_0, f_observe_3_7_0, f_observe_4_7_0, f_observe_5_7_0, f_observe_6_7_0, f_observe_7_7_0, f_observe_8_7_0, f_observe_9_7_0, f_observe_10_7_0, f_observe_11_7_0, f_observe_12_7_0, f_observe_13_7_0, f_observe_14_7_0, f_observe_15_7_0, f_observe_16_7_0, f_observe_17_7_0, f_observe_18_7_0, f_observe_19_7_0, f_observe_20_7_0, f_observe_21_7_0, f_observe_22_7_0, f_observe_23_7_0, f_observe_24_7_0, f_observe_25_7_0, f_observe_26_7_0, f_observe_27_7_0, f_observe_28_7_0, f_observe_29_7_0, f_observe_30_7_0, f_observe_31_7_0, f_observe_32_7_0, f_observe_33_7_0, f_observe_34_7_0, f_observe_35_7_0, f_person_0_8_0, f_observe_0_8_0, f_person_1_8_0, f_observe_1_8_0, f_person_2_8_0, f_observe_2_8_0, f_person_3_8_0, f_observe_3_8_0, f_person_4_8_0, f_observe_4_8_0, f_person_5_8_0, f_observe_5_8_0, f_person_6_8_0, f_observe_6_8_0, f_person_7_8_0, f_observe_7_8_0, f_person_8_8_0, f_observe_8_8_0, f_person_9_8_0, f_observe_9_8_0, f_person_10_8_0, f_observe_10_8_0, f_person_11_8_0, f_observe_11_8_0, f_person_12_8_0, f_observe_12_8_0, f_person_13_8_0, f_observe_13_8_0, f_person_14_8_0, f_observe_14_8_0, f_person_15_8_0, f_observe_15_8_0, f_person_16_8_0, f_observe_16_8_0, f_person_17_8_0, f_observe_17_8_0, f_person_18_8_0, f_observe_18_8_0, f_person_19_8_0, f_observe_19_8_0, f_person_20_8_0, f_observe_20_8_0, f_person_21_8_0, f_observe_21_8_0, f_person_22_8_0, f_observe_22_8_0, f_person_23_8_0, f_observe_23_8_0, f_person_24_8_0, f_observe_24_8_0, f_person_25_8_0, f_observe_25_8_0, f_person_26_8_0, f_observe_26_8_0, f_person_27_8_0, f_observe_27_8_0, f_person_28_8_0, f_observe_28_8_0, f_person_29_8_0, f_observe_29_8_0, f_person_30_8_0, f_observe_30_8_0, f_person_31_8_0, f_observe_31_8_0, f_person_32_8_0, f_observe_32_8_0, f_person_33_8_0, f_observe_33_8_0, f_person_34_8_0, f_observe_34_8_0, f_person_35_8_0, f_observe_35_8_0, f_person_0_9_0, f_observe_0_9_0, f_person_1_9_0, f_observe_1_9_0, f_person_2_9_0, f_observe_2_9_0, f_person_3_9_0, f_observe_3_9_0, f_person_4_9_0, f_observe_4_9_0, f_person_5_9_0, f_observe_5_9_0, f_person_6_9_0, f_observe_6_9_0, f_person_7_9_0, f_observe_7_9_0, f_person_8_9_0, f_observe_8_9_0, f_person_9_9_0, f_observe_9_9_0, f_person_10_9_0, f_observe_10_9_0, f_person_11_9_0, f_observe_11_9_0, f_person_12_9_0, f_observe_12_9_0, f_person_13_9_0, f_observe_13_9_0, f_person_14_9_0, f_observe_14_9_0, f_person_15_9_0, f_observe_15_9_0, f_person_16_9_0, f_observe_16_9_0, f_person_17_9_0, f_observe_17_9_0, f_person_18_9_0, f_observe_18_9_0, f_person_19_9_0, f_observe_19_9_0, f_person_20_9_0, f_observe_20_9_0, f_person_21_9_0, f_observe_21_9_0, f_person_22_9_0, f_observe_22_9_0, f_person_23_9_0, f_observe_23_9_0, f_person_24_9_0, f_observe_24_9_0, f_person_25_9_0, f_observe_25_9_0, f_person_26_9_0, f_observe_26_9_0, f_person_27_9_0, f_observe_27_9_0, f_person_28_9_0, f_observe_28_9_0, f_person_29_9_0, f_observe_29_9_0, f_person_30_9_0, f_observe_30_9_0, f_person_31_9_0, f_observe_31_9_0, f_person_32_9_0, f_observe_32_9_0, f_person_33_9_0, f_observe_33_9_0, f_person_34_9_0, f_observe_34_9_0, f_person_35_9_0, f_observe_35_9_0, f_person_0_10_0, f_observe_0_10_0, f_person_1_10_0, f_observe_1_10_0, f_person_2_10_0, f_observe_2_10_0, f_person_3_10_0, f_observe_3_10_0, f_person_4_10_0, f_observe_4_10_0, f_person_5_10_0, f_observe_5_10_0, f_person_6_10_0, f_observe_6_10_0, f_person_7_10_0, f_observe_7_10_0, f_person_8_10_0, f_observe_8_10_0, f_person_9_10_0, f_observe_9_10_0, f_person_10_10_0, f_observe_10_10_0, f_person_11_10_0, f_observe_11_10_0, f_person_12_10_0, f_observe_12_10_0, f_person_13_10_0, f_observe_13_10_0, f_person_14_10_0, f_observe_14_10_0, f_person_15_10_0, f_observe_15_10_0, f_person_16_10_0, f_observe_16_10_0, f_person_17_10_0, f_observe_17_10_0, f_person_18_10_0, f_observe_18_10_0, f_person_19_10_0, f_observe_19_10_0, f_person_20_10_0, f_observe_20_10_0, f_person_21_10_0, f_observe_21_10_0, f_person_22_10_0, f_observe_22_10_0, f_person_23_10_0, f_observe_23_10_0, f_person_24_10_0, f_observe_24_10_0, f_person_25_10_0, f_observe_25_10_0, f_person_26_10_0, f_observe_26_10_0, f_person_27_10_0, f_observe_27_10_0, f_person_28_10_0, f_observe_28_10_0, f_person_29_10_0, f_observe_29_10_0, f_person_30_10_0, f_observe_30_10_0, f_person_31_10_0, f_observe_31_10_0, f_person_32_10_0, f_observe_32_10_0, f_person_33_10_0, f_observe_33_10_0, f_person_34_10_0, f_observe_34_10_0, f_person_35_10_0, f_observe_35_10_0]
domains_dict = {'person_33_7_0': ['false', 'true'], 'person_4_7_0': ['false', 'true'], 'risk_13_8_0': ['false', 'true'], 'risk_6_8_0': ['false', 'true'], 'person_31_7_0': ['false', 'true'], 'risk_2_9_0': ['false', 'true'], 'person_17_8_0': ['false', 'true'], 'risk_10_9_0': ['false', 'true'], 'observe_23_9_0': ['false', 'true'], 'risk_13_10_0': ['false', 'true'], 'observe_0_10_0': ['false', 'true'], 'person_4_9_0': ['false', 'true'], 'observe_3_10_0': ['false', 'true'], 'person_34_8_0': ['false', 'true'], 'person_31_9_0': ['false', 'true'], 'person_29_10_0': ['false', 'true'], 'person_17_10_0': ['false', 'true'], 'risk_5_10_0': ['false', 'true'], 'risk_23_9_0': ['false', 'true'], 'person_33_10_0': ['false', 'true'], 'person_32_8_0': ['false', 'true'], 'risk_31_10_0': ['false', 'true'], 'person_0_8_0': ['false', 'true'], 'person_9_10_0': ['false', 'true'], 'observe_21_10_0': ['false', 'true'], 'person_27_7_0': ['false', 'true'], 'risk_12_10_0': ['false', 'true'], 'risk_27_10_0': ['false', 'true'], 'risk_26_8_0': ['false', 'true'], 'observe_30_8_0': ['false', 'true'], 'risk_21_9_0': ['false', 'true'], 'observe_17_10_0': ['false', 'true'], 'person_2_8_0': ['false', 'true'], 'observe_4_10_0': ['false', 'true'], 'person_31_10_0': ['false', 'true'], 'person_5_10_0': ['false', 'true'], 'person_18_10_0': ['false', 'true'], 'observe_7_8_0': ['false', 'true'], 'person_25_9_0': ['false', 'true'], 'person_29_9_0': ['false', 'true'], 'person_16_9_0': ['false', 'true'], 'observe_15_8_0': ['false', 'true'], 'risk_28_9_0': ['false', 'true'], 'observe_35_9_0': ['false', 'true'], 'observe_35_7_0': ['false', 'true'], 'risk_0_9_0': ['false', 'true'], 'observe_25_8_0': ['false', 'true'], 'person_7_9_0': ['false', 'true'], 'person_27_8_0': ['false', 'true'], 'person_10_8_0': ['false', 'true'], 'risk_18_9_0': ['false', 'true'], 'person_29_7_0': ['false', 'true'], 'person_1_10_0': ['false', 'true'], 'observe_18_8_0': ['false', 'true'], 'person_26_9_0': ['false', 'true'], 'risk_34_8_0': ['false', 'true'], 'risk_29_8_0': ['false', 'true'], 'risk_24_9_0': ['false', 'true'], 'person_22_10_0': ['false', 'true'], 'observe_25_7_0': ['false', 'true'], 'person_24_9_0': ['false', 'true'], 'observe_1_8_0': ['false', 'true'], 'person_21_8_0': ['false', 'true'], 'risk_11_9_0': ['false', 'true'], 'observe_21_8_0': ['false', 'true'], 'observe_23_10_0': ['false', 'true'], 'observe_27_7_0': ['false', 'true'], 'person_15_8_0': ['false', 'true'], 'risk_8_8_0': ['false', 'true'], 'person_25_10_0': ['false', 'true'], 'risk_34_10_0': ['false', 'true'], 'observe_13_10_0': ['false', 'true'], 'observe_1_10_0': ['false', 'true'], 'person_7_10_0': ['false', 'true'], 'observe_17_9_0': ['false', 'true'], 'person_24_7_0': ['false', 'true'], 'observe_35_10_0': ['false', 'true'], 'person_7_7_0': ['false', 'true'], 'person_11_9_0': ['false', 'true'], 'risk_1_10_0': ['false', 'true'], 'observe_23_8_0': ['false', 'true'], 'observe_18_7_0': ['false', 'true'], 'person_17_9_0': ['false', 'true'], 'observe_27_9_0': ['false', 'true'], 'risk_2_8_0': ['false', 'true'], 'risk_3_9_0': ['false', 'true'], 'person_14_10_0': ['false', 'true'], 'person_34_9_0': ['false', 'true'], 'risk_23_8_0': ['false', 'true'], 'person_12_10_0': ['false', 'true'], 'person_11_7_0': ['false', 'true'], 'observe_7_10_0': ['false', 'true'], 'risk_13_9_0': ['false', 'true'], 'observe_32_10_0': ['false', 'true'], 'person_32_7_0': ['false', 'true'], 'person_3_10_0': ['false', 'true'], 'person_0_9_0': ['false', 'true'], 'person_32_9_0': ['false', 'true'], 'person_14_8_0': ['false', 'true'], 'person_0_7_0': ['false', 'true'], 'observe_23_7_0': ['false', 'true'], 'observe_5_10_0': ['false', 'true'], 'observe_33_10_0': ['false', 'true'], 'risk_21_8_0': ['false', 'true'], 'risk_7_10_0': ['false', 'true'], 'observe_9_8_0': ['false', 'true'], 'person_3_8_0': ['false', 'true'], 'person_8_9_0': ['false', 'true'], 'observe_32_7_0': ['false', 'true'], 'observe_32_9_0': ['false', 'true'], 'risk_22_9_0': ['false', 'true'], 'person_6_7_0': ['false', 'true'], 'risk_28_8_0': ['false', 'true'], 'person_11_10_0': ['false', 'true'], 'observe_25_9_0': ['false', 'true'], 'person_7_8_0': ['false', 'true'], 'risk_14_10_0': ['false', 'true'], 'person_20_8_0': ['false', 'true'], 'person_3_7_0': ['false', 'true'], 'risk_18_8_0': ['false', 'true'], 'risk_30_10_0': ['false', 'true'], 'person_14_7_0': ['false', 'true'], 'person_1_7_0': ['false', 'true'], 'observe_1_7_0': ['false', 'true'], 'observe_34_10_0': ['false', 'true'], 'observe_16_9_0': ['false', 'true'], 'observe_11_9_0': ['false', 'true'], 'risk_34_9_0': ['false', 'true'], 'risk_29_9_0': ['false', 'true'], 'observe_16_7_0': ['false', 'true'], 'person_19_9_0': ['false', 'true'], 'person_20_7_0': ['false', 'true'], 'observe_0_8_0': ['false', 'true'], 'person_5_8_0': ['false', 'true'], 'person_24_8_0': ['false', 'true'], 'risk_8_9_0': ['false', 'true'], 'person_22_7_0': ['false', 'true'], 'risk_11_8_0': ['false', 'true'], 'person_1_9_0': ['false', 'true'], 'risk_10_10_0': ['false', 'true'], 'observe_34_9_0': ['false', 'true'], 'observe_13_8_0': ['false', 'true'], 'risk_31_8_0': ['false', 'true'], 'person_6_9_0': ['false', 'true'], 'risk_2_10_0': ['false', 'true'], 'observe_2_8_0': ['false', 'true'], 'risk_19_8_0': ['false', 'true'], 'person_26_8_0': ['false', 'true'], 'person_11_8_0': ['false', 'true'], 'person_22_9_0': ['false', 'true'], 'observe_27_8_0': ['false', 'true'], 'risk_32_10_0': ['false', 'true'], 'risk_3_8_0': ['false', 'true'], 'observe_26_9_0': ['false', 'true'], 'risk_3_10_0': ['false', 'true'], 'observe_34_7_0': ['false', 'true'], 'observe_25_10_0': ['false', 'true'], 'person_27_10_0': ['false', 'true'], 'observe_26_7_0': ['false', 'true'], 'risk_8_10_0': ['false', 'true'], 'observe_1_9_0': ['false', 'true'], 'observe_29_10_0': ['false', 'true'], 'risk_17_8_0': ['false', 'true'], 'person_32_10_0': ['false', 'true'], 'observe_28_9_0': ['false', 'true'], 'person_5_7_0': ['false', 'true'], 'risk_25_8_0': ['false', 'true'], 'risk_33_9_0': ['false', 'true'], 'risk_23_10_0': ['false', 'true'], 'person_8_7_0': ['false', 'true'], 'person_26_7_0': ['false', 'true'], 'person_14_9_0': ['false', 'true'], 'observe_34_8_0': ['false', 'true'], 'observe_2_7_0': ['false', 'true'], 'person_6_10_0': ['false', 'true'], 'observe_9_9_0': ['false', 'true'], 'risk_22_10_0': ['false', 'true'], 'person_3_9_0': ['false', 'true'], 'person_8_8_0': ['false', 'true'], 'observe_32_8_0': ['false', 'true'], 'observe_33_9_0': ['false', 'true'], 'risk_22_8_0': ['false', 'true'], 'person_20_9_0': ['false', 'true'], 'person_6_8_0': ['false', 'true'], 'observe_10_7_0': ['false', 'true'], 'observe_4_9_0': ['false', 'true'], 'risk_4_10_0': ['false', 'true'], 'risk_20_9_0': ['false', 'true'], 'person_23_10_0': ['false', 'true'], 'observe_11_8_0': ['false', 'true'], 'observe_33_7_0': ['false', 'true'], 'observe_9_7_0': ['false', 'true'], 'observe_16_8_0': ['false', 'true'], 'person_28_10_0': ['false', 'true'], 'observe_31_7_0': ['false', 'true'], 'person_19_8_0': ['false', 'true'], 'risk_5_8_0': ['false', 'true'], 'observe_0_9_0': ['false', 'true'], 'person_28_8_0': ['false', 'true'], 'person_1_8_0': ['false', 'true'], 'risk_9_8_0': ['false', 'true'], 'observe_30_10_0': ['false', 'true'], 'person_12_8_0': ['false', 'true'], 'risk_31_9_0': ['false', 'true'], 'observe_13_9_0': ['false', 'true'], 'risk_27_8_0': ['false', 'true'], 'observe_31_8_0': ['false', 'true'], 'person_25_7_0': ['false', 'true'], 'person_19_7_0': ['false', 'true'], 'risk_19_9_0': ['false', 'true'], 'observe_13_7_0': ['false', 'true'], 'observe_9_10_0': ['false', 'true'], 'observe_2_10_0': ['false', 'true'], 'observe_2_9_0': ['false', 'true'], 'risk_7_9_0': ['false', 'true'], 'observe_6_8_0': ['false', 'true'], 'observe_26_8_0': ['false', 'true'], 'person_22_8_0': ['false', 'true'], 'risk_30_8_0': ['false', 'true'], 'person_23_9_0': ['false', 'true'], 'observe_11_7_0': ['false', 'true'], 'observe_15_10_0': ['false', 'true'], 'observe_10_8_0': ['false', 'true'], 'observe_8_7_0': ['false', 'true'], 'person_23_7_0': ['false', 'true'], 'risk_16_8_0': ['false', 'true'], 'observe_8_9_0': ['false', 'true'], 'observe_0_7_0': ['false', 'true'], 'risk_6_10_0': ['false', 'true'], 'risk_1_9_0': ['false', 'true'], 'observe_28_8_0': ['false', 'true'], 'observe_20_10_0': ['false', 'true'], 'observe_6_10_0': ['false', 'true'], 'risk_20_10_0': ['false', 'true'], 'risk_33_8_0': ['false', 'true'], 'risk_14_8_0': ['false', 'true'], 'person_18_8_0': ['false', 'true'], 'person_24_10_0': ['false', 'true'], 'risk_24_10_0': ['false', 'true'], 'observe_12_10_0': ['false', 'true'], 'risk_30_9_0': ['false', 'true'], 'risk_17_9_0': ['false', 'true'], 'observe_3_7_0': ['false', 'true'], 'risk_25_9_0': ['false', 'true'], 'person_9_8_0': ['false', 'true'], 'person_35_8_0': ['false', 'true'], 'observe_28_7_0': ['false', 'true'], 'person_30_8_0': ['false', 'true'], 'observe_33_8_0': ['false', 'true'], 'person_35_10_0': ['false', 'true'], 'risk_35_10_0': ['false', 'true'], 'person_17_7_0': ['false', 'true'], 'observe_3_9_0': ['false', 'true'], 'observe_4_8_0': ['false', 'true'], 'person_33_9_0': ['false', 'true'], 'person_4_10_0': ['false', 'true'], 'observe_18_9_0': ['false', 'true'], 'observe_19_9_0': ['false', 'true'], 'person_12_7_0': ['false', 'true'], 'risk_16_9_0': ['false', 'true'], 'person_28_9_0': ['false', 'true'], 'observe_14_7_0': ['false', 'true'], 'observe_4_7_0': ['false', 'true'], 'observe_20_8_0': ['false', 'true'], 'person_26_10_0': ['false', 'true'], 'risk_5_9_0': ['false', 'true'], 'observe_6_7_0': ['false', 'true'], 'observe_14_9_0': ['false', 'true'], 'person_35_7_0': ['false', 'true'], 'risk_9_9_0': ['false', 'true'], 'person_12_9_0': ['false', 'true'], 'person_8_10_0': ['false', 'true'], 'risk_27_9_0': ['false', 'true'], 'observe_31_9_0': ['false', 'true'], 'observe_5_8_0': ['false', 'true'], 'person_20_10_0': ['false', 'true'], 'risk_7_8_0': ['false', 'true'], 'observe_24_10_0': ['false', 'true'], 'risk_12_9_0': ['false', 'true'], 'observe_22_9_0': ['false', 'true'], 'observe_29_8_0': ['false', 'true'], 'person_23_8_0': ['false', 'true'], 'observe_6_9_0': ['false', 'true'], 'person_16_10_0': ['false', 'true'], 'observe_10_9_0': ['false', 'true'], 'observe_19_10_0': ['false', 'true'], 'risk_35_8_0': ['false', 'true'], 'risk_16_10_0': ['false', 'true'], 'person_28_7_0': ['false', 'true'], 'risk_28_10_0': ['false', 'true'], 'observe_31_10_0': ['false', 'true'], 'observe_24_7_0': ['false', 'true'], 'risk_4_9_0': ['false', 'true'], 'risk_15_10_0': ['false', 'true'], 'risk_1_8_0': ['false', 'true'], 'observe_24_9_0': ['false', 'true'], 'person_13_9_0': ['false', 'true'], 'observe_12_9_0': ['false', 'true'], 'observe_18_10_0': ['false', 'true'], 'person_13_7_0': ['false', 'true'], 'risk_32_8_0': ['false', 'true'], 'risk_6_9_0': ['false', 'true'], 'person_18_7_0': ['false', 'true'], 'risk_14_9_0': ['false', 'true'], 'observe_19_7_0': ['false', 'true'], 'person_13_10_0': ['false', 'true'], 'person_18_9_0': ['false', 'true'], 'risk_10_8_0': ['false', 'true'], 'observe_12_7_0': ['false', 'true'], 'risk_0_10_0': ['false', 'true'], 'observe_22_10_0': ['false', 'true'], 'risk_19_10_0': ['false', 'true'], 'observe_8_8_0': ['false', 'true'], 'person_35_9_0': ['false', 'true'], 'risk_26_10_0': ['false', 'true'], 'observe_10_10_0': ['false', 'true'], 'person_9_9_0': ['false', 'true'], 'person_31_8_0': ['false', 'true'], 'observe_16_10_0': ['false', 'true'], 'person_9_7_0': ['false', 'true'], 'person_30_9_0': ['false', 'true'], 'risk_33_10_0': ['false', 'true'], 'person_19_10_0': ['false', 'true'], 'person_30_7_0': ['false', 'true'], 'person_34_10_0': ['false', 'true'], 'person_15_10_0': ['false', 'true'], 'observe_28_10_0': ['false', 'true'], 'person_4_8_0': ['false', 'true'], 'observe_22_7_0': ['false', 'true'], 'observe_19_8_0': ['false', 'true'], 'observe_12_8_0': ['false', 'true'], 'risk_26_9_0': ['false', 'true'], 'observe_30_9_0': ['false', 'true'], 'observe_30_7_0': ['false', 'true'], 'observe_20_7_0': ['false', 'true'], 'person_0_10_0': ['false', 'true'], 'observe_3_8_0': ['false', 'true'], 'person_21_10_0': ['false', 'true'], 'observe_7_9_0': ['false', 'true'], 'person_25_8_0': ['false', 'true'], 'person_29_8_0': ['false', 'true'], 'risk_9_10_0': ['false', 'true'], 'observe_20_9_0': ['false', 'true'], 'person_16_8_0': ['false', 'true'], 'observe_7_7_0': ['false', 'true'], 'person_2_10_0': ['false', 'true'], 'observe_14_8_0': ['false', 'true'], 'observe_35_8_0': ['false', 'true'], 'observe_15_9_0': ['false', 'true'], 'risk_17_10_0': ['false', 'true'], 'observe_29_7_0': ['false', 'true'], 'risk_15_9_0': ['false', 'true'], 'observe_27_10_0': ['false', 'true'], 'risk_32_9_0': ['false', 'true'], 'risk_12_8_0': ['false', 'true'], 'risk_15_8_0': ['false', 'true'], 'observe_22_8_0': ['false', 'true'], 'risk_0_8_0': ['false', 'true'], 'observe_29_9_0': ['false', 'true'], 'observe_11_10_0': ['false', 'true'], 'person_10_10_0': ['false', 'true'], 'person_27_9_0': ['false', 'true'], 'person_10_9_0': ['false', 'true'], 'risk_35_9_0': ['false', 'true'], 'observe_14_10_0': ['false', 'true'], 'observe_26_10_0': ['false', 'true'], 'observe_15_7_0': ['false', 'true'], 'person_2_7_0': ['false', 'true'], 'person_15_7_0': ['false', 'true'], 'risk_29_10_0': ['false', 'true'], 'person_2_9_0': ['false', 'true'], 'observe_17_7_0': ['false', 'true'], 'risk_24_8_0': ['false', 'true'], 'person_21_7_0': ['false', 'true'], 'risk_25_10_0': ['false', 'true'], 'observe_21_9_0': ['false', 'true'], 'observe_8_10_0': ['false', 'true'], 'person_33_8_0': ['false', 'true'], 'risk_4_8_0': ['false', 'true'], 'observe_24_8_0': ['false', 'true'], 'person_15_9_0': ['false', 'true'], 'risk_21_10_0': ['false', 'true'], 'person_21_9_0': ['false', 'true'], 'person_5_9_0': ['false', 'true'], 'person_10_7_0': ['false', 'true'], 'person_34_7_0': ['false', 'true'], 'person_13_8_0': ['false', 'true'], 'person_30_10_0': ['false', 'true'], 'observe_5_7_0': ['false', 'true'], 'observe_17_8_0': ['false', 'true'], 'person_16_7_0': ['false', 'true'], 'risk_20_8_0': ['false', 'true'], 'observe_5_9_0': ['false', 'true'], 'risk_18_10_0': ['false', 'true'], 'observe_21_7_0': ['false', 'true'], 'risk_11_10_0': ['false', 'true']}

def create_graph():
    g = build_graph(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/d4_addtional/d4_new17/infection0'
    return g

def create_bbn():
    g = build_bbn(
        *functions,
        domains = domains_dict)
    g.name = '/home/yd/infection/d4_addtional/d4_new17/infection0'
    return g

