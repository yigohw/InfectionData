.. Bayesian documentation master file, created by
   sphinx-quickstart on Mon Jul  8 22:49:16 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Bayesian Belief Network Python Tutorial
=======================================

Contents:

.. toctree::
   :maxdepth: 2

   tutorial


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
